# WealthDash v3 — Step-by-Step Implementation Guide

## 📁 Files You Got

| File | Size | Purpose |
|------|------|---------|
| `wealthdash_v3.html` | 258KB | Complete Dev Dashboard (open in browser) |
| `debug_runner.php` | 15KB | Place at `debug/runner.php` in your project |

---

## 🔧 Common Mistakes Jo Fix Kiye Gaye

### 1. `const` Duplicate Declaration Error
**Problem:** `NEW_PHASES_EXT`, `ROADMAP`, `AI_PROMPTS` do baar declare ho rahe the  
**Fix:** v3 mein sab deduplicated hain. Ek hi declaration hai.

### 2. `showPrompt()` Sirf PHASES Search Karta Tha
**Problem:** NEW_PHASES aur NEW_PHASES_EXT ke tasks ka prompt button kaam nahi karta tha  
**Fix:** Ab `ALL_PHASES = [...PHASES, ...NEW_PHASES, ...NEW_PHASES_EXT]` search karta hai

### 3. Task Ka Own `prompt` Field Ignore Hota Tha  
**Problem:** Kuch tasks mein manually likha prompt tha, lekin woh use nahi hota tha  
**Fix:** Ab `t.prompt` field pehle check hota hai. Custom prompt hai to wahi use karo.

### 4. Category Filter Aur Overview Tab Missing Tha (master_v2 mein)
**Fix:** Dono ab v3 mein hain — Overview tab + Category progress bars + Phase rows

### 5. Health Check Duplicate Code
**Problem:** Do alag `hcGetBase()`, `hcRenderGrid()` functions the  
**Fix:** Only one set remains, properly scoped

---

## 🚀 Implementation Steps

### Step 1: v3 Dashboard Open Karo
```
wealthdash_v3.html → browser mein open karo
Chrome/Firefox mein file:// se bhi kaam karta hai
```

### Step 2: Debug Runner Install Karo
```
debug_runner.php → copy karo:
C:/xampp/htdocs/wealthdash/debug/runner.php
```
XAMPP mein open karo:
```
http://localhost/wealthdash/debug/runner.php
```

### Step 3: Health Check Karo
v3 dashboard → `🩺 Health Check` tab → `▶ Run All Checks`

Ya seedha:
```
http://localhost/wealthdash/debug/runner.php?format=html
```

---

## 🤖 Claude Ko Kya Prompt Dena Hai — Templates

### Template 1: Bug Fix
```
Main WealthDash bana raha hoon — Core PHP + MySQL + XAMPP + Vanilla JS + Chart.js

File structure:
- api/router.php (main API entry, action= parameter)
- templates/pages/ (UI pages)
- public/js/ (mf.js, app.js, stocks.js, nps.js)
- public/css/app.css
- includes/ (auth.php, helpers.php, holding_calculator.php)
- config/database.php (getDB() returns PDO)
- Auth: session_start() + $_SESSION['user_id'] check

BUG: [bug ka naam]
File: [file path]
Expected: [kya hona chahiye]
Actual: [kya ho raha hai]

Code:
[relevant code paste karo]

Fix do sirf changed lines ke saath, poori file mat dena.
```

### Template 2: New Feature
```
WealthDash mein new feature add karna hai.

Stack: Core PHP (no framework), MySQL, XAMPP, Vanilla JS, Chart.js
API pattern: api/router.php?action=ACTION_NAME
DB helper: getDB() → PDO (config/database.php)
Auth: session_start() + $_SESSION['user_id']
Portfolio ID: usually portfolio_id=1 (single user)

Feature: [feature ka naam]

Kya banana hai:
- [point 1]
- [point 2]

Related files:
- [existing file 1]
- [existing file 2]

DB tables needed: [table names]

Please do:
1. DB migration SQL (database/migrations/NNN_name.sql)
2. API file (api/module/action.php) + router.php mein add karne ka code
3. Vanilla JS (NO jQuery, NO frameworks)
4. HTML/PHP template changes
5. Test checklist
```

### Template 3: AI Feature (Claude API)
```
WealthDash mein Claude AI feature add karna hai.

Context:
- PHP backend, MySQL, XAMPP local
- User portfolio data: MF holdings, NPS, Stocks, FD, Post Office, Tax data
- includes/ai_engine.php — Claude API wrapper use karo

Feature: [AI feature naam]

User input: [kya input milega]
AI output: [kya response chahiye — text/JSON/structured]
Data to send: [kaunsa portfolio data Claude ko milega]

Please do:
1. includes/ai_engine.php — claude-sonnet-4-20250514 model use karo
2. API endpoint — caching with DB (weekly refresh)
3. Frontend JS — loading state + error fallback
4. Rate limit + error handling (429, 500)
5. Response caching: DB mein store karo, daily/weekly refresh
```

### Template 4: Debug + Fix (Report ke saath)
```
WealthDash debug report attach kar raha hoon. Issues fix karo:

[debug_runner.php ka output yahan paste karo]

Jo galat ho raha hai:
- [issue 1]
- [issue 2]

Priority: sabse critical issue pehle fix karo.
Har fix ke liye exact file + line number batao.
```

### Template 5: DB Migration
```
WealthDash ke liye DB migration chahiye (MySQL 8.0 XAMPP).

Existing migrations: database/migrations/001 to [N]
Next number: [N+1]

Mujhe chahiye: [kya add karna hai — table/column/index]

Purpose: [ye data kisliye store karna hai]

Please do:
1. Forward migration SQL (CREATE TABLE / ALTER TABLE)
2. Rollback SQL (DROP TABLE / DROP COLUMN) 
3. PHP code sample jo is table ko use karega
4. Index suggestions
5. Sample INSERT data for testing
```

---

## 📋 Per-Task Prompts (v3 mein built-in hain)

Har task ke paas **`🤖 Get Code from Claude`** button hai.  
Click karo → Full prompt auto-generate hoga → Copy karo → Claude ko do.

Tasks jinke paas custom `prompt` field hai woh aur bhi better prompts dete hain — specially Phase 40-43 ke tasks.

---

## 🗂️ Phase Implementation Order (Recommended)

### Priority 0 — Pehle Ye Karo (Critical Fixes)
```
Phase 1: Bug Fixes (t01-t06)
  ├── t01: 1D Change fix in renderHoldings
  ├── t02: Sort menu positioning fix
  ├── t05: Admin NAV auto-update
  └── t06: Peak NAV progress bar fix

Phase 3: Post Office (t14-t16) — calculation bugs
  ├── t14: TD 4 tenures fix
  ├── t15: MIS/SCSS maturity fix
  └── t16: KVP tenure fix
```

### Priority 1 — Data Foundation Banao
```
Phase 25: NAV Data Pipeline
  ├── t160: nav_history populate (MFAPI.in se)
  ├── t161: returns_1y/3y/5y calculator cron
  ├── t162: daily cron mein nav_history insert
  └── t163: MFAPI proxy/cache

Phase 31: Full NAV History Download
  ├── t191: nav_download_progress seed
  ├── t192: parallel downloader processor
  └── t193: status dashboard
```

### Priority 2 — Screener Features
```
Phase 26: Screener Level 3
  ├── t164: Sharpe Ratio
  ├── t165: Sortino Ratio
  ├── t166: Max Drawdown
  └── t167: Category average comparison

Phase 40: Groww Features
  ├── tg01: Goal-based recommendations
  ├── tg02: Consistency Score
  └── tg04: SIP Historical Backtest
```

### Priority 3 — Advanced Features
```
Phase 41: Screener Pro
Phase 42: Portfolio X-Ray
Phase 43: PrimeInvestor Research
Phase 15-23: Holdings analytics, behavioral, integrations
```

---

## ✅ Feature Verification Checklist (Har Feature Ke Baad)

```
□ DB migration run kiya + SHOW TABLES verify kiya
□ PHP -l se syntax check clean
□ API Postman/browser se test kiya (200 + valid JSON)
□ Frontend data display ho raha hai
□ Loading state dikhta hai
□ Error state handle ho raha hai
□ Empty state handle ho raha hai
□ Mobile responsive check kiya
□ Session auth check API mein hai
□ SQL prepared statements use kiye (no string concat)
```

---

## 🩺 Health Check System kaise use karein

### Debug Runner PHP File:
Place: `C:/xampp/htdocs/wealthdash/debug/runner.php`

### URLs:
```
# Full HTML report
http://localhost/wealthdash/debug/runner.php?format=html

# JSON output (for programmatic use)
http://localhost/wealthdash/debug/runner.php?format=json

# Download TXT report (Claude ko dene ke liye)
http://localhost/wealthdash/debug/runner.php?format=txt

# Specific suites only
http://localhost/wealthdash/debug/runner.php?suite=db,api
http://localhost/wealthdash/debug/runner.php?suite=files
http://localhost/wealthdash/debug/runner.php?suite=config,cron
```

### Available Suites:
| Suite | Checks |
|-------|--------|
| `config` | .env file, PHP version, .htaccess |
| `db` | DB connection, all tables, data freshness, row counts |
| `files` | PHP syntax lint on all files, JS/CSS size |
| `api` | Live HTTP test on all API endpoints |
| `ui` | All page templates — load + PHP syntax |
| `cron` | Cron files exist + syntax clean |
| `folders` | Complete folder structure deep scan |

### Claude Ko Debug Report Kaise Do:
1. `http://localhost/wealthdash/debug/runner.php?format=txt` → file download hoga
2. Claude conversation mein paste karo
3. Use Template 4 (Debug + Fix) from above

---

## 🆕 Naye Features Reference Sites Se

| Platform | Feature | WealthDash Phase |
|----------|---------|-----------------|
| Groww | Goal-based fund recommendations | Phase 40 |
| Tickertape | Preset screens, Momentum score | Phase 41 |
| Screener.in | Custom screens, P/E filter | Phase 41 |
| Morningstar | Portfolio X-Ray, Style Box | Phase 42 |
| PrimeInvestor | Quality Score, Research Notes | Phase 43 |
| ValueResearch | Consistency score, Rolling returns | Phase 14B |
| Dhan | NFO deep analysis | Phase 41 |
| Fundoo | Fund family comparison | Phase 43 |

---

*WealthDash v3 — Generated April 2026*
