<?php
/**
 * WealthDash — debug/runner.php
 * Complete File & System Health Checker
 * Place at: C:/xampp/htdocs/wealthdash/debug/runner.php
 */

// ── Security: Only from localhost ─────────────────────────────
$allowed = ['127.0.0.1', '::1', 'localhost'];
if (!in_array($_SERVER['REMOTE_ADDR'], $allowed)) {
    http_response_code(403);
    die('Access denied. localhost only.');
}

define('WD_ROOT', dirname(__DIR__)); // /xampp/htdocs/wealthdash
define('START_TIME', microtime(true));

$format = $_GET['format'] ?? 'html'; // html | json | txt
$suite  = $_GET['suite']  ?? 'all';  // db,files,ui,api,cron,config | all

// ── Result store ──────────────────────────────────────────────
$results = [];
$stats   = ['pass' => 0, 'fail' => 0, 'warn' => 0];

function check($section, $label, $status, $detail = '', $fix = '') {
    global $results, $stats;
    $results[] = compact('section', 'label', 'status', 'detail', 'fix');
    if ($status === 'pass') $stats['pass']++;
    elseif ($status === 'fail') $stats['fail']++;
    else $stats['warn']++;
}

function runSuite($name, $fn) {
    global $suite;
    if ($suite === 'all' || str_contains($suite, $name)) $fn();
}

// ─────────────────────────────────────────────────────────────
// SUITE 1: CONFIG & ENV
// ─────────────────────────────────────────────────────────────
runSuite('config', function() {
    $envFile = WD_ROOT . '/.env';
    if (file_exists($envFile)) {
        check('Config', '.env file exists', 'pass');
        $env = parse_ini_file($envFile);
        $keys = ['DB_HOST','DB_NAME','DB_USER','DB_PASS'];
        foreach ($keys as $k) {
            if (!empty($env[$k])) check('Config', "ENV: $k set", 'pass');
            else check('Config', "ENV: $k missing", 'fail', "$k not set in .env", "Add $k=value to .env");
        }
        if (!empty($env['ANTHROPIC_API_KEY']))
            check('Config', 'ANTHROPIC_API_KEY set', 'pass');
        else
            check('Config', 'ANTHROPIC_API_KEY missing', 'warn', 'AI features will not work', 'Add ANTHROPIC_API_KEY to .env');
    } else {
        check('Config', '.env file missing', 'fail', 'No .env file found at ' . $envFile, 'Create .env from .env.example');
    }

    // .htaccess check
    $htaccess = WD_ROOT . '/.htaccess';
    if (file_exists($htaccess)) check('Config', '.htaccess present', 'pass');
    else check('Config', '.htaccess missing', 'warn', 'Direct file access may be possible', 'Create .htaccess with deny rules');

    // PHP version
    $ver = phpversion();
    if (version_compare($ver, '8.0') >= 0)
        check('Config', "PHP $ver ✅", 'pass');
    else
        check('Config', "PHP $ver — Upgrade needed", 'warn', 'PHP 8.0+ recommended', 'Upgrade PHP in XAMPP');
});

// ─────────────────────────────────────────────────────────────
// SUITE 2: DATABASE
// ─────────────────────────────────────────────────────────────
runSuite('db', function() {
    $cfgFile = WD_ROOT . '/config/database.php';
    if (!file_exists($cfgFile)) {
        check('Database', 'config/database.php missing', 'fail', '', 'Create config/database.php');
        return;
    }

    try {
        require_once $cfgFile;
        $db = getDB();
        check('Database', 'DB Connection', 'pass');

        // Required tables
        $tables = [
            'users','portfolios','funds','nav_history','mf_holdings','mf_transactions',
            'sip_schedules','nps_schemes','nps_holdings','nps_nav_history',
            'stock_master','stock_holdings','fd_accounts','savings_accounts',
            'savings_interest','bank_accounts','epf_accounts','insurance_policies',
            'loan_accounts','po_schemes','goal_buckets','investment_goals',
            'goal_contributions','mf_peak_progress','nav_download_progress',
            'app_settings','audit_log','notifications','price_alerts',
            'fund_watchlist','fund_ratings',
        ];

        $existing = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tables as $t) {
            if (in_array($t, $existing))
                check('Database', "Table: $t", 'pass');
            else
                check('Database', "Table: $t missing", 'warn', "Table $t does not exist", "Run relevant migration in database/migrations/");
        }

        // Data freshness
        try {
            $row = $db->query("SELECT MAX(nav_date) as latest FROM nav_history")->fetch();
            if ($row && $row['latest']) {
                $days = (time() - strtotime($row['latest'])) / 86400;
                if ($days <= 2)
                    check('Database', "NAV data fresh (last: {$row['latest']})", 'pass');
                elseif ($days <= 7)
                    check('Database', "NAV data {$days}d old", 'warn', "Last NAV: {$row['latest']}", 'Run cron/update_nav_daily.php');
                else
                    check('Database', "NAV data stale ({$days}d old)", 'fail', "Last NAV: {$row['latest']}", 'Run: php cron/update_nav_daily.php');
            }
        } catch(Exception $e) { check('Database', 'NAV freshness check', 'warn', $e->getMessage()); }

        // Row counts
        $countChecks = [
            ['funds', 100, 'Funds table low — run AMFI import'],
            ['nav_history', 1000, 'NAV history thin — run populate_nav_history.php'],
        ];
        foreach ($countChecks as [$t, $min, $msg]) {
            try {
                $cnt = $db->query("SELECT COUNT(*) FROM $t")->fetchColumn();
                if ($cnt >= $min)
                    check('Database', "$t: $cnt rows", 'pass');
                else
                    check('Database', "$t: only $cnt rows", 'warn', "$min+ expected", $msg);
            } catch(Exception $e) {}
        }

    } catch(Exception $e) {
        check('Database', 'DB Connection FAILED', 'fail', $e->getMessage(), 'Check MySQL in XAMPP + .env credentials');
    }
});

// ─────────────────────────────────────────────────────────────
// SUITE 3: FILE SYSTEM (Folders + Files)
// ─────────────────────────────────────────────────────────────
runSuite('files', function() {
    // Required directories
    $dirs = [
        'api','api/mutual_funds','api/nps','api/stocks','api/fd','api/savings',
        'api/po_schemes','api/reports','api/admin','api/router.php',
        'templates','templates/pages','templates/layout.php',
        'public','public/js','public/css',
        'includes','config',
        'cron','database','database/migrations',
        'peak_nav','nav_download',
    ];
    foreach ($dirs as $d) {
        $path = WD_ROOT . '/' . $d;
        if (file_exists($path))
            check('Files', "$d", 'pass');
        else
            check('Files', "$d MISSING", 'warn', "Expected at: $path", "Create directory or file");
    }

    // Critical PHP files — syntax check
    $phpFiles = [
        'api/router.php',
        'config/database.php',
        'includes/auth.php',
        'includes/helpers.php',
        'templates/layout.php',
        'cron/update_nav_daily.php',
    ];
    foreach ($phpFiles as $f) {
        $full = WD_ROOT . '/' . $f;
        if (!file_exists($full)) {
            check('PHP Syntax', "$f", 'warn', 'File not found', "Create $f");
            continue;
        }
        // PHP lint check
        $output = shell_exec("php -l " . escapeshellarg($full) . " 2>&1");
        if (str_contains($output, 'No syntax errors')) {
            check('PHP Syntax', "$f ✅", 'pass');
        } else {
            check('PHP Syntax', "$f — SYNTAX ERROR", 'fail', trim($output), "Fix syntax error in $f");
        }
    }

    // Scan api/ folder for all PHP files and lint them
    $apiFiles = glob(WD_ROOT . '/api/**/*.php') ?: [];
    $apiFiles = array_merge($apiFiles, glob(WD_ROOT . '/api/*.php') ?: []);
    $lintErrors = 0;
    foreach ($apiFiles as $full) {
        $rel = str_replace(WD_ROOT . '/', '', $full);
        $output = shell_exec("php -l " . escapeshellarg($full) . " 2>&1");
        if (!str_contains($output, 'No syntax errors')) {
            check('PHP Syntax', "$rel — ERROR", 'fail', trim($output), "Fix syntax in $rel");
            $lintErrors++;
        }
    }
    if ($lintErrors === 0 && count($apiFiles) > 0)
        check('PHP Syntax', "All " . count($apiFiles) . " API files — clean ✅", 'pass');

    // Scan includes/ folder
    $incFiles = glob(WD_ROOT . '/includes/*.php') ?: [];
    foreach ($incFiles as $full) {
        $rel = str_replace(WD_ROOT . '/', '', $full);
        $output = shell_exec("php -l " . escapeshellarg($full) . " 2>&1");
        if (!str_contains($output, 'No syntax errors'))
            check('PHP Syntax', "$rel — ERROR", 'fail', trim($output));
    }

    // Scan cron/ folder
    $cronFiles = glob(WD_ROOT . '/cron/*.php') ?: [];
    foreach ($cronFiles as $full) {
        $rel = str_replace(WD_ROOT . '/', '', $full);
        $output = shell_exec("php -l " . escapeshellarg($full) . " 2>&1");
        if (!str_contains($output, 'No syntax errors'))
            check('PHP Syntax', "$rel — ERROR", 'fail', trim($output));
    }

    // JS files check (size-based — can't lint without Node)
    $jsFiles = [
        'public/js/app.js','public/js/mf.js','public/js/stocks.js',
        'public/js/nps.js','public/css/app.css',
    ];
    foreach ($jsFiles as $f) {
        $full = WD_ROOT . '/' . $f;
        if (file_exists($full)) {
            $size = filesize($full);
            if ($size > 0) check('JS/CSS', "$f (" . round($size/1024) . "KB)", 'pass');
            else check('JS/CSS', "$f is EMPTY", 'fail', "0 bytes", "Restore $f from backup");
        } else {
            check('JS/CSS', "$f missing", 'warn', '', "Create $f");
        }
    }

    // Migration files
    $migrations = glob(WD_ROOT . '/database/migrations/*.sql') ?: [];
    check('Migrations', count($migrations) . " migration files found", count($migrations) > 0 ? 'pass' : 'warn');

    // Log files check
    $logDir = WD_ROOT . '/logs';
    if (is_dir($logDir)) {
        $logs = glob($logDir . '/*.log') ?: [];
        foreach ($logs as $log) {
            $size = filesize($log);
            $rel  = str_replace(WD_ROOT . '/', '', $log);
            if ($size > 5 * 1024 * 1024) // >5MB warning
                check('Logs', "$rel is large (" . round($size/1024/1024, 1) . "MB)", 'warn', 'Log rotation recommended');
            else
                check('Logs', "$rel (" . round($size/1024) . "KB)", 'pass');
        }
    }
});

// ─────────────────────────────────────────────────────────────
// SUITE 4: API ENDPOINTS (Live HTTP check)
// ─────────────────────────────────────────────────────────────
runSuite('api', function() {
    $base = 'http://localhost/wealthdash';
    $endpoints = [
        'mf_list'          => '/api/router.php?action=mf_list&portfolio_id=1',
        'mf_search'        => '/api/router.php?action=mf_search&q=hdfc',
        'nps_list'         => '/api/router.php?action=nps_list&portfolio_id=1',
        'stocks_list'      => '/api/router.php?action=stocks_list&portfolio_id=1',
        'fd_list'          => '/api/router.php?action=fd_list&portfolio_id=1',
        'savings_list'     => '/api/router.php?action=savings_list&portfolio_id=1',
        'po_list'          => '/api/router.php?action=po_list&portfolio_id=1',
        'report_net_worth' => '/api/router.php?action=report_net_worth&portfolio_id=1',
        'report_fy_gains'  => '/api/router.php?action=report_fy_gains&portfolio_id=1',
        'fund_screener'    => '/api/router.php?action=fund_screener&limit=5',
        'indexes_fetch'    => '/api/router.php?action=indexes_fetch',
    ];

    foreach ($endpoints as $name => $path) {
        $url = $base . $path;
        $ctx = stream_context_create(['http' => ['timeout' => 5, 'ignore_errors' => true]]);
        $resp = @file_get_contents($url, false, $ctx);
        $code = (int)explode(' ', $http_response_header[0] ?? 'HTTP/1.1 0')[1];

        if ($resp === false || $code === 0) {
            check('API', "$name — unreachable", 'warn', "XAMPP off?", 'Start XAMPP Apache');
        } elseif ($code === 200) {
            // Check if valid JSON
            $json = json_decode($resp, true);
            if ($json !== null)
                check('API', "$name ✅ (200 JSON)", 'pass', strlen($resp) . " bytes");
            elseif (str_contains($resp, 'Fatal error') || str_contains($resp, 'Parse error'))
                check('API', "$name — PHP ERROR", 'fail', substr($resp, 0, 200), "Check error in PHP file");
            else
                check('API', "$name — non-JSON response", 'warn', substr($resp, 0, 100));
        } elseif ($code === 302 || $code === 301) {
            check('API', "$name — redirect ($code, auth check?)", 'warn', "Redirected to login", 'Check session/auth bypass for testing');
        } elseif ($code === 500) {
            check('API', "$name — 500 SERVER ERROR", 'fail', substr($resp ?? '', 0, 200), "Fix PHP error in API file");
        } else {
            check('API', "$name — HTTP $code", 'warn', $resp ? substr($resp, 0, 100) : '');
        }
    }
});

// ─────────────────────────────────────────────────────────────
// SUITE 5: UI PAGES
// ─────────────────────────────────────────────────────────────
runSuite('ui', function() {
    $base = 'http://localhost/wealthdash';
    $pages = [
        'Dashboard'        => '/templates/pages/dashboard.php',
        'MF Holdings'      => '/templates/pages/mf_holdings.php',
        'MF Transactions'  => '/templates/pages/mf_transactions.php',
        'MF Screener'      => '/templates/pages/mf_screener.php',
        'NPS'              => '/templates/pages/nps.php',
        'Stocks'           => '/templates/pages/stocks.php',
        'Fixed Deposits'   => '/templates/pages/fd.php',
        'Savings'          => '/templates/pages/savings.php',
        'Post Office'      => '/templates/pages/post_office.php',
        'Admin Panel'      => '/templates/pages/admin.php',
        'Report FY Gains'  => '/templates/pages/report_fy.php',
        'Report Tax'       => '/templates/pages/report_tax.php',
        'Report Net Worth' => '/templates/pages/report_networth.php',
        'Report SIP/SWP'   => '/templates/pages/report_sip.php',
        'Login'            => '/auth/login.php',
    ];

    foreach ($pages as $name => $path) {
        $full = WD_ROOT . $path;
        if (!file_exists($full)) {
            check('Pages', "$name — file missing", 'warn', $full, "Create $path");
            continue;
        }
        // Lint check
        $lint = shell_exec("php -l " . escapeshellarg($full) . " 2>&1");
        if (!str_contains($lint, 'No syntax errors')) {
            check('Pages', "$name — SYNTAX ERROR", 'fail', trim($lint));
            continue;
        }
        // HTTP check
        $ctx = stream_context_create(['http' => ['timeout' => 5, 'ignore_errors' => true]]);
        $resp = @file_get_contents($base . $path, false, $ctx);
        $code = (int)explode(' ', $http_response_header[0] ?? 'HTTP/1.1 0')[1];

        if ($resp === false) {
            check('Pages', "$name — unreachable", 'warn', 'XAMPP off?');
        } elseif ($code === 200) {
            if (str_contains($resp, 'Fatal error') || str_contains($resp, 'Parse error'))
                check('Pages', "$name — PHP ERROR in output", 'fail', substr($resp, 0, 200));
            elseif (strlen($resp) < 100)
                check('Pages', "$name — suspiciously small response", 'warn', strlen($resp) . " bytes");
            else
                check('Pages', "$name ✅", 'pass');
        } elseif (in_array($code, [301,302])) {
            check('Pages', "$name → redirect (login?)", 'warn', "HTTP $code — auth required");
        } else {
            check('Pages', "$name — HTTP $code", 'warn');
        }
    }
});

// ─────────────────────────────────────────────────────────────
// SUITE 6: CRON JOBS
// ─────────────────────────────────────────────────────────────
runSuite('cron', function() {
    $cronFiles = [
        'cron/update_nav_daily.php'     => 'Daily NAV Update',
        'cron/update_stocks_daily.php'  => 'Daily Stocks Update',
        'cron/nps_nav_scraper.php'      => 'NPS NAV Scraper',
        'cron/fd_maturity_alert.php'    => 'FD Maturity Alerts',
        'cron/calculate_returns.php'    => 'Returns Calculator',
        'cron/populate_nav_history.php' => 'NAV History Populate',
    ];

    foreach ($cronFiles as $file => $label) {
        $full = WD_ROOT . '/' . $file;
        if (!file_exists($full)) {
            check('Cron', "$label — file missing", 'warn', $file, "Create $file");
            continue;
        }
        $lint = shell_exec("php -l " . escapeshellarg($full) . " 2>&1");
        if (str_contains($lint, 'No syntax errors'))
            check('Cron', "$label ✅", 'pass');
        else
            check('Cron', "$label — SYNTAX ERROR", 'fail', trim($lint));
    }

    // Check last run times from log files (if they exist)
    $logFile = WD_ROOT . '/logs/cron.log';
    if (file_exists($logFile)) {
        $lastLine = trim(shell_exec("tail -1 " . escapeshellarg($logFile)));
        if ($lastLine)
            check('Cron', "Last cron log: $lastLine", 'pass');
    }
});

// ─────────────────────────────────────────────────────────────
// SUITE 7: FOLDER STRUCTURE DEEP SCAN
// ─────────────────────────────────────────────────────────────
runSuite('folders', function() {
    $requiredFolders = [
        'api'                          => 'API Root',
        'api/mutual_funds'             => 'MF API',
        'api/nps'                      => 'NPS API',
        'api/stocks'                   => 'Stocks API',
        'api/fd'                       => 'FD API',
        'api/savings'                  => 'Savings API',
        'api/po_schemes'               => 'Post Office API',
        'api/reports'                  => 'Reports API',
        'api/admin'                    => 'Admin API',
        'templates'                    => 'Templates Root',
        'templates/pages'              => 'Page Templates',
        'public/js'                    => 'JavaScript Files',
        'public/css'                   => 'CSS Files',
        'includes'                     => 'Shared Includes',
        'config'                       => 'Config Files',
        'cron'                         => 'Cron Jobs',
        'database'                     => 'Database Root',
        'database/migrations'          => 'SQL Migrations',
        'peak_nav'                     => 'Peak NAV Module',
        'nav_download'                 => 'NAV Download Module',
        'debug'                        => 'Debug Tools',
    ];

    foreach ($requiredFolders as $path => $label) {
        $full = WD_ROOT . '/' . $path;
        if (is_dir($full)) {
            $fileCount = count(glob($full . '/*') ?: []);
            check('Folders', "$label ($path): $fileCount items", 'pass');
        } else {
            check('Folders', "$label ($path): MISSING", 'warn', "Directory does not exist", "mkdir $path");
        }
    }

    // Check for empty directories
    $allDirs = [];
    $rit = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator(WD_ROOT, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($rit as $item) {
        if ($item->isDir()) {
            $rel = str_replace(WD_ROOT . DIRECTORY_SEPARATOR, '', $item->getPathname());
            // Skip vendor, node_modules, .git
            if (preg_match('/(vendor|node_modules|\.git|\.vs)/', $rel)) continue;
            $files = glob($item->getPathname() . '/*') ?: [];
            if (count($files) === 0)
                check('Folders', "$rel — empty directory", 'warn', 'Empty folder');
        }
    }
});

// ─────────────────────────────────────────────────────────────
// OUTPUT
// ─────────────────────────────────────────────────────────────
$elapsed = round((microtime(true) - START_TIME) * 1000) . 'ms';

if ($format === 'json') {
    header('Content-Type: application/json');
    echo json_encode(['stats' => $stats, 'elapsed' => $elapsed, 'results' => $results], JSON_PRETTY_PRINT);
    exit;
}

if ($format === 'txt') {
    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename="wd_debug_' . date('Y-m-d_Hi') . '.txt"');
    echo "WealthDash Debug Report — " . date('Y-m-d H:i:s') . "\n";
    echo "Passed: {$stats['pass']} | Failed: {$stats['fail']} | Warnings: {$stats['warn']}\n";
    echo "Time: $elapsed\n\n";
    $section = '';
    foreach ($results as $r) {
        if ($r['section'] !== $section) {
            echo "\n═══ {$r['section']} ═══\n";
            $section = $r['section'];
        }
        $icon = $r['status'] === 'pass' ? '✅' : ($r['status'] === 'fail' ? '❌' : '⚠️');
        echo "$icon  {$r['label']}\n";
        if ($r['detail']) echo "     Detail: {$r['detail']}\n";
        if ($r['fix'])    echo "     Fix: {$r['fix']}\n";
    }
    exit;
}

// HTML output
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>WealthDash — Debug Report</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,-apple-system,sans-serif;background:#f5f6fa;color:#18212f;font-size:13px;line-height:1.5}
.topbar{background:#fff;border-bottom:1.5px solid #e4e8f0;padding:12px 24px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
.title{font-size:16px;font-weight:800;letter-spacing:-.3px}
.badge{font-size:11px;font-weight:700;padding:3px 10px;border-radius:99px;border:1px solid}
.stats{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.s-pass{background:#edfbf3;color:#15a854;border-color:#a7e8c5}
.s-fail{background:#fff0f0;color:#d63b3b;border-color:#f5b8b8}
.s-warn{background:#fefae8;color:#c07e00;border-color:#f0d88a}
.s-time{background:#f5f6fa;color:#5a6a85;border-color:#e4e8f0}
.content{padding:20px 24px;max-width:1000px}
.section{background:#fff;border:1.5px solid #e4e8f0;border-radius:12px;margin-bottom:12px;overflow:hidden}
.sec-hdr{padding:10px 14px;font-size:12px;font-weight:800;background:#f8f9ff;border-bottom:1px solid #e4e8f0;display:flex;align-items:center;gap:8px;cursor:pointer}
.sec-hdr:hover{background:#f0f1ff}
.row{display:flex;align-items:flex-start;gap:8px;padding:8px 14px;border-bottom:1px solid #f0f1f5;font-size:12px}
.row:last-child{border-bottom:none}
.row:hover{background:#fafbff}
.ico{font-size:13px;flex-shrink:0;width:18px;text-align:center;margin-top:1px}
.lbl{flex:1;font-weight:600}
.detail{font-size:11px;color:#5a6a85;margin-top:2px;font-family:'Courier New',monospace}
.fix{font-size:11px;color:#4f46e5;margin-top:2px}
.cnt{font-size:10px;color:#5a6a85;margin-left:auto;white-space:nowrap}
.filter-bar{padding:10px 24px;display:flex;gap:6px;flex-wrap:wrap;background:#fff;border-bottom:1.5px solid #e4e8f0;position:sticky;top:57px;z-index:99}
.fbtn{padding:4px 12px;border-radius:99px;border:1.5px solid #e4e8f0;background:#fff;color:#5a6a85;font-size:11px;font-weight:700;cursor:pointer}
.fbtn:hover{border-color:#4f46e5;color:#4f46e5}
.fbtn.active{background:#4f46e5;color:#fff;border-color:#4f46e5}
</style>
</head>
<body>
<div class="topbar">
  <div class="title">🔧 WealthDash — Debug Report</div>
  <div class="stats">
    <span class="badge s-pass">✅ Passed: <?=$stats['pass']?></span>
    <span class="badge s-fail">❌ Failed: <?=$stats['fail']?></span>
    <span class="badge s-warn">⚠️ Warnings: <?=$stats['warn']?></span>
    <span class="badge s-time">⏱ <?=$elapsed?></span>
    <span class="badge s-time"><?=date('H:i:s')?></span>
  </div>
</div>
<div class="filter-bar">
  <button class="fbtn active" onclick="filterRows('all',this)">All</button>
  <button class="fbtn" onclick="filterRows('fail',this)">❌ Failed</button>
  <button class="fbtn" onclick="filterRows('warn',this)">⚠️ Warnings</button>
  <button class="fbtn" onclick="filterRows('pass',this)">✅ Passed</button>
</div>
<div class="content">
<?php
$section = '';
$rows    = '';
foreach ($results as $r) {
    if ($r['section'] !== $section) {
        if ($rows) echo '</div></div>';
        $sectionPass = 0; $sectionFail = 0; $sectionWarn = 0;
        foreach ($results as $sr) {
            if ($sr['section'] === $r['section']) {
                if ($sr['status'] === 'pass') $sectionPass++;
                elseif ($sr['status'] === 'fail') $sectionFail++;
                else $sectionWarn++;
            }
        }
        $color = $sectionFail > 0 ? '#d63b3b' : ($sectionWarn > 0 ? '#c07e00' : '#15a854');
        echo '<div class="section"><div class="sec-hdr" onclick="this.nextSibling.style.display=this.nextSibling.style.display===\'none\'?\'block\':\'none\'">';
        echo "<span style='color:$color'>" . ($sectionFail > 0 ? '❌' : ($sectionWarn > 0 ? '⚠️' : '✅')) . "</span>";
        echo " {$r['section']}";
        echo "<span class='cnt' style='margin-left:auto'>✅$sectionPass ❌$sectionFail ⚠️$sectionWarn</span></div><div>";
        $section = $r['section'];
        $rows = '';
    }
    $ico = $r['status'] === 'pass' ? '✅' : ($r['status'] === 'fail' ? '❌' : '⚠️');
    echo "<div class='row' data-status='{$r['status']}'>";
    echo "<span class='ico'>$ico</span>";
    echo "<div class='lbl'>" . htmlspecialchars($r['label']) . "";
    if ($r['detail']) echo "<div class='detail'>" . htmlspecialchars($r['detail']) . "</div>";
    if ($r['fix'])    echo "<div class='fix'>🔧 " . htmlspecialchars($r['fix']) . "</div>";
    echo "</div></div>\n";
}
if ($section) echo '</div></div>';
?>
</div>
<script>
function filterRows(f, btn) {
  document.querySelectorAll('.fbtn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.row').forEach(r => {
    if (f === 'all' || r.dataset.status === f) r.style.display = '';
    else r.style.display = 'none';
  });
}
</script>
</body>
</html>
