-- ============================================================
-- WealthDash — Database Verification Toolkit
-- File: Database_Health_Check.sql
-- Phase 4 + Phase 5 Combined
-- Generated: 2026-06-04
-- ============================================================
-- HOW TO USE:
--   1. Run on BOTH PCs and compare output side by side.
--   2. Any row with status = 'FAIL' or 'MISSING' must be fixed.
--   3. Section 8 gives exact SQL to fix each issue found.
-- ============================================================

USE `wealthdash`;

-- ============================================================
-- SECTION 1: ENVIRONMENT FINGERPRINT
-- Run on both PCs and diff the output
-- ============================================================
SELECT '=== ENVIRONMENT FINGERPRINT ===' AS section;

SELECT
  @@version                                   AS mysql_version,
  @@version_comment                           AS version_comment,
  @@global.sql_mode                           AS sql_mode,
  @@global.character_set_server               AS char_set_server,
  @@global.collation_server                   AS collation_server,
  @@global.time_zone                          AS timezone,
  @@global.default_storage_engine             AS default_engine,
  @@global.innodb_file_per_table              AS innodb_file_per_table,
  @@global.max_allowed_packet / 1024 / 1024   AS max_allowed_packet_mb,
  @@global.wait_timeout                       AS wait_timeout_sec,
  @@global.foreign_key_checks                 AS fk_checks_global,
  @@global.lower_case_table_names             AS lower_case_table_names;

-- ============================================================
-- SECTION 2: TABLE EXISTENCE CHECK
-- Verifies all 97 production tables are present
-- ============================================================
SELECT '=== TABLE EXISTENCE CHECK ===' AS section;

SELECT
  t.expected_table                        AS table_name,
  CASE WHEN ist.TABLE_NAME IS NOT NULL
       THEN '✅ EXISTS'
       ELSE '❌ MISSING'
  END                                     AS status,
  IFNULL(ist.ENGINE, 'N/A')              AS engine,
  IFNULL(ist.TABLE_COLLATION, 'N/A')     AS collation,
  IFNULL(ist.TABLE_ROWS, 0)              AS approx_rows
FROM (
  SELECT 'users'                     UNION ALL SELECT 'sessions'
  UNION ALL SELECT 'user_sessions'   UNION ALL SELECT 'login_attempts'
  UNION ALL SELECT 'otp_tokens'      UNION ALL SELECT 'password_resets'
  UNION ALL SELECT 'google_auth'     UNION ALL SELECT 'rate_limit_buckets'
  UNION ALL SELECT 'app_settings'    UNION ALL SELECT 'audit_log'
  UNION ALL SELECT 'migration_log'   UNION ALL SELECT 'portfolios'
  UNION ALL SELECT 'import_logs'     UNION ALL SELECT 'fund_houses'
  UNION ALL SELECT 'funds'           UNION ALL SELECT 'nav_history'
  UNION ALL SELECT 'nav_download_progress' UNION ALL SELECT 'nav_proxy_cache'
  UNION ALL SELECT 'mf_peak_progress' UNION ALL SELECT 'fund_ratings'
  UNION ALL SELECT 'fund_stock_holdings' UNION ALL SELECT 'fund_overlap_cache'
  UNION ALL SELECT 'fund_managers'   UNION ALL SELECT 'expense_ratio_history'
  UNION ALL SELECT 'nfo_tracker'     UNION ALL SELECT 'fund_watchlist'
  UNION ALL SELECT 'price_alerts'    UNION ALL SELECT 'mf_compare_sessions'
  UNION ALL SELECT 'mf_holdings'     UNION ALL SELECT 'mf_transactions'
  UNION ALL SELECT 'mf_dividends'    UNION ALL SELECT 'mf_holding_notes'
  UNION ALL SELECT 'sector_rotation_cache' UNION ALL SELECT 'sector_rotation_history'
  UNION ALL SELECT 'sip_schedules'   UNION ALL SELECT 'nps_schemes'
  UNION ALL SELECT 'nps_holdings'    UNION ALL SELECT 'nps_transactions'
  UNION ALL SELECT 'nps_nav_history' UNION ALL SELECT 'stock_master'
  UNION ALL SELECT 'stock_holdings'  UNION ALL SELECT 'stock_transactions'
  UNION ALL SELECT 'stock_dividends' UNION ALL SELECT 'stock_corporate_actions'
  UNION ALL SELECT 'stock_fundamentals_history' UNION ALL SELECT 'stock_screener_filters'
  UNION ALL SELECT 'fd_accounts'     UNION ALL SELECT 'fd_interest_accruals'
  UNION ALL SELECT 'fd_maturity_alerts' UNION ALL SELECT 'fd_market_rates'
  UNION ALL SELECT 'fd_interest_log' UNION ALL SELECT 'savings_accounts'
  UNION ALL SELECT 'savings_interest' UNION ALL SELECT 'bank_accounts'
  UNION ALL SELECT 'bank_balance_history' UNION ALL SELECT 'epf_accounts'
  UNION ALL SELECT 'po_schemes'      UNION ALL SELECT 'insurance_policies'
  UNION ALL SELECT 'loan_accounts'   UNION ALL SELECT 'investment_goals'
  UNION ALL SELECT 'goal_contributions' UNION ALL SELECT 'goal_buckets'
  UNION ALL SELECT 'goal_fund_links' UNION ALL SELECT 'rebalancing_targets'
  UNION ALL SELECT 'investment_calendar_events' UNION ALL SELECT 'net_worth_snapshots'
  UNION ALL SELECT 'sgb_holdings'    UNION ALL SELECT 'sgb_interest_log'
  UNION ALL SELECT 'gold_price_cache' UNION ALL SELECT 'crypto_holdings'
  UNION ALL SELECT 'crypto_transactions' UNION ALL SELECT 'crypto_price_cache'
  UNION ALL SELECT 'vda_transactions' UNION ALL SELECT 'vda_tds_log'
  UNION ALL SELECT 'esop_grants'     UNION ALL SELECT 'esop_vesting_events'
  UNION ALL SELECT 'esop_exercise_log' UNION ALL SELECT 'reits_invits_master'
  UNION ALL SELECT 'reits_invits'    UNION ALL SELECT 'reits_invits_transactions'
  UNION ALL SELECT 'reits_invits_distributions' UNION ALL SELECT 'etf_master'
  UNION ALL SELECT 'etf_holdings'    UNION ALL SELECT 'etf_transactions'
  UNION ALL SELECT 'pms_holdings'    UNION ALL SELECT 'pms_transactions'
  UNION ALL SELECT 'pms_nav_history' UNION ALL SELECT 'us_stock_master'
  UNION ALL SELECT 'us_stock_holdings' UNION ALL SELECT 'us_stock_transactions'
  UNION ALL SELECT 'notifications'   UNION ALL SELECT 'notification_prefs'
  UNION ALL SELECT 'ai_chat_history' UNION ALL SELECT 'ai_portfolio_reviews'
  UNION ALL SELECT 'ai_anomalies'    UNION ALL SELECT 'zerodha_credentials'
  UNION ALL SELECT 'zerodha_sync_log' UNION ALL SELECT 'zerodha_holdings_raw'
  UNION ALL SELECT 'groww_api_credentials' UNION ALL SELECT 'groww_sync_log'
  UNION ALL SELECT 'investment_journal' UNION ALL SELECT 'credit_cards'
  UNION ALL SELECT 'nudge_dismissals' UNION ALL SELECT 'spending_discipline'
) AS t(expected_table)
LEFT JOIN information_schema.TABLES AS ist
  ON ist.TABLE_SCHEMA = DATABASE()
  AND ist.TABLE_NAME  = t.expected_table
ORDER BY status, table_name;

-- ============================================================
-- SECTION 3: CRITICAL COLUMN EXISTENCE CHECK
-- Verifies previously-missing columns now exist
-- ============================================================
SELECT '=== CRITICAL COLUMN CHECK ===' AS section;

SELECT
  c.tbl                           AS table_name,
  c.col                           AS column_name,
  CASE WHEN isc.COLUMN_NAME IS NOT NULL
       THEN '✅ EXISTS'
       ELSE '❌ MISSING — Schema drift not resolved!'
  END                             AS status,
  IFNULL(isc.COLUMN_TYPE, 'N/A') AS data_type,
  IFNULL(isc.IS_NULLABLE, 'N/A') AS nullable
FROM (
  SELECT 'mf_holdings',         'investment_fy'         UNION ALL
  SELECT 'mf_holdings',         'ltcg_date'             UNION ALL
  SELECT 'mf_holdings',         'lock_in_date'          UNION ALL
  SELECT 'mf_holdings',         'withdrawable_date'     UNION ALL
  SELECT 'mf_holdings',         'withdrawable_fy'       UNION ALL
  SELECT 'mf_holdings',         'status'                UNION ALL
  SELECT 'stock_holdings',      'status'                UNION ALL
  SELECT 'savings_accounts',    'status'                UNION ALL
  SELECT 'funds',               'fund_type'             UNION ALL
  SELECT 'funds',               'min_ltcg_days'         UNION ALL
  SELECT 'funds',               'wd_stars'              UNION ALL
  SELECT 'funds',               'style_size'            UNION ALL
  SELECT 'funds',               'style_value'           UNION ALL
  SELECT 'funds',               'style_box'             UNION ALL
  SELECT 'funds',               'returns_1y'            UNION ALL
  SELECT 'funds',               'returns_3y'            UNION ALL
  SELECT 'funds',               'returns_5y'            UNION ALL
  SELECT 'funds',               'alpha'                 UNION ALL
  SELECT 'funds',               'beta'                  UNION ALL
  SELECT 'insurance_policies',  'premium_due_date'      UNION ALL
  SELECT 'nav_download_progress','scheme_code'          UNION ALL
  SELECT 'nav_download_progress','from_date'            UNION ALL
  SELECT 'sip_schedules',       'step_up_pct'           UNION ALL
  SELECT 'sip_schedules',       'step_up_frequency'     UNION ALL
  SELECT 'users',               'totp_secret'           UNION ALL
  SELECT 'users',               'totp_enabled'
) AS c(tbl, col)
LEFT JOIN information_schema.COLUMNS AS isc
  ON isc.TABLE_SCHEMA = DATABASE()
  AND isc.TABLE_NAME  = c.tbl
  AND isc.COLUMN_NAME = c.col
ORDER BY status DESC, table_name;

-- ============================================================
-- SECTION 4: INDEX VERIFICATION
-- Checks critical indexes exist
-- ============================================================
SELECT '=== CRITICAL INDEX CHECK ===' AS section;

SELECT
  i.tbl                                   AS table_name,
  i.idx                                   AS expected_index,
  CASE WHEN iss.INDEX_NAME IS NOT NULL
       THEN '✅ EXISTS'
       ELSE '⚠️  MISSING — Performance impact!'
  END                                     AS status
FROM (
  SELECT 'users',          'uq_email'                  UNION ALL
  SELECT 'funds',          'uq_scheme_code'            UNION ALL
  SELECT 'funds',          'idx_fund_active'           UNION ALL
  SELECT 'funds',          'idx_fund_type'             UNION ALL
  SELECT 'nav_history',    'uq_nav'                    UNION ALL
  SELECT 'mf_holdings',    'uq_mfh'                    UNION ALL
  SELECT 'mf_holdings',    'idx_mfh_portfolio_status'  UNION ALL
  SELECT 'stock_holdings', 'uq_sh'                     UNION ALL
  SELECT 'nps_schemes',    'uq_nps_code'               UNION ALL
  SELECT 'nps_holdings',   'uq_npsh'                   UNION ALL
  SELECT 'migration_log',  'uq_filename'               UNION ALL
  SELECT 'app_settings',   'uq_key'                    UNION ALL
  SELECT 'etf_master',     'uq_etf_symbol'             UNION ALL
  SELECT 'us_stock_master','uq_usm_symbol'             UNION ALL
  SELECT 'vda_tds_log',    'uq_vda_tds'                UNION ALL
  SELECT 'sgb_holdings',   'idx_sgb_maturity'          UNION ALL
  SELECT 'insurance_policies','idx_ins_premium_due'    UNION ALL
  SELECT 'mf_transactions','idx_mft_date'              UNION ALL
  SELECT 'notifications',  'idx_notif_unread'
) AS i(tbl, idx)
LEFT JOIN information_schema.STATISTICS AS iss
  ON iss.TABLE_SCHEMA = DATABASE()
  AND iss.TABLE_NAME  = i.tbl
  AND iss.INDEX_NAME  = i.idx
GROUP BY i.tbl, i.idx, iss.INDEX_NAME
ORDER BY status DESC, table_name;

-- ============================================================
-- SECTION 5: FOREIGN KEY VERIFICATION
-- Checks critical FKs exist
-- ============================================================
SELECT '=== FOREIGN KEY CHECK ===' AS section;

SELECT
  f.fk_name                               AS fk_constraint,
  f.child_table                           AS child_table,
  CASE WHEN rc.CONSTRAINT_NAME IS NOT NULL
       THEN '✅ EXISTS'
       ELSE '❌ MISSING — Referential integrity broken!'
  END                                     AS status
FROM (
  SELECT 'fk_sess_user',       'sessions'             UNION ALL
  SELECT 'fk_portfolio_user',  'portfolios'           UNION ALL
  SELECT 'fk_funds_house',     'funds'                UNION ALL
  SELECT 'fk_nav_fund',        'nav_history'          UNION ALL
  SELECT 'fk_mfh_portfolio',   'mf_holdings'          UNION ALL
  SELECT 'fk_mfh_fund',        'mf_holdings'          UNION ALL
  SELECT 'fk_mft_portfolio',   'mf_transactions'      UNION ALL
  SELECT 'fk_sh_portfolio',    'stock_holdings'       UNION ALL
  SELECT 'fk_sh_stock',        'stock_holdings'       UNION ALL
  SELECT 'fk_npsh_portfolio',  'nps_holdings'         UNION ALL
  SELECT 'fk_npsh_scheme',     'nps_holdings'         UNION ALL
  SELECT 'fk_fd_portfolio',    'fd_accounts'          UNION ALL
  SELECT 'fk_fdia_fd',         'fd_interest_accruals' UNION ALL
  SELECT 'fk_fdma_fd',         'fd_maturity_alerts'   UNION ALL
  SELECT 'fk_eg_portfolio',    'esop_grants'          UNION ALL
  SELECT 'fk_eve_grant',       'esop_vesting_events'  UNION ALL
  SELECT 'fk_ch_portfolio',    'crypto_holdings'      UNION ALL
  SELECT 'fk_vda_portfolio',   'vda_transactions'     UNION ALL
  SELECT 'fk_pmst_holding',    'pms_transactions'     UNION ALL
  SELECT 'fk_notif_user',      'notifications'
) AS f(fk_name, child_table)
LEFT JOIN information_schema.REFERENTIAL_CONSTRAINTS AS rc
  ON rc.CONSTRAINT_SCHEMA = DATABASE()
  AND rc.CONSTRAINT_NAME  = f.fk_name
ORDER BY status DESC, child_table;

-- ============================================================
-- SECTION 6: DATA INTEGRITY VERIFICATION
-- Check for orphan records, nulls where not allowed, etc.
-- ============================================================
SELECT '=== DATA INTEGRITY CHECK ===' AS section;

-- 6a: Orphaned mf_holdings (no parent portfolio)
SELECT
  'mf_holdings → portfolios'       AS check_name,
  COUNT(*)                          AS orphan_count,
  CASE WHEN COUNT(*) = 0 THEN '✅ CLEAN' ELSE '❌ ORPHANS FOUND' END AS status
FROM mf_holdings mfh
WHERE NOT EXISTS (SELECT 1 FROM portfolios p WHERE p.id = mfh.portfolio_id);

-- 6b: Orphaned mf_transactions (no parent portfolio)
SELECT
  'mf_transactions → portfolios'   AS check_name,
  COUNT(*)                          AS orphan_count,
  CASE WHEN COUNT(*) = 0 THEN '✅ CLEAN' ELSE '❌ ORPHANS FOUND' END AS status
FROM mf_transactions t
WHERE NOT EXISTS (SELECT 1 FROM portfolios p WHERE p.id = t.portfolio_id);

-- 6c: Orphaned mf_holdings (no parent fund)
SELECT
  'mf_holdings → funds'            AS check_name,
  COUNT(*)                          AS orphan_count,
  CASE WHEN COUNT(*) = 0 THEN '✅ CLEAN' ELSE '❌ ORPHANS FOUND' END AS status
FROM mf_holdings mfh
WHERE NOT EXISTS (SELECT 1 FROM funds f WHERE f.id = mfh.fund_id);

-- 6d: Portfolios without a user
SELECT
  'portfolios → users'             AS check_name,
  COUNT(*)                          AS orphan_count,
  CASE WHEN COUNT(*) = 0 THEN '✅ CLEAN' ELSE '❌ ORPHANS FOUND' END AS status
FROM portfolios p
WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.id = p.user_id);

-- 6e: nav_history with future dates (likely bad import)
SELECT
  'nav_history future dates'       AS check_name,
  COUNT(*)                          AS bad_count,
  CASE WHEN COUNT(*) = 0 THEN '✅ CLEAN' ELSE '⚠️  REVIEW NEEDED' END AS status
FROM nav_history
WHERE nav_date > CURDATE();

-- 6f: mf_holdings with units = 0 and invested > 0 (data inconsistency)
SELECT
  'mf_holdings zero units'         AS check_name,
  COUNT(*)                          AS bad_count,
  CASE WHEN COUNT(*) = 0 THEN '✅ CLEAN' ELSE '⚠️  REVIEW NEEDED' END AS status
FROM mf_holdings
WHERE units = 0 AND invested_amount > 0;

-- 6g: Duplicate emails in users table
SELECT
  'users duplicate emails'         AS check_name,
  COUNT(*)                          AS dup_count,
  CASE WHEN COUNT(*) = 0 THEN '✅ CLEAN' ELSE '❌ DUPLICATES FOUND' END AS status
FROM (
  SELECT email, COUNT(*) AS cnt
  FROM users
  GROUP BY email
  HAVING cnt > 1
) dupes;

-- 6h: fd_accounts with maturity_date < start_date
SELECT
  'fd_accounts maturity < start'   AS check_name,
  COUNT(*)                          AS bad_count,
  CASE WHEN COUNT(*) = 0 THEN '✅ CLEAN' ELSE '❌ BAD DATES' END AS status
FROM fd_accounts
WHERE maturity_date < start_date;

-- 6i: Seed data check: fund_houses count
SELECT
  'fund_houses seeded'             AS check_name,
  COUNT(*)                          AS row_count,
  CASE WHEN COUNT(*) >= 36 THEN '✅ OK' ELSE '⚠️  UNDER-SEEDED' END AS status
FROM fund_houses;

-- 6j: Seed data check: nps_schemes count
SELECT
  'nps_schemes seeded'             AS check_name,
  COUNT(*)                          AS row_count,
  CASE WHEN COUNT(*) >= 63 THEN '✅ OK' ELSE '⚠️  UNDER-SEEDED' END AS status
FROM nps_schemes;

-- ============================================================
-- SECTION 7: ENVIRONMENT COMPARISON — CHARSET & SQL_MODE
-- Run on both PCs and compare
-- ============================================================
SELECT '=== CHARSET & COLLATION AUDIT ===' AS section;

SELECT
  TABLE_NAME,
  TABLE_COLLATION,
  ENGINE,
  CASE
    WHEN TABLE_COLLATION = 'utf8mb4_unicode_ci' AND ENGINE = 'InnoDB'
    THEN '✅ CORRECT'
    WHEN TABLE_COLLATION LIKE 'utf8mb4%' AND ENGINE = 'InnoDB'
    THEN '⚠️  COLLATION VARIANT — OK but not standard'
    WHEN ENGINE != 'InnoDB'
    THEN '❌ WRONG ENGINE'
    ELSE '❌ WRONG CHARSET'
  END AS status
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_TYPE = 'BASE TABLE'
ORDER BY status DESC, TABLE_NAME;

-- ============================================================
-- SECTION 8: SCHEMA DIFF — compare column count vs expected
-- ============================================================
SELECT '=== COLUMN COUNT AUDIT ===' AS section;

SELECT
  e.tbl                                     AS table_name,
  e.expected_min_cols                       AS expected_min,
  COUNT(isc.COLUMN_NAME)                    AS actual_cols,
  CASE
    WHEN COUNT(isc.COLUMN_NAME) >= e.expected_min_cols
    THEN '✅ OK'
    ELSE CONCAT('❌ MISSING ~', e.expected_min_cols - COUNT(isc.COLUMN_NAME), ' columns')
  END                                       AS status
FROM (
  SELECT 'users',              16  UNION ALL
  SELECT 'funds',              50  UNION ALL
  SELECT 'mf_holdings',        23  UNION ALL
  SELECT 'stock_master',       40  UNION ALL
  SELECT 'stock_holdings',     14  UNION ALL
  SELECT 'sip_schedules',      22  UNION ALL
  SELECT 'nps_schemes',        17  UNION ALL
  SELECT 'fd_accounts',        18  UNION ALL
  SELECT 'insurance_policies', 19  UNION ALL
  SELECT 'esop_grants',        22  UNION ALL
  SELECT 'pms_holdings',       26  UNION ALL
  SELECT 'vda_transactions',   33  UNION ALL
  SELECT 'sgb_holdings',       26  UNION ALL
  SELECT 'etf_master',         28  UNION ALL
  SELECT 'zerodha_credentials',16
) AS e(tbl, expected_min_cols)
LEFT JOIN information_schema.COLUMNS AS isc
  ON isc.TABLE_SCHEMA = DATABASE()
  AND isc.TABLE_NAME  = e.tbl
GROUP BY e.tbl, e.expected_min_cols
ORDER BY status DESC;

-- ============================================================
-- SECTION 9: MYSQL VERSION COMPATIBILITY CHECK
-- ============================================================
SELECT '=== VERSION COMPATIBILITY ===' AS section;

SELECT
  @@version                              AS current_version,
  CASE
    WHEN @@version >= '8.0.0'  THEN '✅ MySQL 8.x — Full compatibility'
    WHEN @@version >= '5.7.0'  THEN '⚠️  MySQL 5.7 — JSON columns may have issues'
    WHEN @@version >= '10.3.0' THEN '✅ MariaDB 10.3+ — Compatible'
    ELSE '❌ Too old — Upgrade required (min MySQL 5.7 / MariaDB 10.3)'
  END                                    AS compatibility,
  CASE
    WHEN @@version LIKE '%MariaDB%'
    THEN '⚠️  MariaDB detected — CHECK: JSON column support, generated columns syntax'
    ELSE '✅ MySQL'
  END                                    AS db_flavour;

-- Check if generated columns are supported (used in funds.style_box)
SELECT
  'Generated column support'            AS feature,
  CASE
    WHEN @@version >= '5.7.6' AND @@version NOT LIKE '%MariaDB%'
    THEN '✅ Supported (MySQL 5.7.6+)'
    WHEN @@version LIKE '%MariaDB%' AND @@version >= '5.2.0'
    THEN '✅ Supported (MariaDB 5.2+)'
    ELSE '❌ NOT SUPPORTED — Remove GENERATED ALWAYS AS from funds.style_box'
  END                                    AS status;

-- Check JSON type support
SELECT
  'Native JSON type support'            AS feature,
  CASE
    WHEN @@version >= '5.7.8' AND @@version NOT LIKE '%MariaDB%'
    THEN '✅ Supported (MySQL 5.7.8+)'
    WHEN @@version LIKE '%MariaDB%' AND @@version >= '10.2.7'
    THEN '✅ Supported (MariaDB 10.2.7+)'
    ELSE '❌ NOT SUPPORTED — Replace JSON columns with LONGTEXT'
  END                                    AS status;
