# WealthDash — Migration Order & Dependency Analysis
**Phase 3 Deliverable | Generated: 2026-06-04**

---

## Clean Install Execution Order (5 Files)

For any **fresh installation**, run only these 5 files in order:

```
01_database_create.sql   ← Creates database, sets charset/collation
02_tables.sql            ← All CREATE TABLE (no ALTER clutter)
03_indexes.sql           ← All indexes (run after tables)
04_foreign_keys.sql      ← All FK constraints (run after indexes)
05_seed_data.sql         ← Lookup/master data (AMCs, NPS, ETFs, Calendar)
```

**Total estimated execution time on fresh MySQL 8.x:** 8–15 seconds

---

## Why Each File Must Run in This Exact Order

### Step 1 — `01_database_create.sql`
**Must run first.** Sets `foreign_key_checks = 0` globally, creates the database with `utf8mb4_unicode_ci`, and sets `SQL_MODE`. If you run `02_tables.sql` before this, every subsequent statement will fail with "Unknown database 'wealthdash'".

### Step 2 — `02_tables.sql`
**Must run before indexes and FKs.** You cannot create an index or foreign key on a table that does not yet exist. All 97 production tables are created here in dependency order (parents before children — see Table Creation Order below).

### Step 3 — `03_indexes.sql`
**Must run after tables, before FKs.** InnoDB requires that FK parent columns be indexed. If indexes do not exist before you add FKs, MySQL will either auto-create them (silently) or refuse the FK with ERROR 1005. Running indexes explicitly gives you named, predictable indexes.

### Step 4 — `04_foreign_keys.sql`
**Must run after tables AND indexes.** All `ALTER TABLE ... ADD CONSTRAINT FOREIGN KEY` statements require both parent and child tables to be fully defined and indexed. `foreign_key_checks = 0` is set at the top so you do not need to worry about the order of individual FK statements within the file.

### Step 5 — `05_seed_data.sql`
**Must run last.** Seeds reference data into `fund_houses`, `nps_schemes`, `etf_master`, `reits_invits_master`, `app_settings`, and `investment_calendar_events`. All these tables must exist (Step 2) and their FKs must be valid (Step 4) before data can be inserted.

---

## Table Creation Order Within `02_tables.sql`

Tables are written in the following sequence so that every parent table is defined before any child that references it:

```
Sequence  Table                          Why Here
--------  -----                          --------
 1        users                          Root parent — no FK dependencies
 2        sessions                       → users
 3        user_sessions                  → users
 4        login_attempts                 standalone
 5        otp_tokens                     → users
 6        password_resets                standalone
 7        google_auth                    → users
 8        rate_limit_buckets             standalone
 9        app_settings                   → users (nullable)
10        audit_log                      standalone (soft FK to users)
11        migration_log                  standalone
12        portfolios                     → users
13        import_logs                    → users, portfolios
14        fund_houses                    standalone master
15        funds                          → fund_houses
16        nav_history                    → funds
17        nav_download_progress          → funds (nullable)
18        nav_proxy_cache                → funds
19        mf_peak_progress               standalone (scheme_code only)
20        fund_ratings                   → funds
21        fund_stock_holdings            → funds
22        fund_overlap_cache             → funds ×2
23        fund_managers                  → funds
24        expense_ratio_history          → funds
25        nfo_tracker                    standalone
26        fund_watchlist                 → users, funds
27        price_alerts                   → users, funds
28        mf_compare_sessions            → users
29        mf_holdings                    → portfolios, funds
30        mf_transactions                → portfolios, funds
31        mf_dividends                   → portfolios, funds
32        mf_holding_notes               → portfolios, funds
33        sector_rotation_cache          standalone
34        sector_rotation_history        standalone
35        sip_schedules                  → portfolios, funds
36        nps_schemes                    standalone master
37        nps_holdings                   → portfolios, nps_schemes
38        nps_transactions               → portfolios, nps_schemes
39        nps_nav_history                → nps_schemes
40        stock_master                   standalone master
41        stock_holdings                 → portfolios, stock_master
42        stock_transactions             → portfolios, stock_master
43        stock_dividends                → portfolios, stock_master
44        stock_corporate_actions        → stock_master
45        stock_fundamentals_history     → stock_master (soft)
46        stock_screener_filters         → users
47        fd_accounts                    → portfolios
48        fd_interest_accruals           → fd_accounts
49        fd_maturity_alerts             → users, fd_accounts
50        fd_market_rates                standalone
51        fd_interest_log                → users, fd_accounts
52        savings_accounts               → portfolios
53        savings_interest               → savings_accounts
54        bank_accounts                  → portfolios
55        bank_balance_history           → bank_accounts
56        epf_accounts                   → portfolios
57        po_schemes                     → portfolios
58        insurance_policies             → portfolios
59        loan_accounts                  → portfolios
60        investment_goals               → portfolios
61        goal_contributions             → investment_goals
62        goal_buckets                   → users
63        goal_fund_links                → goal_buckets, funds
64        rebalancing_targets            → portfolios
65        investment_calendar_events     → users (nullable)
66        net_worth_snapshots            → users
67        sgb_holdings                   → portfolios
68        sgb_interest_log               → sgb_holdings, portfolios
69        gold_price_cache               standalone
70        crypto_holdings                → portfolios
71        crypto_transactions            → portfolios
72        crypto_price_cache             standalone
73        vda_transactions               → portfolios
74        vda_tds_log                    → portfolios
75        esop_grants                    → portfolios
76        esop_vesting_events            → esop_grants
77        esop_exercise_log              → esop_grants, esop_vesting_events
78        reits_invits_master            standalone master
79        reits_invits                   → portfolios, users
80        reits_invits_transactions      → reits_invits, portfolios
81        reits_invits_distributions     → reits_invits
82        etf_master                     standalone master
83        etf_holdings                   → portfolios, etf_master
84        etf_transactions               → portfolios, etf_master
85        pms_holdings                   → portfolios, users
86        pms_transactions               → pms_holdings, portfolios
87        pms_nav_history                → pms_holdings
88        us_stock_master                standalone master
89        us_stock_holdings              → portfolios, us_stock_master
90        us_stock_transactions          → portfolios, us_stock_master
91        notifications                  → users
92        notification_prefs             → users
93        ai_chat_history                → users
94        ai_portfolio_reviews           → users
95        ai_anomalies                   → users
96        zerodha_credentials            → users
97        zerodha_sync_log               → users
98        zerodha_holdings_raw           → users
99        groww_api_credentials          → users
100       groww_sync_log                 → users, portfolios
101       investment_journal             → users
102       credit_cards                   → users
103       nudge_dismissals               → users
104       spending_discipline            → users
```

---

## Foreign Key Dependency Graph

```
                           ┌──────────┐
                           │  users   │  ← ROOT
                           └────┬─────┘
            ┌──────────────────┼──────────────────────────────┐
            │                  │                              │
     ┌──────▼──────┐   ┌───────▼──────┐              ┌───────▼──────┐
     │  portfolios │   │  fund_houses │              │  nps_schemes │
     └──────┬──────┘   └───────┬──────┘              └──────┬───────┘
            │                  │                            │
    ┌───────┼──────────┐  ┌────▼────┐              ┌────────┼────────┐
    │       │          │  │  funds  │              │        │        │
    │       │          │  └────┬────┘         nps_      nps_    nps_nav_
  fd_    savings_   bank_      │            holdings  transactions  history
 accounts accounts accounts   │
    │       │          │      ├────────────────────────────────────────┐
    │       │          │      │                                        │
fd_interest savings_ bank_  ┌─┴────────────────────────────────────┐  │
 _accruals interest balance │  Child tables of funds (all have      │  │
            │      _history │  portfolio_id + fund_id FKs)          │  │
            │               │                                       │  │
            │         mf_holdings ─── mf_transactions               │  │
            │         mf_dividends   mf_holding_notes               │  │
            │         sip_schedules  fund_watchlist                 │  │
            │         price_alerts   nav_history                    │  │
            │         nav_proxy_cache fund_ratings                  │  │
            │         fund_stock_holdings fund_managers             │  │
            │         fund_overlap_cache expense_ratio_history      │  │
            │         nav_download_progress mf_compare_sessions     │  │
            │                                                       │  │
   ┌────────┴──────────────────────────────────────────────────┐   │  │
   │         Other child tables of portfolios                  │   │  │
   │                                                           │   │  │
   │  stock_holdings       stock_transactions   stock_dividends│   │  │
   │  epf_accounts         po_schemes           loan_accounts  │   │  │
   │  insurance_policies   investment_goals     rebalancing_   │   │  │
   │  sgb_holdings         crypto_holdings       targets       │   │  │
   │  crypto_transactions  vda_transactions     vda_tds_log    │   │  │
   │  esop_grants          pms_holdings         etf_holdings   │   │  │
   │  etf_transactions     us_stock_holdings    us_stock_txns  │   │  │
   │  groww_sync_log                                           │   │  │
   └───────────────────────────────────────────────────────────┘   │  │
                                                                    │  │
   ┌────────────────────────────────────────────────────────────────┘  │
   │  Second-level children (depend on tables above)                   │
   │                                                                    │
   │  fd_maturity_alerts ──── fd_accounts                              │
   │  fd_interest_log    ──── fd_accounts                              │
   │  goal_contributions ──── investment_goals                         │
   │  goal_fund_links    ──── goal_buckets + funds                     │
   │  esop_vesting_events─── esop_grants                              │
   │  esop_exercise_log  ──── esop_grants + esop_vesting_events        │
   │  sgb_interest_log   ──── sgb_holdings + portfolios               │
   │  pms_transactions   ──── pms_holdings + portfolios               │
   │  pms_nav_history    ──── pms_holdings                            │
   │  reits_invits_transactions ── reits_invits + portfolios          │
   │  reits_invits_distributions── reits_invits                       │
   └────────────────────────────────────────────────────────────────────┘
                                                            │
   ┌────────────────────────────────────────────────────────┘
   │  Standalone master tables (no parent FK)
   │
   │  stock_master ──── stock_holdings, stock_transactions,
   │                    stock_dividends, stock_corporate_actions
   │  etf_master   ──── etf_holdings, etf_transactions
   │  us_stock_master── us_stock_holdings, us_stock_transactions
   │  reits_invits_master (soft reference to reits_invits.symbol)
   └──────────────────────────────────────────────────────────
```

---

## Legacy Migration Files — What to Do With Them

| File | Status | Action |
|------|--------|--------|
| `01_schema_complete.sql` | Superseded | Archive — DO NOT run on fresh install |
| `04_fix_corrupted_data.sql` | Fixed | Columns now exist in `02_tables.sql` — safe to run to migrate existing data |
| `07_fund_returns.sql` through `45_db_indexes.sql` | Superseded | Archive — all changes merged into clean schema |
| `migrations/t113_migration.sql` through `tv12_migration.sql` | Superseded | Archive |
| `22_NAV_fix_run_only_if_needed.sql` | One-time data fix | Run only on existing DB that has corrupted NAV queue |
| `21_peak_nav_setup.sql` | Dangerous (DROP) | DO NOT run — `mf_peak_progress` now exists in `02_tables.sql` |
| `migrate.php` | Keep but update | Update `MIGRATIONS_DIR` path; the migration tracker logic is sound |

---

## Updating `migrate.php` for Clean Schema

The existing `migrate.php` looks for files in `database/migrations/`. After deploying the clean schema:

1. Move the 5 clean files to `database/clean/`
2. Update `migrate.php`:

```php
// OLD
define('MIGRATIONS_DIR', __DIR__ . '/migrations/');

// NEW — point to the ordered clean install files
define('MIGRATIONS_DIR', __DIR__ . '/clean/');
define('MIGRATIONS_ORDER', [
    '01_database_create.sql',
    '02_tables.sql',
    '03_indexes.sql',
    '04_foreign_keys.sql',
    '05_seed_data.sql',
]);
```

3. Record all 5 files in `migration_log` after first successful run so future incremental migrations don't re-run them.
