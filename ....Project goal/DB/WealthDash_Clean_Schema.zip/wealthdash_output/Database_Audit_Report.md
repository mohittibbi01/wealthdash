# WealthDash — Complete Database Audit Report
**Generated:** 2026-06-04  
**Auditor:** Senior DB Architect  
**Files Analysed:** 126 SQL files + 1 PHP migration runner  
**Total Unique Tables Defined:** 209 (across all files, including migrations)  
**Core Production Tables:** 97  

---

## PHASE 1 — Database Structure Summary

### Group 1: Authentication & Users

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `users` | Core user accounts | 13 | `id` | — | `uq_email`, `idx_users_role` | ✅ |
| `sessions` | Web sessions | 7 | `id` (varchar) | `users.id` | `idx_sess_user`, `idx_sess_activity` | ❌ |
| `login_attempts` | Brute-force logging | 5 | `id` | — | `idx_la_email`, `idx_la_ip`, `idx_la_time` | ✅ |
| `otp_tokens` | OTP/2FA tokens | 7 | `id` | `users.id` | `idx_otp_user`, `idx_otp_token` | ✅ |
| `password_resets` | Password reset tokens | 6 | `id` | — | `uq_pr_token`, `idx_pr_email` | ✅ |
| `google_auth` | Google OAuth tokens | 8 | `id` | `users.id` | `uq_google_id`, `idx_gauth_user` | ✅ |
| `user_sessions` | Extended session security (t387) | 9 | `id` | — | `idx_user`, `idx_token`, `idx_active` | ✅ |

### Group 2: Portfolio Core

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `portfolios` | User portfolio containers | 7 | `id` | `users.id` | `idx_portfolio_user` | ✅ |
| `import_logs` | CSV/CAS import history | 12 | `id` | `users.id` | `idx_il_user`, `idx_il_portfolio` | ✅ |
| `app_settings` | Global config key-value | 5 | `id` | — | `uq_key` | ✅ |
| `audit_log` | Action audit trail | 9 | `id` | — | `idx_audit_user`, `idx_audit_entity`, `idx_audit_created` | ✅ |
| `migration_log` | Migration tracking | 7 | `id` | — | `uq_filename` | ✅ |

### Group 3: Mutual Funds

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `fund_houses` | AMC master (36 seeded) | 4 | `id` | — | `uq_fh_name` | ✅ |
| `funds` | MF scheme master (~50+ cols after ALTERs) | 50+ | `id` | `fund_houses.id` | Multiple | ✅ |
| `nav_history` | Daily NAV history | 4 | `id` (bigint) | `funds.id` | `uq_nav`, `idx_nav_date` | ✅ |
| `mf_holdings` | Portfolio MF positions | 17 | `id` | `portfolios.id`, `funds.id` | `uq_mfh`, `idx_mfh_fund` | ✅ |
| `mf_transactions` | Buy/sell/SIP txns | 13 | `id` | `portfolios.id`, `funds.id` | 4 indexes | ✅ |
| `mf_dividends` | IDCW dividend history | 11 | `id` | `portfolios.id`, `funds.id` | 3 indexes | ✅ |
| `mf_holding_notes` | Personal notes per folio | 7 | `id` | `portfolios.id`, `funds.id` | `uq_note` | ✅ |
| `mf_peak_progress` | Peak NAV tracker progress | 5 | `scheme_code` | — | — | ❌ |
| `nav_download_progress` | NAV download queue | 8 | `id` | `funds.id` | `uq_ndp_fund`, `idx_ndp_status` | ✅ |
| `nav_proxy_cache` | Server-side NAV chart cache | 6 | `fund_id+period` | `funds.id` | `idx_npc_cached_at` | ❌ |
| `nfo_tracker` | NFO open/upcoming tracker | 16 | `id` | — | 3 indexes | ✅ |
| `fund_watchlist` | User watchlisted funds | 7 | `id` | `users.id`, `funds.id` | `uq_user_fund` | ✅ |
| `price_alerts` | NAV price alerts | 8 | `id` | `users.id`, `funds.id` | `idx_pa_user`, `idx_pa_fund` | ✅ |
| `fund_ratings` | Star ratings (1–5) | 6 | `id` | `funds.id` | `uq_fr_fund`, `idx_fr_stars` | ✅ |
| `fund_stock_holdings` | AMFI monthly disclosure | 9 | `id` | `funds.id` | 4 indexes | ✅ |
| `fund_overlap_cache` | Pairwise fund overlap % | 6 | Composite | — | `idx_oc_a`, `idx_oc_b` | ❌ |
| `fund_managers` | Manager track record | 7 | `id` | `funds.id` | 3 indexes | ✅ |
| `expense_ratio_history` | Monthly TER snapshots | 7 | `id` | `funds.id` | `uq_exp_fund_month` | ✅ |
| `mf_compare_sessions` | Saved fund comparisons | 5 | `id` | — | `uq_user` | ✅ |
| `mf_saved_screens` | Saved screener filters | — | `id` | — | — | ✅ |
| `sector_rotation_cache` | Sector performance cache | 10 | `id` | `funds.id` | `uq_sr_sector` | ✅ |
| `sector_rotation_history` | Sector trend time-series | 7 | `id` | — | `uq_srh_sector_date` | ✅ |

### Group 4: NPS

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `nps_schemes` | NPS PFM scheme master (63 seeded) | 17 | `id` | — | `uq_nps_code`, 2 indexes | ✅ |
| `nps_holdings` | NPS portfolio positions | 14 | `id` | `portfolios.id`, `nps_schemes.id` | `uq_npsh` | ✅ |
| `nps_transactions` | NPS buy/switch txns | 10 | `id` | `portfolios.id`, `nps_schemes.id` | 3 indexes | ✅ |
| `nps_nav_history` | Daily NPS NAV | 5 | `id` | `nps_schemes.id` | `uq_nps_nav` | ✅ |

### Group 5: Stocks

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `stock_master` | NSE/BSE stock master (50+ cols after ALTER) | 50+ | `id` | — | `uq_stock`, 2 indexes | ✅ |
| `stock_holdings` | Portfolio stock positions | 13 | `id` | `portfolios.id`, `stock_master.id` | `uq_sh` | ✅ |
| `stock_transactions` | Buy/sell txns | 10 | `id` | `portfolios.id`, `stock_master.id` | 3 indexes | ✅ |
| `stock_dividends` | Dividend records | 9 | `id` | `portfolios.id`, `stock_master.id` | 2 indexes | ✅ |
| `stock_corporate_actions` | Splits/bonuses | 8 | `id` | `stock_master.id` | `idx_sca_stock` | ✅ |
| `stock_screener_filters` | Saved stock screener filters | 4 | `id` | — | `idx_ssf_user` | ✅ |
| `stock_fundamentals_history` | Quarterly fundamental snapshots | 18 | `id` | — | `uq_sfh_stock_period` | ✅ |

### Group 6: Fixed Income

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `fd_accounts` | Fixed deposit accounts | 18 | `id` | `portfolios.id` | `idx_fd_portfolio`, `idx_fd_maturity` | ✅ |
| `fd_interest_accruals` | FD interest accruals | 6 | `id` | `fd_accounts.id` | `idx_fdia_fd` | ✅ |
| `fd_maturity_alerts` | FD maturity notifications | 8 | `id` | — | `uk_fd_days` | ✅ |
| `fd_market_rates` | Bank FD rates reference | 8 | `id` | — | — | ✅ |
| `fd_interest_log` | FD interest credit log | 7 | `id` | — | `idx_user`, `idx_date` | ✅ |
| `savings_accounts` | Savings bank accounts | 11 | `id` | `portfolios.id` | `idx_sa_portfolio` | ✅ |
| `savings_interest` | Savings interest log | 8 | `id` | `savings_accounts.id` | `idx_si_acct_date` | ✅ |
| `savings_interest_log` | Legacy interest log | 6 | `id` | `savings_accounts.id` | `idx_sil_account` | ✅ |
| `bank_accounts` | Bank account balances | 12 | `id` | `portfolios.id` | `idx_ba_portfolio` | ✅ |
| `bank_balance_history` | Balance snapshots | 4 | `id` | `bank_accounts.id` | `uq_bbh`, `idx_bbh_date` | ✅ |
| `po_schemes` | Post Office schemes (PPF/NSC etc.) | 19 | `id` | `portfolios.id` | `idx_po_portfolio`, `idx_po_type` | ✅ |

### Group 7: Goals & Planning

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `investment_goals` | Goal-based investing | 19 | `id` | `portfolios.id` | `idx_ig_portfolio` | ✅ |
| `goal_contributions` | Goal contribution log | 6 | `id` | `investment_goals.id` | `idx_gc_goal` | ✅ |
| `goal_buckets` | Simplified goal buckets | 12 | `id` | `users.id` | `idx_gb_user` | ✅ |
| `goal_fund_links` | Fund↔goal links | 6 | `id` | `goal_buckets.id` | `idx_gfl_goal` | ✅ |
| `goals` | Extended goals (t139) | 12 | `id` | — | `idx_user` | ✅ |
| `goal_holdings` | Assets linked to goals | 8 | `id` | — | `uk_goal_asset` | ✅ |
| `rebalancing_targets` | Asset class allocation targets | 6 | `id` | `portfolios.id` | `uq_rebal_portfolio_asset` | ✅ |
| `investment_calendar_events` | FY tax/investment calendar | 11 | `id` | `users.id` | 3 indexes | ✅ |
| `retirement_plans` | Retirement planning | — | `id` | — | — | ✅ |

### Group 8: Alternative Assets

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `sgb_holdings` | Sovereign Gold Bonds | 21 | `id` | — | 4 indexes | ✅ |
| `sgb_interest_log` | SGB coupon payments | 9 | `id` | — | 3 indexes | ✅ |
| `gold_price_cache` | Gold spot price cache | 7 | `id` | — | `idx_gold_cache_date` | ✅ |
| `physical_gold` | Physical gold tracker | — | `id` | — | — | ✅ |
| `epf_accounts` | EPF account balance | 13 | `id` | `portfolios.id` | `idx_epf_portfolio` | ✅ |
| `loan_accounts` | Loan/EMI tracker | 17 | `id` | `portfolios.id` | 2 indexes | ✅ |
| `insurance_policies` | Insurance portfolio | 18 | `id` | `portfolios.id` | 2 indexes | ✅ |
| `crypto_holdings` | Crypto portfolio | 15 | `id` | — | `idx_portfolio`, `idx_coin` | ✅ |
| `crypto_transactions` | Crypto buy/sell txns | 13 | `id` | — | 3 indexes | ✅ |
| `crypto_price_cache` | Crypto price cache | 8 | `coin_id` | — | — | ❌ |
| `vda_transactions` | VDA tax (Sec 115BBH) | 33 | `id` | `portfolios.id` | 6 indexes | ✅ |
| `vda_tds_log` | VDA TDS per FY | 9 | `id` | — | `uq_vda_tds` | ✅ |
| `reits_invits` | REIT/InvIT holdings | 19 | `id` | — | 3 indexes | ✅ |
| `reits_invits_transactions` | REIT txns | 12 | `id` | — | 3 indexes | ✅ |
| `reits_invits_distributions` | REIT distributions | 13 | `id` | — | 3 indexes | ✅ |
| `reits_invits_master` | REIT/InvIT universe | 9 | `id` | — | `idx_type` | ✅ |
| `etf_master` | ETF universe | 26 | `id` | — | `uq_etf_symbol` | ✅ |
| `etf_holdings` | ETF portfolio | 10 | `id` | — | `uq_eh_portfolio_etf` | ✅ |
| `etf_transactions` | ETF txns | 11 | `id` | — | 3 indexes | ✅ |
| `esop_grants` | ESOP/RSU grants | 22 | `id` | — | 3 indexes | ✅ |
| `esop_vesting_events` | Vesting schedule | 16 | `id` | — | 3 indexes | ✅ |
| `esop_exercise_log` | Exercise log | 14 | `id` | — | 2 indexes | ✅ |
| `pms_holdings` | PMS/AIF investments | 28 | `id` | — | 4 indexes | ✅ |
| `pms_transactions` | PMS txns | 11 | `id` | `pms_holdings.id` | 4 indexes | ✅ |
| `pms_nav_history` | PMS NAV history | 5 | `id` | `pms_holdings.id` | `uq_nav` | ✅ |
| `us_stock_master` | NYSE/NASDAQ stocks | 23 | `id` | — | `uq_usm_symbol` | ✅ |
| `us_stock_holdings` | US stock positions | 15 | `id` | — | `uq_ush_portfolio_stock` | ✅ |
| `us_stock_transactions` | US stock txns | 14 | `id` | — | 3 indexes | ✅ |

### Group 9: Integrations

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `zerodha_credentials` | Kite API keys (encrypted) | 15 | `id` | — | `uq_zerodha_user` | ✅ |
| `zerodha_sync_log` | Kite sync audit | 12 | `id` | — | `idx_zsync_user` | ✅ |
| `zerodha_holdings_raw` | Raw Kite holdings | 20 | `id` | — | `uq_zh_user_symbol` | ✅ |
| `zerodha_positions_raw` | Raw Kite positions | 18 | `id` | — | `uq_zpos_user_sym` | ✅ |
| `zerodha_instruments` | Instrument cache | 15 | `id` | — | `uq_zi_token` | ✅ |
| `zerodha_orders` | Order tracking | 22 | `id` | — | `uq_zo_order` | ✅ |
| `zerodha_margins` | Margin data | 9 | `id` | — | `uq_zm_user_seg` | ✅ |
| `zerodha_quote_snapshots` | Quote snapshots | 14 | `id` | — | `uq_zqs_user_sym` | ✅ |
| `zerodha_gtt` | GTT orders | — | `id` | — | — | ✅ |
| `groww_api_credentials` | Groww OAuth tokens | 12 | `id` | — | `idx_user` | ✅ |
| `groww_sync_log` | Groww sync audit | 11 | `id` | — | `idx_user` | ✅ |
| `groww_mf_holdings_raw` | Raw Groww MF holdings | 13 | `id` | — | `idx_user` | ✅ |
| `groww_stock_holdings_raw` | Raw Groww stock holdings | 12 | `id` | — | `idx_user` | ✅ |

### Group 10: AI & Notifications

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `notifications` | User notifications | 8 | `id` | `users.id` | 3 indexes | ✅ |
| `notification_prefs` | Notification settings | 9 | `user_id` | `users.id` | — | ❌ |
| `ai_chat_history` | AI assistant chat | 6 | `id` | — | `idx_user_ctx` | ✅ |
| `ai_portfolio_reviews` | AI monthly reviews | 11 | `id` | — | `uk_user_month` | ✅ |
| `ai_anomalies` | AI-detected anomalies | 11 | `id` | — | 3 indexes | ✅ |
| `rate_limit_buckets` | API rate limiting | 3 | `bucket_key` | — | `idx_window` | ❌ |

### Group 11: Utility

| Table | Purpose | Cols | PK | FK | Indexes | AI |
|-------|---------|------|----|----|---------|-----|
| `net_worth_snapshots` | Monthly NW timeline | 11 | `id` | `users.id` | `uq_nws` | ✅ |
| `sip_schedules` | SIP/SWP plans | 20+ | `id` | `portfolios.id`, `funds.id` | 2 indexes | ✅ |
| `investment_journal` | Personal investment diary | 13 | `id` | — | `idx_user_date` | ✅ |
| `credit_cards` | Credit card tracker | 14 | `id` | — | `idx_user` | ✅ |
| `nudge_dismissals` | Dismissed nudges | 4 | `id` | — | `uk_user_nudge` | ✅ |
| `spending_discipline` | Savings discipline target | 5 | `id` | — | `uk_user` | ✅ |

---

## PHASE 2 — Schema Drift Detection

### ⚠️ Critical: 25 Tables Defined Multiple Times

The following tables have **duplicate `CREATE TABLE` definitions** across different files. While `IF NOT EXISTS` prevents errors, it hides the fact that later migrations add columns that the earlier definition does not contain.

| Table | Defined In (Conflict Files) | Risk |
|-------|-----------------------------|------|
| `crypto_holdings` | `38_crypto_holdings.sql` (portfolio_id schema) + `41_pending_tasks.sql` (user_id schema) | **HIGH — schema mismatch between files** |
| `crypto_transactions` | `38_crypto_holdings.sql` + `41_pending_tasks.sql` | **HIGH — different column sets** |
| `notifications` | `10_notifications.sql` + `41_pending_tasks.sql` | MEDIUM — different column structure |
| `import_logs` | `01_schema_complete.sql` + `17_expense_history_import_log.sql` | MEDIUM — different columns |
| `mf_dividends` | `01_schema_complete.sql` + `14_mf_dividends_notes.sql` | MEDIUM — `nav_before`/`nav_after` missing in v1 |
| `sgb_holdings` | `29_sgb_holdings.sql` + `migrations/t113_migration.sql` | MEDIUM — extra columns in t113 |
| `sgb_interest_log` | `29_sgb_holdings.sql` + `migrations/t113_migration.sql` | MEDIUM — extra columns in t113 |
| `gold_price_cache` | `29_sgb_holdings.sql` + `migrations/t113_migration.sql` | LOW |
| `nav_download_progress` | `01_schema_complete.sql` + `42_fix_nav_queue.sql` | MEDIUM — different column names |
| `mf_peak_progress` | `01_schema_complete.sql` + `21_peak_nav_setup.sql` (DROP + recreate) | **HIGH — 21 DROPs the table** |
| `migration_log` | `migrate.php` inline + `migrations/t417_migration_log.sql` | LOW |
| `fund_managers` | `16_fund_managers.sql` + inside `migrations/` | LOW |
| `fund_ratings` | `23_fund_ratings.sql` + inside `migrations/` | LOW |
| `goal_buckets` | `01_schema_complete.sql` + `33_goal_buckets.sql` (TODO stub) | LOW |
| `insurance_policies` | `01_schema_complete.sql` + `32_insurance_policies.sql` (TODO stub) | LOW |
| `real_estate` | stub + actual migration | LOW |
| `esop_grants` | `31_esop_grants.sql` stub + `t117_migration.sql` | MEDIUM |
| `esop_vesting_events` | `39_esop_vesting_events.sql` stub + `t117_migration.sql` | MEDIUM |
| `ai_portfolio_reviews` | `41_pending_tasks.sql` + `migrations/` | LOW |
| `goals` | `41_pending_tasks.sql` + goal migrations | LOW |
| `po_payout_log` | Multiple migration files | LOW |
| `investment_journal` | `44_v48_sprint_tables.sql` + `34_investment_journal.sql` stub | LOW |
| `crypto_watchlist` | Multiple files | LOW |

---

### Schema Drift Timeline: `funds` Table (Most Modified Table)

The `funds` table was modified by **11 different files**. Timeline:

```
01_schema_complete.sql — BASE (26 columns):
  id, scheme_code, isin, isin_reinvest, fund_house_id, scheme_name,
  scheme_type, scheme_category, scheme_sub_category, nav, nav_date,
  return_1y, return_3y, return_5y, return_since, aum_cr, expense_ratio,
  exit_load_text, exit_load_pct, exit_load_days, risk_level, benchmark,
  fund_manager, min_sip_amount, min_lumpsum, is_active, created_at, updated_at

07_fund_returns.sql — ADDED 10 columns:
  returns_1y, returns_3y, returns_5y, returns_10y, sharpe_ratio,
  max_drawdown, max_drawdown_date, category_avg_1y, category_avg_3y,
  returns_updated_at
  ⚠️ CONFLICT: returns_1y duplicates return_1y (different naming convention!)

12_alpha_beta.sql — ADDED 5 columns:
  alpha, beta, standard_deviation, r_squared, alpha_updated_at

13_screener_metrics.sql — ADDED 5 columns:
  sortino_ratio, max_drawdown_from_nav, category_avg_5y,
  category_rank_1y, category_total

15_fund_holdings.sql — ADDED 1 column:
  style_box (ENUM)

16_fund_managers.sql — ADDED 2 columns:
  manager_since, fund_manager (⚠️ fund_manager already existed in base!)

23_fund_ratings.sql — ADDED 2 columns:
  wd_stars (INT)

24_style_box.sql — ADDED 6 columns:
  style_size, style_value, style_box (GENERATED), style_drift_note,
  avg_market_cap_cr, avg_pe_ratio, style_updated_at
  ⚠️ CONFLICT: style_box added twice (15 + 24) — different data types!

42_fix_nav_queue.sql — ADDED 1 column:
  nav_date (already existed — safe no-op via IF NOT EXISTS)

45_db_indexes.sql — ADDED 6 indexes:
  idx_fund_cat_subcat, idx_fund_active, idx_fund_fund_type,
  idx_funds_returns_1y, idx_funds_returns_3y, idx_funds_returns_5y
  ⚠️ idx_fund_fund_type references fund_type column — NOT DEFINED ANYWHERE

FINAL STATE: ~55 columns
```

---

### Schema Drift Timeline: `mf_holdings` Table

```
01_schema_complete.sql — BASE (17 columns):
  id, portfolio_id, fund_id, folio_number, platform, units, avg_nav,
  invested_amount, current_value, gain_loss, xirr, sip_active, swp_active,
  first_investment_date, last_transaction_date, notes, created_at, updated_at

04_fix_corrupted_data.sql — REFERENCES missing columns:
  investment_fy, withdrawable_fy, withdrawable_date, ltcg_date, lock_in_date
  ⚠️ These columns are referenced but NEVER defined in any CREATE TABLE!
  This is the PRIMARY reason the project fails on a fresh install.

45_db_indexes.sql — ADDS indexes:
  idx_mfh_portfolio_status references "status" column
  ⚠️ "status" column does NOT exist in mf_holdings!
  idx_mfh_portfolio_fund — valid
```

---

### Schema Drift Timeline: `stock_master` Table

```
01_schema_complete.sql — BASE (14 columns):
  id, exchange, symbol, company_name, isin, sector, industry,
  current_price, prev_close, day_change_pct, market_cap, pe_ratio,
  price_updated_at, created_at

t431_migration.sql — ADDED ~31 columns:
  pb_ratio, ps_ratio, ev_ebitda, enterprise_value, eps_ttm, eps_growth_yoy,
  revenue_ttm, net_profit_ttm, roe, roce, roa, debt_to_equity, current_ratio,
  quick_ratio, interest_coverage, dividend_yield, dividend_payout_ratio,
  book_value, face_value, high_52, low_52, beta, avg_volume_30d,
  shares_outstanding, float_shares, promoter_holding_pct, fii_holding_pct,
  dii_holding_pct, public_holding_pct, fundamentals_source, fundamentals_updated_at
  ⚠️ pe_ratio and market_cap duplicated in both base and ALTER
```

---

### Schema Drift Timeline: `sip_schedules` Table

```
01_schema_complete.sql — BASE (18 columns):
  id, portfolio_id, asset_type, fund_id, stock_id, nps_scheme_id,
  folio_number, sip_amount, swp_amount, sip_type, frequency, sip_day,
  start_date, end_date, platform, is_active, notes, created_at, updated_at

18_rebalancing_stepup.sql — ADDED 4 columns:
  step_up_pct, step_up_frequency, step_up_next_date, step_up_max_amount
```

---

### Schema Drift Timeline: `import_logs` Table (Conflicting Definitions)

```
01_schema_complete.sql — Definition A (12 columns):
  id, user_id, portfolio_id, import_type, filename, rows_total,
  rows_success, rows_failed, status (ENUM), error_log, created_at, completed_at

17_expense_history_import_log.sql — Definition B (12 columns):
  id, user_id, filename, format (ENUM ≠ import_type), imported_count,
  failed_count, skipped_count, status (ENUM ≠), error_log, rollback_data,
  imported_at

⚠️ CRITICAL CONFLICT: Same table name, entirely different column sets.
   Definition A wins because it runs first (01_schema_complete.sql).
   Definition B's columns (format, imported_count, rollback_data) are silently missing.
```

---

### Schema Drift Timeline: `crypto_holdings` (Schema Mismatch)

```
38_crypto_holdings.sql — portfolio_id schema (CORRECT, runs first):
  portfolio_id INT UNSIGNED NOT NULL (FK → portfolios)
  coin_id, coin_symbol, coin_name, quantity, avg_buy_price, total_invested,
  exchange, wallet_address

41_pending_tasks.sql — user_id schema (WRONG, runs second but skipped):
  user_id INT UNSIGNED NOT NULL (no FK to portfolios!)
  Different columns: current_price, current_value_inr, invested_inr,
  is_active, price_updated_at

⚠️ 41 silently skips due to IF NOT EXISTS.
   Dead file api/crypto/crypto.php references user_id schema (broken).
   Live file api/crypto/crypto_list.php uses portfolio_id schema (correct).
```

---

## PHASE 2 CRITICAL FINDINGS

### Missing Columns Referenced by Migrations

These columns are **used in SQL UPDATE/ALTER statements but never defined** in any CREATE TABLE:

| Column | Table | Used In File | Impact |
|--------|-------|--------------|--------|
| `investment_fy` | `mf_holdings` | `04_fix_corrupted_data.sql` | Fix script silently no-ops; corrupted data remains |
| `withdrawable_date` | `mf_holdings` | `04_fix_corrupted_data.sql` | Same |
| `withdrawable_fy` | `mf_holdings` | `04_fix_corrupted_data.sql` | Same |
| `ltcg_date` | `mf_holdings` | `04_fix_corrupted_data.sql` | Same |
| `lock_in_date` | `mf_holdings` | `04_fix_corrupted_data.sql` | Same |
| `min_ltcg_days` | `funds` | `04_fix_corrupted_data.sql` | JOIN fails silently |
| `status` | `mf_holdings` | `45_db_indexes.sql` | Index creation fails |
| `status` | `stock_holdings` | `45_db_indexes.sql` | Index creation fails |
| `status` | `savings_accounts` | `45_db_indexes.sql` | Index creation fails |
| `fund_type` | `funds` | `45_db_indexes.sql` | Index creation fails |
| `premium_due_date` | `insurance_policies` | `45_db_indexes.sql` | Index creation fails |
| `from_date` | `nav_download_progress` | `22_NAV_fix_run_only_if_needed.sql` | Update fails |
| `scheme_code` | `nav_download_progress` | `22_NAV_fix_run_only_if_needed.sql` | JOIN fails |
| `style_box` | `funds` | Added twice in files 15 AND 24 as different types | Second ADD silently fails |
| `fund_manager` | `funds` | Added in file 16 but already in base | Silently no-ops |

### TODO Stubs (Empty Tables Referenced by App Code)

Files 27–37 (except 29, 38) contain only `SELECT` statements with no actual schema:

| File | Table Stub | Used By |
|------|-----------|---------|
| `27_54ec_bonds.sql` | `54ec_bonds` | Tax module |
| `28_loans.sql` | `loans` | Loan tracker |
| `30_bond_holdings.sql` | `bond_holdings` | Bond tracker |
| `31_esop_grants.sql` | `esop_grants` | ESOP (actual in t117) |
| `32_insurance_policies.sql` | `insurance_policies` | Insurance (in 01_schema) |
| `33_goal_buckets.sql` | `goal_buckets` | Goals (in 01_schema) |
| `34_investment_journal.sql` | `investment_journal` | Journal (in 44_v48) |
| `35_referrals.sql` | `referrals` | Referral system |
| `36_automation_rules.sql` | `automation_rules` | Automation |
| `37_real_estate.sql` | `real_estate` | Real estate tracker |
| `39_esop_vesting_events.sql` | `esop_vesting_events` | ESOP (in t117) |
| `40_cibil_history.sql` | `cibil_history` | Credit score tracker |

---
