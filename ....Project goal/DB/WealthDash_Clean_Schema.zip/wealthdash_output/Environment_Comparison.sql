-- ============================================================
-- WealthDash — Environment Comparison Script
-- File: Environment_Comparison.sql
-- Generated: 2026-06-04
-- ============================================================
-- PURPOSE:
--   Run this script on BOTH PCs and save the output to:
--     pc_a_environment.txt
--     pc_b_environment.txt
--   Then diff the two files to find discrepancies.
--
-- USAGE:
--   mysql -u root -p wealthdash < Environment_Comparison.sql > pc_a_environment.txt
-- ============================================================

USE `wealthdash`;

-- ============================================================
-- BLOCK 1: MySQL Server Variables
-- ============================================================
SELECT '====== BLOCK 1: SERVER VARIABLES ======' AS report_section;

SELECT
  'mysql_version'         AS variable_name, @@version                       AS value UNION ALL
SELECT 'mysql_version_comment',              @@version_comment               UNION ALL
SELECT 'operating_system',                   @@version_compile_os            UNION ALL
SELECT 'datadir',                            @@datadir                       UNION ALL
SELECT 'sql_mode',                           @@global.sql_mode               UNION ALL
SELECT 'character_set_server',               @@character_set_server          UNION ALL
SELECT 'character_set_database',             @@character_set_database        UNION ALL
SELECT 'collation_server',                   @@collation_server              UNION ALL
SELECT 'collation_database',                 @@collation_database            UNION ALL
SELECT 'time_zone',                          @@global.time_zone              UNION ALL
SELECT 'system_time_zone',                   @@system_time_zone              UNION ALL
SELECT 'default_storage_engine',             @@default_storage_engine        UNION ALL
SELECT 'lower_case_table_names',             @@lower_case_table_names        UNION ALL
SELECT 'max_allowed_packet_mb',              @@max_allowed_packet/1024/1024  UNION ALL
SELECT 'innodb_file_per_table',              @@innodb_file_per_table         UNION ALL
SELECT 'innodb_strict_mode',                 @@innodb_strict_mode            UNION ALL
SELECT 'innodb_buffer_pool_size_mb',         @@innodb_buffer_pool_size/1024/1024 UNION ALL
SELECT 'wait_timeout',                       @@wait_timeout                  UNION ALL
SELECT 'interactive_timeout',                @@interactive_timeout           UNION ALL
SELECT 'foreign_key_checks',                 @@foreign_key_checks            UNION ALL
SELECT 'unique_checks',                      @@unique_checks                 UNION ALL
SELECT 'autocommit',                         @@autocommit                    UNION ALL
SELECT 'tx_isolation',                       @@tx_isolation                  UNION ALL
SELECT 'explicit_defaults_for_timestamp',    @@explicit_defaults_for_timestamp UNION ALL
SELECT 'NO_ZERO_DATE_in_sql_mode',
  CASE WHEN @@sql_mode LIKE '%NO_ZERO_DATE%' THEN 'YES' ELSE 'NO' END       UNION ALL
SELECT 'STRICT_TRANS_TABLES_in_sql_mode',
  CASE WHEN @@sql_mode LIKE '%STRICT_TRANS_TABLES%' THEN 'YES' ELSE 'NO' END UNION ALL
SELECT 'ONLY_FULL_GROUP_BY_in_sql_mode',
  CASE WHEN @@sql_mode LIKE '%ONLY_FULL_GROUP_BY%' THEN 'YES' ELSE 'NO' END;

-- ============================================================
-- BLOCK 2: Database-Level Settings
-- ============================================================
SELECT '====== BLOCK 2: DATABASE SETTINGS ======' AS report_section;

SELECT
  SCHEMA_NAME,
  DEFAULT_CHARACTER_SET_NAME AS charset,
  DEFAULT_COLLATION_NAME     AS collation
FROM information_schema.SCHEMATA
WHERE SCHEMA_NAME = DATABASE();

-- ============================================================
-- BLOCK 3: Table Engine & Charset Summary
-- ============================================================
SELECT '====== BLOCK 3: TABLE ENGINE / CHARSET ======' AS report_section;

SELECT
  ENGINE,
  TABLE_COLLATION,
  COUNT(*) AS table_count
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_TYPE = 'BASE TABLE'
GROUP BY ENGINE, TABLE_COLLATION
ORDER BY table_count DESC;

-- ============================================================
-- BLOCK 4: Table Row Counts
-- Useful for verifying data parity between PCs
-- ============================================================
SELECT '====== BLOCK 4: TABLE ROW COUNTS ======' AS report_section;

SELECT
  TABLE_NAME,
  TABLE_ROWS AS approx_rows,
  ROUND(DATA_LENGTH/1024/1024, 2) AS data_mb,
  ROUND(INDEX_LENGTH/1024/1024, 2) AS index_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;

-- ============================================================
-- BLOCK 5: Column Count Per Table
-- Diff this between PCs to find missing columns
-- ============================================================
SELECT '====== BLOCK 5: COLUMN COUNT PER TABLE ======' AS report_section;

SELECT
  TABLE_NAME,
  COUNT(*) AS column_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
GROUP BY TABLE_NAME
ORDER BY TABLE_NAME;

-- ============================================================
-- BLOCK 6: All Indexes
-- Diff this to find missing indexes
-- ============================================================
SELECT '====== BLOCK 6: ALL INDEXES ======' AS report_section;

SELECT
  TABLE_NAME,
  INDEX_NAME,
  NON_UNIQUE,
  SEQ_IN_INDEX,
  COLUMN_NAME,
  INDEX_TYPE
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX;

-- ============================================================
-- BLOCK 7: All Foreign Keys
-- Diff this to find missing FK constraints
-- ============================================================
SELECT '====== BLOCK 7: ALL FOREIGN KEYS ======' AS report_section;

SELECT
  kcu.TABLE_NAME          AS child_table,
  kcu.COLUMN_NAME         AS child_column,
  kcu.CONSTRAINT_NAME     AS fk_name,
  kcu.REFERENCED_TABLE_NAME   AS parent_table,
  kcu.REFERENCED_COLUMN_NAME  AS parent_column,
  rc.UPDATE_RULE,
  rc.DELETE_RULE
FROM information_schema.KEY_COLUMN_USAGE AS kcu
JOIN information_schema.REFERENTIAL_CONSTRAINTS AS rc
  ON rc.CONSTRAINT_NAME   = kcu.CONSTRAINT_NAME
  AND rc.CONSTRAINT_SCHEMA = kcu.TABLE_SCHEMA
WHERE kcu.TABLE_SCHEMA = DATABASE()
  AND kcu.REFERENCED_TABLE_NAME IS NOT NULL
ORDER BY child_table, fk_name;

-- ============================================================
-- BLOCK 8: Tables with Non-Standard Collation
-- These will cause comparison issues between PCs
-- ============================================================
SELECT '====== BLOCK 8: NON-STANDARD COLLATION TABLES ======' AS report_section;

SELECT
  t.TABLE_NAME,
  t.TABLE_COLLATION,
  CASE
    WHEN t.TABLE_COLLATION = 'utf8mb4_unicode_ci' THEN '✅ Standard'
    WHEN t.TABLE_COLLATION LIKE 'utf8mb4%' THEN '⚠️  utf8mb4 variant'
    WHEN t.TABLE_COLLATION LIKE 'utf8%' THEN '⚠️  utf8 (not mb4) — emoji will break'
    ELSE '❌ Wrong charset — fix required'
  END AS verdict
FROM information_schema.TABLES t
WHERE t.TABLE_SCHEMA = DATABASE()
  AND t.TABLE_TYPE = 'BASE TABLE'
ORDER BY verdict DESC, t.TABLE_NAME;

-- ============================================================
-- BLOCK 9: Columns with Wrong Charset
-- Per-column charset overrides that don't match table default
-- ============================================================
SELECT '====== BLOCK 9: COLUMN CHARSET OVERRIDES ======' AS report_section;

SELECT
  TABLE_NAME,
  COLUMN_NAME,
  CHARACTER_SET_NAME,
  COLLATION_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND CHARACTER_SET_NAME IS NOT NULL
  AND CHARACTER_SET_NAME != 'utf8mb4'
ORDER BY TABLE_NAME, COLUMN_NAME;

-- ============================================================
-- BLOCK 10: PHP Version (informational — run separately in PHP)
-- ============================================================
SELECT '====== BLOCK 10: PHP VERSION CHECK NOTE ======' AS report_section;

SELECT
  'PHP version check' AS note,
  'Run: php -v on both PCs and compare' AS action,
  'Required: PHP 8.1+ with pdo_mysql, json, mbstring, openssl extensions' AS requirement;

-- Check PHP-relevant MySQL settings
SELECT
  'group_concat_max_len'  AS variable_name,
  @@group_concat_max_len  AS value          UNION ALL
SELECT
  'max_connections',       @@max_connections UNION ALL
SELECT
  'thread_stack',          @@thread_stack    UNION ALL
SELECT
  'key_buffer_size_mb',    @@key_buffer_size/1024/1024;

-- ============================================================
-- BLOCK 11: Migration Log Comparison
-- Shows which migrations have run on this PC
-- ============================================================
SELECT '====== BLOCK 11: MIGRATION LOG ======' AS report_section;

SELECT
  id,
  filename,
  checksum,
  batch,
  executed_at,
  duration_ms,
  notes
FROM migration_log
ORDER BY executed_at;

-- ============================================================
-- BLOCK 12: Seed Data Counts
-- Verify reference data matches between PCs
-- ============================================================
SELECT '====== BLOCK 12: SEED DATA COUNTS ======' AS report_section;

SELECT 'fund_houses'               AS table_name, COUNT(*) AS count FROM fund_houses        UNION ALL
SELECT 'nps_schemes',                               COUNT(*)         FROM nps_schemes        UNION ALL
SELECT 'etf_master',                                COUNT(*)         FROM etf_master         UNION ALL
SELECT 'reits_invits_master',                       COUNT(*)         FROM reits_invits_master UNION ALL
SELECT 'app_settings',                              COUNT(*)         FROM app_settings       UNION ALL
SELECT 'investment_calendar_events',                COUNT(*)         FROM investment_calendar_events;
