# WealthDash — PHP Audit & Deployment Readiness Report
**Phase 6 + Phase 7 Deliverable | Generated: 2026-06-04**

---

## PHASE 6 — PHP Project Audit

### 6.1 Database Risks Found in PHP Files

---

#### RISK-01: `migrate.php` — Hardcoded DB credentials fallback
**File:** `database/migrate.php`  
**Lines:** ~15–30 (connection block)  
**Severity:** 🔴 CRITICAL

```php
// CURRENT (bad)
$host = $_ENV['DB_HOST'] ?? 'localhost';
$user = $_ENV['DB_USER'] ?? 'root';
$pass = $_ENV['DB_PASS'] ?? '';
$db   = $_ENV['DB_NAME'] ?? 'wealthdash';
```

**Problem:** Falls back to `root` with empty password. On PC-A where MySQL root has no password, this works. On PC-B where root requires a password (or doesn't exist), it silently fails or throws a cryptic PDO error. This is the #1 reason migrations fail on a different PC.

**Fix:**
```php
// CORRECT — fail loudly if env vars are missing
$required = ['DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME'];
foreach ($required as $key) {
    if (empty($_ENV[$key]) && !isset($_ENV[$key])) {
        die("FATAL: Environment variable {$key} is not set. Copy .env.example to .env and fill in values.\n");
    }
}
$host = $_ENV['DB_HOST'];
$user = $_ENV['DB_USER'];
$pass = $_ENV['DB_PASS'];
$db   = $_ENV['DB_NAME'];
```

---

#### RISK-02: `migrate.php` — No charset in PDO DSN
**File:** `database/migrate.php`  
**Line:** DSN definition  
**Severity:** 🟠 HIGH

```php
// CURRENT (bad) — no charset specified
$pdo = new PDO("mysql:host={$host};dbname={$db}", $user, $pass);
```

**Problem:** On PC-A (MySQL default utf8), works. On PC-B (MySQL default latin1), string comparisons and LIKE queries on scheme names, fund names, etc. return wrong results or fail entirely.

**Fix:**
```php
// CORRECT
$dsn = "mysql:host={$host};dbname={$db};charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
];
$pdo = new PDO($dsn, $user, $pass, $options);
```

---

#### RISK-03: `migrate.php` — Missing transaction wrapping per migration file
**File:** `database/migrate.php`  
**Severity:** 🟠 HIGH

```php
// CURRENT (bad) — runs migration without transaction
$pdo->exec($sql);
```

**Problem:** If a migration file has 10 statements and fails on statement 7, statements 1–6 are permanently committed. The migration_log records it as failed, so it will try to re-run — but now the first 6 statements will cause "Duplicate column" or "Table already exists" errors.

**Fix:**
```php
// CORRECT — wrap each migration in a transaction
try {
    $pdo->beginTransaction();
    // Split on semicolons, filter empty, execute each
    $statements = array_filter(
        array_map('trim', explode(';', $sql)),
        fn($s) => !empty($s)
    );
    foreach ($statements as $statement) {
        $pdo->exec($statement);
    }
    // Record success
    $stmt = $pdo->prepare(
        "INSERT INTO migration_log (filename, checksum, batch, duration_ms)
         VALUES (?, ?, ?, ?)"
    );
    $stmt->execute([$filename, md5($sql), $batch, $durationMs]);
    $pdo->commit();
} catch (PDOException $e) {
    $pdo->rollBack();
    echo "FAILED: {$filename}\n" . $e->getMessage() . "\n";
    exit(1); // stop further migrations on failure
}
```

---

#### RISK-04: `migrate.php` — Checksum not validated before re-run
**File:** `database/migrate.php`  
**Severity:** 🟡 MEDIUM

**Problem:** `migration_log` stores a checksum but `migrate.php` only checks if the filename exists — not if the file content changed. A migration file edited after being run (e.g., to fix a typo) will be silently skipped, leaving the DB in a wrong state.

**Fix:**
```php
// Add checksum validation
$existingMigration = $pdo->prepare(
    "SELECT checksum FROM migration_log WHERE filename = ?"
);
$existingMigration->execute([$filename]);
$row = $existingMigration->fetch();

if ($row) {
    if ($row['checksum'] !== md5($sql)) {
        echo "WARNING: {$filename} was modified after being run. ";
        echo "Recorded checksum: {$row['checksum']}, Current: " . md5($sql) . "\n";
        echo "Skipping — manually inspect and create a new migration if needed.\n";
    }
    continue; // already run
}
```

---

#### RISK-05: API files — SQL Injection via unparameterised queries
**File:** Multiple files in `api/` directory  
**Severity:** 🔴 CRITICAL

Pattern found in multiple API handlers:
```php
// VULNERABLE — found in api/funds/search.php style files
$q = $_GET['q'];
$sql = "SELECT * FROM funds WHERE scheme_name LIKE '%{$q}%'";
$result = $pdo->query($sql);
```

**Fix — always use prepared statements:**
```php
// CORRECT
$q = '%' . $_GET['q'] . '%';
$stmt = $pdo->prepare(
    "SELECT id, scheme_name, scheme_category, nav
     FROM funds
     WHERE scheme_name LIKE ?
       AND is_active = 1
     ORDER BY scheme_name
     LIMIT 20"
);
$stmt->execute([$q]);
$results = $stmt->fetchAll();
```

---

#### RISK-06: `api/crypto/crypto.php` — References wrong schema
**File:** `api/crypto/crypto.php`  
**Severity:** 🟠 HIGH

```php
// CURRENT (bad) — uses user_id which doesn't exist in crypto_holdings
$sql = "SELECT * FROM crypto_holdings WHERE user_id = ?";
```

**Problem:** `crypto_holdings` uses `portfolio_id`, not `user_id` (the duplicate definition in `41_pending_tasks.sql` was silently skipped). This file will return 0 rows on every installation.

**Fix:**
```php
// CORRECT — join through portfolios to get user's holdings
$sql = "SELECT ch.*, p.name AS portfolio_name
        FROM crypto_holdings ch
        JOIN portfolios p ON p.id = ch.portfolio_id
        WHERE p.user_id = ?
          AND ch.is_active = 1
        ORDER BY ch.coin_name";
```

---

#### RISK-07: Configuration — No `.env.example` or environment documentation
**File:** Root directory  
**Severity:** 🟠 HIGH

**Problem:** A new developer cloning to PC-B has no way of knowing what environment variables are required. This is the #2 reason the project fails on a fresh PC.

**Fix — create `.env.example`:**
```ini
# WealthDash Environment Configuration
# Copy this file to .env and fill in your values

# Database
DB_HOST=localhost
DB_PORT=3306
DB_NAME=wealthdash
DB_USER=wealthdash_user
DB_PASS=your_secure_password_here

# Application
APP_ENV=development
APP_URL=http://localhost:8000
APP_SECRET=change_this_to_a_random_32_char_string

# Session
SESSION_LIFETIME=86400

# External APIs
COINGECKO_API_KEY=
ZERODHA_API_KEY=
ZERODHA_API_SECRET=
GROWW_CLIENT_ID=
GROWW_CLIENT_SECRET=

# AI
ANTHROPIC_API_KEY=

# Email
MAIL_HOST=smtp.mailtrap.io
MAIL_PORT=2525
MAIL_USER=
MAIL_PASS=
MAIL_FROM=noreply@wealthdash.in
```

---

#### RISK-08: Deprecated `mysql_*` functions check
**Severity:** 🟡 MEDIUM (if present)

Run this command in your project root to check for deprecated mysql functions:
```bash
grep -rn "mysql_connect\|mysql_query\|mysql_fetch\|mysql_num_rows\|mysql_select_db" \
  --include="*.php" .
```

If any results are found, replace all `mysql_*` calls with PDO prepared statements. These functions were removed in PHP 7.0.

---

#### RISK-09: Missing error handling in migration runner
**File:** `database/migrate.php`  
**Severity:** 🟡 MEDIUM

```php
// CURRENT (bad) — silently continues on failure
foreach ($files as $file) {
    $pdo->exec(file_get_contents($file));
}
```

**Fix:** See RISK-03 above. Additionally, add:
```php
// At the top of migrate.php
ini_set('display_errors', 1);
error_reporting(E_ALL);
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    throw new ErrorException($errstr, $errno, 0, $errfile, $errline);
});
```

---

#### RISK-10: Hardcoded database name in SQL files
**Severity:** 🟡 MEDIUM

Some migration files use explicit `wealthdash.tablename` references:
```sql
-- Found in some migration files:
SELECT * FROM `wealthdash`.`funds` WHERE ...
```

**Problem:** If the database is deployed as `wealthdash_prod` or `wealthdash_staging`, these queries fail.

**Fix:** Remove the database prefix from all SQL statements. Use `USE wealthdash;` at the top and rely on the current database context. The clean schema files already follow this practice.

---

### 6.2 Configuration Audit Summary

| Config Area | Finding | Severity |
|-------------|---------|----------|
| DB credentials | Hardcoded fallback to root/empty | 🔴 CRITICAL |
| PDO charset | Missing `charset=utf8mb4` in DSN | 🟠 HIGH |
| `.env` file | No `.env.example` provided | 🟠 HIGH |
| Error handling | Migrations fail silently | 🟠 HIGH |
| SQL injection | Unparameterised queries in api/ | 🔴 CRITICAL |
| Schema reference | `crypto.php` uses wrong column | 🟠 HIGH |
| Migration atomicity | No transaction per file | 🟠 HIGH |
| Checksum validation | Not enforced on re-run | 🟡 MEDIUM |
| Deprecated functions | Needs grep verification | 🟡 MEDIUM |
| Hardcoded DB name | DB prefix in some SQL files | 🟡 MEDIUM |

---

## PHASE 7 — Deployment Readiness Report

---

### 🔴 CRITICAL — Must Fix Before Any Deployment

| # | Issue | File | Impact |
|---|-------|------|--------|
| C1 | `mf_holdings` missing 5 columns: `investment_fy`, `ltcg_date`, `lock_in_date`, `withdrawable_date`, `withdrawable_fy` | `01_schema_complete.sql` | LTCG calculations silently fail; `04_fix_corrupted_data.sql` no-ops entirely |
| C2 | 4 indexes on non-existent columns (`status` in wrong tables, `fund_type`, `premium_due_date`) | `45_db_indexes.sql` | Index creation fails with ERROR 1054; migration marks as failed but DB has partial indexes |
| C3 | `crypto_holdings` has two conflicting definitions | `38_crypto_holdings.sql` vs `41_pending_tasks.sql` | `api/crypto/crypto.php` returns 0 rows; crypto portfolio completely broken for new installs |
| C4 | `import_logs` two conflicting definitions with different columns | `01_schema_complete.sql` vs `17_expense_history_import_log.sql` | CSV import undo feature (`rollback_data`) never works; `format` column always NULL |
| C5 | PDO connection missing `charset=utf8mb4` | `migrate.php` | Hindi/special characters in fund names become `????`; search by scheme name broken |
| C6 | SQL injection in API search endpoints | `api/funds/search.php` and others | Full database compromise possible from a single crafted URL |
| C7 | DB credentials fall back to `root/empty` | `migrate.php` | Silent failure on PC-B, server; entire project fails to run |

---

### 🟠 HIGH — Should Fix Before Production

| # | Issue | File | Impact |
|---|-------|------|--------|
| H1 | No `.env.example` file | Root directory | New developer cannot run project without asking you directly |
| H2 | Migration runner has no transaction rollback | `migrate.php` | Half-applied migrations leave DB in inconsistent state; manual cleanup required |
| H3 | `21_peak_nav_setup.sql` has `DROP TABLE IF EXISTS mf_peak_progress` | `21_peak_nav_setup.sql` | Running this wipes all peak NAV progress on existing DB without warning |
| H4 | 12 "TODO stub" files (27–40) contain only SELECT statements | Files 27–37, 39, 40 | Tables expected by app code don't exist; features fail with "Table not found" |
| H5 | `style_box` column added twice in different files (15 & 24) as different types | `15_fund_holdings.sql` + `24_style_box.sql` | Second ADD silently fails; style_box is wrong type (VARCHAR vs GENERATED) |
| H6 | `funds.fund_manager` added in `16_fund_managers.sql` but already in base | `16_fund_managers.sql` line ~8 | Harmless no-op, but if run on fresh DB it fails; `fund_managers` table and `funds.fund_manager` column are confused |
| H7 | No `UNIQUE` constraint on `portfolios.user_id` for default portfolio | `01_schema_complete.sql` | Multiple "My Portfolio" rows per user possible |
| H8 | `sessions` table has no `foreign_key_checks` guard; `user_id` FK added later | Multiple files | Session records for deleted users cause constraint errors |
| H9 | `ai_chat_history` has no size limit on `message` TEXT column | `ai_chat_history` | Very long AI conversations can hit `max_allowed_packet` limit |

---

### 🟡 OPTIONAL — Nice to Have

| # | Issue | Recommendation |
|---|-------|----------------|
| O1 | No `created_by` tracking on `funds`, `nps_schemes` master records | Add `created_by INT` + `source VARCHAR(30)` to track data origin (AMFI/manual/import) |
| O2 | `nav_history` uses `BIGINT` PK but a date+fund composite PK would save space | Consider removing surrogate PK and using `(fund_id, nav_date)` as composite PK directly |
| O3 | `audit_log.old_values` / `new_values` are LONGTEXT with JSON CHECK — change to native JSON | Native JSON type gives built-in validation and JSON_EXTRACT support |
| O4 | No `deleted_at` soft-delete column on `mf_holdings`, `stock_holdings` | Add soft delete to avoid foreign key cascade issues when "removing" a holding |
| O5 | `investment_journal.body` is plain TEXT | Add `body_format ENUM('plain','markdown')` to support rich editor in future |
| O6 | `crypto_price_cache` and `gold_price_cache` have no TTL column | Add `expires_at DATETIME` so stale cache entries can be auto-cleaned |
| O7 | No `READ COMMITTED` isolation level set | Add `SET TRANSACTION ISOLATION LEVEL READ COMMITTED;` to config for better concurrent write performance on holdings tables |
| O8 | `migration_log` tracks `batch` but `migrate.php` always uses batch=1 | Implement proper batch numbering so you can roll back a batch of migrations at once |
| O9 | `users.password_hash` has no `NOT NULL` constraint (allows passwordless users) | Change to `NOT NULL DEFAULT ''` or enforce at application layer |
| O10 | No database user privilege separation | Create `wealthdash_app` user with only SELECT/INSERT/UPDATE/DELETE; no CREATE/DROP in production |

---

## Quick-Fix SQL for Existing Databases

If you have an **existing database** that needs the missing columns added (rather than a fresh install), run this script:

```sql
-- Emergency patch for existing WealthDash databases
-- Adds all missing columns that cause failures
-- Safe to run multiple times (uses IF NOT EXISTS guard)

USE wealthdash;

-- 1. Fix mf_holdings missing columns
ALTER TABLE `mf_holdings`
  ADD COLUMN IF NOT EXISTS `investment_fy`     VARCHAR(10)   DEFAULT NULL AFTER `swp_active`,
  ADD COLUMN IF NOT EXISTS `ltcg_date`         DATE          DEFAULT NULL AFTER `investment_fy`,
  ADD COLUMN IF NOT EXISTS `lock_in_date`      DATE          DEFAULT NULL AFTER `ltcg_date`,
  ADD COLUMN IF NOT EXISTS `withdrawable_date` DATE          DEFAULT NULL AFTER `lock_in_date`,
  ADD COLUMN IF NOT EXISTS `withdrawable_fy`   VARCHAR(10)   DEFAULT NULL AFTER `withdrawable_date`,
  ADD COLUMN IF NOT EXISTS `status`            ENUM('active','redeemed','switched_out') NOT NULL DEFAULT 'active' AFTER `withdrawable_fy`;

-- 2. Fix stock_holdings missing status column
ALTER TABLE `stock_holdings`
  ADD COLUMN IF NOT EXISTS `status` ENUM('active','sold') NOT NULL DEFAULT 'active' AFTER `gain_pct`;

-- 3. Fix savings_accounts missing status column
ALTER TABLE `savings_accounts`
  ADD COLUMN IF NOT EXISTS `status` ENUM('active','closed') NOT NULL DEFAULT 'active' AFTER `account_type`;

-- 4. Fix funds missing columns
ALTER TABLE `funds`
  ADD COLUMN IF NOT EXISTS `fund_type`    VARCHAR(50) DEFAULT NULL AFTER `scheme_sub_category`,
  ADD COLUMN IF NOT EXISTS `min_ltcg_days` INT DEFAULT 365 AFTER `exit_load_days`;

-- 5. Fix insurance_policies missing premium_due_date
ALTER TABLE `insurance_policies`
  ADD COLUMN IF NOT EXISTS `premium_due_date` DATE DEFAULT NULL AFTER `premium_frequency`;

-- 6. Fix nav_download_progress missing columns
ALTER TABLE `nav_download_progress`
  ADD COLUMN IF NOT EXISTS `scheme_code` VARCHAR(20) NOT NULL DEFAULT '' AFTER `fund_id`,
  ADD COLUMN IF NOT EXISTS `from_date`   DATE DEFAULT NULL AFTER `last_nav_date`;

-- 7. Now indexes will succeed — re-run 03_indexes.sql or run manually:
CREATE INDEX IF NOT EXISTS `idx_mfh_portfolio_status`
  ON `mf_holdings` (`portfolio_id`, `status`);

CREATE INDEX IF NOT EXISTS `idx_sh_status`
  ON `stock_holdings` (`status`);

CREATE INDEX IF NOT EXISTS `idx_ins_premium_due`
  ON `insurance_policies` (`premium_due_date`);

CREATE INDEX IF NOT EXISTS `idx_fund_type`
  ON `funds` (`fund_type`);

SELECT 'Emergency patch complete. Verify with Database_Health_Check.sql' AS result;
```

---

## Fresh Install Step-by-Step Guide (Phase 4)

### Prerequisites
- MySQL 8.x or MariaDB 10.6+ installed
- PHP 8.1+ with `pdo_mysql` extension
- A database user with CREATE DATABASE privileges (for first-time setup)

### Step 1 — Create DB user (run as MySQL root)
```sql
CREATE USER 'wealthdash_app'@'localhost' IDENTIFIED BY 'your_strong_password_here';
GRANT ALL PRIVILEGES ON `wealthdash`.* TO 'wealthdash_app'@'localhost';
FLUSH PRIVILEGES;
```

### Step 2 — Copy and configure environment
```bash
cp .env.example .env
# Edit .env and set:
# DB_USER=wealthdash_app
# DB_PASS=your_strong_password_here
# DB_NAME=wealthdash
```

### Step 3 — Run clean schema files in order
```bash
mysql -u wealthdash_app -p < database/clean/01_database_create.sql
mysql -u wealthdash_app -p wealthdash < database/clean/02_tables.sql
mysql -u wealthdash_app -p wealthdash < database/clean/03_indexes.sql
mysql -u wealthdash_app -p wealthdash < database/clean/04_foreign_keys.sql
mysql -u wealthdash_app -p wealthdash < database/clean/05_seed_data.sql
```

### Step 4 — Verify the install
```bash
mysql -u wealthdash_app -p wealthdash < database/clean/Database_Health_Check.sql | less
```

Look for any `❌ MISSING` or `❌ FAIL` rows in the output. There should be none on a fresh install.

### Step 5 — Record migration in log
```sql
USE wealthdash;
INSERT INTO migration_log (filename, checksum, batch, notes)
VALUES ('clean_install_2026_06_04', MD5('clean_install'), 1, 'Fresh install from clean schema');
```

### Step 6 — Verify against existing DB (if comparing PCs)
```sql
-- Run on OLD PC (to export current table column counts)
SELECT TABLE_NAME, COUNT(*) AS col_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = 'wealthdash'
GROUP BY TABLE_NAME
ORDER BY TABLE_NAME;

-- Run same query on NEW PC and diff the output
-- Any table with fewer columns on the new PC = missing migration
```
