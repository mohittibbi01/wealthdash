# WealthDash — Verification Checklist
**Generated: 2026-06-04**

Use this checklist on every new PC / server / staging environment after running the clean schema.
Check every box before considering the installation production-ready.

---

## Pre-Installation Checklist

### Environment Setup
- [ ] MySQL 8.0+ or MariaDB 10.6+ is installed and running
- [ ] `mysql --version` confirms the version
- [ ] PHP 8.1+ is installed (`php -v`)
- [ ] PHP extensions enabled: `pdo_mysql`, `json`, `mbstring`, `openssl`, `curl`
  ```bash
  php -m | grep -E 'pdo_mysql|json|mbstring|openssl|curl'
  ```
- [ ] `.env` file created from `.env.example` with correct values
- [ ] MySQL user `wealthdash_app` created with correct privileges
- [ ] `max_allowed_packet` is at least 64MB in MySQL config
  ```sql
  SELECT @@max_allowed_packet / 1024 / 1024 AS mb;
  -- Should show >= 64
  ```
- [ ] MySQL `character_set_server` = `utf8mb4`
- [ ] MySQL `collation_server` = `utf8mb4_unicode_ci`
  ```sql
  SELECT @@character_set_server, @@collation_server;
  ```

---

## Installation Verification

### Step 1 — Database Created
- [ ] Database `wealthdash` exists
  ```sql
  SHOW DATABASES LIKE 'wealthdash';
  ```
- [ ] Database charset is `utf8mb4`
  ```sql
  SELECT DEFAULT_CHARACTER_SET_NAME, DEFAULT_COLLATION_NAME
  FROM information_schema.SCHEMATA
  WHERE SCHEMA_NAME = 'wealthdash';
  ```

### Step 2 — Tables
- [ ] Table count is exactly 104 (97 production + 7 master/utility)
  ```sql
  SELECT COUNT(*) FROM information_schema.TABLES
  WHERE TABLE_SCHEMA = 'wealthdash' AND TABLE_TYPE = 'BASE TABLE';
  -- Expected: 104
  ```
- [ ] All tables use InnoDB engine
  ```sql
  SELECT COUNT(*) FROM information_schema.TABLES
  WHERE TABLE_SCHEMA = 'wealthdash'
    AND TABLE_TYPE = 'BASE TABLE'
    AND ENGINE != 'InnoDB';
  -- Expected: 0
  ```
- [ ] Run Section 2 of `Database_Health_Check.sql` and confirm zero `❌ MISSING` rows

### Step 3 — Critical Columns
- [ ] Run Section 3 of `Database_Health_Check.sql`
- [ ] Zero `❌ MISSING` rows in the output
- [ ] Specifically verify `mf_holdings` has all 23 columns:
  ```sql
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = 'wealthdash' AND TABLE_NAME = 'mf_holdings';
  -- Expected: 23
  ```

### Step 4 — Indexes
- [ ] Run Section 4 of `Database_Health_Check.sql`
- [ ] Zero `❌ MISSING` rows in the output
- [ ] `nav_history` unique index on `(fund_id, nav_date)` exists:
  ```sql
  SHOW INDEX FROM nav_history WHERE Key_name = 'uq_nav';
  -- Should return 1 row
  ```

### Step 5 — Foreign Keys
- [ ] Run Section 5 of `Database_Health_Check.sql`
- [ ] Zero `❌ MISSING` rows in the output
- [ ] FK count is at least 70:
  ```sql
  SELECT COUNT(*) FROM information_schema.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = 'wealthdash';
  -- Expected: >= 70
  ```

### Step 6 — Seed Data
- [ ] `fund_houses` has exactly 36 rows
  ```sql
  SELECT COUNT(*) FROM fund_houses; -- Expected: 36
  ```
- [ ] `nps_schemes` has exactly 63 rows
  ```sql
  SELECT COUNT(*) FROM nps_schemes; -- Expected: 63
  ```
- [ ] `etf_master` has 15 rows (more can be added later)
  ```sql
  SELECT COUNT(*) FROM etf_master; -- Expected: >= 15
  ```
- [ ] `app_settings` has 25 rows
  ```sql
  SELECT COUNT(*) FROM app_settings; -- Expected: 25
  ```
- [ ] `investment_calendar_events` has 20 system events
  ```sql
  SELECT COUNT(*) FROM investment_calendar_events
  WHERE user_id IS NULL; -- Expected: 20
  ```

---

## Application Smoke Tests

### User Registration & Login
- [ ] Can register a new user
- [ ] Activation email sent (if email configured)
- [ ] Can log in with registered credentials
- [ ] Session persists across page refreshes
- [ ] Logout works and session is destroyed

### Portfolio Operations
- [ ] Can create a new portfolio
- [ ] `portfolios.user_id` FK is honoured (delete user → portfolio deleted)
- [ ] Can import a CAMS CAS file without errors
- [ ] `import_logs` row created with correct `rows_total`, `rows_success`

### MF Holdings
- [ ] Holdings appear on dashboard after import
- [ ] `mf_holdings.investment_fy` is populated correctly
- [ ] `mf_holdings.ltcg_date` is calculated correctly for equity funds (> 365 days)
- [ ] `mf_holdings.status` = 'active' for current holdings
- [ ] XIRR calculation runs without errors

### NAV
- [ ] NAV download queue populates `nav_download_progress` with `scheme_code`
- [ ] NAV download completes and `nav_history` has records
- [ ] `nav_proxy_cache` is populated after first chart view

### Crypto
- [ ] Crypto holdings page loads without errors
- [ ] `crypto_holdings` table is queried via `portfolio_id` (not `user_id`)
- [ ] Price cache updates via CoinGecko API

### LTCG / Tax
- [ ] LTCG report generates correctly for MF holdings > 1 year
- [ ] `mf_holdings.withdrawable_date` is correctly set
- [ ] VDA tax calculator uses `vda_transactions` correctly

---

## Security Verification

- [ ] No SQL injection possible via fund search (test with `' OR '1'='1`)
- [ ] Prepared statements used in all API endpoints (code review)
- [ ] `.env` file is NOT accessible from the web (`http://yoursite/.env` returns 403)
- [ ] `migrate.php` is NOT accessible from the web (move to CLI-only or add IP restriction)
- [ ] `database/` directory is NOT web-accessible
- [ ] API keys in `zerodha_credentials` are stored encrypted (verify `api_secret` column is not plain text)
- [ ] Session cookies have `HttpOnly` and `Secure` flags set

---

## Performance Baseline (Optional but Recommended)

Run these queries and record the times. Use as benchmark for future comparisons:

```sql
-- Test 1: NAV lookup (most frequent query in app)
EXPLAIN SELECT nav, nav_date FROM nav_history
WHERE fund_id = 1 ORDER BY nav_date DESC LIMIT 1;
-- Expected: uses uq_nav or idx_nav_fund index, NOT full table scan

-- Test 2: Holdings summary (dashboard load)
EXPLAIN SELECT COUNT(*), SUM(current_value), SUM(invested_amount)
FROM mf_holdings
WHERE portfolio_id = 1 AND status = 'active';
-- Expected: uses idx_mfh_portfolio_status index

-- Test 3: Fund search
EXPLAIN SELECT id, scheme_name, nav
FROM funds WHERE scheme_name LIKE '%nifty%' AND is_active = 1
LIMIT 20;
-- Expected: uses idx_fund_active (at minimum)

-- Check for full table scans (should return 0 rows)
SELECT * FROM information_schema.PROCESSLIST
WHERE INFO LIKE '%funds%' AND STATE = 'Sending data';
```

---

## Cross-PC Comparison Procedure

1. Run `Environment_Comparison.sql` on **PC-A** (working PC):
   ```bash
   mysql -u wealthdash_app -p wealthdash < Environment_Comparison.sql > pc_a_env.txt
   ```

2. Run same script on **PC-B** (new PC):
   ```bash
   mysql -u wealthdash_app -p wealthdash < Environment_Comparison.sql > pc_b_env.txt
   ```

3. Diff the outputs:
   ```bash
   diff pc_a_env.txt pc_b_env.txt
   ```

4. Any differences in **BLOCK 5** (column counts) or **BLOCK 6** (indexes) indicate schema drift that needs fixing.

5. Differences in **BLOCK 1** (server variables) that matter:
   - `sql_mode` — must be identical; different modes affect INSERT validation
   - `character_set_server` — must be `utf8mb4` on both
   - `lower_case_table_names` — must be identical; value 0 vs 1 causes "table not found" errors on case-sensitive OS (Linux vs Windows/macOS)

---

## Sign-Off

| Check | Person | Date | Notes |
|-------|--------|------|-------|
| Schema verified | | | |
| Seed data verified | | | |
| Application smoke test | | | |
| Security review | | | |
| Performance baseline | | | |
| Cross-PC comparison | | | |

**Installation Status:** ☐ In Progress  ☐ Verified  ☐ Production Ready
