-- ============================================================
-- WealthDash — Clean Master Schema
-- File 03: indexes.sql
-- Generated: 2026-06-04
-- ============================================================
-- Run AFTER tables.sql, BEFORE foreign_keys.sql
-- All indexes verified against final column definitions.
-- Indexes on non-existent columns (fund_type, status in wrong
-- tables, premium_due_date) have been FIXED or REMOVED.
-- ============================================================

USE `wealthdash`;

-- ============================================================
-- users
-- ============================================================
CREATE INDEX `idx_users_role`       ON `users` (`role`);
CREATE INDEX `idx_users_active`     ON `users` (`is_active`);

-- ============================================================
-- sessions
-- ============================================================
CREATE INDEX `idx_sess_user`        ON `sessions` (`user_id`);
CREATE INDEX `idx_sess_activity`    ON `sessions` (`last_activity`);

-- ============================================================
-- user_sessions
-- ============================================================
CREATE INDEX `idx_us_user`          ON `user_sessions` (`user_id`);
CREATE INDEX `idx_us_active`        ON `user_sessions` (`last_active`);

-- ============================================================
-- login_attempts
-- ============================================================
CREATE INDEX `idx_la_email`         ON `login_attempts` (`email`);
CREATE INDEX `idx_la_ip`            ON `login_attempts` (`ip_address`);
CREATE INDEX `idx_la_time`          ON `login_attempts` (`attempted_at`);

-- ============================================================
-- otp_tokens
-- ============================================================
CREATE INDEX `idx_otp_user`         ON `otp_tokens` (`user_id`);
CREATE INDEX `idx_otp_expires`      ON `otp_tokens` (`expires_at`);

-- ============================================================
-- password_resets
-- ============================================================
CREATE INDEX `idx_pr_email`         ON `password_resets` (`email`);
CREATE INDEX `idx_pr_expires`       ON `password_resets` (`expires_at`);

-- ============================================================
-- google_auth
-- ============================================================
CREATE INDEX `idx_gauth_user`       ON `google_auth` (`user_id`);

-- ============================================================
-- rate_limit_buckets
-- ============================================================
CREATE INDEX `idx_rlb_window`       ON `rate_limit_buckets` (`window_start`);

-- ============================================================
-- audit_log
-- ============================================================
CREATE INDEX `idx_audit_user`       ON `audit_log` (`user_id`);
CREATE INDEX `idx_audit_entity`     ON `audit_log` (`entity_type`, `entity_id`);
CREATE INDEX `idx_audit_created`    ON `audit_log` (`created_at`);

-- ============================================================
-- portfolios
-- ============================================================
CREATE INDEX `idx_portfolio_user`   ON `portfolios` (`user_id`);

-- ============================================================
-- import_logs
-- ============================================================
CREATE INDEX `idx_il_user`          ON `import_logs` (`user_id`);
CREATE INDEX `idx_il_portfolio`     ON `import_logs` (`portfolio_id`);
CREATE INDEX `idx_il_status`        ON `import_logs` (`status`);

-- ============================================================
-- funds
-- ============================================================
CREATE INDEX `idx_fund_house`       ON `funds` (`fund_house_id`);
CREATE INDEX `idx_fund_cat`         ON `funds` (`scheme_category`);
CREATE INDEX `idx_fund_cat_subcat`  ON `funds` (`scheme_category`, `scheme_sub_category`);
CREATE INDEX `idx_fund_active`      ON `funds` (`is_active`);
CREATE INDEX `idx_fund_type`        ON `funds` (`fund_type`);          -- fund_type column now exists
CREATE INDEX `idx_funds_returns_1y` ON `funds` (`returns_1y`);
CREATE INDEX `idx_funds_returns_3y` ON `funds` (`returns_3y`);
CREATE INDEX `idx_funds_returns_5y` ON `funds` (`returns_5y`);
CREATE INDEX `idx_funds_stars`      ON `funds` (`wd_stars`);

-- ============================================================
-- nav_history
-- ============================================================
CREATE INDEX `idx_nav_fund`         ON `nav_history` (`fund_id`);
CREATE INDEX `idx_nav_date`         ON `nav_history` (`nav_date`);

-- ============================================================
-- nav_download_progress
-- ============================================================
CREATE INDEX `idx_ndp_status`       ON `nav_download_progress` (`status`);

-- ============================================================
-- fund_stock_holdings
-- ============================================================
CREATE INDEX `idx_fsh_fund`         ON `fund_stock_holdings` (`fund_id`);
CREATE INDEX `idx_fsh_sector`       ON `fund_stock_holdings` (`sector`);
CREATE INDEX `idx_fsh_month`        ON `fund_stock_holdings` (`month_year`);
CREATE INDEX `idx_fsh_isin`         ON `fund_stock_holdings` (`isin`);

-- ============================================================
-- fund_overlap_cache
-- ============================================================
CREATE INDEX `idx_oc_a`             ON `fund_overlap_cache` (`fund_id_a`);
CREATE INDEX `idx_oc_b`             ON `fund_overlap_cache` (`fund_id_b`);

-- ============================================================
-- fund_managers
-- ============================================================
CREATE INDEX `idx_fm_fund`          ON `fund_managers` (`fund_id`);
CREATE INDEX `idx_fm_current`       ON `fund_managers` (`is_current`);
CREATE INDEX `idx_fm_from`          ON `fund_managers` (`from_date`);

-- ============================================================
-- expense_ratio_history
-- ============================================================
CREATE INDEX `idx_erh_fund`         ON `expense_ratio_history` (`fund_id`);
CREATE INDEX `idx_erh_date`         ON `expense_ratio_history` (`recorded_date`);

-- ============================================================
-- nfo_tracker
-- ============================================================
CREATE INDEX `idx_nfo_status`       ON `nfo_tracker` (`status`);
CREATE INDEX `idx_nfo_open`         ON `nfo_tracker` (`open_date`);
CREATE INDEX `idx_nfo_close`        ON `nfo_tracker` (`close_date`);

-- ============================================================
-- fund_watchlist
-- ============================================================
CREATE INDEX `idx_fw_user`          ON `fund_watchlist` (`user_id`);
CREATE INDEX `idx_fw_fund`          ON `fund_watchlist` (`fund_id`);

-- ============================================================
-- price_alerts
-- ============================================================
CREATE INDEX `idx_pa_user`          ON `price_alerts` (`user_id`);
CREATE INDEX `idx_pa_fund`          ON `price_alerts` (`fund_id`);
CREATE INDEX `idx_pa_active`        ON `price_alerts` (`is_active`);

-- ============================================================
-- fund_ratings
-- ============================================================
CREATE INDEX `idx_fr_stars`         ON `fund_ratings` (`stars`);

-- ============================================================
-- mf_holdings
-- ============================================================
CREATE INDEX `idx_mfh_fund`             ON `mf_holdings` (`fund_id`);
CREATE INDEX `idx_mfh_portfolio`        ON `mf_holdings` (`portfolio_id`);
CREATE INDEX `idx_mfh_portfolio_fund`   ON `mf_holdings` (`portfolio_id`, `fund_id`);
CREATE INDEX `idx_mfh_portfolio_status` ON `mf_holdings` (`portfolio_id`, `status`); -- status column now defined

-- ============================================================
-- mf_transactions
-- ============================================================
CREATE INDEX `idx_mft_portfolio`    ON `mf_transactions` (`portfolio_id`);
CREATE INDEX `idx_mft_fund`         ON `mf_transactions` (`fund_id`);
CREATE INDEX `idx_mft_date`         ON `mf_transactions` (`txn_date`);
CREATE INDEX `idx_mft_type`         ON `mf_transactions` (`txn_type`);

-- ============================================================
-- mf_dividends
-- ============================================================
CREATE INDEX `idx_mfd_portfolio`    ON `mf_dividends` (`portfolio_id`);
CREATE INDEX `idx_mfd_fund`         ON `mf_dividends` (`fund_id`);
CREATE INDEX `idx_mfd_date`         ON `mf_dividends` (`dividend_date`);

-- ============================================================
-- sip_schedules
-- ============================================================
CREATE INDEX `idx_sip_portfolio`    ON `sip_schedules` (`portfolio_id`);
CREATE INDEX `idx_sip_active`       ON `sip_schedules` (`is_active`);
CREATE INDEX `idx_sip_fund`         ON `sip_schedules` (`fund_id`);

-- ============================================================
-- nps_schemes
-- ============================================================
CREATE INDEX `idx_nps_pfm`          ON `nps_schemes` (`pfm_name`);
CREATE INDEX `idx_nps_asset`        ON `nps_schemes` (`asset_class`);
CREATE INDEX `idx_nps_active`       ON `nps_schemes` (`is_active`);

-- ============================================================
-- nps_holdings
-- ============================================================
CREATE INDEX `idx_npsh_portfolio`   ON `nps_holdings` (`portfolio_id`);
CREATE INDEX `idx_npsh_scheme`      ON `nps_holdings` (`scheme_id`);

-- ============================================================
-- nps_transactions
-- ============================================================
CREATE INDEX `idx_npst_portfolio`   ON `nps_transactions` (`portfolio_id`);
CREATE INDEX `idx_npst_scheme`      ON `nps_transactions` (`scheme_id`);
CREATE INDEX `idx_npst_date`        ON `nps_transactions` (`txn_date`);

-- ============================================================
-- nps_nav_history
-- ============================================================
CREATE INDEX `idx_nnh_scheme`       ON `nps_nav_history` (`scheme_id`);
CREATE INDEX `idx_nnh_date`         ON `nps_nav_history` (`nav_date`);

-- ============================================================
-- stock_master
-- ============================================================
CREATE INDEX `idx_sm_exchange`      ON `stock_master` (`exchange`);
CREATE INDEX `idx_sm_sector`        ON `stock_master` (`sector`);
CREATE INDEX `idx_sm_isin`          ON `stock_master` (`isin`);

-- ============================================================
-- stock_holdings
-- ============================================================
CREATE INDEX `idx_sh_portfolio`     ON `stock_holdings` (`portfolio_id`);
CREATE INDEX `idx_sh_stock`         ON `stock_holdings` (`stock_id`);
CREATE INDEX `idx_sh_status`        ON `stock_holdings` (`status`);    -- status now defined

-- ============================================================
-- stock_transactions
-- ============================================================
CREATE INDEX `idx_st_portfolio`     ON `stock_transactions` (`portfolio_id`);
CREATE INDEX `idx_st_stock`         ON `stock_transactions` (`stock_id`);
CREATE INDEX `idx_st_date`          ON `stock_transactions` (`txn_date`);

-- ============================================================
-- stock_dividends
-- ============================================================
CREATE INDEX `idx_sd_portfolio`     ON `stock_dividends` (`portfolio_id`);
CREATE INDEX `idx_sd_stock`         ON `stock_dividends` (`stock_id`);

-- ============================================================
-- stock_corporate_actions
-- ============================================================
CREATE INDEX `idx_sca_stock`        ON `stock_corporate_actions` (`stock_id`);
CREATE INDEX `idx_sca_date`         ON `stock_corporate_actions` (`action_date`);

-- ============================================================
-- stock_screener_filters
-- ============================================================
CREATE INDEX `idx_ssf_user`         ON `stock_screener_filters` (`user_id`);

-- ============================================================
-- stock_fundamentals_history
-- ============================================================
CREATE INDEX `idx_sfh_stock`        ON `stock_fundamentals_history` (`stock_id`);
CREATE INDEX `idx_sfh_period`       ON `stock_fundamentals_history` (`period_type`, `period`);

-- ============================================================
-- fd_accounts
-- ============================================================
CREATE INDEX `idx_fd_portfolio`     ON `fd_accounts` (`portfolio_id`);
CREATE INDEX `idx_fd_maturity`      ON `fd_accounts` (`maturity_date`);
CREATE INDEX `idx_fd_status`        ON `fd_accounts` (`status`);

-- ============================================================
-- fd_interest_accruals
-- ============================================================
CREATE INDEX `idx_fdia_fd`          ON `fd_interest_accruals` (`fd_id`);
CREATE INDEX `idx_fdia_date`        ON `fd_interest_accruals` (`accrual_date`);

-- ============================================================
-- fd_maturity_alerts
-- ============================================================
CREATE INDEX `idx_fdma_user`        ON `fd_maturity_alerts` (`user_id`);

-- ============================================================
-- fd_interest_log
-- ============================================================
CREATE INDEX `idx_fdil_user`        ON `fd_interest_log` (`user_id`);
CREATE INDEX `idx_fdil_date`        ON `fd_interest_log` (`credit_date`);

-- ============================================================
-- savings_accounts
-- ============================================================
CREATE INDEX `idx_sa_portfolio`     ON `savings_accounts` (`portfolio_id`);
CREATE INDEX `idx_sa_status`        ON `savings_accounts` (`status`);  -- status now defined

-- ============================================================
-- savings_interest
-- ============================================================
CREATE INDEX `idx_si_acct_date`     ON `savings_interest` (`account_id`, `interest_date`);
CREATE INDEX `idx_si_fy`            ON `savings_interest` (`interest_fy`);

-- ============================================================
-- bank_accounts
-- ============================================================
CREATE INDEX `idx_ba_portfolio`     ON `bank_accounts` (`portfolio_id`);

-- ============================================================
-- bank_balance_history
-- ============================================================
CREATE INDEX `idx_bbh_date`         ON `bank_balance_history` (`recorded_at`);

-- ============================================================
-- epf_accounts
-- ============================================================
CREATE INDEX `idx_epf_portfolio`    ON `epf_accounts` (`portfolio_id`);
CREATE INDEX `idx_epf_status`       ON `epf_accounts` (`status`);

-- ============================================================
-- po_schemes
-- ============================================================
CREATE INDEX `idx_po_portfolio`     ON `po_schemes` (`portfolio_id`);
CREATE INDEX `idx_po_type`          ON `po_schemes` (`scheme_type`);
CREATE INDEX `idx_po_maturity`      ON `po_schemes` (`maturity_date`);

-- ============================================================
-- insurance_policies
-- ============================================================
CREATE INDEX `idx_ins_portfolio`    ON `insurance_policies` (`portfolio_id`);
CREATE INDEX `idx_ins_type`         ON `insurance_policies` (`policy_type`);
CREATE INDEX `idx_ins_status`       ON `insurance_policies` (`status`);
CREATE INDEX `idx_ins_premium_due`  ON `insurance_policies` (`premium_due_date`); -- column now defined

-- ============================================================
-- loan_accounts
-- ============================================================
CREATE INDEX `idx_la_portfolio`     ON `loan_accounts` (`portfolio_id`);
CREATE INDEX `idx_la_status`        ON `loan_accounts` (`status`);

-- ============================================================
-- investment_goals
-- ============================================================
CREATE INDEX `idx_ig_portfolio`     ON `investment_goals` (`portfolio_id`);
CREATE INDEX `idx_ig_achieved`      ON `investment_goals` (`is_achieved`);

-- ============================================================
-- goal_contributions
-- ============================================================
CREATE INDEX `idx_gc_goal`          ON `goal_contributions` (`goal_id`);
CREATE INDEX `idx_gc_date`          ON `goal_contributions` (`contribution_date`);

-- ============================================================
-- goal_buckets
-- ============================================================
CREATE INDEX `idx_gb_user`          ON `goal_buckets` (`user_id`);

-- ============================================================
-- goal_fund_links
-- ============================================================
CREATE INDEX `idx_gfl_goal`         ON `goal_fund_links` (`goal_id`);
CREATE INDEX `idx_gfl_fund`         ON `goal_fund_links` (`fund_id`);

-- ============================================================
-- rebalancing_targets
-- ============================================================
CREATE INDEX `idx_rt_portfolio`     ON `rebalancing_targets` (`portfolio_id`);

-- ============================================================
-- investment_calendar_events
-- ============================================================
CREATE INDEX `idx_ice_date`         ON `investment_calendar_events` (`event_date`);
CREATE INDEX `idx_ice_type`         ON `investment_calendar_events` (`event_type`);
CREATE INDEX `idx_ice_user`         ON `investment_calendar_events` (`user_id`);

-- ============================================================
-- net_worth_snapshots
-- ============================================================
CREATE INDEX `idx_nws_user`         ON `net_worth_snapshots` (`user_id`);
CREATE INDEX `idx_nws_date`         ON `net_worth_snapshots` (`snapshot_date`);

-- ============================================================
-- sgb_holdings
-- ============================================================
CREATE INDEX `idx_sgb_portfolio`    ON `sgb_holdings` (`portfolio_id`);
CREATE INDEX `idx_sgb_maturity`     ON `sgb_holdings` (`maturity_date`);
CREATE INDEX `idx_sgb_active`       ON `sgb_holdings` (`is_active`);
CREATE INDEX `idx_sgb_tranche`      ON `sgb_holdings` (`tranche_code`);

-- ============================================================
-- sgb_interest_log
-- ============================================================
CREATE INDEX `idx_sgbil_sgb`        ON `sgb_interest_log` (`sgb_id`);
CREATE INDEX `idx_sgbil_portfolio`  ON `sgb_interest_log` (`portfolio_id`);
CREATE INDEX `idx_sgbil_date`       ON `sgb_interest_log` (`payout_date`);

-- ============================================================
-- gold_price_cache
-- ============================================================
CREATE INDEX `idx_gold_date`        ON `gold_price_cache` (`date_for`);

-- ============================================================
-- crypto_holdings
-- ============================================================
CREATE INDEX `idx_ch_portfolio`     ON `crypto_holdings` (`portfolio_id`);
CREATE INDEX `idx_ch_coin`          ON `crypto_holdings` (`coin_id`);
CREATE INDEX `idx_ch_active`        ON `crypto_holdings` (`is_active`);

-- ============================================================
-- crypto_transactions
-- ============================================================
CREATE INDEX `idx_ct_portfolio`     ON `crypto_transactions` (`portfolio_id`);
CREATE INDEX `idx_ct_coin`          ON `crypto_transactions` (`coin_id`);
CREATE INDEX `idx_ct_date`          ON `crypto_transactions` (`txn_date`);

-- ============================================================
-- vda_transactions
-- ============================================================
CREATE INDEX `idx_vda_portfolio`    ON `vda_transactions` (`portfolio_id`);
CREATE INDEX `idx_vda_coin`         ON `vda_transactions` (`coin_symbol`);
CREATE INDEX `idx_vda_fy`           ON `vda_transactions` (`fy`);
CREATE INDEX `idx_vda_sell_date`    ON `vda_transactions` (`sell_date`);
CREATE INDEX `idx_vda_buy_date`     ON `vda_transactions` (`buy_date`);
CREATE INDEX `idx_vda_tds`          ON `vda_transactions` (`tds_deducted`);

-- ============================================================
-- vda_tds_log
-- ============================================================
CREATE INDEX `idx_vdatds_portfolio` ON `vda_tds_log` (`portfolio_id`);
CREATE INDEX `idx_vdatds_fy`        ON `vda_tds_log` (`fy`);

-- ============================================================
-- esop_grants
-- ============================================================
CREATE INDEX `idx_eg_portfolio`     ON `esop_grants` (`portfolio_id`);
CREATE INDEX `idx_eg_status`        ON `esop_grants` (`status`);
CREATE INDEX `idx_eg_company`       ON `esop_grants` (`company_symbol`);

-- ============================================================
-- esop_vesting_events
-- ============================================================
CREATE INDEX `idx_eve_grant`        ON `esop_vesting_events` (`grant_id`);
CREATE INDEX `idx_eve_vest_date`    ON `esop_vesting_events` (`vest_date`);
CREATE INDEX `idx_eve_exercised`    ON `esop_vesting_events` (`is_exercised`);

-- ============================================================
-- esop_exercise_log
-- ============================================================
CREATE INDEX `idx_eel_grant`        ON `esop_exercise_log` (`grant_id`);
CREATE INDEX `idx_eel_date`         ON `esop_exercise_log` (`exercise_date`);

-- ============================================================
-- reits_invits
-- ============================================================
CREATE INDEX `idx_ri_user`          ON `reits_invits` (`user_id`);
CREATE INDEX `idx_ri_portfolio`     ON `reits_invits` (`portfolio_id`);
CREATE INDEX `idx_ri_symbol`        ON `reits_invits` (`symbol`);

-- ============================================================
-- reits_invits_transactions
-- ============================================================
CREATE INDEX `idx_rit_holding`      ON `reits_invits_transactions` (`holding_id`);
CREATE INDEX `idx_rit_user`         ON `reits_invits_transactions` (`user_id`);
CREATE INDEX `idx_rit_date`         ON `reits_invits_transactions` (`txn_date`);

-- ============================================================
-- reits_invits_distributions
-- ============================================================
CREATE INDEX `idx_rid_holding`      ON `reits_invits_distributions` (`holding_id`);
CREATE INDEX `idx_rid_user`         ON `reits_invits_distributions` (`user_id`);
CREATE INDEX `idx_rid_date`         ON `reits_invits_distributions` (`ex_date`);

-- ============================================================
-- etf_master
-- ============================================================
CREATE INDEX `idx_etf_category`     ON `etf_master` (`category`);
CREATE INDEX `idx_etf_amc`          ON `etf_master` (`amc`);
CREATE INDEX `idx_etf_gold`         ON `etf_master` (`is_gold_etf`);
CREATE INDEX `idx_etf_intl`         ON `etf_master` (`is_international`);

-- ============================================================
-- etf_holdings
-- ============================================================
CREATE INDEX `idx_eh_portfolio`     ON `etf_holdings` (`portfolio_id`);
CREATE INDEX `idx_eh_etf`           ON `etf_holdings` (`etf_id`);

-- ============================================================
-- etf_transactions
-- ============================================================
CREATE INDEX `idx_et_portfolio`     ON `etf_transactions` (`portfolio_id`);
CREATE INDEX `idx_et_etf`           ON `etf_transactions` (`etf_id`);
CREATE INDEX `idx_et_date`          ON `etf_transactions` (`txn_date`);

-- ============================================================
-- pms_holdings
-- ============================================================
CREATE INDEX `idx_pmsh_user`        ON `pms_holdings` (`user_id`);
CREATE INDEX `idx_pmsh_portfolio`   ON `pms_holdings` (`portfolio_id`);
CREATE INDEX `idx_pmsh_active`      ON `pms_holdings` (`is_active`);
CREATE INDEX `idx_pmsh_class`       ON `pms_holdings` (`asset_class`);

-- ============================================================
-- pms_transactions
-- ============================================================
CREATE INDEX `idx_pmst_holding`     ON `pms_transactions` (`holding_id`);
CREATE INDEX `idx_pmst_user`        ON `pms_transactions` (`user_id`);
CREATE INDEX `idx_pmst_date`        ON `pms_transactions` (`txn_date`);
CREATE INDEX `idx_pmst_type`        ON `pms_transactions` (`txn_type`);

-- ============================================================
-- us_stock_master
-- ============================================================
CREATE INDEX `idx_usm_exchange`     ON `us_stock_master` (`exchange`);
CREATE INDEX `idx_usm_sector`       ON `us_stock_master` (`sector`);

-- ============================================================
-- us_stock_holdings
-- ============================================================
CREATE INDEX `idx_ush_portfolio`    ON `us_stock_holdings` (`portfolio_id`);
CREATE INDEX `idx_ush_stock`        ON `us_stock_holdings` (`stock_id`);

-- ============================================================
-- us_stock_transactions
-- ============================================================
CREATE INDEX `idx_ust_portfolio`    ON `us_stock_transactions` (`portfolio_id`);
CREATE INDEX `idx_ust_stock`        ON `us_stock_transactions` (`stock_id`);
CREATE INDEX `idx_ust_date`         ON `us_stock_transactions` (`txn_date`);

-- ============================================================
-- notifications
-- ============================================================
CREATE INDEX `idx_notif_user`       ON `notifications` (`user_id`);
CREATE INDEX `idx_notif_unread`     ON `notifications` (`user_id`, `is_read`);
CREATE INDEX `idx_notif_type`       ON `notifications` (`type`);

-- ============================================================
-- ai_chat_history
-- ============================================================
CREATE INDEX `idx_ai_user_ctx`      ON `ai_chat_history` (`user_id`, `context_id`);
CREATE INDEX `idx_ai_created`       ON `ai_chat_history` (`created_at`);

-- ============================================================
-- ai_portfolio_reviews
-- ============================================================
CREATE INDEX `idx_apr_user`         ON `ai_portfolio_reviews` (`user_id`);

-- ============================================================
-- ai_anomalies
-- ============================================================
CREATE INDEX `idx_anom_user`        ON `ai_anomalies` (`user_id`);
CREATE INDEX `idx_anom_type`        ON `ai_anomalies` (`anomaly_type`);
CREATE INDEX `idx_anom_severity`    ON `ai_anomalies` (`severity`);

-- ============================================================
-- zerodha_credentials
-- ============================================================
CREATE INDEX `idx_zc_active`        ON `zerodha_credentials` (`is_active`);

-- ============================================================
-- zerodha_sync_log
-- ============================================================
CREATE INDEX `idx_zsync_user`       ON `zerodha_sync_log` (`user_id`);
CREATE INDEX `idx_zsync_status`     ON `zerodha_sync_log` (`status`);

-- ============================================================
-- groww_api_credentials
-- ============================================================
CREATE INDEX `idx_groww_status`     ON `groww_api_credentials` (`status`);

-- ============================================================
-- groww_sync_log
-- ============================================================
CREATE INDEX `idx_gsync_user`       ON `groww_sync_log` (`user_id`);
CREATE INDEX `idx_gsync_status`     ON `groww_sync_log` (`status`);

-- ============================================================
-- investment_journal
-- ============================================================
CREATE INDEX `idx_ij_user_date`     ON `investment_journal` (`user_id`, `entry_date`);
CREATE INDEX `idx_ij_mood`          ON `investment_journal` (`mood`);

-- ============================================================
-- credit_cards
-- ============================================================
CREATE INDEX `idx_cc_user`          ON `credit_cards` (`user_id`);
CREATE INDEX `idx_cc_due`           ON `credit_cards` (`due_date`);
