-- ============================================================
-- WealthDash — Clean Master Schema
-- File 05: seed_data.sql
-- Generated: 2026-06-04
-- ============================================================
-- Contains ONLY essential lookup / master data.
-- Run LAST, after foreign_keys.sql
-- Safe to run multiple times (INSERT IGNORE used throughout)
-- ============================================================

USE `wealthdash`;
SET foreign_key_checks = 0;

-- ============================================================
-- 1. FUND HOUSES (36 AMCs as of June 2026)
-- ============================================================
INSERT IGNORE INTO `fund_houses` (`id`, `name`, `short_name`) VALUES
(1,  'Aditya Birla Sun Life Mutual Fund',    'ABSL'),
(2,  'Axis Mutual Fund',                      'Axis'),
(3,  'Bandhan Mutual Fund',                   'Bandhan'),
(4,  'Bank of India Mutual Fund',             'BOI'),
(5,  'Baroda BNP Paribas Mutual Fund',        'Baroda BNP'),
(6,  'Canara Robeco Mutual Fund',             'Canara Robeco'),
(7,  'DSP Mutual Fund',                       'DSP'),
(8,  'Edelweiss Mutual Fund',                 'Edelweiss'),
(9,  'Franklin Templeton Mutual Fund',        'Franklin'),
(10, 'HDFC Mutual Fund',                      'HDFC'),
(11, 'HSBC Mutual Fund',                      'HSBC'),
(12, 'ICICI Prudential Mutual Fund',          'ICICI Pru'),
(13, 'Invesco Mutual Fund',                   'Invesco'),
(14, 'ITI Mutual Fund',                       'ITI'),
(15, 'JM Financial Mutual Fund',              'JM'),
(16, 'Kotak Mahindra Mutual Fund',            'Kotak'),
(17, 'LIC Mutual Fund',                       'LIC'),
(18, 'Mahindra Manulife Mutual Fund',         'Mahindra Manulife'),
(19, 'Mirae Asset Mutual Fund',               'Mirae'),
(20, 'Motilal Oswal Mutual Fund',             'Motilal'),
(21, 'Navi Mutual Fund',                      'Navi'),
(22, 'Nippon India Mutual Fund',              'Nippon'),
(23, 'NJ Mutual Fund',                        'NJ'),
(24, 'PGIM India Mutual Fund',                'PGIM'),
(25, 'PPFAS Mutual Fund',                     'PPFAS'),
(26, 'Quant Mutual Fund',                     'Quant'),
(27, 'Quantum Mutual Fund',                   'Quantum'),
(28, 'Samco Mutual Fund',                     'Samco'),
(29, 'SBI Mutual Fund',                       'SBI'),
(30, 'Shriram Mutual Fund',                   'Shriram'),
(31, 'Sundaram Mutual Fund',                  'Sundaram'),
(32, 'Tata Mutual Fund',                      'Tata'),
(33, 'Taurus Mutual Fund',                    'Taurus'),
(34, 'Trust Mutual Fund',                     'Trust'),
(35, 'Union Mutual Fund',                     'Union'),
(36, 'UTI Mutual Fund',                       'UTI');

-- ============================================================
-- 2. NPS SCHEMES (63 active schemes across all PFMs)
-- ============================================================
INSERT IGNORE INTO `nps_schemes`
  (`id`, `pfm_name`, `scheme_name`, `scheme_code`, `tier`, `asset_class`, `is_active`)
VALUES
-- SBI Pension Fund
(1,  'SBI Pension Fund',            'SBI Pension Fund - Scheme E - Tier I',  'SBI-E-T1',  'tier1', 'E', 1),
(2,  'SBI Pension Fund',            'SBI Pension Fund - Scheme C - Tier I',  'SBI-C-T1',  'tier1', 'C', 1),
(3,  'SBI Pension Fund',            'SBI Pension Fund - Scheme G - Tier I',  'SBI-G-T1',  'tier1', 'G', 1),
(4,  'SBI Pension Fund',            'SBI Pension Fund - Scheme A - Tier I',  'SBI-A-T1',  'tier1', 'A', 1),
(5,  'SBI Pension Fund',            'SBI Pension Fund - Scheme E - Tier II', 'SBI-E-T2',  'tier2', 'E', 1),
(6,  'SBI Pension Fund',            'SBI Pension Fund - Scheme C - Tier II', 'SBI-C-T2',  'tier2', 'C', 1),
(7,  'SBI Pension Fund',            'SBI Pension Fund - Scheme G - Tier II', 'SBI-G-T2',  'tier2', 'G', 1),
-- LIC Pension Fund
(8,  'LIC Pension Fund',            'LIC Pension Fund - Scheme E - Tier I',  'LIC-E-T1',  'tier1', 'E', 1),
(9,  'LIC Pension Fund',            'LIC Pension Fund - Scheme C - Tier I',  'LIC-C-T1',  'tier1', 'C', 1),
(10, 'LIC Pension Fund',            'LIC Pension Fund - Scheme G - Tier I',  'LIC-G-T1',  'tier1', 'G', 1),
(11, 'LIC Pension Fund',            'LIC Pension Fund - Scheme A - Tier I',  'LIC-A-T1',  'tier1', 'A', 1),
(12, 'LIC Pension Fund',            'LIC Pension Fund - Scheme E - Tier II', 'LIC-E-T2',  'tier2', 'E', 1),
(13, 'LIC Pension Fund',            'LIC Pension Fund - Scheme C - Tier II', 'LIC-C-T2',  'tier2', 'C', 1),
(14, 'LIC Pension Fund',            'LIC Pension Fund - Scheme G - Tier II', 'LIC-G-T2',  'tier2', 'G', 1),
-- UTI Retirement Solutions
(15, 'UTI Retirement Solutions',    'UTI Retirement Solutions - Scheme E - Tier I',  'UTI-E-T1',  'tier1', 'E', 1),
(16, 'UTI Retirement Solutions',    'UTI Retirement Solutions - Scheme C - Tier I',  'UTI-C-T1',  'tier1', 'C', 1),
(17, 'UTI Retirement Solutions',    'UTI Retirement Solutions - Scheme G - Tier I',  'UTI-G-T1',  'tier1', 'G', 1),
(18, 'UTI Retirement Solutions',    'UTI Retirement Solutions - Scheme A - Tier I',  'UTI-A-T1',  'tier1', 'A', 1),
(19, 'UTI Retirement Solutions',    'UTI Retirement Solutions - Scheme E - Tier II', 'UTI-E-T2',  'tier2', 'E', 1),
(20, 'UTI Retirement Solutions',    'UTI Retirement Solutions - Scheme C - Tier II', 'UTI-C-T2',  'tier2', 'C', 1),
(21, 'UTI Retirement Solutions',    'UTI Retirement Solutions - Scheme G - Tier II', 'UTI-G-T2',  'tier2', 'G', 1),
-- HDFC Pension Fund
(22, 'HDFC Pension Fund',           'HDFC Pension Fund - Scheme E - Tier I',  'HDFC-E-T1',  'tier1', 'E', 1),
(23, 'HDFC Pension Fund',           'HDFC Pension Fund - Scheme C - Tier I',  'HDFC-C-T1',  'tier1', 'C', 1),
(24, 'HDFC Pension Fund',           'HDFC Pension Fund - Scheme G - Tier I',  'HDFC-G-T1',  'tier1', 'G', 1),
(25, 'HDFC Pension Fund',           'HDFC Pension Fund - Scheme A - Tier I',  'HDFC-A-T1',  'tier1', 'A', 1),
(26, 'HDFC Pension Fund',           'HDFC Pension Fund - Scheme E - Tier II', 'HDFC-E-T2',  'tier2', 'E', 1),
(27, 'HDFC Pension Fund',           'HDFC Pension Fund - Scheme C - Tier II', 'HDFC-C-T2',  'tier2', 'C', 1),
(28, 'HDFC Pension Fund',           'HDFC Pension Fund - Scheme G - Tier II', 'HDFC-G-T2',  'tier2', 'G', 1),
-- ICICI Prudential Pension Fund
(29, 'ICICI Prudential Pension Fund','ICICI Pru Pension Fund - Scheme E - Tier I',  'ICICI-E-T1',  'tier1', 'E', 1),
(30, 'ICICI Prudential Pension Fund','ICICI Pru Pension Fund - Scheme C - Tier I',  'ICICI-C-T1',  'tier1', 'C', 1),
(31, 'ICICI Prudential Pension Fund','ICICI Pru Pension Fund - Scheme G - Tier I',  'ICICI-G-T1',  'tier1', 'G', 1),
(32, 'ICICI Prudential Pension Fund','ICICI Pru Pension Fund - Scheme A - Tier I',  'ICICI-A-T1',  'tier1', 'A', 1),
(33, 'ICICI Prudential Pension Fund','ICICI Pru Pension Fund - Scheme E - Tier II', 'ICICI-E-T2',  'tier2', 'E', 1),
(34, 'ICICI Prudential Pension Fund','ICICI Pru Pension Fund - Scheme C - Tier II', 'ICICI-C-T2',  'tier2', 'C', 1),
(35, 'ICICI Prudential Pension Fund','ICICI Pru Pension Fund - Scheme G - Tier II', 'ICICI-G-T2',  'tier2', 'G', 1),
-- Aditya Birla Sun Life Pension Fund
(36, 'Aditya Birla Sun Life Pension Fund','ABSL Pension Fund - Scheme E - Tier I',  'ABSL-E-T1',  'tier1', 'E', 1),
(37, 'Aditya Birla Sun Life Pension Fund','ABSL Pension Fund - Scheme C - Tier I',  'ABSL-C-T1',  'tier1', 'C', 1),
(38, 'Aditya Birla Sun Life Pension Fund','ABSL Pension Fund - Scheme G - Tier I',  'ABSL-G-T1',  'tier1', 'G', 1),
(39, 'Aditya Birla Sun Life Pension Fund','ABSL Pension Fund - Scheme A - Tier I',  'ABSL-A-T1',  'tier1', 'A', 1),
(40, 'Aditya Birla Sun Life Pension Fund','ABSL Pension Fund - Scheme E - Tier II', 'ABSL-E-T2',  'tier2', 'E', 1),
(41, 'Aditya Birla Sun Life Pension Fund','ABSL Pension Fund - Scheme C - Tier II', 'ABSL-C-T2',  'tier2', 'C', 1),
(42, 'Aditya Birla Sun Life Pension Fund','ABSL Pension Fund - Scheme G - Tier II', 'ABSL-G-T2',  'tier2', 'G', 1),
-- Kotak Mahindra Pension Fund
(43, 'Kotak Mahindra Pension Fund', 'Kotak Pension Fund - Scheme E - Tier I',  'KOTAK-E-T1',  'tier1', 'E', 1),
(44, 'Kotak Mahindra Pension Fund', 'Kotak Pension Fund - Scheme C - Tier I',  'KOTAK-C-T1',  'tier1', 'C', 1),
(45, 'Kotak Mahindra Pension Fund', 'Kotak Pension Fund - Scheme G - Tier I',  'KOTAK-G-T1',  'tier1', 'G', 1),
(46, 'Kotak Mahindra Pension Fund', 'Kotak Pension Fund - Scheme A - Tier I',  'KOTAK-A-T1',  'tier1', 'A', 1),
(47, 'Kotak Mahindra Pension Fund', 'Kotak Pension Fund - Scheme E - Tier II', 'KOTAK-E-T2',  'tier2', 'E', 1),
(48, 'Kotak Mahindra Pension Fund', 'Kotak Pension Fund - Scheme C - Tier II', 'KOTAK-C-T2',  'tier2', 'C', 1),
(49, 'Kotak Mahindra Pension Fund', 'Kotak Pension Fund - Scheme G - Tier II', 'KOTAK-G-T2',  'tier2', 'G', 1),
-- Tata Pension Fund
(50, 'Tata Pension Fund',           'Tata Pension Fund - Scheme E - Tier I',  'TATA-E-T1',  'tier1', 'E', 1),
(51, 'Tata Pension Fund',           'Tata Pension Fund - Scheme C - Tier I',  'TATA-C-T1',  'tier1', 'C', 1),
(52, 'Tata Pension Fund',           'Tata Pension Fund - Scheme G - Tier I',  'TATA-G-T1',  'tier1', 'G', 1),
(53, 'Tata Pension Fund',           'Tata Pension Fund - Scheme A - Tier I',  'TATA-A-T1',  'tier1', 'A', 1),
(54, 'Tata Pension Fund',           'Tata Pension Fund - Scheme E - Tier II', 'TATA-E-T2',  'tier2', 'E', 1),
(55, 'Tata Pension Fund',           'Tata Pension Fund - Scheme C - Tier II', 'TATA-C-T2',  'tier2', 'C', 1),
(56, 'Tata Pension Fund',           'Tata Pension Fund - Scheme G - Tier II', 'TATA-G-T2',  'tier2', 'G', 1),
-- Axis Pension Fund (newest PFM as of 2024)
(57, 'Axis Pension Fund',           'Axis Pension Fund - Scheme E - Tier I',  'AXIS-E-T1',  'tier1', 'E', 1),
(58, 'Axis Pension Fund',           'Axis Pension Fund - Scheme C - Tier I',  'AXIS-C-T1',  'tier1', 'C', 1),
(59, 'Axis Pension Fund',           'Axis Pension Fund - Scheme G - Tier I',  'AXIS-G-T1',  'tier1', 'G', 1),
(60, 'Axis Pension Fund',           'Axis Pension Fund - Scheme A - Tier I',  'AXIS-A-T1',  'tier1', 'A', 1),
(61, 'Axis Pension Fund',           'Axis Pension Fund - Scheme E - Tier II', 'AXIS-E-T2',  'tier2', 'E', 1),
(62, 'Axis Pension Fund',           'Axis Pension Fund - Scheme C - Tier II', 'AXIS-C-T2',  'tier2', 'C', 1),
(63, 'Axis Pension Fund',           'Axis Pension Fund - Scheme G - Tier II', 'AXIS-G-T2',  'tier2', 'G', 1);

-- ============================================================
-- 3. APP SETTINGS (default configuration)
-- ============================================================
INSERT IGNORE INTO `app_settings` (`setting_key`, `setting_val`) VALUES
('app_version',             '4.8'),
('nav_auto_update',         '1'),
('nav_update_time',         '22:00'),
('nfo_refresh_interval_hrs','6'),
('gold_price_source',       'ibja'),
('gold_refresh_interval_hrs','4'),
('crypto_price_source',     'coingecko'),
('default_currency',        'INR'),
('fiscal_year_start_month', '4'),
('ltcg_mf_days',            '365'),
('ltcg_stock_days',         '365'),
('stcg_mf_tax_pct',         '20'),
('ltcg_mf_tax_pct',         '12.5'),
('stcg_stock_tax_pct',      '20'),
('ltcg_stock_tax_pct',      '12.5'),
('vda_tax_pct',             '30'),
('vda_tds_pct',             '1'),
('max_login_attempts',      '5'),
('login_lockout_minutes',   '30'),
('otp_expiry_minutes',      '10'),
('session_timeout_hours',   '24'),
('net_worth_snapshot_day',  '1'),
('rebalance_drift_threshold','5.0'),
('ai_review_enabled',       '1'),
('ai_review_day_of_month',  '1');

-- ============================================================
-- 4. INVESTMENT CALENDAR EVENTS (FY 2025-26)
-- System-level events: user_id = NULL
-- ============================================================
INSERT IGNORE INTO `investment_calendar_events`
  (`user_id`, `event_date`, `event_type`, `title`, `description`, `icon`, `color`, `is_important`)
VALUES
-- Advance Tax
(NULL, '2025-06-15', 'advance_tax',    'Advance Tax Q1 Due (FY 2025-26)', 'Pay 15% of estimated annual tax liability', '💰', '#ef4444', 1),
(NULL, '2025-09-15', 'advance_tax',    'Advance Tax Q2 Due (FY 2025-26)', 'Pay 45% cumulative of estimated annual tax', '💰', '#ef4444', 1),
(NULL, '2025-12-15', 'advance_tax',    'Advance Tax Q3 Due (FY 2025-26)', 'Pay 75% cumulative of estimated annual tax', '💰', '#ef4444', 1),
(NULL, '2026-03-15', 'advance_tax',    'Advance Tax Q4 Due (FY 2025-26)', 'Pay 100% of estimated annual tax liability', '💰', '#ef4444', 1),
-- ITR Deadlines
(NULL, '2025-07-31', 'tax_deadline',   'ITR Filing Deadline (Non-Audit)',  'Last date to file ITR for FY 2024-25 (non-audit)', '📋', '#f97316', 1),
(NULL, '2025-10-31', 'tax_deadline',   'ITR Filing Deadline (Audit Cases)','Last date for audit cases FY 2024-25', '📋', '#f97316', 1),
(NULL, '2025-12-31', 'tax_deadline',   'Belated/Revised ITR Deadline',     'Last date for belated/revised return FY 2024-25', '📋', '#f97316', 1),
-- 80C / Tax Saving
(NULL, '2026-03-31', 'tax_deadline',   'Last Date for 80C Investments',    'ELSS, PPF, NPS, NSC contributions for FY 2025-26', '🏦', '#8b5cf6', 1),
(NULL, '2026-03-31', 'tax_deadline',   'Last Date for Health Insurance (80D)','Pay health insurance premium for 80D deduction', '🏥', '#8b5cf6', 1),
(NULL, '2026-03-31', 'tax_deadline',   'Last Date for NPS 80CCD(1B)',      'Additional ₹50,000 NPS deduction under 80CCD(1B)', '🏛️', '#8b5cf6', 1),
-- Form 15G / 15H
(NULL, '2025-04-30', 'sebi_compliance','Form 15G/15H Submission Deadline',  'Submit to bank to avoid TDS on interest income', '📄', '#0ea5e9', 0),
-- RBI Policy (approximate dates)
(NULL, '2025-04-09', 'rbi_policy',     'RBI MPC Meeting (Apr 2025)',       'Monetary Policy Committee rate decision', '🏛️', '#64748b', 0),
(NULL, '2025-06-06', 'rbi_policy',     'RBI MPC Meeting (Jun 2025)',       'Monetary Policy Committee rate decision', '🏛️', '#64748b', 0),
(NULL, '2025-08-08', 'rbi_policy',     'RBI MPC Meeting (Aug 2025)',       'Monetary Policy Committee rate decision', '🏛️', '#64748b', 0),
(NULL, '2025-10-08', 'rbi_policy',     'RBI MPC Meeting (Oct 2025)',       'Monetary Policy Committee rate decision', '🏛️', '#64748b', 0),
(NULL, '2025-12-06', 'rbi_policy',     'RBI MPC Meeting (Dec 2025)',       'Monetary Policy Committee rate decision', '🏛️', '#64748b', 0),
(NULL, '2026-02-07', 'rbi_policy',     'RBI MPC Meeting (Feb 2026)',       'Monetary Policy Committee rate decision', '🏛️', '#64748b', 0),
-- Union Budget
(NULL, '2026-02-01', 'budget',         'Union Budget 2026-27',             'Annual Union Budget presentation by Finance Minister', '🇮🇳', '#16a34a', 1),
-- FY transition
(NULL, '2026-03-31', 'tax_deadline',   'End of Financial Year 2025-26',    'Last date for FY 2025-26 investments and tax planning', '📅', '#dc2626', 1),
(NULL, '2026-04-01', 'tax_deadline',   'New Financial Year 2026-27 Begins','Start of FY 2026-27', '🎉', '#16a34a', 0);

-- ============================================================
-- 5. REITS/INVITS MASTER (active as of June 2026)
-- ============================================================
INSERT IGNORE INTO `reits_invits_master`
  (`symbol`, `name`, `trust_type`, `exchange`, `isin`, `sector`, `sponsor`, `is_active`)
VALUES
('EMBASSY',    'Embassy Office Parks REIT',         'REIT',   'NSE', 'INE041L01044', 'Office',           'Embassy Group / Blackstone', 1),
('MINDSPACE',  'Mindspace Business Parks REIT',     'REIT',   'NSE', 'INE752P01024', 'Office',           'K Raheja Corp / Blackstone', 1),
('BROOKFIELD', 'Brookfield India REIT',             'REIT',   'NSE', 'INE436X01026', 'Office',           'Brookfield Asset Management', 1),
('NEXUS',      'Nexus Select Trust REIT',           'REIT',   'NSE', 'INE803L01024', 'Retail',           'Blackstone', 1),
('INDIGRID',   'India Grid Trust InvIT',            'InvIT',  'NSE', 'INE219X01019', 'Power Transmission','Sterlite Power', 1),
('POWERGRID',  'PowerGrid InvIT',                   'InvIT',  'NSE', 'INE949U01014', 'Power Transmission','Power Grid Corp of India', 1),
('NHAI',       'National Highways Infra Trust',     'InvIT',  'NSE', 'INE936Z01016', 'Roads & Highways', 'NHAI', 1),
('BHARAT',     'Bharat Highways InvIT',             'InvIT',  'NSE', 'INE0GIW01016', 'Roads & Highways', 'IRB Infrastructure', 1);

-- ============================================================
-- 6. ETF MASTER — Popular Index ETFs
-- ============================================================
INSERT IGNORE INTO `etf_master`
  (`symbol`, `exchange`, `isin`, `scheme_name`, `amc`, `category`,
   `sub_category`, `underlying_index`, `expense_ratio`, `is_gold_etf`, `is_international`)
VALUES
('NIFTYBEES',  'NSE', 'INE732E01054', 'Nippon India ETF Nifty 50 BeES',          'Nippon',  'Equity', 'Large Cap', 'Nifty 50',            0.04,  0, 0),
('JUNIORBEES', 'NSE', 'INE732E01120', 'Nippon India ETF Junior BeES',            'Nippon',  'Equity', 'Mid Cap',   'Nifty Next 50',       0.19,  0, 0),
('BANKBEES',   'NSE', 'INE732E01070', 'Nippon India ETF Bank BeES',              'Nippon',  'Equity', 'Sector',    'Nifty Bank',          0.18,  0, 0),
('ITBEES',     'NSE', 'INE732E01088', 'Nippon India ETF IT',                     'Nippon',  'Equity', 'Sector',    'Nifty IT',            0.18,  0, 0),
('MAN50ETF',   'NSE', 'INE00NV01017', 'Mirae Asset Nifty 50 ETF',               'Mirae',   'Equity', 'Large Cap', 'Nifty 50',            0.03,  0, 0),
('HDFCNIFTY',  'NSE', 'INE044C01023', 'HDFC Nifty 50 ETF',                      'HDFC',    'Equity', 'Large Cap', 'Nifty 50',            0.05,  0, 0),
('SETFNN50',   'NSE', 'INE036S01010', 'SBI - ETF Nifty Next 50',                'SBI',     'Equity', 'Mid Cap',   'Nifty Next 50',       0.18,  0, 0),
('MAFANG',     'NSE', 'INE916L01028', 'Mirae Asset NYSE FANG+ ETF',             'Mirae',   'Equity', 'International','NYSE FANG+ Index', 0.58,  0, 1),
('MON100',     'NSE', 'INE658R01022', 'Motilal Oswal Nasdaq 100 ETF',           'Motilal', 'Equity', 'International','Nasdaq 100',       0.58,  0, 1),
('GOLDBEES',   'NSE', 'INE732E01096', 'Nippon India ETF Gold BeES',             'Nippon',  'Gold',   'Gold ETF',  'Physical Gold',       0.79,  1, 0),
('HDFCGOLD',   'NSE', 'INE044C01056', 'HDFC Gold ETF',                          'HDFC',    'Gold',   'Gold ETF',  'Physical Gold',       0.59,  1, 0),
('SGBBSE',     'BSE', NULL,           'SBI Gold ETF',                           'SBI',     'Gold',   'Gold ETF',  'Physical Gold',       0.65,  1, 0),
('LIQUIDBEES', 'NSE', 'INE732E01112', 'Nippon India ETF Liquid BeES',           'Nippon',  'Debt',   'Liquid',    'Nifty 1D Rate Index', 0.0694,0, 0),
('CPSEETF',    'NSE', 'INE548N01011', 'SBI - ETF CPSE',                         'SBI',     'Equity', 'CPSE',      'Nifty CPSE Index',    0.07,  0, 0),
('ICICIB22',   'NSE', 'INE248U01020', 'ICICI Prudential Bharat 22 ETF',         'ICICI',   'Equity', 'CPSE',      'S&P BSE Bharat 22',   0.07,  0, 0);

-- ============================================================
-- 7. MIGRATION LOG — record this clean install
-- ============================================================
INSERT IGNORE INTO `migration_log`
  (`filename`, `checksum`, `batch`, `notes`)
VALUES
  ('00_clean_master_install', MD5('wealthdash_clean_schema_2026_06_04'), 0,
   'Clean production schema install — all historical ALTER clutter removed');

SET foreign_key_checks = 1;
