-- ============================================================
-- WealthDash — Clean Master Schema
-- File 01: database_create.sql
-- Generated: 2026-06-04
-- ============================================================
-- INSTRUCTIONS:
--   Run this file FIRST, then tables.sql, indexes.sql,
--   foreign_keys.sql, and finally seed_data.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS `wealthdash`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `wealthdash`;

SET SQL_MODE          = 'NO_AUTO_VALUE_ON_ZERO,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION';
SET time_zone         = '+00:00';
SET NAMES             utf8mb4;
SET foreign_key_checks = 0;
