-- ============================================================
-- WealthDash — Clean Master Schema
-- File 04: foreign_keys.sql
-- Generated: 2026-06-04
-- ============================================================
-- Run AFTER indexes.sql
-- All FK targets verified to exist in tables.sql.
-- Dangling FKs (missing parent tables) have been removed.
-- ============================================================

USE `wealthdash`;
SET foreign_key_checks = 0;

-- ============================================================
-- sessions → users
-- ============================================================
ALTER TABLE `sessions`
  ADD CONSTRAINT `fk_sess_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- user_sessions → users
-- ============================================================
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `fk_us_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- otp_tokens → users
-- ============================================================
ALTER TABLE `otp_tokens`
  ADD CONSTRAINT `fk_otp_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- google_auth → users
-- ============================================================
ALTER TABLE `google_auth`
  ADD CONSTRAINT `fk_gauth_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- portfolios → users
-- ============================================================
ALTER TABLE `portfolios`
  ADD CONSTRAINT `fk_portfolio_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- import_logs → users, portfolios
-- ============================================================
ALTER TABLE `import_logs`
  ADD CONSTRAINT `fk_il_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_il_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE;

-- ============================================================
-- app_settings → users (updated_by)
-- ============================================================
ALTER TABLE `app_settings`
  ADD CONSTRAINT `fk_settings_updater`
    FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE;

-- ============================================================
-- funds → fund_houses
-- ============================================================
ALTER TABLE `funds`
  ADD CONSTRAINT `fk_funds_house`
    FOREIGN KEY (`fund_house_id`) REFERENCES `fund_houses` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE;

-- ============================================================
-- nav_history → funds
-- ============================================================
ALTER TABLE `nav_history`
  ADD CONSTRAINT `fk_nav_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- nav_download_progress → funds
-- ============================================================
ALTER TABLE `nav_download_progress`
  ADD CONSTRAINT `fk_ndp_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE;

-- ============================================================
-- nav_proxy_cache → funds
-- ============================================================
ALTER TABLE `nav_proxy_cache`
  ADD CONSTRAINT `fk_npc_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- fund_ratings → funds
-- ============================================================
ALTER TABLE `fund_ratings`
  ADD CONSTRAINT `fk_fr_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- fund_stock_holdings → funds
-- ============================================================
ALTER TABLE `fund_stock_holdings`
  ADD CONSTRAINT `fk_fsh_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- fund_overlap_cache → funds (both directions)
-- ============================================================
ALTER TABLE `fund_overlap_cache`
  ADD CONSTRAINT `fk_oc_fund_a`
    FOREIGN KEY (`fund_id_a`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_oc_fund_b`
    FOREIGN KEY (`fund_id_b`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- fund_managers → funds
-- ============================================================
ALTER TABLE `fund_managers`
  ADD CONSTRAINT `fk_fm_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- expense_ratio_history → funds
-- ============================================================
ALTER TABLE `expense_ratio_history`
  ADD CONSTRAINT `fk_erh_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- fund_watchlist → users, funds
-- ============================================================
ALTER TABLE `fund_watchlist`
  ADD CONSTRAINT `fk_fw_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_fw_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- price_alerts → users, funds
-- ============================================================
ALTER TABLE `price_alerts`
  ADD CONSTRAINT `fk_pa_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pa_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- mf_compare_sessions → users
-- ============================================================
ALTER TABLE `mf_compare_sessions`
  ADD CONSTRAINT `fk_mcs_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- mf_holdings → portfolios, funds
-- ============================================================
ALTER TABLE `mf_holdings`
  ADD CONSTRAINT `fk_mfh_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mfh_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- mf_transactions → portfolios, funds
-- ============================================================
ALTER TABLE `mf_transactions`
  ADD CONSTRAINT `fk_mft_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mft_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- mf_dividends → portfolios, funds
-- ============================================================
ALTER TABLE `mf_dividends`
  ADD CONSTRAINT `fk_mfd_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mfd_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- mf_holding_notes → portfolios, funds
-- ============================================================
ALTER TABLE `mf_holding_notes`
  ADD CONSTRAINT `fk_mhn_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mhn_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- sip_schedules → portfolios, funds
-- ============================================================
ALTER TABLE `sip_schedules`
  ADD CONSTRAINT `fk_sip_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sip_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE;

-- ============================================================
-- nps_holdings → portfolios, nps_schemes
-- ============================================================
ALTER TABLE `nps_holdings`
  ADD CONSTRAINT `fk_npsh_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_npsh_scheme`
    FOREIGN KEY (`scheme_id`) REFERENCES `nps_schemes` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- nps_transactions → portfolios, nps_schemes
-- ============================================================
ALTER TABLE `nps_transactions`
  ADD CONSTRAINT `fk_npst_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_npst_scheme`
    FOREIGN KEY (`scheme_id`) REFERENCES `nps_schemes` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- nps_nav_history → nps_schemes
-- ============================================================
ALTER TABLE `nps_nav_history`
  ADD CONSTRAINT `fk_nnh_scheme`
    FOREIGN KEY (`scheme_id`) REFERENCES `nps_schemes` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- stock_holdings → portfolios, stock_master
-- ============================================================
ALTER TABLE `stock_holdings`
  ADD CONSTRAINT `fk_sh_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sh_stock`
    FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- stock_transactions → portfolios, stock_master
-- ============================================================
ALTER TABLE `stock_transactions`
  ADD CONSTRAINT `fk_st_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_st_stock`
    FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- stock_dividends → portfolios, stock_master
-- ============================================================
ALTER TABLE `stock_dividends`
  ADD CONSTRAINT `fk_sd_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sd_stock`
    FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- stock_corporate_actions → stock_master
-- ============================================================
ALTER TABLE `stock_corporate_actions`
  ADD CONSTRAINT `fk_sca_stock`
    FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- fd_accounts → portfolios
-- ============================================================
ALTER TABLE `fd_accounts`
  ADD CONSTRAINT `fk_fd_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- fd_interest_accruals → fd_accounts
-- ============================================================
ALTER TABLE `fd_interest_accruals`
  ADD CONSTRAINT `fk_fdia_fd`
    FOREIGN KEY (`fd_id`) REFERENCES `fd_accounts` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- fd_maturity_alerts → users, fd_accounts
-- ============================================================
ALTER TABLE `fd_maturity_alerts`
  ADD CONSTRAINT `fk_fdma_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_fdma_fd`
    FOREIGN KEY (`fd_id`) REFERENCES `fd_accounts` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- fd_interest_log → users, fd_accounts
-- ============================================================
ALTER TABLE `fd_interest_log`
  ADD CONSTRAINT `fk_fdil_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_fdil_fd`
    FOREIGN KEY (`fd_id`) REFERENCES `fd_accounts` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- savings_accounts → portfolios
-- ============================================================
ALTER TABLE `savings_accounts`
  ADD CONSTRAINT `fk_sa_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- savings_interest → savings_accounts
-- ============================================================
ALTER TABLE `savings_interest`
  ADD CONSTRAINT `fk_si_account`
    FOREIGN KEY (`account_id`) REFERENCES `savings_accounts` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- bank_accounts → portfolios
-- ============================================================
ALTER TABLE `bank_accounts`
  ADD CONSTRAINT `fk_ba_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- bank_balance_history → bank_accounts
-- ============================================================
ALTER TABLE `bank_balance_history`
  ADD CONSTRAINT `fk_bbh_account`
    FOREIGN KEY (`account_id`) REFERENCES `bank_accounts` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- epf_accounts → portfolios
-- ============================================================
ALTER TABLE `epf_accounts`
  ADD CONSTRAINT `fk_epf_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- po_schemes → portfolios
-- ============================================================
ALTER TABLE `po_schemes`
  ADD CONSTRAINT `fk_po_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- insurance_policies → portfolios
-- ============================================================
ALTER TABLE `insurance_policies`
  ADD CONSTRAINT `fk_ins_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- loan_accounts → portfolios
-- ============================================================
ALTER TABLE `loan_accounts`
  ADD CONSTRAINT `fk_la_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- investment_goals → portfolios
-- ============================================================
ALTER TABLE `investment_goals`
  ADD CONSTRAINT `fk_ig_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- goal_contributions → investment_goals
-- ============================================================
ALTER TABLE `goal_contributions`
  ADD CONSTRAINT `fk_gc_goal`
    FOREIGN KEY (`goal_id`) REFERENCES `investment_goals` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- goal_buckets → users
-- ============================================================
ALTER TABLE `goal_buckets`
  ADD CONSTRAINT `fk_gb_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- goal_fund_links → goal_buckets, funds
-- ============================================================
ALTER TABLE `goal_fund_links`
  ADD CONSTRAINT `fk_gfl_goal`
    FOREIGN KEY (`goal_id`) REFERENCES `goal_buckets` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_gfl_fund`
    FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE;

-- ============================================================
-- rebalancing_targets → portfolios
-- ============================================================
ALTER TABLE `rebalancing_targets`
  ADD CONSTRAINT `fk_rt_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- investment_calendar_events → users (nullable)
-- ============================================================
ALTER TABLE `investment_calendar_events`
  ADD CONSTRAINT `fk_ice_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- net_worth_snapshots → users
-- ============================================================
ALTER TABLE `net_worth_snapshots`
  ADD CONSTRAINT `fk_nws_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- sgb_holdings → portfolios
-- ============================================================
ALTER TABLE `sgb_holdings`
  ADD CONSTRAINT `fk_sgb_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- sgb_interest_log → sgb_holdings, portfolios
-- ============================================================
ALTER TABLE `sgb_interest_log`
  ADD CONSTRAINT `fk_sgbil_sgb`
    FOREIGN KEY (`sgb_id`) REFERENCES `sgb_holdings` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sgbil_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- crypto_holdings → portfolios
-- ============================================================
ALTER TABLE `crypto_holdings`
  ADD CONSTRAINT `fk_ch_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- crypto_transactions → portfolios
-- ============================================================
ALTER TABLE `crypto_transactions`
  ADD CONSTRAINT `fk_ct_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- vda_transactions → portfolios
-- ============================================================
ALTER TABLE `vda_transactions`
  ADD CONSTRAINT `fk_vda_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- vda_tds_log → portfolios
-- ============================================================
ALTER TABLE `vda_tds_log`
  ADD CONSTRAINT `fk_vdatds_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- esop_grants → portfolios
-- ============================================================
ALTER TABLE `esop_grants`
  ADD CONSTRAINT `fk_eg_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- esop_vesting_events → esop_grants
-- ============================================================
ALTER TABLE `esop_vesting_events`
  ADD CONSTRAINT `fk_eve_grant`
    FOREIGN KEY (`grant_id`) REFERENCES `esop_grants` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- esop_exercise_log → esop_grants, esop_vesting_events
-- ============================================================
ALTER TABLE `esop_exercise_log`
  ADD CONSTRAINT `fk_eel_grant`
    FOREIGN KEY (`grant_id`) REFERENCES `esop_grants` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_eel_event`
    FOREIGN KEY (`vesting_event_id`) REFERENCES `esop_vesting_events` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE;

-- ============================================================
-- reits_invits → portfolios
-- ============================================================
ALTER TABLE `reits_invits`
  ADD CONSTRAINT `fk_ri_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_ri_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- reits_invits_transactions → reits_invits, portfolios
-- ============================================================
ALTER TABLE `reits_invits_transactions`
  ADD CONSTRAINT `fk_rit_holding`
    FOREIGN KEY (`holding_id`) REFERENCES `reits_invits` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rit_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- reits_invits_distributions → reits_invits
-- ============================================================
ALTER TABLE `reits_invits_distributions`
  ADD CONSTRAINT `fk_rid_holding`
    FOREIGN KEY (`holding_id`) REFERENCES `reits_invits` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- etf_holdings → portfolios, etf_master
-- ============================================================
ALTER TABLE `etf_holdings`
  ADD CONSTRAINT `fk_eh_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_eh_etf`
    FOREIGN KEY (`etf_id`) REFERENCES `etf_master` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- etf_transactions → portfolios, etf_master
-- ============================================================
ALTER TABLE `etf_transactions`
  ADD CONSTRAINT `fk_et_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_et_etf`
    FOREIGN KEY (`etf_id`) REFERENCES `etf_master` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- pms_holdings → portfolios, users
-- ============================================================
ALTER TABLE `pms_holdings`
  ADD CONSTRAINT `fk_pmsh_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pmsh_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- pms_transactions → pms_holdings, portfolios
-- ============================================================
ALTER TABLE `pms_transactions`
  ADD CONSTRAINT `fk_pmst_holding`
    FOREIGN KEY (`holding_id`) REFERENCES `pms_holdings` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pmst_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- pms_nav_history → pms_holdings
-- ============================================================
ALTER TABLE `pms_nav_history`
  ADD CONSTRAINT `fk_pnh_holding`
    FOREIGN KEY (`holding_id`) REFERENCES `pms_holdings` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- us_stock_holdings → portfolios, us_stock_master
-- ============================================================
ALTER TABLE `us_stock_holdings`
  ADD CONSTRAINT `fk_ush_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_ush_stock`
    FOREIGN KEY (`stock_id`) REFERENCES `us_stock_master` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- us_stock_transactions → portfolios, us_stock_master
-- ============================================================
ALTER TABLE `us_stock_transactions`
  ADD CONSTRAINT `fk_ust_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_ust_stock`
    FOREIGN KEY (`stock_id`) REFERENCES `us_stock_master` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- ============================================================
-- notifications → users
-- ============================================================
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notif_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- notification_prefs → users
-- ============================================================
ALTER TABLE `notification_prefs`
  ADD CONSTRAINT `fk_np_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- ai_chat_history → users
-- ============================================================
ALTER TABLE `ai_chat_history`
  ADD CONSTRAINT `fk_ach_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- ai_portfolio_reviews → users
-- ============================================================
ALTER TABLE `ai_portfolio_reviews`
  ADD CONSTRAINT `fk_apr_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- ai_anomalies → users
-- ============================================================
ALTER TABLE `ai_anomalies`
  ADD CONSTRAINT `fk_anom_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- zerodha_credentials → users
-- ============================================================
ALTER TABLE `zerodha_credentials`
  ADD CONSTRAINT `fk_zc_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- zerodha_sync_log → users
-- ============================================================
ALTER TABLE `zerodha_sync_log`
  ADD CONSTRAINT `fk_zsync_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- zerodha_holdings_raw → users
-- ============================================================
ALTER TABLE `zerodha_holdings_raw`
  ADD CONSTRAINT `fk_zhr_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- groww_api_credentials → users
-- ============================================================
ALTER TABLE `groww_api_credentials`
  ADD CONSTRAINT `fk_gac_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- groww_sync_log → users, portfolios
-- ============================================================
ALTER TABLE `groww_sync_log`
  ADD CONSTRAINT `fk_gsl_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_gsl_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- investment_journal → users
-- ============================================================
ALTER TABLE `investment_journal`
  ADD CONSTRAINT `fk_ij_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- credit_cards → users
-- ============================================================
ALTER TABLE `credit_cards`
  ADD CONSTRAINT `fk_cc_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- nudge_dismissals → users
-- ============================================================
ALTER TABLE `nudge_dismissals`
  ADD CONSTRAINT `fk_nd_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- spending_discipline → users
-- ============================================================
ALTER TABLE `spending_discipline`
  ADD CONSTRAINT `fk_spd_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

SET foreign_key_checks = 1;
