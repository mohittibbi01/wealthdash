-- ============================================================
-- WealthDash — Clean Master Schema
-- File 02: tables.sql
-- Generated: 2026-06-04
-- ============================================================
-- Contains ONLY final optimized CREATE TABLE statements.
-- All ALTER-based column additions have been merged into
-- the correct CREATE TABLE definitions.
-- All duplicate/stub definitions removed.
-- All missing columns (investment_fy, ltcg_date etc.) added.
-- ============================================================

USE `wealthdash`;
SET foreign_key_checks = 0;

-- ============================================================
-- GROUP 1: AUTHENTICATION & USERS
-- ============================================================

CREATE TABLE IF NOT EXISTS `users` (
  `id`               INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `name`             VARCHAR(100)     NOT NULL,
  `email`            VARCHAR(150)     NOT NULL,
  `password_hash`    VARCHAR(255)     DEFAULT NULL,
  `role`             ENUM('user','admin') NOT NULL DEFAULT 'user',
  `is_active`        TINYINT(1)       NOT NULL DEFAULT 1,
  `email_verified`   TINYINT(1)       NOT NULL DEFAULT 0,
  `theme`            VARCHAR(20)      NOT NULL DEFAULT 'light',
  `currency`         VARCHAR(10)      NOT NULL DEFAULT 'INR',
  `avatar_url`       VARCHAR(500)     DEFAULT NULL,
  `last_login`       DATETIME         DEFAULT NULL,
  -- 2FA columns (t386)
  `totp_secret`      VARCHAR(64)      DEFAULT NULL,
  `totp_enabled`     TINYINT(1)       NOT NULL DEFAULT 0,
  `totp_backup_codes`TEXT             DEFAULT NULL,
  `created_at`       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sessions` (
  `id`            VARCHAR(128)     NOT NULL,
  `user_id`       INT UNSIGNED     NOT NULL,
  `ip_address`    VARCHAR(45)      DEFAULT NULL,
  `user_agent`    VARCHAR(500)     DEFAULT NULL,
  `payload`       LONGTEXT         DEFAULT NULL,
  `last_activity` DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id`             BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`        INT UNSIGNED     NOT NULL,
  `session_token`  VARCHAR(128)     NOT NULL,
  `device_name`    VARCHAR(120)     DEFAULT NULL,
  `device_type`    ENUM('desktop','mobile','tablet','unknown') DEFAULT 'unknown',
  `browser`        VARCHAR(80)      DEFAULT NULL,
  `ip_address`     VARCHAR(45)      DEFAULT NULL,
  `last_active`    DATETIME         NOT NULL,
  `created_at`     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_session_token` (`session_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `email`        VARCHAR(150)  NOT NULL,
  `ip_address`   VARCHAR(45)   NOT NULL,
  `attempted_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `success`      TINYINT(1)    NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `otp_tokens` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED  NOT NULL,
  `token`      VARCHAR(10)   NOT NULL,
  `purpose`    VARCHAR(50)   NOT NULL DEFAULT 'login',
  `expires_at` DATETIME      NOT NULL,
  `used_at`    DATETIME      DEFAULT NULL,
  `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `password_resets` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `email`      VARCHAR(150)  NOT NULL,
  `token`      VARCHAR(100)  NOT NULL,
  `expires_at` DATETIME      NOT NULL,
  `used_at`    DATETIME      DEFAULT NULL,
  `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pr_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `google_auth` (
  `id`               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`          INT UNSIGNED  NOT NULL,
  `google_id`        VARCHAR(100)  NOT NULL,
  `access_token`     TEXT          DEFAULT NULL,
  `refresh_token`    TEXT          DEFAULT NULL,
  `token_expires_at` DATETIME      DEFAULT NULL,
  `created_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_google_id` (`google_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `rate_limit_buckets` (
  `bucket_key`   VARCHAR(180)     NOT NULL,
  `requests`     SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `window_start` INT UNSIGNED     NOT NULL,
  PRIMARY KEY (`bucket_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 2: SYSTEM & AUDIT
-- ============================================================

CREATE TABLE IF NOT EXISTS `app_settings` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(100)  NOT NULL,
  `setting_val` TEXT          DEFAULT NULL,
  `updated_by`  INT UNSIGNED  DEFAULT NULL,
  `updated_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `audit_log` (
  `id`          BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED     DEFAULT NULL,
  `action`      VARCHAR(100)     NOT NULL,
  `entity_type` VARCHAR(50)      DEFAULT NULL,
  `entity_id`   INT UNSIGNED     DEFAULT NULL,
  `old_values`  LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
                CHECK (json_valid(`old_values`)),
  `new_values`  LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
                CHECK (json_valid(`new_values`)),
  `ip_address`  VARCHAR(45)      DEFAULT NULL,
  `created_at`  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `migration_log` (
  `id`          INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `filename`    VARCHAR(255)   NOT NULL,
  `checksum`    VARCHAR(64)    NOT NULL,
  `batch`       SMALLINT       NOT NULL DEFAULT 1,
  `executed_at` DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `duration_ms` INT            DEFAULT NULL,
  `notes`       TEXT           DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_filename` (`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 3: PORTFOLIO CORE
-- ============================================================

CREATE TABLE IF NOT EXISTS `portfolios` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED  NOT NULL,
  `name`        VARCHAR(100)  NOT NULL DEFAULT 'My Portfolio',
  `description` TEXT          DEFAULT NULL,
  `is_default`  TINYINT(1)    NOT NULL DEFAULT 0,
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `import_logs` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`        INT UNSIGNED  NOT NULL,
  `portfolio_id`   INT UNSIGNED  DEFAULT NULL,
  `import_type`    VARCHAR(50)   NOT NULL COMMENT 'cams_cas, kfintech_cas, groww_csv, zerodha_csv, kuvera_csv, wealthdash_csv, other',
  `filename`       VARCHAR(300)  DEFAULT NULL,
  `rows_total`     INT           NOT NULL DEFAULT 0,
  `rows_success`   INT           NOT NULL DEFAULT 0,
  `rows_failed`    INT           NOT NULL DEFAULT 0,
  `rows_skipped`   INT           NOT NULL DEFAULT 0,
  `status`         ENUM('pending','processing','done','partial','failed') NOT NULL DEFAULT 'pending',
  `error_log`      TEXT          DEFAULT NULL,
  `rollback_data`  LONGTEXT      DEFAULT NULL COMMENT 'JSON for import undo',
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at`   DATETIME      DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 4: MUTUAL FUNDS MASTER
-- ============================================================

CREATE TABLE IF NOT EXISTS `fund_houses` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(150)  NOT NULL,
  `short_name` VARCHAR(50)   DEFAULT NULL,
  `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fh_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `funds` (
  -- Core identification
  `id`                    INT UNSIGNED      NOT NULL AUTO_INCREMENT,
  `scheme_code`           VARCHAR(20)       NOT NULL,
  `isin`                  VARCHAR(20)       DEFAULT NULL,
  `isin_reinvest`         VARCHAR(20)       DEFAULT NULL,
  `fund_house_id`         INT UNSIGNED      DEFAULT NULL,
  `scheme_name`           VARCHAR(300)      NOT NULL,
  `scheme_type`           VARCHAR(100)      DEFAULT NULL,
  `scheme_category`       VARCHAR(100)      DEFAULT NULL,
  `scheme_sub_category`   VARCHAR(100)      DEFAULT NULL,
  `fund_type`             VARCHAR(50)       DEFAULT NULL COMMENT 'open_ended, close_ended, interval',
  -- NAV
  `nav`                   DECIMAL(14,4)     DEFAULT NULL,
  `nav_date`              DATE              DEFAULT NULL,
  -- Returns (File 07 ALTER merged in)
  `return_1y`             DECIMAL(8,4)      DEFAULT NULL COMMENT 'AMFI-published 1Y return',
  `return_3y`             DECIMAL(8,4)      DEFAULT NULL,
  `return_5y`             DECIMAL(8,4)      DEFAULT NULL,
  `return_since`          DECIMAL(8,4)      DEFAULT NULL,
  `returns_1y`            DECIMAL(8,4)      DEFAULT NULL COMMENT 'Cron-calculated 1Y CAGR',
  `returns_3y`            DECIMAL(8,4)      DEFAULT NULL,
  `returns_5y`            DECIMAL(8,4)      DEFAULT NULL,
  `returns_10y`           DECIMAL(8,4)      DEFAULT NULL,
  `returns_updated_at`    DATETIME          DEFAULT NULL,
  -- Risk metrics (File 07, 12, 13 ALTERs merged in)
  `sharpe_ratio`          DECIMAL(8,4)      DEFAULT NULL,
  `sortino_ratio`         DECIMAL(8,4)      DEFAULT NULL,
  `max_drawdown`          DECIMAL(8,4)      DEFAULT NULL,
  `max_drawdown_date`     DATE              DEFAULT NULL,
  `max_drawdown_from_nav` DECIMAL(12,4)     DEFAULT NULL,
  `alpha`                 DECIMAL(8,4)      DEFAULT NULL,
  `beta`                  DECIMAL(8,4)      DEFAULT NULL,
  `standard_deviation`    DECIMAL(8,4)      DEFAULT NULL,
  `r_squared`             DECIMAL(5,2)      DEFAULT NULL,
  `alpha_updated_at`      DATETIME          DEFAULT NULL,
  -- Category peer averages (File 07, 13)
  `category_avg_1y`       DECIMAL(8,4)      DEFAULT NULL,
  `category_avg_3y`       DECIMAL(8,4)      DEFAULT NULL,
  `category_avg_5y`       DECIMAL(8,4)      DEFAULT NULL,
  `category_rank_1y`      SMALLINT          DEFAULT NULL,
  `category_total`        SMALLINT          DEFAULT NULL,
  -- Fund details
  `aum_cr`                DECIMAL(14,2)     DEFAULT NULL,
  `expense_ratio`         DECIMAL(5,3)      DEFAULT NULL,
  `exit_load_text`        TEXT              DEFAULT NULL,
  `exit_load_pct`         DECIMAL(5,3)      DEFAULT NULL,
  `exit_load_days`        INT               DEFAULT NULL,
  `min_ltcg_days`         INT               DEFAULT 365 COMMENT 'Days for LTCG eligibility',
  `lock_in_days`          INT               DEFAULT NULL COMMENT 'ELSS lock-in days',
  `risk_level`            VARCHAR(30)       DEFAULT NULL,
  `benchmark`             VARCHAR(150)      DEFAULT NULL,
  `fund_manager`          VARCHAR(200)      DEFAULT NULL,
  `manager_since`         DATE              DEFAULT NULL,
  `min_sip_amount`        DECIMAL(10,2)     DEFAULT NULL,
  `min_lumpsum`           DECIMAL(10,2)     DEFAULT NULL,
  -- Style box (File 24 merged in)
  `style_size`            ENUM('large','mid','small') DEFAULT NULL,
  `style_value`           ENUM('value','blend','growth') DEFAULT NULL,
  `style_box`             VARCHAR(20) GENERATED ALWAYS AS (
                            CASE WHEN style_size IS NOT NULL AND style_value IS NOT NULL
                                 THEN CONCAT(style_size, '_', style_value)
                                 ELSE NULL END
                          ) STORED,
  `style_drift_note`      VARCHAR(500)      DEFAULT NULL,
  `avg_market_cap_cr`     DECIMAL(14,2)     DEFAULT NULL,
  `avg_pe_ratio`          DECIMAL(8,2)      DEFAULT NULL,
  `style_updated_at`      DATETIME          DEFAULT NULL,
  -- Ratings (File 23 merged in)
  `wd_stars`              TINYINT UNSIGNED  DEFAULT NULL COMMENT '1-5 star rating',
  -- Status
  `is_active`             TINYINT(1)        NOT NULL DEFAULT 1,
  `created_at`            DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`            DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_scheme_code` (`scheme_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nav_history` (
  `id`       BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_id`  INT UNSIGNED     NOT NULL,
  `nav_date` DATE             NOT NULL,
  `nav`      DECIMAL(14,4)    NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nav` (`fund_id`, `nav_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nav_download_progress` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_id`      INT UNSIGNED  DEFAULT NULL,
  `scheme_code`  VARCHAR(20)   NOT NULL,
  `status`       ENUM('pending','running','downloading','completed','done','error','needs_update') NOT NULL DEFAULT 'pending',
  `total_records`INT           NOT NULL DEFAULT 0,
  `records_saved`INT           NOT NULL DEFAULT 0,
  `last_nav_date`DATE          DEFAULT NULL,
  `from_date`    DATE          DEFAULT NULL COMMENT 'Earliest date downloaded',
  `error_message`VARCHAR(500)  DEFAULT NULL,
  `updated_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_scheme` (`scheme_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nav_proxy_cache` (
  `fund_id`     INT UNSIGNED  NOT NULL,
  `period`      ENUM('1M','3M','6M','1Y','3Y','5Y','ALL') NOT NULL,
  `data_json`   LONGTEXT      NOT NULL,
  `data_points` INT           NOT NULL DEFAULT 0,
  `cached_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `source`      ENUM('nav_history','mfapi') NOT NULL DEFAULT 'nav_history',
  PRIMARY KEY (`fund_id`, `period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mf_peak_progress` (
  `scheme_code`         VARCHAR(20)  NOT NULL,
  `last_processed_date` DATE         DEFAULT NULL,
  `status`              ENUM('pending','in_progress','completed','needs_update','error') NOT NULL DEFAULT 'pending',
  `error_message`       TEXT         DEFAULT NULL,
  `updated_at`          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`scheme_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fund_ratings` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_id`         INT UNSIGNED  NOT NULL,
  `stars`           TINYINT UNSIGNED NOT NULL COMMENT '1-5',
  `score_total`     DECIMAL(6,4)  DEFAULT NULL,
  `score_breakdown` JSON          DEFAULT NULL,
  `rated_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fr_fund` (`fund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fund_stock_holdings` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_id`    INT UNSIGNED  NOT NULL,
  `stock_name` VARCHAR(300)  NOT NULL,
  `isin`       VARCHAR(15)   DEFAULT NULL,
  `sector`     VARCHAR(100)  DEFAULT NULL,
  `weight_pct` DECIMAL(6,3)  NOT NULL,
  `market_cap` ENUM('large','mid','small','other') DEFAULT NULL,
  `month_year` DATE          NOT NULL,
  `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fund_stock_month` (`fund_id`, `isin`(15), `month_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fund_overlap_cache` (
  `fund_id_a`    INT UNSIGNED  NOT NULL,
  `fund_id_b`    INT UNSIGNED  NOT NULL,
  `overlap_pct`  DECIMAL(5,2)  NOT NULL,
  `common_stocks`SMALLINT      NOT NULL DEFAULT 0,
  `month_year`   DATE          NOT NULL,
  `updated_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`fund_id_a`, `fund_id_b`, `month_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fund_managers` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_id`      INT UNSIGNED  NOT NULL,
  `manager_name` VARCHAR(200)  NOT NULL,
  `from_date`    DATE          NOT NULL,
  `to_date`      DATE          DEFAULT NULL,
  `is_current`   TINYINT(1)    NOT NULL DEFAULT 1,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `expense_ratio_history` (
  `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_id`       INT UNSIGNED  NOT NULL,
  `expense_ratio` DECIMAL(6,4)  NOT NULL,
  `plan_type`     ENUM('direct','regular') NOT NULL DEFAULT 'direct',
  `recorded_date` DATE          NOT NULL,
  `source`        VARCHAR(100)  DEFAULT 'amfi_website',
  `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_exp_fund_month` (`fund_id`, `plan_type`, `recorded_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nfo_tracker` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_name`      VARCHAR(300)  NOT NULL,
  `amc`            VARCHAR(200)  NOT NULL,
  `scheme_code`    VARCHAR(50)   DEFAULT NULL,
  `category`       VARCHAR(100)  DEFAULT NULL,
  `nfo_price`      DECIMAL(10,4) DEFAULT 10.0000,
  `min_investment` DECIMAL(12,2) DEFAULT 5000.00,
  `open_date`      DATE          NOT NULL,
  `close_date`     DATE          NOT NULL,
  `allotment_date` DATE          DEFAULT NULL,
  `status`         ENUM('upcoming','open','closing_soon','closed','allotted') NOT NULL DEFAULT 'upcoming',
  `fund_type`      ENUM('open_ended','close_ended','interval') DEFAULT 'open_ended',
  `tax_saving`     TINYINT(1)    NOT NULL DEFAULT 0,
  `benchmark`      VARCHAR(200)  DEFAULT NULL,
  `fund_manager`   VARCHAR(200)  DEFAULT NULL,
  `amc_website`    VARCHAR(500)  DEFAULT NULL,
  `last_updated`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nfo_name_open` (`fund_name`(150), `open_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fund_watchlist` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED  NOT NULL,
  `fund_id`    INT UNSIGNED  NOT NULL,
  `notes`      TEXT          DEFAULT NULL,
  `alert_nav`  DECIMAL(10,4) DEFAULT NULL,
  `alert_type` ENUM('above','below') DEFAULT NULL,
  `added_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_fund` (`user_id`, `fund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `price_alerts` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED  NOT NULL,
  `fund_id`      INT UNSIGNED  NOT NULL,
  `type`         ENUM('above','below') NOT NULL,
  `target_nav`   DECIMAL(12,4) NOT NULL,
  `note`         VARCHAR(300)  DEFAULT NULL,
  `is_active`    TINYINT(1)    NOT NULL DEFAULT 1,
  `triggered_at` DATETIME      DEFAULT NULL,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mf_compare_sessions` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED  NOT NULL,
  `fund_ids`   VARCHAR(100)  NOT NULL COMMENT 'comma-separated fund IDs, max 5',
  `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 5: MF HOLDINGS & TRANSACTIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS `mf_holdings` (
  `id`                    INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `portfolio_id`          INT UNSIGNED   NOT NULL,
  `fund_id`               INT UNSIGNED   NOT NULL,
  `folio_number`          VARCHAR(50)    DEFAULT NULL,
  `platform`              VARCHAR(50)    DEFAULT NULL,
  `units`                 DECIMAL(18,4)  NOT NULL DEFAULT 0.0000,
  `avg_nav`               DECIMAL(14,4)  NOT NULL DEFAULT 0.0000,
  `invested_amount`       DECIMAL(16,2)  NOT NULL DEFAULT 0.00,
  `current_value`         DECIMAL(16,2)  NOT NULL DEFAULT 0.00,
  `gain_loss`             DECIMAL(16,2)  NOT NULL DEFAULT 0.00,
  `xirr`                  DECIMAL(8,4)   DEFAULT NULL,
  `sip_active`            TINYINT(1)     NOT NULL DEFAULT 0,
  `swp_active`            TINYINT(1)     NOT NULL DEFAULT 0,
  -- Missing columns (referenced by 04_fix_corrupted_data.sql but never defined in original)
  `investment_fy`         VARCHAR(10)    DEFAULT NULL COMMENT 'e.g. 2024-25',
  `ltcg_date`             DATE           DEFAULT NULL COMMENT 'Date when LTCG eligibility begins',
  `lock_in_date`          DATE           DEFAULT NULL COMMENT 'ELSS lock-in expiry date',
  `withdrawable_date`     DATE           DEFAULT NULL COMMENT 'Later of ltcg_date and lock_in_date',
  `withdrawable_fy`       VARCHAR(10)    DEFAULT NULL COMMENT 'FY of withdrawable_date',
  `status`                ENUM('active','redeemed','switched_out') NOT NULL DEFAULT 'active',
  `first_investment_date` DATE           DEFAULT NULL,
  `last_transaction_date` DATE           DEFAULT NULL,
  `notes`                 TEXT           DEFAULT NULL,
  `created_at`            DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`            DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mfh` (`portfolio_id`, `fund_id`, `folio_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mf_transactions` (
  `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`  INT UNSIGNED  NOT NULL,
  `fund_id`       INT UNSIGNED  NOT NULL,
  `folio_number`  VARCHAR(50)   DEFAULT NULL,
  `txn_type`      ENUM('purchase','redemption','switch_in','switch_out','dividend_reinvest','sip','swp') NOT NULL,
  `txn_date`      DATE          NOT NULL,
  `units`         DECIMAL(18,4) NOT NULL DEFAULT 0.0000,
  `nav`           DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `amount`        DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `platform`      VARCHAR(50)   DEFAULT NULL,
  `investment_fy` VARCHAR(10)   DEFAULT NULL COMMENT 'e.g. 2024-25',
  `notes`         TEXT          DEFAULT NULL,
  `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mf_dividends` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`    INT UNSIGNED  NOT NULL,
  `fund_id`         INT UNSIGNED  NOT NULL,
  `folio_number`    VARCHAR(50)   DEFAULT NULL,
  `dividend_date`   DATE          NOT NULL,
  `nav_before`      DECIMAL(12,4) DEFAULT NULL,
  `nav_after`       DECIMAL(12,4) DEFAULT NULL,
  `rate_per_unit`   DECIMAL(10,4) DEFAULT NULL,
  `units_held`      DECIMAL(18,4) DEFAULT NULL,
  `total_dividend`  DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `tds_deducted`    DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `net_dividend`    DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `dividend_type`   ENUM('cash','reinvest') NOT NULL DEFAULT 'cash',
  `is_reinvested`   TINYINT(1)    NOT NULL DEFAULT 0,
  `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mf_holding_notes` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id` INT UNSIGNED  NOT NULL,
  `fund_id`      INT UNSIGNED  NOT NULL,
  `folio_number` VARCHAR(50)   DEFAULT NULL,
  `note`         TEXT          NOT NULL,
  `updated_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_note` (`portfolio_id`, `fund_id`, `folio_number`(30))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sector_rotation_cache` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `sector_name` VARCHAR(100)  NOT NULL,
  `sector_slug` VARCHAR(60)   NOT NULL,
  `ret_1m`      DECIMAL(8,4)  DEFAULT NULL,
  `ret_3m`      DECIMAL(8,4)  DEFAULT NULL,
  `ret_6m`      DECIMAL(8,4)  DEFAULT NULL,
  `ret_1y`      DECIMAL(8,4)  DEFAULT NULL,
  `fund_count`  SMALLINT UNSIGNED DEFAULT 0,
  `top_fund_id` INT UNSIGNED  DEFAULT NULL,
  `data_source` ENUM('category_proxy','amfi_holdings') NOT NULL DEFAULT 'category_proxy',
  `computed_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sr_sector` (`sector_slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sector_rotation_history` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `sector_slug` VARCHAR(60)   NOT NULL,
  `period_date` DATE          NOT NULL,
  `ret_1m`      DECIMAL(8,4)  DEFAULT NULL,
  `ret_3m`      DECIMAL(8,4)  DEFAULT NULL,
  `ret_1y`      DECIMAL(8,4)  DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_srh_sector_date` (`sector_slug`, `period_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 6: SIP
-- ============================================================

CREATE TABLE IF NOT EXISTS `sip_schedules` (
  `id`               INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `portfolio_id`     INT UNSIGNED   NOT NULL,
  `asset_type`       ENUM('mf','stock','nps') NOT NULL DEFAULT 'mf',
  `fund_id`          INT UNSIGNED   DEFAULT NULL,
  `stock_id`         INT UNSIGNED   DEFAULT NULL,
  `nps_scheme_id`    INT UNSIGNED   DEFAULT NULL,
  `folio_number`     VARCHAR(50)    DEFAULT NULL,
  `sip_amount`       DECIMAL(14,2)  NOT NULL,
  `swp_amount`       DECIMAL(14,2)  DEFAULT NULL,
  `sip_type`         ENUM('sip','swp') NOT NULL DEFAULT 'sip',
  `frequency`        ENUM('monthly','quarterly','weekly','yearly') NOT NULL DEFAULT 'monthly',
  `sip_day`          TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `start_date`       DATE           NOT NULL,
  `end_date`         DATE           DEFAULT NULL,
  `platform`         VARCHAR(50)    DEFAULT NULL,
  `is_active`        TINYINT(1)     NOT NULL DEFAULT 1,
  `notes`            VARCHAR(255)   DEFAULT NULL,
  -- Step-up columns (File 18 merged in)
  `step_up_pct`      DECIMAL(5,2)   DEFAULT NULL,
  `step_up_frequency`ENUM('annual','semi_annual') DEFAULT 'annual',
  `step_up_next_date`DATE           DEFAULT NULL,
  `step_up_max_amount`DECIMAL(12,2) DEFAULT NULL,
  `created_at`       DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 7: NPS
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_schemes` (
  `id`                    INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `pfm_name`              VARCHAR(100)  NOT NULL,
  `scheme_name`           VARCHAR(200)  NOT NULL,
  `scheme_code`           VARCHAR(30)   NOT NULL,
  `tier`                  ENUM('tier1','tier2') NOT NULL DEFAULT 'tier1',
  `asset_class`           ENUM('E','C','G','A') NOT NULL DEFAULT 'E',
  `nav`                   DECIMAL(12,4) DEFAULT NULL,
  `nav_date`              DATE          DEFAULT NULL,
  `return_1y`             DECIMAL(8,4)  DEFAULT NULL,
  `return_3y`             DECIMAL(8,4)  DEFAULT NULL,
  `return_5y`             DECIMAL(8,4)  DEFAULT NULL,
  `return_since`          DECIMAL(8,4)  DEFAULT NULL,
  `aum_cr`                DECIMAL(14,2) DEFAULT NULL,
  `nav_returns_updated_at`DATETIME      DEFAULT NULL,
  `is_active`             TINYINT(1)    NOT NULL DEFAULT 1,
  `created_at`            DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nps_code` (`scheme_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nps_holdings` (
  `id`                   INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`         INT UNSIGNED  NOT NULL,
  `scheme_id`            INT UNSIGNED  NOT NULL,
  `units`                DECIMAL(18,4) NOT NULL DEFAULT 0.0000,
  `avg_nav`              DECIMAL(12,4) NOT NULL DEFAULT 0.0000,
  `invested_amount`      DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `current_value`        DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `gain_loss`            DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `gain_pct`             DECIMAL(8,4)  NOT NULL DEFAULT 0.0000,
  `cagr`                 DECIMAL(8,4)  NOT NULL DEFAULT 0.0000,
  `first_investment_date`DATE          DEFAULT NULL,
  `notes`                TEXT          DEFAULT NULL,
  `created_at`           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_npsh` (`portfolio_id`, `scheme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nps_transactions` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id` INT UNSIGNED  NOT NULL,
  `scheme_id`    INT UNSIGNED  NOT NULL,
  `txn_type`     ENUM('purchase','redemption','switch_in','switch_out') NOT NULL DEFAULT 'purchase',
  `txn_date`     DATE          NOT NULL,
  `units`        DECIMAL(18,4) NOT NULL DEFAULT 0.0000,
  `nav`          DECIMAL(12,4) NOT NULL DEFAULT 0.0000,
  `amount`       DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `notes`        TEXT          DEFAULT NULL,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nps_nav_history` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `scheme_id`  INT UNSIGNED  NOT NULL,
  `nav_date`   DATE          NOT NULL,
  `nav`        DECIMAL(12,4) NOT NULL,
  `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nps_nav` (`scheme_id`, `nav_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 8: STOCKS
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_master` (
  -- Core (base schema)
  `id`                     INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `exchange`               ENUM('NSE','BSE') NOT NULL DEFAULT 'NSE',
  `symbol`                 VARCHAR(30)     NOT NULL,
  `company_name`           VARCHAR(200)    NOT NULL,
  `isin`                   VARCHAR(20)     DEFAULT NULL,
  `sector`                 VARCHAR(100)    DEFAULT NULL,
  `industry`               VARCHAR(100)    DEFAULT NULL,
  `current_price`          DECIMAL(12,4)   DEFAULT NULL,
  `prev_close`             DECIMAL(12,4)   DEFAULT NULL,
  `day_change_pct`         DECIMAL(8,4)    DEFAULT NULL,
  `price_updated_at`       DATETIME        DEFAULT NULL,
  -- Fundamental columns (t431 ALTER merged in)
  `market_cap`             DECIMAL(22,4)   DEFAULT NULL COMMENT 'INR crores',
  `enterprise_value`       DECIMAL(22,4)   DEFAULT NULL,
  `pe_ratio`               DECIMAL(12,4)   DEFAULT NULL,
  `pb_ratio`               DECIMAL(10,4)   DEFAULT NULL,
  `ps_ratio`               DECIMAL(10,4)   DEFAULT NULL,
  `ev_ebitda`              DECIMAL(10,4)   DEFAULT NULL,
  `eps_ttm`                DECIMAL(12,4)   DEFAULT NULL,
  `eps_growth_yoy`         DECIMAL(8,4)    DEFAULT NULL,
  `revenue_ttm`            DECIMAL(22,4)   DEFAULT NULL,
  `net_profit_ttm`         DECIMAL(22,4)   DEFAULT NULL,
  `roe`                    DECIMAL(8,4)    DEFAULT NULL,
  `roce`                   DECIMAL(8,4)    DEFAULT NULL,
  `roa`                    DECIMAL(8,4)    DEFAULT NULL,
  `debt_to_equity`         DECIMAL(10,4)   DEFAULT NULL,
  `current_ratio`          DECIMAL(10,4)   DEFAULT NULL,
  `quick_ratio`            DECIMAL(10,4)   DEFAULT NULL,
  `interest_coverage`      DECIMAL(10,4)   DEFAULT NULL,
  `dividend_yield`         DECIMAL(8,4)    DEFAULT NULL,
  `dividend_payout_ratio`  DECIMAL(8,4)    DEFAULT NULL,
  `book_value`             DECIMAL(14,4)   DEFAULT NULL,
  `face_value`             DECIMAL(10,4)   DEFAULT NULL,
  `high_52`                DECIMAL(14,4)   DEFAULT NULL,
  `low_52`                 DECIMAL(14,4)   DEFAULT NULL,
  `beta`                   DECIMAL(8,4)    DEFAULT NULL,
  `avg_volume_30d`         BIGINT UNSIGNED DEFAULT NULL,
  `shares_outstanding`     BIGINT UNSIGNED DEFAULT NULL,
  `float_shares`           BIGINT UNSIGNED DEFAULT NULL,
  `promoter_holding_pct`   DECIMAL(6,3)    DEFAULT NULL,
  `fii_holding_pct`        DECIMAL(6,3)    DEFAULT NULL,
  `dii_holding_pct`        DECIMAL(6,3)    DEFAULT NULL,
  `public_holding_pct`     DECIMAL(6,3)    DEFAULT NULL,
  `fundamentals_source`    VARCHAR(30)     DEFAULT NULL,
  `fundamentals_updated_at`DATETIME        DEFAULT NULL,
  `created_at`             DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stock` (`exchange`, `symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stock_holdings` (
  `id`                 INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`       INT UNSIGNED  NOT NULL,
  `stock_id`           INT UNSIGNED  NOT NULL,
  `quantity`           DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `avg_price`          DECIMAL(12,4) NOT NULL DEFAULT 0.0000,
  `invested_amount`    DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `current_value`      DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `gain_loss`          DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `gain_pct`           DECIMAL(8,4)  NOT NULL DEFAULT 0.0000,
  `current_price`      DECIMAL(12,4) NOT NULL DEFAULT 0.0000,
  `status`             ENUM('active','sold') NOT NULL DEFAULT 'active',
  `first_purchase_date`DATE          DEFAULT NULL,
  `notes`              TEXT          DEFAULT NULL,
  `created_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sh` (`portfolio_id`, `stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stock_transactions` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id` INT UNSIGNED  NOT NULL,
  `stock_id`     INT UNSIGNED  NOT NULL,
  `txn_type`     ENUM('buy','sell','bonus','split','rights') NOT NULL DEFAULT 'buy',
  `txn_date`     DATE          NOT NULL,
  `quantity`     DECIMAL(14,4) NOT NULL,
  `price`        DECIMAL(12,4) NOT NULL,
  `brokerage`    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `notes`        TEXT          DEFAULT NULL,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stock_dividends` (
  `id`                INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`      INT UNSIGNED  NOT NULL,
  `stock_id`          INT UNSIGNED  NOT NULL,
  `ex_date`           DATE          NOT NULL,
  `dividend_per_share`DECIMAL(10,4) NOT NULL,
  `shares_held`       DECIMAL(14,4) DEFAULT NULL,
  `total_dividend`    DECIMAL(14,2) DEFAULT NULL,
  `tds_deducted`      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `notes`             TEXT          DEFAULT NULL,
  `created_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stock_corporate_actions` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `stock_id`    INT UNSIGNED  NOT NULL,
  `action_type` ENUM('split','bonus','rights','merger','demerger') NOT NULL,
  `action_date` DATE          NOT NULL,
  `ratio_from`  DECIMAL(10,4) DEFAULT NULL,
  `ratio_to`    DECIMAL(10,4) DEFAULT NULL,
  `notes`       TEXT          DEFAULT NULL,
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stock_fundamentals_history` (
  `id`               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `stock_id`         INT UNSIGNED  NOT NULL,
  `period`           VARCHAR(10)   NOT NULL COMMENT 'e.g. Q3FY25, FY2024',
  `period_type`      ENUM('quarterly','annual') NOT NULL DEFAULT 'quarterly',
  `pe_ratio`         DECIMAL(12,4) DEFAULT NULL,
  `pb_ratio`         DECIMAL(10,4) DEFAULT NULL,
  `market_cap`       DECIMAL(22,4) DEFAULT NULL,
  `eps`              DECIMAL(12,4) DEFAULT NULL,
  `revenue`          DECIMAL(22,4) DEFAULT NULL,
  `net_profit`       DECIMAL(22,4) DEFAULT NULL,
  `roe`              DECIMAL(8,4)  DEFAULT NULL,
  `roce`             DECIMAL(8,4)  DEFAULT NULL,
  `debt_to_equity`   DECIMAL(10,4) DEFAULT NULL,
  `promoter_holding` DECIMAL(6,3)  DEFAULT NULL,
  `fii_holding`      DECIMAL(6,3)  DEFAULT NULL,
  `source`           VARCHAR(30)   DEFAULT NULL,
  `fetched_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sfh_stock_period` (`stock_id`, `period`, `period_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stock_screener_filters` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED  NOT NULL,
  `name`        VARCHAR(100)  NOT NULL,
  `filter_json` JSON          NOT NULL,
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 9: FIXED INCOME
-- ============================================================

CREATE TABLE IF NOT EXISTS `fd_accounts` (
  `id`               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`     INT UNSIGNED  NOT NULL,
  `bank_name`        VARCHAR(100)  NOT NULL,
  `fd_type`          ENUM('cumulative','non_cumulative','tax_saver','flexi','senior_citizen') NOT NULL DEFAULT 'cumulative',
  `principal_amount` DECIMAL(14,2) NOT NULL,
  `interest_rate`    DECIMAL(6,3)  NOT NULL,
  `compounding`      ENUM('monthly','quarterly','half_yearly','yearly','at_maturity') NOT NULL DEFAULT 'quarterly',
  `start_date`       DATE          NOT NULL,
  `maturity_date`    DATE          NOT NULL,
  `maturity_amount`  DECIMAL(14,2) DEFAULT NULL,
  `interest_earned`  DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `status`           ENUM('active','matured','broken','renewed') NOT NULL DEFAULT 'active',
  `auto_renew`       TINYINT(1)    NOT NULL DEFAULT 0,
  `folio_number`     VARCHAR(50)   DEFAULT NULL,
  `nominee`          VARCHAR(100)  DEFAULT NULL,
  `notes`            TEXT          DEFAULT NULL,
  `created_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fd_interest_accruals` (
  `id`                  INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fd_id`               INT UNSIGNED  NOT NULL,
  `accrual_date`        DATE          NOT NULL,
  `interest_amount`     DECIMAL(14,2) NOT NULL,
  `cumulative_interest` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fd_maturity_alerts` (
  `id`           BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED     NOT NULL,
  `fd_id`        INT UNSIGNED     NOT NULL,
  `alert_days`   TINYINT UNSIGNED NOT NULL,
  `is_sent`      TINYINT(1)       NOT NULL DEFAULT 0,
  `sent_at`      DATETIME         DEFAULT NULL,
  `is_dismissed` TINYINT(1)       NOT NULL DEFAULT 0,
  `created_at`   DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_fd_days` (`fd_id`, `alert_days`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fd_market_rates` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `bank_name`      VARCHAR(80)   NOT NULL,
  `tenure_label`   VARCHAR(30)   NOT NULL,
  `rate_general`   DECIMAL(5,2)  NOT NULL,
  `rate_senior`    DECIMAL(5,2)  NOT NULL,
  `effective_date` DATE          DEFAULT NULL,
  `source_url`     VARCHAR(300)  DEFAULT NULL,
  `updated_at`     DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fd_interest_log` (
  `id`              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`         INT UNSIGNED     NOT NULL,
  `fd_id`           INT UNSIGNED     NOT NULL,
  `credit_date`     DATE             NOT NULL,
  `interest_earned` DECIMAL(12,2)    NOT NULL,
  `tds_deducted`    DECIMAL(10,2)    DEFAULT 0,
  `created_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `savings_accounts` (
  `id`                    INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`          INT UNSIGNED  NOT NULL,
  `bank_name`             VARCHAR(100)  NOT NULL,
  `account_number`        VARCHAR(30)   DEFAULT NULL,
  `account_type`          VARCHAR(20)   NOT NULL DEFAULT 'savings',
  `status`                ENUM('active','closed') NOT NULL DEFAULT 'active',
  `current_balance`       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `balance_date`          DATE          DEFAULT NULL,
  `interest_rate`         DECIMAL(5,3)  NOT NULL DEFAULT 4.000,
  `annual_interest_earned`DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `notes`                 TEXT          DEFAULT NULL,
  `created_at`            DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`            DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `savings_interest` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `account_id`      INT UNSIGNED  NOT NULL,
  `interest_date`   DATE          NOT NULL,
  `interest_amount` DECIMAL(12,2) NOT NULL,
  `balance_after`   DECIMAL(14,2) DEFAULT NULL,
  `interest_fy`     VARCHAR(10)   NOT NULL,
  `notes`           TEXT          DEFAULT NULL,
  `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bank_accounts` (
  `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`  INT UNSIGNED  NOT NULL,
  `bank_name`     VARCHAR(100)  NOT NULL,
  `account_type`  ENUM('savings','current','salary','nre','nro','other') NOT NULL DEFAULT 'savings',
  `account_number`VARCHAR(30)   DEFAULT NULL,
  `ifsc_code`     VARCHAR(15)   DEFAULT NULL,
  `balance`       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `interest_rate` DECIMAL(5,3)  NOT NULL DEFAULT 4.000,
  `is_primary`    TINYINT(1)    NOT NULL DEFAULT 0,
  `notes`         TEXT          DEFAULT NULL,
  `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bank_balance_history` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `account_id`  INT UNSIGNED  NOT NULL,
  `balance`     DECIMAL(14,2) NOT NULL,
  `recorded_at` DATE          NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bbh` (`account_id`, `recorded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `epf_accounts` (
  `id`                  INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`        INT UNSIGNED  NOT NULL,
  `uan`                 VARCHAR(20)   DEFAULT NULL,
  `employer_name`       VARCHAR(100)  NOT NULL,
  `employee_share`      DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `employer_share`      DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `interest_earned`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_balance`       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `interest_rate`       DECIMAL(5,3)  NOT NULL DEFAULT 8.150,
  `monthly_contribution`DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `status`              ENUM('active','inactive','withdrawn') NOT NULL DEFAULT 'active',
  `last_updated`        DATE          DEFAULT NULL,
  `notes`               TEXT          DEFAULT NULL,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `po_schemes` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`    INT UNSIGNED  NOT NULL,
  `scheme_type`     ENUM('PPF','NSC','SCSS','MIS','SSY','KVP','TD','RD','NPS_APY') NOT NULL,
  `account_number`  VARCHAR(50)   DEFAULT NULL,
  `post_office`     VARCHAR(100)  DEFAULT NULL,
  `principal_amount`DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `current_value`   DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `interest_rate`   DECIMAL(6,3)  NOT NULL DEFAULT 0.000,
  `start_date`      DATE          NOT NULL,
  `maturity_date`   DATE          DEFAULT NULL,
  `maturity_amount` DECIMAL(14,2) DEFAULT NULL,
  `interest_earned` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `annual_deposit`  DECIMAL(14,2) DEFAULT NULL,
  `status`          ENUM('active','matured','closed','extended') NOT NULL DEFAULT 'active',
  `nominee`         VARCHAR(100)  DEFAULT NULL,
  `notes`           TEXT          DEFAULT NULL,
  `meta`            LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
                    CHECK (json_valid(`meta`)),
  `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `insurance_policies` (
  `id`                INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`      INT UNSIGNED  NOT NULL,
  `policy_number`     VARCHAR(50)   DEFAULT NULL,
  `insurer_name`      VARCHAR(100)  NOT NULL,
  `policy_type`       ENUM('term','health','ulip','endowment','money_back','vehicle','home','travel','other') NOT NULL DEFAULT 'term',
  `insured_name`      VARCHAR(100)  DEFAULT NULL,
  `sum_assured`       DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `premium_amount`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `premium_frequency` ENUM('monthly','quarterly','half_yearly','yearly','single') NOT NULL DEFAULT 'yearly',
  `premium_due_date`  DATE          DEFAULT NULL COMMENT 'Next premium due date',
  `start_date`        DATE          NOT NULL,
  `end_date`          DATE          DEFAULT NULL,
  `maturity_date`     DATE          DEFAULT NULL,
  `maturity_amount`   DECIMAL(16,2) DEFAULT NULL,
  `surrender_value`   DECIMAL(16,2) DEFAULT NULL,
  `status`            ENUM('active','lapsed','surrendered','matured','claimed') NOT NULL DEFAULT 'active',
  `nominee`           VARCHAR(100)  DEFAULT NULL,
  `notes`             TEXT          DEFAULT NULL,
  `created_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_accounts` (
  `id`                 INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`       INT UNSIGNED  NOT NULL,
  `lender_name`        VARCHAR(100)  NOT NULL,
  `loan_type`          ENUM('home','personal','vehicle','education','gold','business','other') NOT NULL DEFAULT 'personal',
  `account_number`     VARCHAR(50)   DEFAULT NULL,
  `principal_amount`   DECIMAL(16,2) NOT NULL,
  `outstanding_balance`DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `interest_rate`      DECIMAL(6,3)  NOT NULL,
  `rate_type`          ENUM('fixed','floating') NOT NULL DEFAULT 'fixed',
  `emi_amount`         DECIMAL(12,2) DEFAULT NULL,
  `tenure_months`      INT           DEFAULT NULL,
  `disbursement_date`  DATE          NOT NULL,
  `first_emi_date`     DATE          DEFAULT NULL,
  `end_date`           DATE          DEFAULT NULL,
  `prepayment_penalty` DECIMAL(5,3)  DEFAULT NULL,
  `status`             ENUM('active','closed','npa') NOT NULL DEFAULT 'active',
  `notes`              TEXT          DEFAULT NULL,
  `created_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 10: GOALS & PLANNING
-- ============================================================

CREATE TABLE IF NOT EXISTS `investment_goals` (
  `id`                 INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`       INT UNSIGNED  NOT NULL,
  `name`               VARCHAR(150)  NOT NULL,
  `description`        TEXT          DEFAULT NULL,
  `target_amount`      DECIMAL(16,2) NOT NULL,
  `target_date`        DATE          NOT NULL,
  `current_saved`      DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `monthly_sip_needed` DECIMAL(14,2) DEFAULT NULL,
  `expected_return_pct`DECIMAL(5,2)  NOT NULL DEFAULT 12.00,
  `priority`           ENUM('high','medium','low') NOT NULL DEFAULT 'medium',
  `color`              VARCHAR(7)    NOT NULL DEFAULT '#2563EB',
  `icon`               VARCHAR(30)   DEFAULT 'target',
  `linked_fund_ids`    LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
                       CHECK (json_valid(`linked_fund_ids`)),
  `linked_stock_ids`   LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
                       CHECK (json_valid(`linked_stock_ids`)),
  `linked_fd_ids`      LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
                       CHECK (json_valid(`linked_fd_ids`)),
  `is_achieved`        TINYINT(1)    NOT NULL DEFAULT 0,
  `achieved_at`        DATE          DEFAULT NULL,
  `created_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `goal_contributions` (
  `id`                INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `goal_id`           INT UNSIGNED  NOT NULL,
  `amount`            DECIMAL(14,2) NOT NULL,
  `contribution_date` DATE          NOT NULL,
  `note`              VARCHAR(255)  DEFAULT NULL,
  `created_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `goal_buckets` (
  `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED  NOT NULL,
  `name`          VARCHAR(150)  NOT NULL,
  `emoji`         VARCHAR(10)   NOT NULL DEFAULT '🎯',
  `color`         VARCHAR(7)    NOT NULL DEFAULT '#6366f1',
  `target_amount` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `target_date`   DATE          DEFAULT NULL,
  `notes`         TEXT          DEFAULT NULL,
  `is_achieved`   TINYINT(1)    NOT NULL DEFAULT 0,
  `achieved_at`   DATE          DEFAULT NULL,
  `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `goal_fund_links` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `goal_id`    INT UNSIGNED  NOT NULL,
  `fund_id`    INT UNSIGNED  DEFAULT NULL,
  `sip_id`     INT UNSIGNED  DEFAULT NULL,
  `link_type`  ENUM('holding','sip') NOT NULL DEFAULT 'holding',
  `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `rebalancing_targets` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`    INT UNSIGNED  NOT NULL,
  `asset_class`     ENUM('equity','debt','gold','cash','international','other') NOT NULL,
  `target_pct`      DECIMAL(5,2)  NOT NULL,
  `drift_threshold` DECIMAL(5,2)  NOT NULL DEFAULT 5.00,
  `updated_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rebal_portfolio_asset` (`portfolio_id`, `asset_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `investment_calendar_events` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED  DEFAULT NULL,
  `event_date`   DATE          NOT NULL,
  `event_type`   ENUM('tax_deadline','sebi_compliance','rbi_policy','budget','sgb_window','nfo_open','nfo_close','advance_tax','custom') NOT NULL DEFAULT 'custom',
  `title`        VARCHAR(200)  NOT NULL,
  `description`  TEXT          DEFAULT NULL,
  `icon`         VARCHAR(10)   DEFAULT '📅',
  `color`        VARCHAR(20)   DEFAULT '#3b82f6',
  `is_important` TINYINT(1)    NOT NULL DEFAULT 0,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `net_worth_snapshots` (
  `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED  NOT NULL,
  `snapshot_date` DATE          NOT NULL,
  `total_value`   DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `mf_value`      DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `stock_value`   DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `fd_value`      DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `savings_value` DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `nps_value`     DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `po_value`      DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `gold_value`    DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `crypto_value`  DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `other_value`   DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nws` (`user_id`, `snapshot_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 11: ALTERNATIVE ASSETS
-- ============================================================

CREATE TABLE IF NOT EXISTS `sgb_holdings` (
  `id`                       INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`             INT UNSIGNED  NOT NULL,
  `series_name`              VARCHAR(100)  NOT NULL,
  `tranche_code`             VARCHAR(30)   DEFAULT NULL,
  `isin`                     VARCHAR(20)   DEFAULT NULL,
  `nse_symbol`               VARCHAR(30)   DEFAULT NULL,
  `issue_date`               DATE          NOT NULL,
  `maturity_date`            DATE          NOT NULL,
  `units`                    DECIMAL(12,4) NOT NULL,
  `issue_price`              DECIMAL(10,2) NOT NULL,
  `total_invested`           DECIMAL(14,2) NOT NULL,
  `coupon_rate`              DECIMAL(5,2)  NOT NULL DEFAULT 2.50,
  `interest_payout`          ENUM('semi-annual','annual') NOT NULL DEFAULT 'semi-annual',
  `last_interest_date`       DATE          DEFAULT NULL,
  `next_interest_date`       DATE          DEFAULT NULL,
  `total_interest_received`  DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `current_nav`              DECIMAL(10,2) DEFAULT NULL,
  `current_value`            DECIMAL(14,2) DEFAULT NULL,
  `nav_updated_at`           DATETIME      DEFAULT NULL,
  `nse_price`                DECIMAL(10,2) DEFAULT NULL,
  `nse_updated_at`           DATETIME      DEFAULT NULL,
  `tax_exemption`            TINYINT(1)    NOT NULL DEFAULT 1,
  `is_active`                TINYINT(1)    NOT NULL DEFAULT 1,
  `notes`                    TEXT          DEFAULT NULL,
  `created_at`               DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`               DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sgb_interest_log` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `sgb_id`       INT UNSIGNED  NOT NULL,
  `portfolio_id` INT UNSIGNED  NOT NULL,
  `payout_date`  DATE          NOT NULL,
  `period`       VARCHAR(20)   DEFAULT NULL,
  `units`        DECIMAL(12,4) NOT NULL,
  `rate_pct`     DECIMAL(5,2)  NOT NULL,
  `amount`       DECIMAL(12,2) NOT NULL,
  `notes`        VARCHAR(255)  DEFAULT NULL,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `gold_price_cache` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `source`         VARCHAR(30)   NOT NULL DEFAULT 'ibja',
  `price_24k_gram` DECIMAL(10,2) NOT NULL,
  `price_22k_gram` DECIMAL(10,2) DEFAULT NULL,
  `price_18k_gram` DECIMAL(10,2) DEFAULT NULL,
  `fetched_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_for`       DATE          NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `crypto_holdings` (
  `id`               INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `portfolio_id`     INT UNSIGNED    NOT NULL,
  `coin_id`          VARCHAR(60)     NOT NULL,
  `coin_symbol`      VARCHAR(20)     NOT NULL,
  `coin_name`        VARCHAR(100)    NOT NULL,
  `quantity`         DECIMAL(24,8)   NOT NULL DEFAULT 0,
  `avg_buy_price`    DECIMAL(20,4)   NOT NULL DEFAULT 0,
  `total_invested`   DECIMAL(20,2)   NOT NULL DEFAULT 0,
  `current_price`    DECIMAL(20,4)   DEFAULT 0,
  `current_value_inr`DECIMAL(20,2)   DEFAULT 0,
  `exchange`         VARCHAR(60)     DEFAULT NULL,
  `wallet_address`   VARCHAR(200)    DEFAULT NULL,
  `is_active`        TINYINT(1)      NOT NULL DEFAULT 1,
  `price_updated_at` DATETIME        DEFAULT NULL,
  `notes`            TEXT            DEFAULT NULL,
  `created_at`       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `crypto_transactions` (
  `id`           BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id` INT UNSIGNED     NOT NULL,
  `coin_id`      VARCHAR(60)      NOT NULL,
  `coin_symbol`  VARCHAR(20)      NOT NULL,
  `txn_type`     ENUM('BUY','SELL','TRANSFER_IN','TRANSFER_OUT','REWARD') NOT NULL DEFAULT 'BUY',
  `quantity`     DECIMAL(24,8)    NOT NULL,
  `price_inr`    DECIMAL(20,4)    NOT NULL DEFAULT 0,
  `amount_inr`   DECIMAL(20,2)    NOT NULL DEFAULT 0,
  `fee_inr`      DECIMAL(10,2)    DEFAULT 0,
  `tds_deducted` DECIMAL(10,2)    NOT NULL DEFAULT 0,
  `exchange`     VARCHAR(60)      DEFAULT NULL,
  `txn_date`     DATE             NOT NULL,
  `notes`        TEXT             DEFAULT NULL,
  `created_at`   DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `crypto_price_cache` (
  `coin_id`    VARCHAR(60)   NOT NULL,
  `symbol`     VARCHAR(20)   NOT NULL,
  `name`       VARCHAR(100)  NOT NULL,
  `price_inr`  DECIMAL(20,4) DEFAULT 0,
  `price_usd`  DECIMAL(20,8) DEFAULT 0,
  `change_24h` DECIMAL(10,4) DEFAULT 0,
  `market_cap` BIGINT        DEFAULT 0,
  `fetched_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`coin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `vda_transactions` (
  `id`                  INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `portfolio_id`        INT UNSIGNED    NOT NULL,
  `coin_symbol`         VARCHAR(20)     NOT NULL,
  `coin_name`           VARCHAR(100)    DEFAULT NULL,
  `coingecko_id`        VARCHAR(80)     DEFAULT NULL,
  `txn_type`            ENUM('BUY','SELL','GIFT_RECEIVED','GIFT_GIVEN','MINING','STAKING','AIRDROP') NOT NULL DEFAULT 'BUY',
  `buy_date`            DATE            DEFAULT NULL,
  `buy_quantity`        DECIMAL(24,8)   DEFAULT 0,
  `buy_price_inr`       DECIMAL(20,4)   DEFAULT 0,
  `buy_cost_inr`        DECIMAL(20,2)   DEFAULT 0,
  `buy_fees_inr`        DECIMAL(14,2)   DEFAULT 0,
  `buy_exchange`        VARCHAR(80)     DEFAULT NULL,
  `sell_date`           DATE            DEFAULT NULL,
  `sell_quantity`       DECIMAL(24,8)   DEFAULT 0,
  `sell_price_inr`      DECIMAL(20,4)   DEFAULT 0,
  `sell_proceeds_inr`   DECIMAL(20,2)   DEFAULT 0,
  `sell_fees_inr`       DECIMAL(14,2)   DEFAULT 0,
  `sell_exchange`       VARCHAR(80)     DEFAULT NULL,
  `cost_of_acquisition` DECIMAL(20,2)   DEFAULT 0,
  `gross_proceeds`      DECIMAL(20,2)   DEFAULT 0,
  `gain_loss_inr`       DECIMAL(20,2)   DEFAULT 0,
  `is_gain`             TINYINT(1)      DEFAULT 1,
  `tax_30pct`           DECIMAL(14,2)   DEFAULT 0,
  `cess_4pct`           DECIMAL(14,2)   DEFAULT 0,
  `total_tax_payable`   DECIMAL(14,2)   DEFAULT 0,
  `tds_deducted`        DECIMAL(14,2)   NOT NULL DEFAULT 0,
  `tds_date`            DATE            DEFAULT NULL,
  `tds_certificate_no`  VARCHAR(50)     DEFAULT NULL,
  `fy`                  VARCHAR(9)      NOT NULL,
  `fy_quarter`          TINYINT UNSIGNED DEFAULT NULL,
  `txn_hash`            VARCHAR(100)    DEFAULT NULL,
  `notes`               TEXT            DEFAULT NULL,
  `created_at`          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `vda_tds_log` (
  `id`                  INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`        INT UNSIGNED  NOT NULL,
  `exchange`            VARCHAR(80)   NOT NULL,
  `fy`                  VARCHAR(9)    NOT NULL,
  `total_sale_value`    DECIMAL(20,2) NOT NULL DEFAULT 0,
  `tds_1pct`            DECIMAL(14,2) NOT NULL DEFAULT 0,
  `tds_paid`            DECIMAL(14,2) NOT NULL DEFAULT 0,
  `tds_balance`         DECIMAL(14,2) NOT NULL DEFAULT 0,
  `form_26as_verified`  TINYINT(1)    NOT NULL DEFAULT 0,
  `notes`               VARCHAR(255)  DEFAULT NULL,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vda_tds` (`portfolio_id`, `exchange`, `fy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `esop_grants` (
  `id`                    INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`          INT UNSIGNED  NOT NULL,
  `company_name`          VARCHAR(200)  NOT NULL,
  `company_symbol`        VARCHAR(30)   DEFAULT NULL,
  `grant_type`            ENUM('ESOP','RSU','SAR','PHANTOM') NOT NULL DEFAULT 'ESOP',
  `grant_date`            DATE          NOT NULL,
  `grant_ref`             VARCHAR(100)  DEFAULT NULL,
  `total_options`         INT UNSIGNED  NOT NULL,
  `exercise_price`        DECIMAL(12,4) NOT NULL DEFAULT 0,
  `currency`              CHAR(3)       NOT NULL DEFAULT 'INR',
  `vesting_start`         DATE          NOT NULL,
  `vesting_cliff_months`  SMALLINT UNSIGNED NOT NULL DEFAULT 12,
  `vesting_period_months` SMALLINT UNSIGNED NOT NULL DEFAULT 48,
  `vesting_schedule`      VARCHAR(100)  DEFAULT '1/4 per year',
  `vesting_type`          ENUM('cliff','graded','custom') NOT NULL DEFAULT 'graded',
  `current_fmv`           DECIMAL(12,4) DEFAULT NULL,
  `fmv_updated_at`        DATETIME      DEFAULT NULL,
  `options_vested`        INT UNSIGNED  NOT NULL DEFAULT 0,
  `options_exercised`     INT UNSIGNED  NOT NULL DEFAULT 0,
  `options_lapsed`        INT UNSIGNED  NOT NULL DEFAULT 0,
  `status`                ENUM('active','fully_vested','lapsed','exercised_partial','exercised_full','cancelled') NOT NULL DEFAULT 'active',
  `expiry_date`           DATE          DEFAULT NULL,
  `notes`                 TEXT          DEFAULT NULL,
  `created_at`            DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`            DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `esop_vesting_events` (
  `id`               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `grant_id`         INT UNSIGNED  NOT NULL,
  `vest_date`        DATE          NOT NULL,
  `units_vested`     INT UNSIGNED  NOT NULL,
  `fmv_on_vest`      DECIMAL(12,4) DEFAULT NULL,
  `perquisite_value` DECIMAL(14,4) DEFAULT NULL,
  `perquisite_tax`   DECIMAL(14,4) DEFAULT NULL,
  `tax_slab_pct`     DECIMAL(5,2)  DEFAULT NULL,
  `is_exercised`     TINYINT(1)    NOT NULL DEFAULT 0,
  `exercise_date`    DATE          DEFAULT NULL,
  `exercise_price`   DECIMAL(12,4) DEFAULT NULL,
  `units_exercised`  INT UNSIGNED  DEFAULT 0,
  `sale_date`        DATE          DEFAULT NULL,
  `sale_price`       DECIMAL(12,4) DEFAULT NULL,
  `units_sold`       INT UNSIGNED  DEFAULT 0,
  `capital_gain`     DECIMAL(14,4) DEFAULT NULL,
  `gain_type`        ENUM('STCG','LTCG') DEFAULT NULL,
  `notes`            VARCHAR(255)  DEFAULT NULL,
  `created_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `esop_exercise_log` (
  `id`                INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `grant_id`          INT UNSIGNED  NOT NULL,
  `vesting_event_id`  INT UNSIGNED  DEFAULT NULL,
  `exercise_date`     DATE          NOT NULL,
  `units`             INT UNSIGNED  NOT NULL,
  `exercise_price`    DECIMAL(12,4) NOT NULL,
  `fmv_on_exercise`   DECIMAL(12,4) DEFAULT NULL,
  `perquisite_value`  DECIMAL(14,4) DEFAULT NULL,
  `broker_charges`    DECIMAL(10,2) DEFAULT 0,
  `tds_deducted`      DECIMAL(12,4) DEFAULT NULL,
  `sale_date`         DATE          DEFAULT NULL,
  `sale_price`        DECIMAL(12,4) DEFAULT NULL,
  `capital_gain`      DECIMAL(14,4) DEFAULT NULL,
  `gain_type`         ENUM('STCG','LTCG') DEFAULT NULL,
  `notes`             VARCHAR(255)  DEFAULT NULL,
  `created_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `reits_invits_master` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `symbol`     VARCHAR(30)   NOT NULL,
  `name`       VARCHAR(200)  NOT NULL,
  `trust_type` ENUM('REIT','InvIT') NOT NULL,
  `exchange`   VARCHAR(10)   NOT NULL DEFAULT 'NSE',
  `isin`       VARCHAR(20)   DEFAULT NULL,
  `sector`     VARCHAR(100)  DEFAULT NULL,
  `sponsor`    VARCHAR(200)  DEFAULT NULL,
  `is_active`  TINYINT(1)    NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ri_symbol` (`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `reits_invits` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`        INT UNSIGNED  NOT NULL,
  `portfolio_id`   INT UNSIGNED  NOT NULL,
  `symbol`         VARCHAR(30)   NOT NULL,
  `name`           VARCHAR(200)  NOT NULL,
  `trust_type`     ENUM('REIT','InvIT') NOT NULL DEFAULT 'REIT',
  `exchange`       ENUM('NSE','BSE') NOT NULL DEFAULT 'NSE',
  `isin`           VARCHAR(20)   DEFAULT NULL,
  `units`          DECIMAL(14,4) NOT NULL DEFAULT 0,
  `avg_buy_price`  DECIMAL(12,4) NOT NULL DEFAULT 0,
  `total_invested` DECIMAL(14,2) NOT NULL DEFAULT 0,
  `current_price`  DECIMAL(12,4) DEFAULT NULL,
  `current_value`  DECIMAL(14,2) DEFAULT NULL,
  `gain_loss`      DECIMAL(14,2) DEFAULT NULL,
  `gain_loss_pct`  DECIMAL(8,4)  DEFAULT NULL,
  `last_price_date`DATE          DEFAULT NULL,
  `notes`          TEXT          DEFAULT NULL,
  `created_at`     DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `reits_invits_transactions` (
  `id`               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `holding_id`       INT UNSIGNED  NOT NULL,
  `user_id`          INT UNSIGNED  NOT NULL,
  `portfolio_id`     INT UNSIGNED  NOT NULL,
  `symbol`           VARCHAR(30)   NOT NULL,
  `transaction_type` ENUM('BUY','SELL','DIVIDEND','DISTRIBUTION') NOT NULL,
  `txn_date`         DATE          NOT NULL,
  `units`            DECIMAL(14,4) NOT NULL,
  `price`            DECIMAL(12,4) NOT NULL,
  `amount`           DECIMAL(14,2) NOT NULL,
  `brokerage`        DECIMAL(10,2) DEFAULT 0,
  `notes`            TEXT          DEFAULT NULL,
  `created_at`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `reits_invits_distributions` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `holding_id`      INT UNSIGNED  NOT NULL,
  `user_id`         INT UNSIGNED  NOT NULL,
  `symbol`          VARCHAR(30)   NOT NULL,
  `dist_type`       ENUM('dividend','interest','SPD','return_of_capital') NOT NULL DEFAULT 'dividend',
  `ex_date`         DATE          NOT NULL,
  `pay_date`        DATE          DEFAULT NULL,
  `per_unit_amount` DECIMAL(10,4) NOT NULL,
  `units_held`      DECIMAL(14,4) NOT NULL,
  `total_amount`    DECIMAL(12,2) NOT NULL,
  `tds_deducted`    DECIMAL(10,2) DEFAULT 0,
  `net_amount`      DECIMAL(12,2) NOT NULL,
  `notes`           TEXT          DEFAULT NULL,
  `created_at`      DATETIME      DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `etf_master` (
  `id`                  INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `symbol`              VARCHAR(20)   NOT NULL,
  `exchange`            VARCHAR(10)   NOT NULL DEFAULT 'NSE',
  `isin`                VARCHAR(20)   DEFAULT NULL,
  `scheme_name`         VARCHAR(200)  NOT NULL,
  `amc`                 VARCHAR(100)  DEFAULT NULL,
  `category`            VARCHAR(100)  DEFAULT NULL,
  `sub_category`        VARCHAR(100)  DEFAULT NULL,
  `underlying_index`    VARCHAR(100)  DEFAULT NULL,
  `benchmark`           VARCHAR(100)  DEFAULT NULL,
  `latest_price`        DECIMAL(14,4) DEFAULT 0,
  `nav`                 DECIMAL(14,4) DEFAULT NULL,
  `price_change_1d`     DECIMAL(10,4) DEFAULT NULL,
  `price_change_1d_pct` DECIMAL(8,4)  DEFAULT NULL,
  `expense_ratio`       DECIMAL(6,4)  DEFAULT NULL,
  `tracking_error`      DECIMAL(8,4)  DEFAULT NULL,
  `aum_cr`              DECIMAL(14,4) DEFAULT NULL,
  `avg_volume`          BIGINT UNSIGNED DEFAULT NULL,
  `high_52`             DECIMAL(14,4) DEFAULT NULL,
  `low_52`              DECIMAL(14,4) DEFAULT NULL,
  `dividend_yield`      DECIMAL(8,4)  DEFAULT NULL,
  `returns_1y`          DECIMAL(8,4)  DEFAULT NULL,
  `returns_3y`          DECIMAL(8,4)  DEFAULT NULL,
  `returns_5y`          DECIMAL(8,4)  DEFAULT NULL,
  `is_gold_etf`         TINYINT(1)    DEFAULT 0,
  `is_international`    TINYINT(1)    DEFAULT 0,
  `price_updated_at`    DATETIME      DEFAULT NULL,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_etf_symbol` (`symbol`, `exchange`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `etf_holdings` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`   INT UNSIGNED  NOT NULL,
  `etf_id`         INT UNSIGNED  NOT NULL,
  `quantity`       DECIMAL(16,4) NOT NULL DEFAULT 0,
  `avg_buy_price`  DECIMAL(14,4) NOT NULL DEFAULT 0,
  `total_invested` DECIMAL(18,4) DEFAULT 0,
  `current_value`  DECIMAL(18,4) DEFAULT 0,
  `first_buy_date` DATE          DEFAULT NULL,
  `broker`         VARCHAR(50)   DEFAULT NULL,
  `notes`          TEXT          DEFAULT NULL,
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_eh_portfolio_etf` (`portfolio_id`, `etf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `etf_transactions` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id` INT UNSIGNED  NOT NULL,
  `etf_id`       INT UNSIGNED  NOT NULL,
  `type`         ENUM('buy','sell','dividend') NOT NULL DEFAULT 'buy',
  `quantity`     DECIMAL(16,4) NOT NULL,
  `price`        DECIMAL(14,4) NOT NULL DEFAULT 0,
  `total_value`  DECIMAL(18,4) DEFAULT 0,
  `brokerage`    DECIMAL(10,4) DEFAULT 0,
  `broker`       VARCHAR(50)   DEFAULT NULL,
  `txn_date`     DATE          NOT NULL,
  `notes`        TEXT          DEFAULT NULL,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `pms_holdings` (
  `id`                  INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`             INT UNSIGNED  NOT NULL,
  `portfolio_id`        INT UNSIGNED  NOT NULL,
  `pms_name`            VARCHAR(200)  NOT NULL,
  `manager_name`        VARCHAR(150)  DEFAULT NULL,
  `strategy_name`       VARCHAR(200)  DEFAULT NULL,
  `asset_class`         ENUM('PMS','AIF_CAT1','AIF_CAT2','AIF_CAT3') NOT NULL DEFAULT 'PMS',
  `investment_date`     DATE          NOT NULL,
  `invested_amount`     DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `current_value`       DECIMAL(16,2) DEFAULT NULL,
  `xirr`                DECIMAL(8,4)  DEFAULT NULL,
  `nav_current`         DECIMAL(14,4) DEFAULT NULL,
  `nav_date`            DATE          DEFAULT NULL,
  `units`               DECIMAL(14,4) DEFAULT NULL,
  `folio_number`        VARCHAR(60)   DEFAULT NULL,
  `lock_in_months`      INT UNSIGNED  DEFAULT NULL,
  `lock_in_end_date`    DATE          DEFAULT NULL,
  `management_fee_pct`  DECIMAL(5,3)  DEFAULT NULL,
  `performance_fee_pct` DECIMAL(5,3)  DEFAULT NULL,
  `hurdle_rate_pct`     DECIMAL(5,3)  DEFAULT NULL,
  `benchmark`           VARCHAR(150)  DEFAULT NULL,
  `platform`            VARCHAR(100)  DEFAULT NULL,
  `notes`               TEXT          DEFAULT NULL,
  `is_active`           TINYINT(1)    NOT NULL DEFAULT 1,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `pms_transactions` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `holding_id`   INT UNSIGNED  NOT NULL,
  `user_id`      INT UNSIGNED  NOT NULL,
  `portfolio_id` INT UNSIGNED  NOT NULL,
  `txn_type`     ENUM('investment','withdrawal','dividend','management_fee','performance_fee','nav_update','switch') NOT NULL,
  `txn_date`     DATE          NOT NULL,
  `amount`       DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `nav`          DECIMAL(14,4) DEFAULT NULL,
  `units`        DECIMAL(14,4) DEFAULT NULL,
  `notes`        TEXT          DEFAULT NULL,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `pms_nav_history` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `holding_id` INT UNSIGNED  NOT NULL,
  `nav_date`   DATE          NOT NULL,
  `nav`        DECIMAL(14,4) NOT NULL,
  `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nav` (`holding_id`, `nav_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `us_stock_master` (
  `id`                      INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `symbol`                  VARCHAR(20)   NOT NULL,
  `exchange`                ENUM('NYSE','NASDAQ','AMEX','OTC') NOT NULL DEFAULT 'NASDAQ',
  `company_name`            VARCHAR(200)  DEFAULT NULL,
  `isin`                    VARCHAR(20)   DEFAULT NULL,
  `sector`                  VARCHAR(100)  DEFAULT NULL,
  `industry`                VARCHAR(100)  DEFAULT NULL,
  `country`                 VARCHAR(50)   DEFAULT 'US',
  `currency`                VARCHAR(5)    NOT NULL DEFAULT 'USD',
  `latest_price_usd`        DECIMAL(14,4) DEFAULT 0,
  `latest_price_inr`        DECIMAL(14,4) DEFAULT 0,
  `pe_ratio`                DECIMAL(12,4) DEFAULT NULL,
  `pb_ratio`                DECIMAL(10,4) DEFAULT NULL,
  `eps_ttm`                 DECIMAL(12,4) DEFAULT NULL,
  `market_cap_usd`          DECIMAL(22,4) DEFAULT NULL,
  `high_52_usd`             DECIMAL(14,4) DEFAULT NULL,
  `low_52_usd`              DECIMAL(14,4) DEFAULT NULL,
  `dividend_yield`          DECIMAL(8,4)  DEFAULT NULL,
  `beta`                    DECIMAL(8,4)  DEFAULT NULL,
  `price_change_24h_pct`    DECIMAL(8,4)  DEFAULT NULL,
  `price_updated_at`        DATETIME      DEFAULT NULL,
  `fundamentals_updated_at` DATETIME      DEFAULT NULL,
  `created_at`              DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usm_symbol` (`symbol`, `exchange`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `us_stock_holdings` (
  `id`                  INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`        INT UNSIGNED  NOT NULL,
  `stock_id`            INT UNSIGNED  NOT NULL,
  `quantity`            DECIMAL(16,6) NOT NULL DEFAULT 0,
  `avg_buy_price_usd`   DECIMAL(14,4) NOT NULL DEFAULT 0,
  `avg_buy_price_inr`   DECIMAL(14,4) DEFAULT NULL,
  `total_invested_usd`  DECIMAL(18,4) DEFAULT 0,
  `total_invested_inr`  DECIMAL(18,4) DEFAULT 0,
  `current_value_usd`   DECIMAL(18,4) DEFAULT 0,
  `current_value_inr`   DECIMAL(18,4) DEFAULT 0,
  `broker`              VARCHAR(50)   DEFAULT NULL,
  `account_type`        ENUM('LRS','GIFT_CITY','DOMESTIC_BROKER','OTHER') DEFAULT 'LRS',
  `first_buy_date`      DATE          DEFAULT NULL,
  `notes`               TEXT          DEFAULT NULL,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ush_portfolio_stock` (`portfolio_id`, `stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `us_stock_transactions` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id` INT UNSIGNED  NOT NULL,
  `stock_id`     INT UNSIGNED  NOT NULL,
  `type`         ENUM('buy','sell','dividend','transfer_in','transfer_out') NOT NULL DEFAULT 'buy',
  `quantity`     DECIMAL(16,6) NOT NULL,
  `price_usd`    DECIMAL(14,4) NOT NULL DEFAULT 0,
  `price_inr`    DECIMAL(14,4) DEFAULT NULL,
  `total_usd`    DECIMAL(18,4) DEFAULT 0,
  `total_inr`    DECIMAL(18,4) DEFAULT 0,
  `usd_inr_rate` DECIMAL(10,4) DEFAULT NULL,
  `fee_usd`      DECIMAL(10,4) DEFAULT 0,
  `broker`       VARCHAR(50)   DEFAULT NULL,
  `account_type` ENUM('LRS','GIFT_CITY','DOMESTIC_BROKER','OTHER') DEFAULT 'LRS',
  `txn_date`     DATE          NOT NULL,
  `notes`        TEXT          DEFAULT NULL,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 12: NOTIFICATIONS & AI
-- ============================================================

CREATE TABLE IF NOT EXISTS `notifications` (
  `id`           BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED     NOT NULL,
  `type`         ENUM('nav_alert','fd_maturity','sip_reminder','drawdown','nfo_closing','system','goal','tax','ai_review') NOT NULL,
  `title`        VARCHAR(300)     NOT NULL,
  `body`         TEXT             NOT NULL,
  `link_url`     VARCHAR(500)     DEFAULT NULL,
  `is_read`      TINYINT(1)       NOT NULL DEFAULT 0,
  `triggered_at` DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `read_at`      DATETIME         DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `notification_prefs` (
  `user_id`         INT UNSIGNED  NOT NULL,
  `nav_alerts`      TINYINT(1)    NOT NULL DEFAULT 1,
  `fd_maturity`     TINYINT(1)    NOT NULL DEFAULT 1,
  `sip_reminder`    TINYINT(1)    NOT NULL DEFAULT 1,
  `drawdown_alerts` TINYINT(1)    NOT NULL DEFAULT 1,
  `nfo_alerts`      TINYINT(1)    NOT NULL DEFAULT 1,
  `tax_reminders`   TINYINT(1)    NOT NULL DEFAULT 1,
  `updated_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ai_chat_history` (
  `id`         BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED     NOT NULL,
  `role`       ENUM('user','assistant') NOT NULL,
  `message`    TEXT             NOT NULL,
  `context_id` VARCHAR(36)      DEFAULT NULL,
  `created_at` DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ai_portfolio_reviews` (
  `id`           BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED     NOT NULL,
  `review_month` VARCHAR(7)       NOT NULL,
  `review_type`  VARCHAR(30)      NOT NULL DEFAULT 'monthly',
  `grade`        CHAR(2)          DEFAULT NULL,
  `score`        TINYINT UNSIGNED DEFAULT NULL,
  `summary`      TEXT             DEFAULT NULL,
  `strengths`    TEXT             DEFAULT NULL,
  `weaknesses`   TEXT             DEFAULT NULL,
  `actions`      TEXT             DEFAULT NULL,
  `raw_response` TEXT             DEFAULT NULL,
  `created_at`   DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_month` (`user_id`, `review_month`, `review_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ai_anomalies` (
  `id`           BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED     NOT NULL,
  `anomaly_type` VARCHAR(60)      NOT NULL,
  `severity`     ENUM('info','warning','critical') DEFAULT 'warning',
  `title`        VARCHAR(200)     NOT NULL,
  `description`  TEXT             DEFAULT NULL,
  `data_json`    TEXT             DEFAULT NULL,
  `is_dismissed` TINYINT(1)       NOT NULL DEFAULT 0,
  `detected_at`  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dismissed_at` DATETIME         DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 13: INTEGRATIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_credentials` (
  `id`               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`          INT UNSIGNED  NOT NULL,
  `api_key`          VARCHAR(255)  NOT NULL,
  `api_secret`       VARCHAR(255)  NOT NULL,
  `access_token`     VARCHAR(512)  DEFAULT NULL,
  `request_token`    VARCHAR(255)  DEFAULT NULL,
  `token_expiry`     DATETIME      DEFAULT NULL,
  `kite_user_id`     VARCHAR(30)   DEFAULT NULL,
  `kite_user_name`   VARCHAR(100)  DEFAULT NULL,
  `login_time`       DATETIME      DEFAULT NULL,
  `is_active`        TINYINT(1)    NOT NULL DEFAULT 1,
  `last_sync_at`     DATETIME      DEFAULT NULL,
  `last_sync_status` ENUM('success','failed','pending') DEFAULT NULL,
  `last_sync_error`  TEXT          DEFAULT NULL,
  `created_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_zerodha_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `zerodha_sync_log` (
  `id`                INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`           INT UNSIGNED  NOT NULL,
  `portfolio_id`      INT UNSIGNED  DEFAULT NULL,
  `triggered_by`      ENUM('manual','cron','webhook') NOT NULL DEFAULT 'manual',
  `holdings_fetched`  INT UNSIGNED  DEFAULT 0,
  `holdings_added`    INT UNSIGNED  DEFAULT 0,
  `holdings_updated`  INT UNSIGNED  DEFAULT 0,
  `positions_fetched` INT UNSIGNED  DEFAULT 0,
  `status`            ENUM('success','failed','partial') NOT NULL DEFAULT 'success',
  `error_message`     TEXT          DEFAULT NULL,
  `api_calls_made`    TINYINT UNSIGNED DEFAULT 0,
  `duration_ms`       INT UNSIGNED  DEFAULT NULL,
  `synced_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `zerodha_holdings_raw` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`         INT UNSIGNED  NOT NULL,
  `tradingsymbol`   VARCHAR(50)   NOT NULL,
  `exchange`        VARCHAR(10)   NOT NULL DEFAULT 'NSE',
  `isin`            VARCHAR(20)   DEFAULT NULL,
  `quantity`        INT           NOT NULL DEFAULT 0,
  `t1_quantity`     INT           NOT NULL DEFAULT 0,
  `average_price`   DECIMAL(12,4) NOT NULL DEFAULT 0,
  `last_price`      DECIMAL(12,4) DEFAULT NULL,
  `close_price`     DECIMAL(12,4) DEFAULT NULL,
  `pnl`             DECIMAL(14,4) DEFAULT NULL,
  `day_change`      DECIMAL(12,4) DEFAULT NULL,
  `day_change_pct`  DECIMAL(8,4)  DEFAULT NULL,
  `product`         VARCHAR(10)   DEFAULT NULL,
  `collateral_qty`  INT           DEFAULT 0,
  `collateral_type` VARCHAR(30)   DEFAULT NULL,
  `used_quantity`   INT           DEFAULT 0,
  `realised_quantity`INT          DEFAULT 0,
  `authorised_date` DATE          DEFAULT NULL,
  `raw_json`        JSON          DEFAULT NULL,
  `synced_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_zh_user_symbol` (`user_id`, `tradingsymbol`, `exchange`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `groww_api_credentials` (
  `id`               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`          INT UNSIGNED  NOT NULL,
  `access_token`     TEXT          DEFAULT NULL,
  `refresh_token`    TEXT          DEFAULT NULL,
  `token_expires_at` DATETIME      DEFAULT NULL,
  `linked_email`     VARCHAR(200)  DEFAULT NULL,
  `scope`            VARCHAR(200)  DEFAULT NULL,
  `status`           ENUM('active','expired','revoked','error') NOT NULL DEFAULT 'active',
  `last_sync_at`     DATETIME      DEFAULT NULL,
  `last_sync_type`   VARCHAR(50)   DEFAULT NULL,
  `error_msg`        VARCHAR(500)  DEFAULT NULL,
  `created_at`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_groww_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `groww_sync_log` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED  NOT NULL,
  `portfolio_id` INT UNSIGNED  NOT NULL,
  `sync_type`    ENUM('mf_holdings','mf_transactions','stock_holdings','stock_transactions','full') NOT NULL,
  `status`       ENUM('running','done','failed','partial') NOT NULL DEFAULT 'running',
  `mf_synced`    INT UNSIGNED  DEFAULT 0,
  `stock_synced` INT UNSIGNED  DEFAULT 0,
  `errors`       INT UNSIGNED  DEFAULT 0,
  `error_detail` TEXT          DEFAULT NULL,
  `started_at`   DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `completed_at` DATETIME      DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- GROUP 14: UTILITY / V48 SPRINT
-- ============================================================

CREATE TABLE IF NOT EXISTS `investment_journal` (
  `id`                   INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`              INT UNSIGNED  NOT NULL,
  `entry_date`           DATE          NOT NULL,
  `title`                VARCHAR(200)  NOT NULL DEFAULT '',
  `body`                 TEXT          NOT NULL,
  `mood`                 ENUM('bullish','bearish','neutral','anxious','confident') NOT NULL DEFAULT 'neutral',
  `tags`                 JSON          DEFAULT NULL,
  `linked_fund_id`       INT UNSIGNED  DEFAULT NULL,
  `portfolio_change_pct` DECIMAL(6,2)  DEFAULT NULL,
  `nifty_change_pct`     DECIMAL(6,2)  DEFAULT NULL,
  `is_private`           TINYINT(1)    NOT NULL DEFAULT 1,
  `created_at`           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `credit_cards` (
  `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED  NOT NULL,
  `card_name`     VARCHAR(100)  NOT NULL,
  `bank_name`     VARCHAR(100)  NOT NULL DEFAULT '',
  `card_type`     VARCHAR(50)   NOT NULL DEFAULT 'credit',
  `credit_limit`  DECIMAL(12,2) NOT NULL DEFAULT 0,
  `outstanding`   DECIMAL(12,2) NOT NULL DEFAULT 0,
  `min_payment`   DECIMAL(12,2) NOT NULL DEFAULT 0,
  `due_date`      DATE          DEFAULT NULL,
  `interest_rate` DECIMAL(5,2)  NOT NULL DEFAULT 36.00,
  `reward_type`   VARCHAR(50)   NOT NULL DEFAULT 'cashback',
  `reward_rate`   DECIMAL(5,2)  NOT NULL DEFAULT 1.00,
  `annual_fee`    DECIMAL(8,2)  NOT NULL DEFAULT 0,
  `is_active`     TINYINT(1)    NOT NULL DEFAULT 1,
  `notes`         TEXT          DEFAULT NULL,
  `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nudge_dismissals` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED  NOT NULL,
  `nudge_id`     VARCHAR(60)   NOT NULL,
  `dismissed_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_nudge` (`user_id`, `nudge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `spending_discipline` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`        INT UNSIGNED  NOT NULL,
  `monthly_income` DECIMAL(15,2) NOT NULL DEFAULT 0,
  `target_pct`     DECIMAL(5,2)  NOT NULL DEFAULT 20.00,
  `updated_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET foreign_key_checks = 1;
