// popup.js

let allTabs = [];
let currentWindowId = null;
let selectedFormat = 'lines';

const $ = id => document.getElementById(id);

// ── Init ──
async function init() {
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentWindowId = activeTab.windowId;

  allTabs = await chrome.tabs.query({});
  renderStats();
  renderTabList();
}

// ── Get filtered tabs based on options ──
function getFilteredTabs(windowOnly = false) {
  let tabs = windowOnly
    ? allTabs.filter(t => t.windowId === currentWindowId)
    : ($('allWindows').checked ? allTabs : allTabs.filter(t => t.windowId === currentWindowId));

  if ($('skipDuplicates').checked) {
    const seen = new Set();
    tabs = tabs.filter(t => {
      if (seen.has(t.url)) return false;
      seen.add(t.url);
      return true;
    });
  }

  return tabs;
}

// ── Stats ──
function renderStats() {
  const filtered = getFilteredTabs();
  const windows = new Set(allTabs.map(t => t.windowId)).size;
  $('totalTabs').textContent = allTabs.length;
  $('totalWindows').textContent = windows;
  $('filteredCount').textContent = filtered.length;
}

// ── Tab list preview ──
function renderTabList() {
  const tabs = getFilteredTabs();
  const list = $('tabList');
  list.innerHTML = '';

  tabs.forEach(tab => {
    const item = document.createElement('div');
    item.className = 'tab-item';

    // Favicon
    let faviconHtml = '';
    if (tab.favIconUrl && !tab.favIconUrl.startsWith('chrome://')) {
      faviconHtml = `<img class="tab-favicon" src="${escHtml(tab.favIconUrl)}" onerror="this.style.display='none'" />`;
    } else {
      const letter = (tab.title || tab.url || '?')[0].toUpperCase();
      faviconHtml = `<div class="tab-favicon-fallback">${letter}</div>`;
    }

    const hostname = safeHostname(tab.url);
    item.innerHTML = `
      ${faviconHtml}
      <div class="tab-title">${escHtml(tab.title || tab.url)}</div>
      <div class="tab-url">${escHtml(hostname)}</div>
    `;
    list.appendChild(item);
  });
}

// ── Format output ──
function formatTabs(tabs, fmt) {
  const includeTitles = $('includeTitles').checked;

  if (fmt === 'lines') {
    return tabs.map(t => {
      if (includeTitles) return `${t.title}\n${decodeUrl(t.url)}`;
      return decodeUrl(t.url);
    }).join('\n');
  }

  if (fmt === 'markdown') {
    return tabs.map(t => `- [${(t.title || t.url).replace(/\[|\]/g, '')}](${decodeUrl(t.url)})`).join('\n');
  }

  if (fmt === 'csv') {
    const rows = [['Title', 'URL']];
    tabs.forEach(t => rows.push([csvEsc(t.title || ''), csvEsc(decodeUrl(t.url))]));
    return rows.map(r => r.join(',')).join('\n');
  }

  if (fmt === 'json') {
    return JSON.stringify(tabs.map(t => ({ title: t.title || '', url: decodeUrl(t.url) })), null, 2);
  }

  return tabs.map(t => decodeUrl(t.url)).join('\n');
}

// ── Copy to clipboard ──
async function copyTabs(windowOnly = false) {
  const tabs = getFilteredTabs(windowOnly);
  const text = formatTabs(tabs, selectedFormat);

  try {
    await navigator.clipboard.writeText(text);
    showSuccess(windowOnly ? 'copyCurrentWindowBtn' : 'copyBtn', `✅ Copied ${tabs.length} URLs!`);
  } catch {
    // Fallback
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
    showSuccess(windowOnly ? 'copyCurrentWindowBtn' : 'copyBtn', `✅ Copied ${tabs.length} URLs!`);
  }
}

function showSuccess(btnId, msg) {
  const btn = $(btnId);
  const original = btn.innerHTML;
  const wasPrimary = btn.classList.contains('btn-primary');
  if (wasPrimary) btn.classList.add('success');
  btn.innerHTML = msg;
  setTimeout(() => {
    btn.innerHTML = original;
    if (wasPrimary) btn.classList.remove('success');
  }, 2000);
}

// ── Event listeners ──
$('copyBtn').addEventListener('click', () => copyTabs(false));
$('copyCurrentWindowBtn').addEventListener('click', () => copyTabs(true));

['allWindows', 'includeTitles', 'skipDuplicates'].forEach(id => {
  $(id).addEventListener('change', () => {
    renderStats();
    renderTabList();
    // Toggle visual active state on parent row
    const row = $(id + 'Row');
    if (row) row.classList.toggle('active', $(id).checked);
  });
  // Set initial active state
  const row = $(id + 'Row');
  if (row && $(id).checked) row.classList.add('active');
});

document.querySelectorAll('.fmt-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.fmt-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    selectedFormat = btn.dataset.fmt;
  });
});

// ── Decode percent-encoded URLs (e.g. %E0%A4%A1 → डि) ──
function decodeUrl(url) {
  try { return decodeURI(url); } catch { return url; }
}

// ── Helpers ──
function escHtml(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function csvEsc(str) {
  str = String(str || '');
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return '"' + str.replace(/"/g, '""') + '"';
  }
  return str;
}
function safeHostname(url) {
  try { return new URL(url).hostname; } catch { return url; }
}

init();
