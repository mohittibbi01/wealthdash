// background.js — service worker

let isCollecting = false;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'startAutoCollect') {
    if (isCollecting) { sendResponse({ error: 'Already collecting' }); return true; }
    autoCollect(msg.startUrl, msg.maxPages);
    sendResponse({ started: true });
    return true;
  }

  if (msg.action === 'openTabs') {
    openTabsBatched(msg.urls);
    sendResponse({ ok: true });
    return true;
  }

  return true;
});

async function autoCollect(startUrl, maxPages = 10) {
  isCollecting = true;
  await chrome.storage.local.set({ collecting: true, progress: 0, collectedLinks: [], error: null });

  let url = startUrl;
  let page = 0;

  while (url && page < maxPages) {
    try {
      // Create a hidden tab
      const tab = await chrome.tabs.create({ url, active: false });

      // Wait for the tab to fully load
      await waitForTab(tab.id);

      // Inject content script (in case it wasn't auto-injected)
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      }).catch(() => {});

      // Small delay for JS to settle
      await sleep(1200);

      // Extract links
      let result;
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { action: 'extractLinks' });
        result = response;
      } catch (e) {
        // Fallback: inject and run inline
        const [res] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: extractLinksInPage
        });
        result = res.result;
      }

      // Close the tab
      await chrome.tabs.remove(tab.id).catch(() => {});

      if (result && result.links && result.links.length > 0) {
        const stored = await chrome.storage.local.get('collectedLinks');
        const existing = stored.collectedLinks || [];
        const updated = [...existing, ...result.links];
        page++;
        await chrome.storage.local.set({
          collectedLinks: updated,
          progress: page,
          currentPage: page
        });

        url = result.nextUrl || null;
      } else {
        break;
      }

    } catch (err) {
      await chrome.storage.local.set({ error: err.message });
      break;
    }
  }

  isCollecting = false;
  await chrome.storage.local.set({ collecting: false, progress: maxPages });
}

// This function runs IN the page context (no closure access)
function extractLinksInPage() {
  const results = [];
  const seen = new Set();
  const selectors = ['a[jsname="UWckNb"]', 'div.yuRUbf a', 'div#search a[ping]'];
  for (const sel of selectors) {
    document.querySelectorAll(sel).forEach(a => {
      const href = a.href;
      if (href && href.startsWith('http') && !href.includes('google.com') && !seen.has(href)) {
        seen.add(href);
        const h3 = a.querySelector('h3');
        results.push({ url: href, title: h3 ? h3.innerText : a.innerText || href });
      }
    });
    if (results.length >= 10) break;
  }
  const nextLink = document.querySelector('a#pnnext, a[aria-label="Next page"]');
  return { links: results.slice(0, 10), nextUrl: nextLink ? nextLink.href : null };
}

function waitForTab(tabId) {
  return new Promise((resolve) => {
    const listener = (id, info) => {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    // Fallback timeout
    setTimeout(resolve, 8000);
  });
}

async function openTabsBatched(urls) {
  for (let i = 0; i < urls.length; i++) {
    await chrome.tabs.create({ url: urls[i], active: false });
    if (i % 10 === 9) await sleep(300); // small pause every 10 tabs
  }
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}
