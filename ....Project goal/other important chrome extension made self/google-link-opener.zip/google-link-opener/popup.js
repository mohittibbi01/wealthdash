// popup.js

const $ = id => document.getElementById(id);

let pollInterval = null;

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const isGoogle = tab.url && tab.url.includes('google.com/search');

  if (!isGoogle) {
    $('notOnGoogle').classList.remove('hidden');
    setFooter('Not on Google Search');
    return;
  }

  $('statusCard').classList.remove('hidden');
  $('btnAutoCollect').classList.remove('hidden');
  $('btnCurrentPage').classList.remove('hidden');

  // Load stored state
  await refreshUI();
  startPolling();
}

async function refreshUI() {
  const data = await chrome.storage.local.get(['collectedLinks', 'collecting', 'progress', 'error']);
  const links = data.collectedLinks || [];
  const collecting = data.collecting || false;
  const progress = data.progress || 0;
  const error = data.error;

  // Update counts
  $('linkCount').textContent = links.length;
  $('pageCount').textContent = `${progress} / 10`;

  // Progress bar
  const pct = Math.round((progress / 10) * 100);
  $('progressBar').style.width = pct + '%';
  $('progressPct').textContent = pct + '%';
  $('progressText').textContent = collecting ? `Scanning page ${progress + 1}…` : (links.length > 0 ? 'Collection complete' : 'Ready to collect');

  // Link list
  if (links.length > 0) {
    $('linkListWrap').classList.remove('hidden');
    renderLinkList(links);
    $('btnOpen').classList.remove('hidden');
    $('openCount').textContent = links.length;
    $('btnClear').classList.remove('hidden');
  } else {
    $('linkListWrap').classList.add('hidden');
    $('btnOpen').classList.add('hidden');
    $('btnClear').classList.add('hidden');
  }

  // Collecting state
  if (collecting) {
    $('collectingWrap').classList.remove('hidden');
    $('scanPage').textContent = progress + 1;
    $('btnAutoCollect').querySelector('button').disabled = true;
    $('btnCurrentPage').querySelector('button').disabled = true;
    setFooter('Collecting…');
  } else {
    $('collectingWrap').classList.add('hidden');
    $('btnAutoCollect').querySelector('button').disabled = false;
    $('btnCurrentPage').querySelector('button').disabled = false;
    if (error) {
      setFooter('Error: ' + error.slice(0, 30));
    } else if (links.length >= 100) {
      setFooter('✅ 100 links collected!');
    } else if (links.length > 0) {
      setFooter(`${links.length} links ready`);
    } else {
      setFooter('Ready');
    }
  }
}

function renderLinkList(links) {
  const list = $('linkList');
  list.innerHTML = '';
  links.forEach((link, i) => {
    const item = document.createElement('div');
    item.className = 'link-item';
    item.innerHTML = `
      <div class="link-dot"></div>
      <div class="link-title" title="${escapeHtml(link.url)}">${escapeHtml(link.title || link.url)}</div>
      <div class="link-num">#${i + 1}</div>
    `;
    list.appendChild(item);
  });
}

function escapeHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function setFooter(msg) {
  $('footerStatus').textContent = msg;
}

function startPolling() {
  if (pollInterval) clearInterval(pollInterval);
  pollInterval = setInterval(refreshUI, 800);
}

// ── Auto-collect all pages ──
$('autoCollectBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.storage.local.set({ collectedLinks: [], collecting: false, progress: 0, error: null });
  chrome.runtime.sendMessage({ action: 'startAutoCollect', startUrl: tab.url, maxPages: 10 });
  await refreshUI();
  setFooter('Started auto-collect…');
});

// ── Collect current page only ──
$('currentPageBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Try messaging the content script
  let result;
  try {
    result = await chrome.tabs.sendMessage(tab.id, { action: 'extractLinks' });
  } catch {
    // Inject and run inline
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
    await sleep(400);
    result = await chrome.tabs.sendMessage(tab.id, { action: 'extractLinks' });
  }

  if (result && result.links && result.links.length > 0) {
    const stored = await chrome.storage.local.get('collectedLinks');
    const existing = stored.collectedLinks || [];
    // Deduplicate
    const existingUrls = new Set(existing.map(l => l.url));
    const newLinks = result.links.filter(l => !existingUrls.has(l.url));
    const updated = [...existing, ...newLinks];
    const newProgress = (await chrome.storage.local.get('progress')).progress || 0;
    await chrome.storage.local.set({ collectedLinks: updated, progress: newProgress + 1 });
    await refreshUI();
    setFooter(`Added ${newLinks.length} links from page`);
  } else {
    setFooter('No links found on this page');
  }
});

// ── Open all tabs ──
$('openTabsBtn').addEventListener('click', async () => {
  const data = await chrome.storage.local.get('collectedLinks');
  const links = data.collectedLinks || [];
  if (links.length === 0) { setFooter('No links to open'); return; }

  const urls = links.map(l => l.url);
  chrome.runtime.sendMessage({ action: 'openTabs', urls });
  setFooter(`Opening ${urls.length} tabs…`);
});

// ── Clear ──
$('clearBtn').addEventListener('click', async () => {
  await chrome.storage.local.set({ collectedLinks: [], collecting: false, progress: 0, error: null });
  await refreshUI();
  setFooter('Cleared');
});

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// Cleanup on popup close
window.addEventListener('unload', () => {
  if (pollInterval) clearInterval(pollInterval);
});

init();
