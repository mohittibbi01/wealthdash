// content.js — injected into every Google search results page

function extractLinks() {
  const results = [];
  const seen = new Set();

  // Primary selector for organic results
  const selectors = [
    'a[jsname="UWckNb"]',
    'div#search a[ping]',
    'div.yuRUbf a',
    'div[data-sokoban-container] a[href^="http"]'
  ];

  for (const sel of selectors) {
    document.querySelectorAll(sel).forEach(a => {
      const href = a.href;
      if (
        href &&
        href.startsWith('http') &&
        !href.includes('google.com') &&
        !href.includes('youtube.com/results') &&
        !seen.has(href)
      ) {
        seen.add(href);
        const titleEl = a.querySelector('h3') || a.closest('[data-sokoban-container]')?.querySelector('h3');
        results.push({
          url: href,
          title: titleEl ? titleEl.innerText.trim() : a.innerText.trim() || href
        });
      }
    });
    if (results.length >= 10) break;
  }

  // Get current page number
  const pageEl = document.querySelector('table#nav td.YyVfkd, td[aria-current="page"]');
  const pageNum = pageEl ? parseInt(pageEl.innerText) : 1;

  // Get next page URL
  const nextLink = document.querySelector('a#pnnext, a[aria-label="Next page"]');
  const nextUrl = nextLink ? nextLink.href : null;

  return { links: results.slice(0, 10), pageNum, nextUrl };
}

// Listen for messages from popup/background
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'extractLinks') {
    sendResponse(extractLinks());
  }
  return true;
});
