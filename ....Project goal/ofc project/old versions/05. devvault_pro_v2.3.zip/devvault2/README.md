# 🔐 DevVault Pro v2.0
### Team Credential & Project Infrastructure Manager

---

## ✅ Requirements

- **PHP 7.4+** (bas yahi chahiye — koi server install nahi)
- PHP extensions: `pdo_sqlite`, `openssl` *(default PHP ke saath aate hain)*

Check karo:
```bash
php -m | grep -E "pdo_sqlite|openssl"
```

---

## 🚀 Start Karna (1 Command)

```bash
cd devvault2
php -S 0.0.0.0:8080
```

| Platform | Browser mein open karo |
|----------|------------------------|
| Apna PC  | `http://localhost:8080` |
| LAN (team) | `http://192.168.X.X:8080` |

> **IP dhundne ke liye:**
> - Windows: `ipconfig` → IPv4 Address
> - Linux/Mac: `hostname -I`

---

## 🔑 Default Login

| Username | Password |
|----------|----------|
| `admin`  | `admin123` |

> ⚠️ Pehle login ke baad **Admin Panel → Change Password** se badlo!

---

## 📁 Project Structure

```
devvault2/
├── login.php              ← Login page
├── logout.php             ← Logout
├── index.php              ← Main dashboard
├── project_form.php       ← Add / Edit project form
├── admin.php              ← Admin: users, logs, dropdown options
├── export.php             ← JSON / CSV / Printable report
├── api.php                ← Password reveal + prefs API
├── change_password.php    ← Password change
├── config.php             ← DB init, encryption, helpers
├── auth.php               ← Session, CSRF, role helpers
│
└── data/
    ├── vault.db           ← 🗄 SQLite DB — SABA KUCH YAHAN
    └── vault_backup.json  ← Auto JSON backup (har save pe)
```

---

## 📋 Form Fields (Excel Sheet ke anusar)

### Department Info
- Department Name
- Nodal Officer Name, Designation, Contact, Email

### Project Info
- Technology *(Dot Net / WebMyWay / AEM / Other → auto-save)*
- Website / Application type
- Project Name, Description
- Current Status: Live / Under Development / Redevelopment / Closed
- Last Audit Date
- Live Date *(only if status = Live)*
- Total Visitor Counter *(only if status = Live)*
- Last Update Date *(only if status = Live)*

### Environment Details (5 environments)
Each with: URL, Admin URL, Login ID, Password (encrypted), Remark
- 🔵 Local
- 🟡 Staging
- 🟢 Production
- 🟣 Audit
- ⚪ Other

### Application Infrastructure
- App IP, LB IP, OS Version *(dropdown + Other)*
- Core, RAM, Primary Storage, Secondary Storage
- Individual / Shared hosting
- App Infra Remark

### Database Infrastructure
- DB IP, DB Name, DB Version *(dropdown + Other)*
- DB Server OS *(dropdown + Other)*
- Individual / Shared
- DB Remark

### General Remarks
- Free text notes, SSH commands, deployment steps, etc.

---

## ✨ Features

| Feature | Details |
|---------|---------|
| 🔐 Login/Logout | Session-based with CSRF protection |
| 👥 Multi-user | Admin + Member roles |
| 🎨 Theming | Accent color, Dark/Light, Font family & size |
| 🔍 Search | Real-time search across all fields |
| 🏷 Filter | By status, technology |
| 📊 Dashboard | Status + Tech-wise breakdown table |
| 🌐 Environments | Local, Staging, Production, Audit, Other |
| 🔒 Passwords | AES-256 encrypted, show/hide toggle, copy button |
| 📤 Export | JSON, CSV (Excel), Printable HTML report |
| 🔧 Dynamic Options | "Other" fields auto-save to dropdown |
| 📋 Activity Log | Who did what, when, from which IP |
| 💾 Portable | Bas folder copy karo — koi data loss nahi |

---

## 💾 Portable Use (PC Change karna ho)

**Sab kuch `data/` folder mein hai:**

```
1. Puri devvault2/ folder copy karo (USB/Google Drive)
2. Naye PC pe paste karo
3. php -S 0.0.0.0:8080 run karo
4. ✅ Done — same data, same users, sab kuch!
```

---

## 🌐 LAN Access Setup

```
Server PC pe:    cd devvault2 && php -S 0.0.0.0:8080
Server PC ka IP: ipconfig (Windows) ya hostname -I (Linux)

Dusre PCs pe: http://[SERVER-IP]:8080
```

---

## 🔒 Security

- Passwords: **AES-256-CBC** encrypted SQLite mein store
- Sessions: PHP server-side session + CSRF tokens
- Roles: Admin (full) vs Member (view+edit, no delete)
- Audit: Har action log hota hai IP address ke saath
- Non-admin export: passwords hidden

> ⚠️ `config.php` mein `ENCRYPT_KEY` production use se pehle **zaroor** badlo!
> ```php
> define('ENCRYPT_KEY', 'APNA_UNIQUE_KEY_YAHAN_LIKHO_32CHARS+');
> ```

---

## 🛠 Troubleshooting

**SQLite extension missing:**
```bash
# Ubuntu/Debian
sudo apt install php-sqlite3

# CentOS/RHEL
sudo yum install php-pdo php-sqlite
```

**Port already in use:**
```bash
php -S 0.0.0.0:9090   # alag port use karo
```

**data/ folder permission error (Linux):**
```bash
chmod 755 devvault2/data/
chmod 644 devvault2/data/vault.db
```

**Windows mein php command nahi chalta (XAMPP installed):**
1. Start → "Environment Variables" search karo
2. System Variables → Path → Edit
3. New: `C:\xampp\php`
4. OK → CMD restart → `php -v` check karo

---

## 🛣 Future Enhancement Ideas

- [ ] Project-wise file attachments (SSL certs, .env files)
- [ ] Department-wise grouping / categories
- [ ] Two-Factor Authentication (2FA)
- [ ] Email notifications (project expiry alerts)
- [ ] Bulk CSV import
- [ ] Project clone (staging → production copy)
- [ ] API access tokens for external tools
- [ ] Dashboard charts (Chart.js)
- [ ] Project tags / labels
- [ ] Version history / change log per project
