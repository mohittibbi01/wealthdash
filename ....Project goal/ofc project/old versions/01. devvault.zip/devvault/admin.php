<?php
require_once __DIR__ . '/auth.php';
require_login();
require_admin();

$db = get_db();

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_user') {
        $uname = trim($_POST['username'] ?? '');
        $upw   = $_POST['password'] ?? '';
        $role  = in_array($_POST['role'] ?? '', ['admin','member']) ? $_POST['role'] : 'member';
        if ($uname && $upw) {
            try {
                $stmt = $db->prepare("INSERT INTO users (username, password_hash, role) VALUES (?,?,?)");
                $stmt->execute([$uname, password_hash($upw, PASSWORD_DEFAULT), $role]);
                $_SESSION['flash'] = ['type' => 'success', 'msg' => "✅ User \"$uname\" added."];
            } catch (Exception $e) {
                $_SESSION['flash'] = ['type' => 'error', 'msg' => "⚠ Username already exists."];
            }
        }
    }

    if ($action === 'delete_user') {
        $uid = intval($_POST['uid'] ?? 0);
        if ($uid !== $_SESSION['user_id']) {
            $db->prepare("DELETE FROM users WHERE id = ?")->execute([$uid]);
            $_SESSION['flash'] = ['type' => 'success', 'msg' => "🗑 User deleted."];
        }
    }

    if ($action === 'change_role') {
        $uid  = intval($_POST['uid'] ?? 0);
        $role = in_array($_POST['role'] ?? '', ['admin','member']) ? $_POST['role'] : 'member';
        if ($uid !== $_SESSION['user_id']) {
            $db->prepare("UPDATE users SET role = ? WHERE id = ?")->execute([$role, $uid]);
        }
    }

    if ($action === 'reset_password') {
        $uid = intval($_POST['uid'] ?? 0);
        $npw = $_POST['new_password'] ?? '';
        if ($npw) {
            $db->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([password_hash($npw, PASSWORD_DEFAULT), $uid]);
            $_SESSION['flash'] = ['type' => 'success', 'msg' => "🔑 Password reset successfully."];
        }
    }

    header('Location: admin.php');
    exit;
}

$users   = $db->query("SELECT *, (SELECT COUNT(*) FROM projects WHERE created_by = users.id) as project_count FROM users ORDER BY role DESC, username")->fetchAll();
$logs    = $db->query("SELECT l.*, u.username FROM activity_log l LEFT JOIN users u ON l.user_id = u.id ORDER BY l.created_at DESC LIMIT 100")->fetchAll();
$flash   = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DevVault — Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0d1117;--surface:#161b22;--surface2:#21262d;--border:#30363d;--text:#e6edf3;--text-muted:#8b949e;--accent:#58a6ff;--accent-glow:rgba(88,166,255,.12);--success:#3fb950;--danger:#f85149;--amber:#d29922;--purple:#bc8cff}
body{font-family:'Syne',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;padding:24px}
.wrap{max-width:900px;margin:0 auto}
.page-header{display:flex;align-items:center;gap:12px;margin-bottom:24px}
.back-btn{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:8px 14px;color:var(--text-muted);text-decoration:none;font-size:13px;font-family:'JetBrains Mono',monospace;transition:all .15s}
.back-btn:hover{color:var(--text)}
h1{font-size:22px;font-weight:800}
.flash{padding:10px 16px;border-radius:8px;font-size:13px;font-family:'JetBrains Mono',monospace;margin-bottom:16px}
.flash-success{background:rgba(63,185,80,.1);border:1px solid rgba(63,185,80,.3);color:var(--success)}
.flash-error{background:rgba(248,81,73,.1);border:1px solid rgba(248,81,73,.3);color:var(--danger)}
.tabs{display:flex;gap:4px;margin-bottom:20px;background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:4px}
.tab{flex:1;text-align:center;padding:9px;border-radius:7px;cursor:pointer;font-size:13px;font-weight:700;transition:all .15s;border:none;background:none;color:var(--text-muted);font-family:'Syne',sans-serif}
.tab.active,.tab:hover{background:var(--surface2);color:var(--text)}
.tab.active{background:var(--accent);color:#0d1117}
.tab-content{display:none}
.tab-content.active{display:block}
.card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:22px;margin-bottom:16px}
.card h2{font-size:14px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text-muted);font-family:'JetBrains Mono',monospace;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--border)}
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:left;padding:8px 12px;font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:var(--text-muted);font-family:'JetBrains Mono',monospace;border-bottom:1px solid var(--border)}
td{padding:10px 12px;border-bottom:1px solid rgba(48,54,61,.5);vertical-align:middle;font-family:'JetBrains Mono',monospace}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}
.role-badge{padding:2px 9px;border-radius:20px;font-size:10px;text-transform:uppercase;letter-spacing:.5px;font-weight:600}
.role-admin{background:rgba(188,140,255,.15);color:var(--purple);border:1px solid rgba(188,140,255,.3)}
.role-member{background:rgba(139,148,158,.15);color:var(--text-muted);border:1px solid rgba(139,148,158,.3)}
.btn{display:inline-flex;align-items:center;gap:5px;padding:5px 11px;border-radius:7px;font-size:12px;font-weight:700;font-family:'Syne',sans-serif;cursor:pointer;border:none;transition:opacity .15s}
.btn-ghost{background:var(--surface2);color:var(--text-muted);border:1px solid var(--border)}
.btn-ghost:hover{color:var(--text)}
.btn-danger{background:rgba(248,81,73,.15);color:var(--danger);border:1px solid rgba(248,81,73,.3)}
.btn-danger:hover{background:rgba(248,81,73,.25)}
.btn-primary{background:var(--accent);color:#0d1117}
.btn-primary:hover{opacity:.88}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.form-group{margin-bottom:12px}
label{display:block;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text-muted);margin-bottom:5px;font-family:'JetBrains Mono',monospace}
input,select{width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:7px;padding:9px 12px;color:var(--text);font-size:13px;font-family:'JetBrains Mono',monospace;outline:none;transition:border-color .2s}
input:focus,select:focus{border-color:var(--accent)}
select option{background:var(--surface2)}
.log-row{display:flex;gap:10px;padding:7px 0;border-bottom:1px solid rgba(48,54,61,.4);font-size:12px;font-family:'JetBrains Mono',monospace;align-items:center}
.log-row:last-child{border-bottom:none}
.log-time{color:var(--text-muted);min-width:130px;flex-shrink:0}
.log-user{color:var(--accent);min-width:90px}
.log-action{flex:1;color:var(--text)}
.action-icon{display:inline-block;width:20px;text-align:center}
@media(max-width:600px){.grid2{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="wrap">
    <div class="page-header">
        <a href="index.php" class="back-btn">← Back</a>
        <h1>⚙️ Admin Panel</h1>
    </div>

    <?php if ($flash): ?>
    <div class="flash flash-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg']) ?></div>
    <?php endif; ?>

    <div class="tabs">
        <button class="tab active" onclick="showTab('users')">👥 Users</button>
        <button class="tab" onclick="showTab('add')">➕ Add User</button>
        <button class="tab" onclick="showTab('logs')">📋 Activity Log</button>
    </div>

    <!-- Users list -->
    <div class="tab-content active" id="tab-users">
        <div class="card">
            <h2>Team Members</h2>
            <table>
                <tr>
                    <th>#</th><th>Username</th><th>Role</th><th>Projects</th><th>Joined</th><th>Actions</th>
                </tr>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td style="font-weight:600;color:var(--text)"><?= htmlspecialchars($u['username']) ?></td>
                    <td><span class="role-badge role-<?= $u['role'] ?>"><?= $u['role'] ?></span></td>
                    <td><?= $u['project_count'] ?></td>
                    <td style="color:var(--text-muted)"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                    <td>
                        <?php if ($u['id'] !== $_SESSION['user_id']): ?>
                        <!-- Toggle role -->
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            <input type="hidden" name="action" value="change_role">
                            <input type="hidden" name="uid" value="<?= $u['id'] ?>">
                            <input type="hidden" name="role" value="<?= $u['role'] === 'admin' ? 'member' : 'admin' ?>">
                            <button type="submit" class="btn btn-ghost" onclick="return confirm('Change role of <?= htmlspecialchars($u['username']) ?>?')">
                                <?= $u['role'] === 'admin' ? '↓ Member' : '↑ Admin' ?>
                            </button>
                        </form>
                        <!-- Reset password -->
                        <button class="btn btn-ghost" onclick="resetPw(<?= $u['id'] ?>, '<?= htmlspecialchars($u['username']) ?>')">🔑</button>
                        <!-- Delete -->
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            <input type="hidden" name="action" value="delete_user">
                            <input type="hidden" name="uid" value="<?= $u['id'] ?>">
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Delete user <?= htmlspecialchars($u['username']) ?>?')">🗑</button>
                        </form>
                        <?php else: ?>
                        <span style="color:var(--text-muted);font-size:11px">(you)</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>

    <!-- Add user -->
    <div class="tab-content" id="tab-add">
        <div class="card">
            <h2>Add New User</h2>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="add_user">
                <div class="grid2">
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" placeholder="john_dev" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" placeholder="Strong password" required>
                    </div>
                    <div class="form-group">
                        <label>Role</label>
                        <select name="role">
                            <option value="member">Member (can view + edit)</option>
                            <option value="admin">Admin (full access + delete)</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">➕ Add User</button>
            </form>
        </div>
    </div>

    <!-- Activity log -->
    <div class="tab-content" id="tab-logs">
        <div class="card">
            <h2>Recent Activity (last 100)</h2>
            <?php foreach ($logs as $log):
                $icons = ['login'=>'🟢','logout'=>'🔴','add_project'=>'➕','edit_project'=>'✏️',
                          'delete_project'=>'🗑','view_password'=>'👁','export_csv'=>'📊','export_json'=>'📄'];
                $icon = $icons[$log['action']] ?? '•';
            ?>
            <div class="log-row">
                <span class="log-time"><?= date('d M H:i', strtotime($log['created_at'])) ?></span>
                <span class="log-user"><?= htmlspecialchars($log['username'] ?? 'system') ?></span>
                <span class="log-action"><span class="action-icon"><?= $icon ?></span> <?= htmlspecialchars($log['action']) ?>
                    <?php if ($log['detail']): ?>
                    <span style="color:var(--text-muted)">— <?= htmlspecialchars($log['detail']) ?></span>
                    <?php endif; ?>
                </span>
            </div>
            <?php endforeach; ?>
            <?php if (!$logs): ?>
            <p style="color:var(--text-muted);font-size:13px;font-family:'JetBrains Mono',monospace">No activity yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Reset password modal form (hidden) -->
<form method="POST" id="reset-pw-form" style="display:none">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <input type="hidden" name="action" value="reset_password">
    <input type="hidden" name="uid" id="reset-uid">
    <input type="hidden" name="new_password" id="reset-pw-val">
</form>

<script>
function showTab(name) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    event.target.classList.add('active');
}

function resetPw(uid, username) {
    const pw = prompt('New password for ' + username + ':');
    if (!pw || pw.length < 4) { if (pw !== null) alert('Password too short (min 4 chars)'); return; }
    document.getElementById('reset-uid').value = uid;
    document.getElementById('reset-pw-val').value = pw;
    document.getElementById('reset-pw-form').submit();
}
</script>
</body>
</html>
