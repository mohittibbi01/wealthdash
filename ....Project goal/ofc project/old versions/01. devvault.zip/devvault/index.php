<?php
require_once __DIR__ . '/auth.php';
require_login();

$db = get_db();

// ── Filters ────────────────────────────────────────────────────────────────
$search  = trim($_GET['q'] ?? '');
$env     = $_GET['env'] ?? '';
$tag     = $_GET['tag'] ?? '';

$where  = ['1=1'];
$params = [];

if ($search) {
    $where[]  = '(p.name LIKE ? OR p.description LIKE ? OR p.server_ip LIKE ? OR p.tech_stack LIKE ? OR p.tags LIKE ?)';
    $like     = "%$search%";
    $params   = array_merge($params, [$like, $like, $like, $like, $like]);
}
if ($env) {
    $where[]  = 'p.environment = ?';
    $params[] = $env;
}
if ($tag) {
    $where[]  = 'p.tags LIKE ?';
    $params[] = "%$tag%";
}

$sql = "SELECT p.*, u.username as creator FROM projects p
        LEFT JOIN users u ON p.created_by = u.id
        WHERE " . implode(' AND ', $where) . "
        ORDER BY p.updated_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$projects = $stmt->fetchAll();

// Stats
$total     = $db->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$envCounts = $db->query("SELECT environment, COUNT(*) as c FROM projects GROUP BY environment")->fetchAll();
$envMap    = array_column($envCounts, 'c', 'environment');

// All unique tags for filter cloud
$allTags = [];
foreach ($db->query("SELECT tags FROM projects WHERE tags != ''")->fetchAll() as $row) {
    foreach (explode(',', $row['tags']) as $t) {
        $t = trim($t);
        if ($t) $allTags[$t] = ($allTags[$t] ?? 0) + 1;
    }
}
arsort($allTags);

$envColors = [
    'local'      => '#58a6ff',
    'staging'    => '#d29922',
    'production' => '#3fb950',
    'testing'    => '#bc8cff',
    'other'      => '#8b949e',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DevVault — Dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
    --bg: #0d1117;
    --surface: #161b22;
    --surface2: #21262d;
    --border: #30363d;
    --text: #e6edf3;
    --text-muted: #8b949e;
    --accent: #58a6ff;
    --accent-glow: rgba(88,166,255,0.12);
    --success: #3fb950;
    --danger: #f85149;
    --amber: #d29922;
    --purple: #bc8cff;
    --sidebar-w: 220px;
}

body {
    font-family: 'Syne', sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    display: flex;
}

/* ── Sidebar ── */
.sidebar {
    width: var(--sidebar-w);
    background: var(--surface);
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    position: fixed;
    top: 0; left: 0; bottom: 0;
    z-index: 100;
    overflow-y: auto;
}

.sidebar-logo {
    padding: 20px 16px 16px;
    border-bottom: 1px solid var(--border);
}

.sidebar-logo .logo-row {
    display: flex;
    align-items: center;
    gap: 10px;
}

.logo-icon {
    width: 36px; height: 36px;
    background: var(--accent);
    border-radius: 9px;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px;
    flex-shrink: 0;
}

.sidebar-logo h1 {
    font-size: 18px;
    font-weight: 800;
    letter-spacing: -0.3px;
}

.sidebar-logo .version {
    font-size: 10px;
    font-family: 'JetBrains Mono', monospace;
    color: var(--text-muted);
    margin-top: 2px;
}

.sidebar-section {
    padding: 12px 16px 4px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--text-muted);
    font-family: 'JetBrains Mono', monospace;
}

.sidebar-nav a {
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 9px 16px;
    color: var(--text-muted);
    text-decoration: none;
    font-size: 14px;
    font-weight: 600;
    border-left: 2px solid transparent;
    transition: all 0.15s;
}

.sidebar-nav a:hover, .sidebar-nav a.active {
    color: var(--text);
    background: var(--surface2);
    border-left-color: var(--accent);
}

.sidebar-nav a span.icon { font-size: 16px; }

.env-stat {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 16px;
    font-size: 12px;
    cursor: pointer;
    border-radius: 0;
    text-decoration: none;
    transition: background 0.15s;
}
.env-stat:hover { background: var(--surface2); }
.env-stat .env-dot {
    width: 8px; height: 8px;
    border-radius: 50%;
    flex-shrink: 0;
}
.env-stat .env-name { flex: 1; margin-left: 8px; color: var(--text-muted); font-family: 'JetBrains Mono', monospace; }
.env-stat .env-count {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 1px 7px;
    font-size: 11px;
    font-family: 'JetBrains Mono', monospace;
    color: var(--text-muted);
}

.sidebar-footer {
    margin-top: auto;
    padding: 12px 16px;
    border-top: 1px solid var(--border);
}

.user-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}

.avatar {
    width: 28px; height: 28px;
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 12px;
    font-weight: 700;
    color: var(--accent);
    flex-shrink: 0;
}

.user-info .uname { font-size: 13px; font-weight: 700; }
.user-info .urole {
    font-size: 10px;
    font-family: 'JetBrains Mono', monospace;
    color: var(--text-muted);
}

.sidebar-footer .links {
    display: flex;
    gap: 8px;
}

.sidebar-footer .links a {
    font-size: 11px;
    font-family: 'JetBrains Mono', monospace;
    color: var(--text-muted);
    text-decoration: none;
    padding: 4px 8px;
    border: 1px solid var(--border);
    border-radius: 6px;
    transition: all 0.15s;
}
.sidebar-footer .links a:hover { color: var(--text); border-color: var(--text-muted); }

/* ── Main content ── */
.main {
    margin-left: var(--sidebar-w);
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

.topbar {
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    padding: 14px 24px;
    display: flex;
    align-items: center;
    gap: 12px;
    position: sticky;
    top: 0;
    z-index: 50;
}

.search-wrap {
    flex: 1;
    position: relative;
}

.search-wrap input {
    width: 100%;
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 9px 14px 9px 38px;
    color: var(--text);
    font-size: 14px;
    font-family: 'JetBrains Mono', monospace;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
}

.search-wrap input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px var(--accent-glow);
}

.search-icon {
    position: absolute;
    left: 12px; top: 50%;
    transform: translateY(-50%);
    color: var(--text-muted);
    font-size: 14px;
    pointer-events: none;
}

.btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    font-family: 'Syne', sans-serif;
    cursor: pointer;
    border: none;
    text-decoration: none;
    transition: opacity 0.15s, transform 0.1s;
    white-space: nowrap;
}
.btn:active { transform: scale(0.97); }
.btn-primary { background: var(--accent); color: #0d1117; }
.btn-primary:hover { opacity: 0.88; }
.btn-ghost {
    background: var(--surface2);
    color: var(--text-muted);
    border: 1px solid var(--border);
}
.btn-ghost:hover { color: var(--text); border-color: var(--text-muted); }
.btn-danger { background: rgba(248,81,73,0.15); color: var(--danger); border: 1px solid rgba(248,81,73,0.3); }
.btn-danger:hover { background: rgba(248,81,73,0.25); }
.btn-sm { padding: 5px 10px; font-size: 12px; }

.content { padding: 24px; flex: 1; }

/* ── Stats bar ── */
.stats-bar {
    display: flex;
    gap: 12px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.stat-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 14px 18px;
    flex: 1;
    min-width: 120px;
}

.stat-card .num {
    font-size: 26px;
    font-weight: 800;
    line-height: 1;
    font-family: 'JetBrains Mono', monospace;
    color: var(--accent);
}

.stat-card .label {
    font-size: 11px;
    color: var(--text-muted);
    margin-top: 4px;
    font-family: 'JetBrains Mono', monospace;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* ── Tag cloud ── */
.tag-cloud {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.tag-pill {
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-family: 'JetBrains Mono', monospace;
    background: var(--surface2);
    border: 1px solid var(--border);
    color: var(--text-muted);
    text-decoration: none;
    transition: all 0.15s;
    cursor: pointer;
}
.tag-pill:hover, .tag-pill.active {
    background: var(--accent-glow);
    border-color: var(--accent);
    color: var(--accent);
}

/* ── Project grid ── */
.projects-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 16px;
}

.project-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 12px;
    overflow: hidden;
    transition: border-color 0.2s, transform 0.2s, box-shadow 0.2s;
}

.project-card:hover {
    border-color: var(--accent);
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.3);
}

.card-header {
    padding: 14px 16px 10px;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
}

.card-title {
    font-size: 16px;
    font-weight: 700;
    line-height: 1.3;
}

.card-desc {
    font-size: 12px;
    color: var(--text-muted);
    margin-top: 3px;
    font-family: 'JetBrains Mono', monospace;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 200px;
}

.env-badge {
    padding: 3px 9px;
    border-radius: 20px;
    font-size: 10px;
    font-family: 'JetBrains Mono', monospace;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    flex-shrink: 0;
    border: 1px solid currentColor;
}

.card-body {
    padding: 12px 16px;
}

.info-row {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 5px 0;
    border-bottom: 1px solid rgba(48,54,61,0.5);
    font-size: 12px;
}
.info-row:last-child { border-bottom: none; }

.info-row .ikey {
    font-family: 'JetBrains Mono', monospace;
    color: var(--text-muted);
    min-width: 80px;
    font-size: 11px;
}

.info-row .ival {
    font-family: 'JetBrains Mono', monospace;
    color: var(--text);
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.info-row a.ival {
    color: var(--accent);
    text-decoration: none;
}
.info-row a.ival:hover { text-decoration: underline; }

.pw-mask { letter-spacing: 2px; color: var(--text-muted); }

.card-footer {
    padding: 10px 16px;
    border-top: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

.card-meta {
    font-size: 10px;
    color: var(--text-muted);
    font-family: 'JetBrains Mono', monospace;
}

.card-actions { display: flex; gap: 6px; }

/* ── Empty state ── */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: var(--text-muted);
}

.empty-state .big-icon { font-size: 48px; margin-bottom: 12px; }
.empty-state h3 { font-size: 18px; font-weight: 700; color: var(--text); margin-bottom: 8px; }
.empty-state p { font-size: 14px; margin-bottom: 20px; font-family: 'JetBrains Mono', monospace; }

/* ── Toast ── */
.toast {
    position: fixed;
    bottom: 24px; right: 24px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 12px 18px;
    font-size: 13px;
    font-family: 'JetBrains Mono', monospace;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    z-index: 999;
    display: none;
    align-items: center;
    gap: 8px;
    animation: slideUp 0.25s ease;
}
@keyframes slideUp {
    from { transform: translateY(20px); opacity: 0; }
    to   { transform: translateY(0); opacity: 1; }
}

/* ── Flash message ── */
.flash {
    padding: 10px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-family: 'JetBrains Mono', monospace;
    margin-bottom: 16px;
}
.flash-success { background: rgba(63,185,80,0.1); border: 1px solid rgba(63,185,80,0.3); color: var(--success); }
.flash-error   { background: rgba(248,81,73,0.1);  border: 1px solid rgba(248,81,73,0.3);  color: var(--danger);  }

/* ── Responsive ── */
@media (max-width: 768px) {
    :root { --sidebar-w: 0px; }
    .sidebar { display: none; }
    .main { margin-left: 0; }
    .projects-grid { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<!-- Sidebar -->
<aside class="sidebar">
    <div class="sidebar-logo">
        <div class="logo-row">
            <div class="logo-icon">🔐</div>
            <div>
                <h1>DevVault</h1>
                <div class="version">v<?= APP_VERSION ?></div>
            </div>
        </div>
    </div>

    <div class="sidebar-section">Navigation</div>
    <nav class="sidebar-nav">
        <a href="index.php" class="active"><span class="icon">📋</span> All Projects</a>
        <a href="project_form.php"><span class="icon">➕</span> Add Project</a>
        <a href="export.php"><span class="icon">📤</span> Export</a>
        <?php if (is_admin()): ?>
        <a href="admin.php"><span class="icon">⚙️</span> Admin Panel</a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-section">Environments</div>
    <?php foreach (['local','staging','production','testing','other'] as $e): ?>
    <a class="env-stat" href="index.php?env=<?= $e ?>" style="text-decoration:none">
        <span class="env-dot" style="background:<?= $envColors[$e] ?>"></span>
        <span class="env-name"><?= $e ?></span>
        <span class="env-count"><?= $envMap[$e] ?? 0 ?></span>
    </a>
    <?php endforeach; ?>

    <div class="sidebar-footer">
        <div class="user-row">
            <div class="avatar"><?= strtoupper(substr($_SESSION['username'], 0, 1)) ?></div>
            <div class="user-info">
                <div class="uname"><?= htmlspecialchars($_SESSION['username']) ?></div>
                <div class="urole"><?= $_SESSION['role'] ?></div>
            </div>
        </div>
        <div class="links">
            <a href="logout.php">Logout</a>
            <a href="change_password.php">Password</a>
        </div>
    </div>
</aside>

<!-- Main -->
<div class="main">
    <div class="topbar">
        <form method="GET" class="search-wrap" style="display:flex;gap:8px;flex:1">
            <div class="search-wrap" style="flex:1;position:relative;">
                <span class="search-icon">🔍</span>
                <input type="text" name="q" placeholder="Search projects, IPs, stack..." value="<?= htmlspecialchars($search) ?>" id="search-input">
            </div>
            <?php if ($search || $env || $tag): ?>
            <a href="index.php" class="btn btn-ghost btn-sm" style="align-self:center">✕ Clear</a>
            <?php endif; ?>
        </form>
        <a href="project_form.php" class="btn btn-primary">+ Add Project</a>
    </div>

    <div class="content">
        <?php
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        if ($flash): ?>
        <div class="flash flash-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg']) ?></div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="stats-bar">
            <div class="stat-card">
                <div class="num"><?= $total ?></div>
                <div class="label">Total Projects</div>
            </div>
            <?php foreach (['production' => '🟢', 'staging' => '🟡', 'local' => '🔵'] as $e => $icon): ?>
            <div class="stat-card">
                <div class="num" style="color:<?= $envColors[$e] ?>"><?= $envMap[$e] ?? 0 ?></div>
                <div class="label"><?= $icon ?> <?= $e ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Tag cloud -->
        <?php if ($allTags): ?>
        <div class="tag-cloud">
            <?php foreach (array_slice($allTags, 0, 20, true) as $t => $cnt): ?>
            <a href="index.php?tag=<?= urlencode($t) ?><?= $search ? '&q='.urlencode($search) : '' ?>"
               class="tag-pill <?= $tag === $t ? 'active' : '' ?>">
                #<?= htmlspecialchars($t) ?> <span style="opacity:.5"><?= $cnt ?></span>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Results info -->
        <?php if ($search || $env || $tag): ?>
        <p style="font-size:12px;color:var(--text-muted);margin-bottom:14px;font-family:'JetBrains Mono',monospace">
            <?= count($projects) ?> result(s)
            <?= $search ? "for \"$search\"" : '' ?>
            <?= $env ? "in <strong style='color:var(--text)'>$env</strong>" : '' ?>
            <?= $tag ? "tagged <strong style='color:var(--accent)'>#$tag</strong>" : '' ?>
        </p>
        <?php endif; ?>

        <!-- Projects grid -->
        <?php if (empty($projects)): ?>
        <div class="empty-state">
            <div class="big-icon">📭</div>
            <h3>No projects found</h3>
            <p>Koi project nahi mila. Pehla project add karo!</p>
            <a href="project_form.php" class="btn btn-primary">+ Add First Project</a>
        </div>
        <?php else: ?>
        <div class="projects-grid">
        <?php foreach ($projects as $p):
            $envColor = $envColors[$p['environment']] ?? '#8b949e';
            $tags = array_filter(array_map('trim', explode(',', $p['tags'] ?? '')));
        ?>
        <div class="project-card">
            <div class="card-header">
                <div style="min-width:0">
                    <div class="card-title"><?= htmlspecialchars($p['name']) ?></div>
                    <?php if ($p['description']): ?>
                    <div class="card-desc" title="<?= htmlspecialchars($p['description']) ?>">
                        <?= htmlspecialchars($p['description']) ?>
                    </div>
                    <?php endif; ?>
                </div>
                <span class="env-badge" style="color:<?= $envColor ?>;border-color:<?= $envColor ?>20;background:<?= $envColor ?>15">
                    <?= $p['environment'] ?>
                </span>
            </div>

            <div class="card-body">
                <?php if ($p['server_ip']): ?>
                <div class="info-row">
                    <span class="ikey">server IP</span>
                    <span class="ival">
                        <button class="btn btn-ghost btn-sm" onclick="copyText('<?= htmlspecialchars($p['server_ip']) ?>')" style="padding:2px 7px;font-size:10px">📋</button>
                        <?= htmlspecialchars($p['server_ip']) ?>
                        <?php if ($p['server_os']): ?>
                        <span style="color:var(--text-muted);margin-left:4px">(<?= htmlspecialchars($p['server_os']) ?>)</span>
                        <?php endif; ?>
                    </span>
                </div>
                <?php endif; ?>

                <?php if ($p['simple_url']): ?>
                <div class="info-row">
                    <span class="ikey">site URL</span>
                    <a class="ival" href="<?= htmlspecialchars($p['simple_url']) ?>" target="_blank" rel="noopener">
                        <?= htmlspecialchars($p['simple_url']) ?>
                    </a>
                </div>
                <?php endif; ?>

                <?php if ($p['admin_url']): ?>
                <div class="info-row">
                    <span class="ikey">admin URL</span>
                    <a class="ival" href="<?= htmlspecialchars($p['admin_url']) ?>" target="_blank" rel="noopener">
                        <?= htmlspecialchars($p['admin_url']) ?>
                    </a>
                </div>
                <?php endif; ?>

                <?php if ($p['login_id']): ?>
                <div class="info-row">
                    <span class="ikey">login ID</span>
                    <span class="ival">
                        <button class="btn btn-ghost btn-sm" onclick="copyText('<?= htmlspecialchars($p['login_id']) ?>')" style="padding:2px 7px;font-size:10px">📋</button>
                        <?= htmlspecialchars($p['login_id']) ?>
                    </span>
                </div>
                <?php endif; ?>

                <?php if ($p['login_password']): ?>
                <div class="info-row">
                    <span class="ikey">password</span>
                    <span class="ival" style="display:flex;align-items:center;gap:6px">
                        <button class="btn btn-ghost btn-sm" onclick="copyDecrypted(<?= $p['id'] ?>, '<?= csrf_token() ?>')" style="padding:2px 7px;font-size:10px">📋</button>
                        <span class="pw-mask" id="pw-<?= $p['id'] ?>">••••••••</span>
                        <button class="btn btn-ghost btn-sm" onclick="togglePw(<?= $p['id'] ?>, '<?= csrf_token() ?>')" style="padding:2px 7px;font-size:10px" id="pwtoggle-<?= $p['id'] ?>">👁</button>
                    </span>
                </div>
                <?php endif; ?>

                <?php if ($p['tech_stack']): ?>
                <div class="info-row">
                    <span class="ikey">stack</span>
                    <span class="ival"><?= htmlspecialchars($p['tech_stack']) ?></span>
                </div>
                <?php endif; ?>

                <?php if ($p['git_repo']): ?>
                <div class="info-row">
                    <span class="ikey">git repo</span>
                    <a class="ival" href="<?= htmlspecialchars($p['git_repo']) ?>" target="_blank" rel="noopener">
                        <?= htmlspecialchars($p['git_repo']) ?>
                    </a>
                </div>
                <?php endif; ?>

                <?php if ($tags): ?>
                <div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:8px">
                    <?php foreach ($tags as $t): ?>
                    <a href="index.php?tag=<?= urlencode($t) ?>" class="tag-pill" style="font-size:10px;padding:2px 7px">#<?= htmlspecialchars($t) ?></a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <div class="card-footer">
                <div class="card-meta">
                    Updated <?= date('d M Y', strtotime($p['updated_at'])) ?><br>
                    by <?= htmlspecialchars($p['creator'] ?? 'unknown') ?>
                </div>
                <div class="card-actions">
                    <?php if ($p['notes']): ?>
                    <button class="btn btn-ghost btn-sm" onclick="showNotes(<?= $p['id'] ?>)" title="Notes">📝</button>
                    <?php endif; ?>
                    <a href="project_form.php?id=<?= $p['id'] ?>" class="btn btn-ghost btn-sm">Edit</a>
                    <?php if (is_admin()): ?>
                    <button class="btn btn-danger btn-sm" onclick="deleteProject(<?= $p['id'] ?>, '<?= htmlspecialchars($p['name']) ?>', '<?= csrf_token() ?>')">Delete</button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Notes panel (hidden) -->
            <?php if ($p['notes']): ?>
            <div id="notes-<?= $p['id'] ?>" style="display:none;padding:12px 16px;background:var(--surface2);border-top:1px solid var(--border);font-size:12px;font-family:'JetBrains Mono',monospace;color:var(--text-muted);white-space:pre-wrap;"><?= htmlspecialchars($p['notes']) ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Toast -->
<div class="toast" id="toast">
    <span id="toast-text"></span>
</div>

<script>
// Auto-submit search on type (debounced)
let searchTimer;
document.getElementById('search-input').addEventListener('input', function() {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => this.closest('form').submit(), 500);
});

function showToast(msg, icon = '✅') {
    const t = document.getElementById('toast');
    document.getElementById('toast-text').textContent = icon + ' ' + msg;
    t.style.display = 'flex';
    setTimeout(() => t.style.display = 'none', 2500);
}

function copyText(text) {
    navigator.clipboard.writeText(text).then(() => showToast('Copied!'));
}

async function copyDecrypted(id, csrf) {
    const res = await fetch('api.php?action=get_password&id=' + id + '&csrf=' + csrf);
    const data = await res.json();
    if (data.password) {
        navigator.clipboard.writeText(data.password).then(() => showToast('Password copied!'));
    }
}

const pwVisible = {};
async function togglePw(id, csrf) {
    const el = document.getElementById('pw-' + id);
    if (pwVisible[id]) {
        el.textContent = '••••••••';
        el.className = 'pw-mask';
        pwVisible[id] = false;
    } else {
        const res = await fetch('api.php?action=get_password&id=' + id + '&csrf=' + csrf);
        const data = await res.json();
        if (data.password) {
            el.textContent = data.password;
            el.className = 'ival';
            pwVisible[id] = true;
        }
    }
}

function showNotes(id) {
    const el = document.getElementById('notes-' + id);
    el.style.display = el.style.display === 'none' ? 'block' : 'none';
}

function deleteProject(id, name, csrf) {
    if (!confirm('Delete "' + name + '"? Yeh action undo nahi ho sakta.')) return;
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'api.php';
    form.innerHTML = `<input name="action" value="delete_project">
                      <input name="id" value="${id}">
                      <input name="csrf_token" value="${csrf}">`;
    document.body.appendChild(form);
    form.submit();
}
</script>
</body>
</html>
