<?php
require_once __DIR__ . '/auth.php';
require_login();

$db = get_db();
$id = intval($_GET['id'] ?? 0);
$project = null;
$error = '';

if ($id) {
    $stmt = $db->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $project = $stmt->fetch();
    if (!$project) { header('Location: index.php'); exit; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { die('CSRF error'); }

    $name     = trim($_POST['name'] ?? '');
    $desc     = trim($_POST['description'] ?? '');
    $env      = $_POST['environment'] ?? 'local';
    $surl     = trim($_POST['simple_url'] ?? '');
    $aurl     = trim($_POST['admin_url'] ?? '');
    $lid      = trim($_POST['login_id'] ?? '');
    $lpw_raw  = trim($_POST['login_password'] ?? '');
    $ip       = trim($_POST['server_ip'] ?? '');
    $os       = trim($_POST['server_os'] ?? '');
    $stack    = trim($_POST['tech_stack'] ?? '');
    $git      = trim($_POST['git_repo'] ?? '');
    $notes    = trim($_POST['notes'] ?? '');
    $tags     = trim($_POST['tags'] ?? '');

    if (!$name) {
        $error = 'Project name required.';
    } else {
        // Encrypt password only if provided; if editing and field is blank, keep existing
        if ($lpw_raw !== '') {
            $lpw = encrypt_password($lpw_raw);
        } elseif ($project) {
            $lpw = $project['login_password'];
        } else {
            $lpw = '';
        }

        if ($id) {
            $stmt = $db->prepare("UPDATE projects SET
                name=?,description=?,environment=?,simple_url=?,admin_url=?,
                login_id=?,login_password=?,server_ip=?,server_os=?,
                tech_stack=?,git_repo=?,notes=?,tags=?,updated_at=CURRENT_TIMESTAMP
                WHERE id=?");
            $stmt->execute([$name,$desc,$env,$surl,$aurl,$lid,$lpw,$ip,$os,$stack,$git,$notes,$tags,$id]);
            log_activity('edit_project', $id, $name);
        } else {
            $stmt = $db->prepare("INSERT INTO projects
                (name,description,environment,simple_url,admin_url,login_id,login_password,
                server_ip,server_os,tech_stack,git_repo,notes,tags,created_by)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([$name,$desc,$env,$surl,$aurl,$lid,$lpw,$ip,$os,$stack,$git,$notes,$tags,$_SESSION['user_id']]);
            $id = $db->lastInsertId();
            log_activity('add_project', $id, $name);
        }

        backup_to_json();
        $_SESSION['flash'] = ['type' => 'success', 'msg' => "✅ Project \"$name\" saved successfully."];
        header('Location: index.php');
        exit;
    }
}

$envs = ['local','staging','production','testing','other'];
$oss  = ['Linux (Ubuntu)','Linux (CentOS)','Linux (Debian)','Windows Server','macOS','Docker','Other'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DevVault — <?= $project ? 'Edit' : 'Add' ?> Project</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
    --bg:#0d1117;--surface:#161b22;--surface2:#21262d;
    --border:#30363d;--text:#e6edf3;--text-muted:#8b949e;
    --accent:#58a6ff;--accent-glow:rgba(88,166,255,.12);
    --success:#3fb950;--danger:#f85149;
}
body{font-family:'Syne',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;padding:24px}
.wrap{max-width:760px;margin:0 auto}
.page-header{display:flex;align-items:center;gap:12px;margin-bottom:24px}
.back-btn{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:8px 14px;color:var(--text-muted);text-decoration:none;font-size:13px;font-family:'JetBrains Mono',monospace;transition:all .15s}
.back-btn:hover{color:var(--text);border-color:var(--text-muted)}
h1{font-size:22px;font-weight:800;letter-spacing:-.3px}
.error-msg{background:rgba(248,81,73,.1);border:1px solid rgba(248,81,73,.3);color:var(--danger);padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:20px;font-family:'JetBrains Mono',monospace}
.card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:16px}
.card h2{font-size:14px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text-muted);font-family:'JetBrains Mono',monospace;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--border)}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.form-group{margin-bottom:14px}
.form-group.full{grid-column:1/-1}
label{display:block;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text-muted);margin-bottom:6px;font-family:'JetBrains Mono',monospace}
input,select,textarea{width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:10px 13px;color:var(--text);font-size:14px;font-family:'JetBrains Mono',monospace;outline:none;transition:border-color .2s,box-shadow .2s}
input:focus,select:focus,textarea:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-glow)}
select option{background:var(--surface2)}
textarea{resize:vertical;min-height:90px;line-height:1.6}
.pw-wrap{position:relative}
.pw-wrap input{padding-right:42px}
.pw-toggle{position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:16px;color:var(--text-muted);padding:4px}
.hint-text{font-size:11px;color:var(--text-muted);margin-top:5px;font-family:'JetBrains Mono',monospace}
.actions{display:flex;gap:10px;justify-content:flex-end;margin-top:8px}
.btn{display:inline-flex;align-items:center;gap:6px;padding:10px 20px;border-radius:8px;font-size:14px;font-weight:700;font-family:'Syne',sans-serif;cursor:pointer;border:none;text-decoration:none;transition:opacity .15s,transform .1s}
.btn:active{transform:scale(.97)}
.btn-primary{background:var(--accent);color:#0d1117}
.btn-primary:hover{opacity:.88}
.btn-ghost{background:var(--surface2);color:var(--text-muted);border:1px solid var(--border)}
.btn-ghost:hover{color:var(--text)}
@media(max-width:600px){.grid2{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="wrap">
    <div class="page-header">
        <a href="index.php" class="back-btn">← Back</a>
        <h1><?= $project ? '✏️ Edit Project' : '➕ Add New Project' ?></h1>
    </div>

    <?php if ($error): ?>
    <div class="error-msg">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

        <!-- Basic Info -->
        <div class="card">
            <h2>🗂 Basic Info</h2>
            <div class="grid2">
                <div class="form-group full">
                    <label>Project Name *</label>
                    <input type="text" name="name" placeholder="My Awesome Project" required value="<?= htmlspecialchars($project['name'] ?? $_POST['name'] ?? '') ?>">
                </div>
                <div class="form-group full">
                    <label>Description</label>
                    <input type="text" name="description" placeholder="Short description..." value="<?= htmlspecialchars($project['description'] ?? $_POST['description'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Environment</label>
                    <select name="environment">
                        <?php foreach ($envs as $e): ?>
                        <option value="<?= $e ?>" <?= ($project['environment'] ?? 'local') === $e ? 'selected' : '' ?>><?= ucfirst($e) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tags <span style="color:var(--text-muted);font-weight:400">(comma separated)</span></label>
                    <input type="text" name="tags" placeholder="laravel, react, ecommerce" value="<?= htmlspecialchars($project['tags'] ?? '') ?>">
                </div>
            </div>
        </div>

        <!-- URLs -->
        <div class="card">
            <h2>🔗 URLs</h2>
            <div class="grid2">
                <div class="form-group">
                    <label>Site / App URL</label>
                    <input type="url" name="simple_url" placeholder="https://myproject.com" value="<?= htmlspecialchars($project['simple_url'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Admin Panel URL</label>
                    <input type="url" name="admin_url" placeholder="https://myproject.com/admin" value="<?= htmlspecialchars($project['admin_url'] ?? '') ?>">
                </div>
            </div>
        </div>

        <!-- Credentials -->
        <div class="card">
            <h2>🔑 Login Credentials</h2>
            <div class="grid2">
                <div class="form-group">
                    <label>Login ID / Username / Email</label>
                    <input type="text" name="login_id" placeholder="admin@example.com" autocomplete="off" value="<?= htmlspecialchars($project['login_id'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <div class="pw-wrap">
                        <input type="password" name="login_password" id="pw-field" placeholder="<?= $project ? 'Leave blank to keep existing' : 'Enter password' ?>" autocomplete="new-password">
                        <button type="button" class="pw-toggle" onclick="togglePw()">👁</button>
                    </div>
                    <?php if ($project && $project['login_password']): ?>
                    <div class="hint-text">⚠ Password already saved. Enter new one to change.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Server Info -->
        <div class="card">
            <h2>🖥 Server Info</h2>
            <div class="grid2">
                <div class="form-group">
                    <label>Server IP</label>
                    <input type="text" name="server_ip" placeholder="192.168.1.100 or 103.x.x.x" value="<?= htmlspecialchars($project['server_ip'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Server OS</label>
                    <select name="server_os">
                        <option value="">— Select OS —</option>
                        <?php foreach ($oss as $o): ?>
                        <option value="<?= $o ?>" <?= ($project['server_os'] ?? '') === $o ? 'selected' : '' ?>><?= $o ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tech Stack</label>
                    <input type="text" name="tech_stack" placeholder="Laravel 10, React, MySQL, Nginx" value="<?= htmlspecialchars($project['tech_stack'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Git Repository</label>
                    <input type="url" name="git_repo" placeholder="https://github.com/org/repo" value="<?= htmlspecialchars($project['git_repo'] ?? '') ?>">
                </div>
            </div>
        </div>

        <!-- Notes -->
        <div class="card">
            <h2>📝 Notes / Remarks</h2>
            <div class="form-group">
                <label>Notes</label>
                <textarea name="notes" placeholder="Deployment steps, SSH commands, special instructions, API keys location..."><?= htmlspecialchars($project['notes'] ?? '') ?></textarea>
            </div>
        </div>

        <div class="actions">
            <a href="index.php" class="btn btn-ghost">Cancel</a>
            <button type="submit" class="btn btn-primary">💾 Save Project</button>
        </div>
    </form>
</div>

<script>
function togglePw() {
    const f = document.getElementById('pw-field');
    f.type = f.type === 'password' ? 'text' : 'password';
}
</script>
</body>
</html>
