<?php
require_once __DIR__ . '/auth.php';
require_login();

header('Content-Type: application/json');

$action = $_REQUEST['action'] ?? '';

// ── GET: reveal password ──────────────────────────────────────────────────────
if ($action === 'get_password' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $id   = intval($_GET['id'] ?? 0);
    $csrf = $_GET['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
        echo json_encode(['error' => 'Invalid CSRF']); exit;
    }
    $db   = get_db();
    $stmt = $db->prepare("SELECT login_password FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $row  = $stmt->fetch();
    if (!$row) { echo json_encode(['error' => 'Not found']); exit; }

    $plain = $row['login_password'] ? decrypt_password($row['login_password']) : '';
    log_activity('view_password', $id);
    echo json_encode(['password' => $plain]);
    exit;
}

// ── POST: delete project ──────────────────────────────────────────────────────
if ($action === 'delete_project' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!is_admin()) { echo json_encode(['error' => 'Forbidden']); exit; }
    if (!verify_csrf()) { echo json_encode(['error' => 'CSRF']); exit; }

    $id   = intval($_POST['id'] ?? 0);
    $db   = get_db();
    $stmt = $db->prepare("SELECT name FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $row  = $stmt->fetch();
    if ($row) {
        $db->prepare("DELETE FROM projects WHERE id = ?")->execute([$id]);
        log_activity('delete_project', $id, $row['name']);
        backup_to_json();
        $_SESSION['flash'] = ['type' => 'success', 'msg' => "🗑 Project \"{$row['name']}\" deleted."];
    }
    header('Location: index.php');
    exit;
}

echo json_encode(['error' => 'Unknown action']);
