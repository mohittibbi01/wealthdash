<?php
define('APP_NAME', 'DevVault');
define('APP_VERSION', '1.0.0');
define('DB_PATH', __DIR__ . '/data/vault.db');
define('JSON_BACKUP_PATH', __DIR__ . '/data/vault.json');
define('SESSION_LIFETIME', 3600 * 8); // 8 hours
define('ENCRYPT_KEY', 'DevVault_S3cur3_K3y_Ch4ng3_Th1s_!'); // Change this in production

// ─── Encryption helpers ───────────────────────────────────────────────────────
function encrypt_password(string $plain): string {
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($plain, 'AES-256-CBC', ENCRYPT_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted);
}

function decrypt_password(string $cipher): string {
    $decoded = base64_decode($cipher);
    [$iv, $encrypted] = explode('::', $decoded, 2);
    return openssl_decrypt($encrypted, 'AES-256-CBC', ENCRYPT_KEY, 0, $iv);
}

// ─── Database init ────────────────────────────────────────────────────────────
function get_db(): PDO {
    static $db = null;
    if ($db) return $db;

    $db = new PDO('sqlite:' . DB_PATH);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $db->exec('PRAGMA journal_mode=WAL');

    $db->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'member',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            environment TEXT DEFAULT 'local',
            simple_url TEXT,
            admin_url TEXT,
            login_id TEXT,
            login_password TEXT,
            server_ip TEXT,
            server_os TEXT,
            tech_stack TEXT,
            git_repo TEXT,
            notes TEXT,
            tags TEXT,
            created_by INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS activity_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT,
            project_id INTEGER,
            detail TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    ");

    // Default admin user (admin / admin123) — change after first login
    $db->exec("
        INSERT OR IGNORE INTO users (username, password_hash, role)
        VALUES ('admin', '" . password_hash('admin123', PASSWORD_DEFAULT) . "', 'admin')
    ");

    return $db;
}

// ─── JSON backup ──────────────────────────────────────────────────────────────
function backup_to_json(): void {
    $db = get_db();
    $projects = $db->query("SELECT * FROM projects")->fetchAll();
    $users    = $db->query("SELECT id, username, role, created_at FROM users")->fetchAll();
    $backup = [
        'exported_at' => date('Y-m-d H:i:s'),
        'version'     => APP_VERSION,
        'projects'    => $projects,
        'users'       => $users,
    ];
    file_put_contents(JSON_BACKUP_PATH, json_encode($backup, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// ─── Activity log ─────────────────────────────────────────────────────────────
function log_activity(string $action, ?int $project_id = null, string $detail = ''): void {
    $db = get_db();
    $stmt = $db->prepare("INSERT INTO activity_log (user_id, action, project_id, detail) VALUES (?,?,?,?)");
    $stmt->execute([$_SESSION['user_id'] ?? null, $action, $project_id, $detail]);
}
