<?php
require_once __DIR__ . '/config.php';
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $db = get_db();
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            log_activity('login');
            header('Location: index.php');
            exit;
        } else {
            $error = 'Invalid username or password.';
        }
    } else {
        $error = 'Please enter username and password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DevVault — Login</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
    --bg: #0d1117;
    --surface: #161b22;
    --surface2: #21262d;
    --border: #30363d;
    --text: #e6edf3;
    --text-muted: #8b949e;
    --accent: #58a6ff;
    --accent-glow: rgba(88,166,255,0.15);
    --success: #3fb950;
    --danger: #f85149;
    --amber: #d29922;
}

body {
    font-family: 'Syne', sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
}

body::before {
    content: '';
    position: fixed;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(ellipse at 60% 40%, rgba(88,166,255,0.06) 0%, transparent 60%),
                radial-gradient(ellipse at 30% 70%, rgba(63,185,80,0.04) 0%, transparent 50%);
    pointer-events: none;
}

.login-wrap {
    width: 100%;
    max-width: 400px;
    padding: 24px;
    position: relative;
    z-index: 1;
}

.logo {
    text-align: center;
    margin-bottom: 36px;
}

.logo-icon {
    width: 56px;
    height: 56px;
    background: linear-gradient(135deg, var(--accent), #388bfd);
    border-radius: 14px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 12px;
    font-size: 26px;
    box-shadow: 0 0 30px rgba(88,166,255,0.3);
}

.logo h1 {
    font-size: 28px;
    font-weight: 800;
    letter-spacing: -0.5px;
}

.logo p {
    color: var(--text-muted);
    font-size: 13px;
    font-family: 'JetBrains Mono', monospace;
    margin-top: 4px;
}

.card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 28px;
}

.error-msg {
    background: rgba(248,81,73,0.1);
    border: 1px solid rgba(248,81,73,0.3);
    color: var(--danger);
    padding: 10px 14px;
    border-radius: 8px;
    font-size: 13px;
    margin-bottom: 20px;
    font-family: 'JetBrains Mono', monospace;
}

.form-group {
    margin-bottom: 16px;
}

label {
    display: block;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: var(--text-muted);
    margin-bottom: 7px;
    font-family: 'JetBrains Mono', monospace;
}

input[type="text"],
input[type="password"] {
    width: 100%;
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 11px 14px;
    color: var(--text);
    font-size: 15px;
    font-family: 'JetBrains Mono', monospace;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
}

input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px var(--accent-glow);
}

.btn-login {
    width: 100%;
    background: var(--accent);
    color: #0d1117;
    border: none;
    border-radius: 8px;
    padding: 12px;
    font-size: 15px;
    font-weight: 700;
    font-family: 'Syne', sans-serif;
    cursor: pointer;
    margin-top: 8px;
    transition: opacity 0.2s, transform 0.1s;
    letter-spacing: 0.3px;
}

.btn-login:hover { opacity: 0.88; }
.btn-login:active { transform: scale(0.98); }

.hint {
    text-align: center;
    margin-top: 18px;
    font-size: 12px;
    color: var(--text-muted);
    font-family: 'JetBrains Mono', monospace;
}
</style>
</head>
<body>
<div class="login-wrap">
    <div class="logo">
        <div class="logo-icon">🔐</div>
        <h1>DevVault</h1>
        <p>// team credential manager</p>
    </div>
    <div class="card">
        <?php if ($error): ?>
            <div class="error-msg">⚠ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="your-username" autofocus autocomplete="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="••••••••" autocomplete="current-password">
            </div>
            <button type="submit" class="btn-login">Sign In →</button>
        </form>
    </div>
    <div class="hint">Default: admin / admin123 — pehle login ke baad badlo</div>
</div>
</body>
</html>
