<?php
require_once __DIR__ . '/auth.php';
require_login();

$db     = get_db();
$format = $_GET['format'] ?? '';

if ($format === 'json') {
    $projects = $db->query("SELECT p.*, u.username as creator FROM projects p LEFT JOIN users u ON p.created_by = u.id ORDER BY p.name")->fetchAll();
    // Decrypt passwords for export (admin only)
    foreach ($projects as &$p) {
        if (is_admin() && $p['login_password']) {
            $p['login_password_plain'] = decrypt_password($p['login_password']);
        }
        unset($p['login_password']); // Remove cipher from export
    }
    unset($p);

    log_activity('export_json');
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="devvault_export_' . date('Ymd_His') . '.json"');
    echo json_encode([
        'exported_at' => date('Y-m-d H:i:s'),
        'exported_by' => $_SESSION['username'],
        'total'       => count($projects),
        'projects'    => $projects,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

if ($format === 'csv') {
    $projects = $db->query("SELECT p.*, u.username as creator FROM projects p LEFT JOIN users u ON p.created_by = u.id ORDER BY p.name")->fetchAll();

    log_activity('export_csv');
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="devvault_export_' . date('Ymd_His') . '.csv"');

    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF)); // UTF-8 BOM for Excel

    fputcsv($out, ['#','Name','Description','Environment','Simple URL','Admin URL','Login ID',
                   is_admin() ? 'Password' : 'Password (hidden)',
                   'Server IP','Server OS','Tech Stack','Git Repo','Tags','Notes','Creator','Created At','Updated At']);

    $i = 1;
    foreach ($projects as $p) {
        fputcsv($out, [
            $i++,
            $p['name'],
            $p['description'],
            $p['environment'],
            $p['simple_url'],
            $p['admin_url'],
            $p['login_id'],
            is_admin() && $p['login_password'] ? decrypt_password($p['login_password']) : '(hidden)',
            $p['server_ip'],
            $p['server_os'],
            $p['tech_stack'],
            $p['git_repo'],
            $p['tags'],
            $p['notes'],
            $p['creator'],
            $p['created_at'],
            $p['updated_at'],
        ]);
    }
    fclose($out);
    exit;
}

// ── Export page UI ────────────────────────────────────────────────────────────
$total = $db->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$lastBackup = file_exists(JSON_BACKUP_PATH) ? date('d M Y, H:i', filemtime(JSON_BACKUP_PATH)) : 'Never';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DevVault — Export</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0d1117;--surface:#161b22;--surface2:#21262d;--border:#30363d;--text:#e6edf3;--text-muted:#8b949e;--accent:#58a6ff;--success:#3fb950;--amber:#d29922}
body{font-family:'Syne',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;padding:24px}
.wrap{max-width:640px;margin:0 auto}
.page-header{display:flex;align-items:center;gap:12px;margin-bottom:28px}
.back-btn{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:8px 14px;color:var(--text-muted);text-decoration:none;font-size:13px;font-family:'JetBrains Mono',monospace;transition:all .15s}
.back-btn:hover{color:var(--text)}
h1{font-size:22px;font-weight:800}
.card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:16px}
.card h2{font-size:14px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text-muted);font-family:'JetBrains Mono',monospace;margin-bottom:16px}
.export-option{display:flex;align-items:center;gap:16px;padding:16px;background:var(--surface2);border:1px solid var(--border);border-radius:10px;margin-bottom:12px;text-decoration:none;color:var(--text);transition:border-color .2s,transform .15s}
.export-option:hover{border-color:var(--accent);transform:translateX(4px)}
.exp-icon{font-size:32px;flex-shrink:0}
.exp-info h3{font-size:16px;font-weight:700;margin-bottom:3px}
.exp-info p{font-size:12px;color:var(--text-muted);font-family:'JetBrains Mono',monospace}
.exp-badge{margin-left:auto;font-size:11px;font-family:'JetBrains Mono',monospace;padding:3px 9px;border-radius:20px;flex-shrink:0}
.badge-green{background:rgba(63,185,80,.15);color:var(--success);border:1px solid rgba(63,185,80,.3)}
.badge-amber{background:rgba(210,153,34,.15);color:var(--amber);border:1px solid rgba(210,153,34,.3)}
.info-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:13px}
.info-row:last-child{border-bottom:none}
.info-row .key{color:var(--text-muted);font-family:'JetBrains Mono',monospace}
.info-row .val{font-family:'JetBrains Mono',monospace;font-weight:600}
.warning-box{background:rgba(210,153,34,.1);border:1px solid rgba(210,153,34,.3);border-radius:8px;padding:12px 14px;font-size:12px;font-family:'JetBrains Mono',monospace;color:var(--amber);margin-top:12px}
</style>
</head>
<body>
<div class="wrap">
    <div class="page-header">
        <a href="index.php" class="back-btn">← Back</a>
        <h1>📤 Export & Backup</h1>
    </div>

    <div class="card">
        <h2>Current Data</h2>
        <div class="info-row"><span class="key">Total Projects</span><span class="val"><?= $total ?></span></div>
        <div class="info-row"><span class="key">Last Auto-Backup</span><span class="val"><?= $lastBackup ?></span></div>
        <div class="info-row"><span class="key">Backup File</span><span class="val">data/vault.json</span></div>
    </div>

    <div class="card">
        <h2>Download Export</h2>
        <a class="export-option" href="export.php?format=json">
            <span class="exp-icon">📄</span>
            <div class="exp-info">
                <h3>JSON Export</h3>
                <p>Full data with all fields — best for backup & restore</p>
            </div>
            <span class="exp-badge badge-green">Recommended</span>
        </a>
        <a class="export-option" href="export.php?format=csv">
            <span class="exp-icon">📊</span>
            <div class="exp-info">
                <h3>CSV Export</h3>
                <p>Excel-compatible — open karo spreadsheet mein</p>
            </div>
            <span class="exp-badge badge-amber">Excel ready</span>
        </a>

        <?php if (!is_admin()): ?>
        <div class="warning-box">
            ⚠ Non-admin users ke liye passwords export mein hidden honge. Admin se contact karo full export ke liye.
        </div>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>Portable Backup Guide</h2>
        <div style="font-size:13px;font-family:'JetBrains Mono',monospace;color:var(--text-muted);line-height:1.8">
            <p style="margin-bottom:8px">PC change karne ke liye sirf yeh karo:</p>
            <p>1. Puri <strong style="color:var(--text)">devvault/</strong> folder copy karo</p>
            <p>2. Naye PC pe paste karo</p>
            <p>3. <strong style="color:var(--text)">data/vault.db</strong> file mein sab kuch hai</p>
            <p>4. PHP run karo — koi install nahi</p>
            <p style="margin-top:12px;color:var(--success)">✅ Sab data <strong>data/</strong> folder mein hai — koi cloud sync needed nahi</p>
        </div>
    </div>
</div>
</body>
</html>
