# 🔐 DevVault — Team Credential Manager

Developer teams ke liye ek portable, lightweight credential & project info manager.

---

## ✅ Requirements

- **PHP 7.4+** (alag se koi install nahi — bas PHP chahiye)
- PHP extensions: `pdo_sqlite`, `openssl` (usually default mein aate hain)

Check karo:
```
php -m | grep -E "pdo_sqlite|openssl"
```

---

## 🚀 Start Karna (Ek Command)

```bash
cd devvault
php -S 0.0.0.0:8080
```

Browser mein:
- **Apne PC pe:** `http://localhost:8080`
- **LAN mein kisi bhi PC se:** `http://192.168.X.X:8080`

> 🔍 Apna IP jaanne ke liye: `ipconfig` (Windows) ya `hostname -I` (Linux/Mac)

---

## 🔑 Default Login

| Username | Password |
|----------|----------|
| `admin`  | `admin123` |

> ⚠️ **Pehle login ke baad password zaroor badlo!**  
> Admin Panel → Change Password

---

## 📁 Folder Structure

```
devvault/
├── index.php          ← Main dashboard
├── login.php          ← Login page
├── logout.php         ← Logout
├── project_form.php   ← Add/Edit project
├── admin.php          ← Admin panel (users + logs)
├── export.php         ← CSV/JSON export
├── api.php            ← Password reveal API
├── change_password.php
├── config.php         ← Settings & DB init
├── auth.php           ← Session helpers
│
└── data/
    ├── vault.db       ← SQLite database (SABA KUCH YAHAN HAI)
    └── vault.json     ← Auto JSON backup
```

---

## 💾 Portable Kaise Hai?

**Sab kuch `data/` folder mein hai.**

PC change karna ho toh:
1. Pura `devvault/` folder copy karo (USB/Drive)
2. Naye PC pe paste karo
3. PHP se run karo
4. Done — koi data loss nahi! ✅

---

## 🌐 LAN Access

Jo PC server chal raha ho uska IP:
- Windows: `ipconfig` → IPv4 Address
- Linux: `hostname -I`

Phir dusre logon ko batao: `http://[SERVER-IP]:8080`

---

## 🔒 Security Notes

- Passwords **AES-256 encrypted** store hote hain
- Admin aur Member ke alag roles hain
- CSRF protection enabled hai
- Activity log: kaun kya kar raha hai sab track hota hai
- Non-admin users passwords **export mein nahi dekh sakte**

---

## 🔧 `config.php` mein changes

```php
// Encryption key — production mein badlo (unique rakho)
define('ENCRYPT_KEY', 'DevVault_S3cur3_K3y_Ch4ng3_Th1s_!');

// Session lifetime (default: 8 hours)
define('SESSION_LIFETIME', 3600 * 8);
```

---

## 📤 Export / Backup

Dashboard → Export:
- **JSON** — Full backup (restore ke liye)
- **CSV** — Excel mein open karo

Auto JSON backup: har save pe `data/vault.json` update hota hai.

---

## 🛣️ Future Enhancements (Suggestions)

- [ ] Project categories / groups
- [ ] File attachments (SSL certs, env files)
- [ ] Two-factor authentication (2FA)
- [ ] Dark/Light theme toggle
- [ ] Notifications (project expiry alerts)
- [ ] API access tokens
- [ ] Audit trail with IP logging
- [ ] Bulk import via CSV
- [ ] Project cloning (staging → production copy)

---

## ❓ Troubleshooting

**SQLite not working?**
```bash
php -m | grep pdo_sqlite
# Agar kuch nahi aaya:
sudo apt install php-sqlite3  # Ubuntu/Debian
```

**Permission error on data/ folder?**
```bash
chmod 755 data/
chmod 644 data/vault.db
```

**Port already in use?**
```bash
php -S 0.0.0.0:9090  # alag port use karo
```
