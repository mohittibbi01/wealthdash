<?php
require_once __DIR__ . '/auth.php';
require_login();

$db    = get_db();
$error = '';
$ok    = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf()) {
    $current  = $_POST['current_password'] ?? '';
    $new      = $_POST['new_password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    $stmt = $db->prepare("SELECT password_hash FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!password_verify($current, $user['password_hash'])) {
        $error = 'Current password is incorrect.';
    } elseif (strlen($new) < 6) {
        $error = 'New password must be at least 6 characters.';
    } elseif ($new !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $db->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['user_id']]);
        log_activity('change_password');
        $ok = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DevVault — Change Password</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0d1117;--surface:#161b22;--surface2:#21262d;--border:#30363d;--text:#e6edf3;--text-muted:#8b949e;--accent:#58a6ff;--accent-glow:rgba(88,166,255,.12);--success:#3fb950;--danger:#f85149}
body{font-family:'Syne',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.wrap{width:100%;max-width:420px}
.page-header{display:flex;align-items:center;gap:12px;margin-bottom:24px}
.back-btn{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:8px 14px;color:var(--text-muted);text-decoration:none;font-size:13px;font-family:'JetBrains Mono',monospace}
h1{font-size:22px;font-weight:800}
.card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px}
.msg{padding:10px 14px;border-radius:8px;font-size:13px;font-family:'JetBrains Mono',monospace;margin-bottom:16px}
.msg-success{background:rgba(63,185,80,.1);border:1px solid rgba(63,185,80,.3);color:var(--success)}
.msg-error{background:rgba(248,81,73,.1);border:1px solid rgba(248,81,73,.3);color:var(--danger)}
.form-group{margin-bottom:14px}
label{display:block;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text-muted);margin-bottom:6px;font-family:'JetBrains Mono',monospace}
input{width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:10px 13px;color:var(--text);font-size:14px;font-family:'JetBrains Mono',monospace;outline:none;transition:border-color .2s,box-shadow .2s}
input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-glow)}
.btn{width:100%;background:var(--accent);color:#0d1117;border:none;border-radius:8px;padding:12px;font-size:15px;font-weight:700;font-family:'Syne',sans-serif;cursor:pointer;margin-top:6px;transition:opacity .2s}
.btn:hover{opacity:.88}
</style>
</head>
<body>
<div class="wrap">
    <div class="page-header">
        <a href="index.php" class="back-btn">← Back</a>
        <h1>🔑 Change Password</h1>
    </div>
    <div class="card">
        <?php if ($ok): ?>
        <div class="msg msg-success">✅ Password changed successfully!</div>
        <a href="index.php" style="color:var(--accent);font-family:'JetBrains Mono',monospace;font-size:13px">← Back to dashboard</a>
        <?php else: ?>
        <?php if ($error): ?><div class="msg msg-error">⚠ <?= htmlspecialchars($error) ?></div><?php endif; ?>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" name="current_password" required autocomplete="current-password">
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password" required autocomplete="new-password">
            </div>
            <div class="form-group">
                <label>Confirm New Password</label>
                <input type="password" name="confirm_password" required autocomplete="new-password">
            </div>
            <button type="submit" class="btn">Update Password</button>
        </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
