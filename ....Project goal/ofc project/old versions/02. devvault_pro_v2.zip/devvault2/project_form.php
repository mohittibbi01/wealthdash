<?php
require_once __DIR__ . '/auth.php';
require_login();

$db = get_db();
$id = intval($_GET['id'] ?? 0);
$p  = null;
$error = '';

if ($id) {
    $st = $db->prepare("SELECT * FROM projects WHERE id=?");
    $st->execute([$id]);
    $p = $st->fetch();
    if (!$p) { header('Location: index.php'); exit; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) die('CSRF error');

    // Handle dynamic "Other" options — save new option to DB
    foreach (['technology','app_os','db_version','db_os'] as $grp) {
        $other_key = $grp . '_other';
        if (($_POST[$grp] ?? '') === 'Other' && !empty($_POST[$other_key])) {
            add_option($grp, $_POST[$other_key]);
        }
    }

    $fields = [
        'department_name','nodal_officer_name','nodal_designation','nodal_contact','dept_email',
        'technology','technology_other','website_app','project_name','description',
        'current_status','last_audit_date','live_date','total_visitor_counter','last_update_date',
        'env_local_url','env_local_admin_url','env_local_id','env_local_remark',
        'env_staging_url','env_staging_admin_url','env_staging_id','env_staging_remark',
        'env_production_url','env_production_admin_url','env_production_id','env_production_remark',
        'env_audit_url','env_audit_admin_url','env_audit_id','env_audit_remark',
        'env_other_url','env_other_admin_url','env_other_id','env_other_remark',
        'app_ip','app_lb_ip','app_os','app_os_other','app_core','app_ram',
        'app_primary_storage','app_secondary_storage','app_hosting_type','app_infra_remark',
        'db_ip','db_name','db_version','db_version_other','db_os','db_os_other',
        'db_hosting_type','db_remark','general_remark',
    ];

    $data = [];
    foreach ($fields as $f) {
        $data[$f] = trim($_POST[$f] ?? '');
    }

    // Encrypt passwords per env
    $envNames = ['local','staging','production','audit','other'];
    foreach ($envNames as $env) {
        $key = "env_{$env}_password";
        $raw = trim($_POST[$key] ?? '');
        if ($raw !== '') {
            $data[$key] = encrypt_val($raw);
        } elseif ($p) {
            $data[$key] = $p[$key]; // keep existing
        } else {
            $data[$key] = '';
        }
    }

    if (!$data['project_name']) {
        $error = 'Project name is required.';
    } else {
        if ($id) {
            $sets = implode(',', array_map(fn($f) => "`$f`=?", array_keys($data)));
            $sets .= ',updated_at=CURRENT_TIMESTAMP';
            $st = $db->prepare("UPDATE projects SET $sets WHERE id=?");
            $st->execute([...array_values($data), $id]);
            log_activity('edit_project', $id, $data['project_name']);
        } else {
            $cols = implode(',', array_map(fn($f) => "`$f`", array_keys($data)));
            $phs  = implode(',', array_fill(0, count($data), '?'));
            $st = $db->prepare("INSERT INTO projects ($cols,created_by) VALUES ($phs,?)");
            $st->execute([...array_values($data), $_SESSION['user_id']]);
            $id = $db->lastInsertId();
            log_activity('add_project', $id, $data['project_name']);
        }
        backup_json();
        $_SESSION['flash'] = ['type'=>'success','msg'=>"✅ Project \"{$data['project_name']}\" saved."];
        header('Location: index.php'); exit;
    }
}

// Options
$techOpts   = get_options_arr('technology');
$appOsOpts  = get_options_arr('app_os');
$dbVerOpts  = get_options_arr('db_version');
$dbOsOpts   = get_options_arr('db_os');

$v = fn($f) => htmlspecialchars($p[$f] ?? $_POST[$f] ?? '');
$sel = fn($f,$val) => ($p[$f] ?? $_POST[$f] ?? '') === $val ? 'selected' : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DevVault Pro — <?=$p?'Edit':'Add'?> Project</title>
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Orbitron:wght@700;900&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#070b14;--surface:#0d1422;--surface2:#111a2e;--surface3:#16213e;
  --border:#1e2d4a;--text:#e8edf5;--muted:#5a7a9a;--accent:#00d4ff;
  --success:#00e676;--danger:#ff3d5a;--amber:#ffd740}
body{font-family:'Rajdhani',sans-serif;background:var(--bg);color:var(--text);
  min-height:100vh;padding:0}

/* grid bg */
body::before{content:'';position:fixed;inset:0;
  background-image:linear-gradient(rgba(0,212,255,.02) 1px,transparent 1px),
    linear-gradient(90deg,rgba(0,212,255,.02) 1px,transparent 1px);
  background-size:40px 40px;pointer-events:none;z-index:0}

.topbar{position:sticky;top:0;z-index:100;background:rgba(7,11,20,.95);
  border-bottom:1px solid var(--border);backdrop-filter:blur(12px);
  padding:0 24px;height:54px;display:flex;align-items:center;gap:12px}
.logo-text{font-family:'Orbitron',monospace;font-size:15px;font-weight:900;
  letter-spacing:2px;color:var(--accent)}
.page-title{font-size:17px;font-weight:700;color:var(--text)}
.topbar-right{margin-left:auto;display:flex;gap:8px}
.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:7px;
  font-size:13px;font-weight:600;font-family:'Rajdhani',sans-serif;letter-spacing:.5px;
  cursor:pointer;border:none;text-decoration:none;transition:all .15s}
.btn-accent{background:var(--accent);color:#000}
.btn-accent:hover{opacity:.85}
.btn-ghost{background:var(--surface2);color:var(--muted);border:1px solid var(--border)}
.btn-ghost:hover{color:var(--text)}
.btn:active{transform:scale(.97)}

.wrap{max-width:1000px;margin:0 auto;padding:24px;position:relative;z-index:1}

/* Error */
.error-msg{background:rgba(255,61,90,.08);border:1px solid rgba(255,61,90,.3);
  color:var(--danger);padding:10px 16px;border-radius:8px;font-size:13px;
  margin-bottom:16px;font-family:'Share Tech Mono',monospace}

/* Section cards */
.section{background:var(--surface);border:1px solid var(--border);border-radius:14px;
  margin-bottom:16px;overflow:hidden}
.section-head{padding:14px 18px;border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none}
.section-head h2{font-family:'Orbitron',monospace;font-size:12px;font-weight:700;
  letter-spacing:2px;color:var(--accent);text-transform:uppercase}
.section-head .toggle{margin-left:auto;color:var(--muted);font-size:18px;
  transition:transform .2s;font-family:'Share Tech Mono',monospace}
.section-head.collapsed .toggle{transform:rotate(-90deg)}
.section-body{padding:18px}
.section-body.hidden{display:none}

/* Form fields */
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}
.grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.full{grid-column:1/-1}

.field{display:flex;flex-direction:column;gap:5px}
.field label{font-family:'Share Tech Mono',monospace;font-size:10px;text-transform:uppercase;
  letter-spacing:1.5px;color:var(--muted)}
.field label .req{color:var(--danger)}

input[type=text],input[type=url],input[type=date],input[type=email],
input[type=tel],input[type=number],select,textarea{
  background:var(--surface2);border:1px solid var(--border);border-radius:8px;
  padding:9px 12px;color:var(--text);font-size:14px;
  font-family:'Rajdhani',sans-serif;font-weight:500;outline:none;
  transition:border-color .2s,box-shadow .2s;width:100%}
input:focus,select:focus,textarea:focus{
  border-color:var(--accent);box-shadow:0 0 0 3px rgba(0,212,255,.08)}
input::placeholder,textarea::placeholder{color:var(--muted)}
select option{background:var(--surface2)}
textarea{resize:vertical;min-height:80px;line-height:1.6}

.pw-wrap{position:relative}
.pw-wrap input{padding-right:42px}
.pw-toggle{position:absolute;right:10px;top:50%;transform:translateY(-50%);
  background:none;border:none;cursor:pointer;font-size:15px;color:var(--muted);padding:4px}
.hint{font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--muted);margin-top:3px}

/* Env table */
.env-table{width:100%;border-collapse:collapse}
.env-table th{font-family:'Share Tech Mono',monospace;font-size:10px;text-transform:uppercase;
  letter-spacing:1px;color:var(--muted);padding:8px 10px;text-align:left;
  border-bottom:1px solid var(--border)}
.env-table td{padding:6px 8px;border-bottom:1px solid rgba(30,45,74,.5)}
.env-table tr:last-child td{border-bottom:none}
.env-label{font-family:'Share Tech Mono',monospace;font-size:11px;font-weight:600;
  color:var(--accent);padding:6px 10px;white-space:nowrap}

/* Conditional fields */
.cond-field{display:none}
.cond-field.show{display:flex}

.form-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:8px;padding-top:16px;
  border-top:1px solid var(--border)}

@media(max-width:700px){
  .grid2,.grid3,.grid4{grid-template-columns:1fr}
  .env-table{display:block;overflow-x:auto}}
</style>
</head>
<body>
<div class="topbar">
  <span class="logo-text">DEVVAULT</span>
  <span style="color:var(--border)">|</span>
  <span class="page-title"><?=$p?'✏ Edit Project':'＋ Add New Project'?></span>
  <div class="topbar-right">
    <a href="index.php" class="btn btn-ghost">← Back</a>
  </div>
</div>

<div class="wrap">
<?php if($error):?>
<div class="error-msg">⚠ <?=htmlspecialchars($error)?></div>
<?php endif;?>

<form method="POST" id="main-form">
<input type="hidden" name="csrf" value="<?=csrf_token()?>">

<!-- ── SECTION 1: Department Info ── -->
<div class="section">
  <div class="section-head" onclick="toggleSection(this)">
    <h2>🏢 Department Information</h2>
    <span class="toggle">▾</span>
  </div>
  <div class="section-body">
    <div class="grid3">
      <div class="field">
        <label>Department Name</label>
        <input type="text" name="department_name" placeholder="e.g. IT Department" value="<?=$v('department_name')?>">
      </div>
      <div class="field">
        <label>Nodal Officer Name</label>
        <input type="text" name="nodal_officer_name" placeholder="Full name" value="<?=$v('nodal_officer_name')?>">
      </div>
      <div class="field">
        <label>Designation</label>
        <input type="text" name="nodal_designation" placeholder="e.g. Senior Developer" value="<?=$v('nodal_designation')?>">
      </div>
      <div class="field">
        <label>Contact No.</label>
        <input type="tel" name="nodal_contact" placeholder="10-digit mobile" value="<?=$v('nodal_contact')?>">
      </div>
      <div class="field">
        <label>Department Email</label>
        <input type="email" name="dept_email" placeholder="dept@gov.in" value="<?=$v('dept_email')?>">
      </div>
    </div>
  </div>
</div>

<!-- ── SECTION 2: Project Info ── -->
<div class="section">
  <div class="section-head" onclick="toggleSection(this)">
    <h2>🗂 Project Information</h2>
    <span class="toggle">▾</span>
  </div>
  <div class="section-body">
    <div class="grid2" style="margin-bottom:14px">
      <div class="field">
        <label>Technology <span class="req">*</span></label>
        <select name="technology" id="tech-select" onchange="handleOther(this,'tech-other')">
          <option value="">— Select Technology —</option>
          <?php foreach($techOpts as $t):?>
          <option value="<?=htmlspecialchars($t)?>" <?=$sel('technology',$t)?>><?=htmlspecialchars($t)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="field cond-field" id="tech-other" style="display:<?=($p['technology']??'')==='Other'?'flex':'none'?>">
        <label>Specify Technology</label>
        <input type="text" name="technology_other" placeholder="Enter technology name" value="<?=$v('technology_other')?>">
        <span class="hint">This will be saved and available in dropdown next time</span>
      </div>
      <div class="field">
        <label>Website / Application</label>
        <input type="text" name="website_app" placeholder="e.g. Website, Mobile App, Portal" value="<?=$v('website_app')?>">
      </div>
    </div>

    <div class="grid2" style="margin-bottom:14px">
      <div class="field full" style="grid-column:1/-1">
        <label>Project Name <span class="req">*</span></label>
        <input type="text" name="project_name" placeholder="e.g. Employee Portal" required value="<?=$v('project_name')?>">
      </div>
      <div class="field full" style="grid-column:1/-1">
        <label>Description</label>
        <textarea name="description" placeholder="Short description of the project..."><?=$v('description')?></textarea>
      </div>
    </div>

    <div class="grid4">
      <div class="field">
        <label>Current Status</label>
        <select name="current_status" id="status-select" onchange="handleStatus(this.value)">
          <option value="live" <?=$sel('current_status','live')?>>🟢 Live</option>
          <option value="under_development" <?=$sel('current_status','under_development')?>>🟡 Under Development</option>
          <option value="redevelopment" <?=$sel('current_status','redevelopment')?>>🔵 Redevelopment</option>
          <option value="closed" <?=$sel('current_status','closed')?>>🔴 Closed</option>
        </select>
      </div>
      <div class="field">
        <label>Last Audit Date</label>
        <input type="date" name="last_audit_date" value="<?=$v('last_audit_date')?>">
      </div>
      <div class="field" id="live-date-field" style="display:<?=in_array($p['current_status']??'',['live'])?'flex':'none'?>">
        <label>Live Date</label>
        <input type="date" name="live_date" value="<?=$v('live_date')?>">
        <span class="hint">Only if status is Live</span>
      </div>
      <div class="field" id="visitor-field" style="display:<?=($p['current_status']??'')==='live'?'flex':'none'?>">
        <label>Total Visitor Counter</label>
        <input type="text" name="total_visitor_counter" placeholder="e.g. 1,50,000" value="<?=$v('total_visitor_counter')?>">
      </div>
      <div class="field" id="lastupdate-field" style="display:<?=($p['current_status']??'')==='live'?'flex':'none'?>">
        <label>Last Update Date</label>
        <input type="date" name="last_update_date" value="<?=$v('last_update_date')?>">
      </div>
    </div>
  </div>
</div>

<!-- ── SECTION 3: Environment URLs ── -->
<div class="section">
  <div class="section-head" onclick="toggleSection(this)">
    <h2>🌐 Environment Details</h2>
    <span class="toggle">▾</span>
  </div>
  <div class="section-body" style="overflow-x:auto">
    <table class="env-table">
      <thead>
        <tr>
          <th>Environment</th>
          <th>URL</th>
          <th>Admin URL</th>
          <th>Login ID</th>
          <th>Password</th>
          <th>Remark</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $envList = [
          'local'      => ['🔵','#40c4ff'],
          'staging'    => ['🟡','#ffd740'],
          'production' => ['🟢','#00e676'],
          'audit'      => ['🟣','#ea80fc'],
          'other'      => ['⚪','#8c9eff'],
        ];
        foreach ($envList as $env => [$icon, $clr]):
          $ep = fn($f) => htmlspecialchars($p["env_{$env}_{$f}"] ?? '');
        ?>
        <tr>
          <td class="env-label" style="color:<?=$clr?>"><?=$icon?> <?=ucfirst($env)?></td>
          <td><input type="url" name="env_<?=$env?>_url" placeholder="https://..." value="<?=$ep('url')?>"></td>
          <td><input type="url" name="env_<?=$env?>_admin_url" placeholder="https://.../admin" value="<?=$ep('admin_url')?>"></td>
          <td><input type="text" name="env_<?=$env?>_id" placeholder="username/email" autocomplete="off" value="<?=$ep('id')?>"></td>
          <td>
            <div class="pw-wrap">
              <input type="password" name="env_<?=$env?>_password"
                placeholder="<?=($p && $p["env_{$env}_password"]) ? '(keep existing)' : 'password'?>"
                autocomplete="new-password" id="pw-<?=$env?>">
              <button type="button" class="pw-toggle" onclick="togglePwField('pw-<?=$env?>')">👁</button>
            </div>
          </td>
          <td><input type="text" name="env_<?=$env?>_remark" placeholder="remark..." value="<?=$ep('remark')?>"></td>
        </tr>
        <?php endforeach;?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── SECTION 4: App Infra ── -->
<div class="section">
  <div class="section-head" onclick="toggleSection(this)">
    <h2>🖥 Application Infrastructure</h2>
    <span class="toggle">▾</span>
  </div>
  <div class="section-body">
    <div class="grid4" style="margin-bottom:14px">
      <div class="field">
        <label>Application IP Address</label>
        <input type="text" name="app_ip" placeholder="192.168.x.x" value="<?=$v('app_ip')?>">
      </div>
      <div class="field">
        <label>LB IP Address</label>
        <input type="text" name="app_lb_ip" placeholder="Load Balancer IP" value="<?=$v('app_lb_ip')?>">
      </div>
      <div class="field">
        <label>OS Version</label>
        <select name="app_os" onchange="handleOther(this,'app-os-other')">
          <option value="">— Select OS —</option>
          <?php foreach($appOsOpts as $o):?>
          <option value="<?=htmlspecialchars($o)?>" <?=$sel('app_os',$o)?>><?=htmlspecialchars($o)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="field cond-field" id="app-os-other" style="display:<?=($p['app_os']??'')==='Other'?'flex':'none'?>">
        <label>Specify OS</label>
        <input type="text" name="app_os_other" placeholder="e.g. Win 2022" value="<?=$v('app_os_other')?>">
        <span class="hint">Saved for future use</span>
      </div>
    </div>
    <div class="grid4" style="margin-bottom:14px">
      <div class="field">
        <label>Core</label>
        <input type="text" name="app_core" placeholder="e.g. 4 vCPU" value="<?=$v('app_core')?>">
      </div>
      <div class="field">
        <label>RAM</label>
        <input type="text" name="app_ram" placeholder="e.g. 8 GB" value="<?=$v('app_ram')?>">
      </div>
      <div class="field">
        <label>Primary Storage</label>
        <input type="text" name="app_primary_storage" placeholder="e.g. 100 GB SSD" value="<?=$v('app_primary_storage')?>">
      </div>
      <div class="field">
        <label>Secondary Storage</label>
        <input type="text" name="app_secondary_storage" placeholder="e.g. 500 GB HDD" value="<?=$v('app_secondary_storage')?>">
      </div>
      <div class="field">
        <label>Individual / Shared</label>
        <select name="app_hosting_type">
          <option value="individual" <?=$sel('app_hosting_type','individual')?>>Individual</option>
          <option value="shared" <?=$sel('app_hosting_type','shared')?>>Shared</option>
        </select>
      </div>
    </div>
    <div class="field">
      <label>App Infra Remark</label>
      <textarea name="app_infra_remark" placeholder="Any notes about application infrastructure..."><?=$v('app_infra_remark')?></textarea>
    </div>
  </div>
</div>

<!-- ── SECTION 5: DB Infra ── -->
<div class="section">
  <div class="section-head" onclick="toggleSection(this)">
    <h2>🗄 Database Infrastructure</h2>
    <span class="toggle">▾</span>
  </div>
  <div class="section-body">
    <div class="grid4" style="margin-bottom:14px">
      <div class="field">
        <label>DB IP Address</label>
        <input type="text" name="db_ip" placeholder="192.168.x.x" value="<?=$v('db_ip')?>">
      </div>
      <div class="field">
        <label>DB Name</label>
        <input type="text" name="db_name" placeholder="e.g. myapp_db" value="<?=$v('db_name')?>">
      </div>
      <div class="field">
        <label>DB Version</label>
        <select name="db_version" onchange="handleOther(this,'db-ver-other')">
          <option value="">— Select DB —</option>
          <?php foreach($dbVerOpts as $o):?>
          <option value="<?=htmlspecialchars($o)?>" <?=$sel('db_version',$o)?>><?=htmlspecialchars($o)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="field cond-field" id="db-ver-other" style="display:<?=($p['db_version']??'')==='Other'?'flex':'none'?>">
        <label>Specify DB Version</label>
        <input type="text" name="db_version_other" placeholder="e.g. MongoDB 6.0" value="<?=$v('db_version_other')?>">
        <span class="hint">Saved for future use</span>
      </div>
    </div>
    <div class="grid4" style="margin-bottom:14px">
      <div class="field">
        <label>DB Server OS</label>
        <select name="db_os" onchange="handleOther(this,'db-os-other')">
          <option value="">— Select OS —</option>
          <?php foreach($dbOsOpts as $o):?>
          <option value="<?=htmlspecialchars($o)?>" <?=$sel('db_os',$o)?>><?=htmlspecialchars($o)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="field cond-field" id="db-os-other" style="display:<?=($p['db_os']??'')==='Other'?'flex':'none'?>">
        <label>Specify DB OS</label>
        <input type="text" name="db_os_other" placeholder="e.g. RHEL 9" value="<?=$v('db_os_other')?>">
        <span class="hint">Saved for future use</span>
      </div>
      <div class="field">
        <label>Shared / Individual</label>
        <select name="db_hosting_type">
          <option value="individual" <?=$sel('db_hosting_type','individual')?>>Individual</option>
          <option value="shared" <?=$sel('db_hosting_type','shared')?>>Shared</option>
        </select>
      </div>
    </div>
    <div class="field">
      <label>DB Remark</label>
      <textarea name="db_remark" placeholder="Any notes about database..."><?=$v('db_remark')?></textarea>
    </div>
  </div>
</div>

<!-- ── SECTION 6: General Remark ── -->
<div class="section">
  <div class="section-head" onclick="toggleSection(this)">
    <h2>📝 General Remarks</h2>
    <span class="toggle">▾</span>
  </div>
  <div class="section-body">
    <div class="field">
      <label>Remark / Notes</label>
      <textarea name="general_remark" rows="5"
        placeholder="Deployment steps, SSH commands, special configurations, API keys location, important notes..."><?=$v('general_remark')?></textarea>
    </div>
  </div>
</div>

<div class="form-actions">
  <a href="index.php" class="btn btn-ghost">✕ Cancel</a>
  <button type="submit" class="btn btn-accent">💾 Save Project</button>
</div>
</form>
</div><!-- /wrap -->

<script>
function toggleSection(head) {
  head.classList.toggle('collapsed');
  head.nextElementSibling.classList.toggle('hidden');
}

function handleOther(sel, otherId) {
  const el = document.getElementById(otherId);
  if (el) el.style.display = sel.value === 'Other' ? 'flex' : 'none';
}

function handleStatus(val) {
  const isLive = val === 'live';
  document.getElementById('live-date-field').style.display    = isLive ? 'flex' : 'none';
  document.getElementById('visitor-field').style.display      = isLive ? 'flex' : 'none';
  document.getElementById('lastupdate-field').style.display   = isLive ? 'flex' : 'none';
}

function togglePwField(id) {
  const f = document.getElementById(id);
  if (f) f.type = f.type === 'password' ? 'text' : 'password';
}

// Init conditional fields on load
document.addEventListener('DOMContentLoaded', () => {
  handleStatus(document.getElementById('status-select').value);
  ['tech-select'].forEach(sid => {
    const sel = document.getElementById(sid);
    if (sel && sel.value === 'Other') handleOther(sel, 'tech-other');
  });
});
</script>
</body>
</html>
