<?php
require_once __DIR__ . '/auth.php';
require_login(); require_admin();
$db = get_db();

if ($_SERVER['REQUEST_METHOD']==='POST' && verify_csrf()) {
    $action = $_POST['action'] ?? '';
    if ($action==='add_user') {
        $u=$_POST['username']??''; $pw=$_POST['password']??''; $role=in_array($_POST['role']??'',['admin','member'])?$_POST['role']:'member';
        if ($u&&$pw) try{$db->prepare("INSERT INTO users(username,password_hash,role)VALUES(?,?,?)")->execute([$u,password_hash($pw,PASSWORD_DEFAULT),$role]);$_SESSION['flash']=['type'=>'success','msg'=>"✅ User \"$u\" added."];}
        catch(Exception $e){$_SESSION['flash']=['type'=>'error','msg'=>'⚠ Username already exists.'];}
    }
    if ($action==='delete_user'){$uid=intval($_POST['uid']??0);if($uid!==$_SESSION['user_id']){$db->prepare("DELETE FROM users WHERE id=?")->execute([$uid]);$_SESSION['flash']=['type'=>'success','msg'=>'🗑 User deleted.'];}}
    if ($action==='change_role'){$uid=intval($_POST['uid']??0);$role=in_array($_POST['role']??'',['admin','member'])?$_POST['role']:'member';if($uid!==$_SESSION['user_id'])$db->prepare("UPDATE users SET role=? WHERE id=?")->execute([$role,$uid]);}
    if ($action==='reset_pw'){$uid=intval($_POST['uid']??0);$np=$_POST['new_pw']??'';if($np&&strlen($np)>=4){$db->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([password_hash($np,PASSWORD_DEFAULT),$uid]);$_SESSION['flash']=['type'=>'success','msg'=>'🔑 Password reset.'];}}
    if ($action==='delete_option'){$oid=intval($_POST['oid']??0);$db->prepare("DELETE FROM dynamic_options WHERE id=?")->execute([$oid]);}
    header('Location: admin.php'); exit;
}

$users   = $db->query("SELECT *,(SELECT COUNT(*) FROM projects WHERE created_by=users.id) as pc FROM users ORDER BY role DESC,username")->fetchAll();
$logs    = $db->query("SELECT l.*,u.username FROM activity_log l LEFT JOIN users u ON l.user_id=u.id ORDER BY l.created_at DESC LIMIT 150")->fetchAll();
$dynOpts = $db->query("SELECT * FROM dynamic_options ORDER BY option_group,sort_order")->fetchAll();
$flash   = $_SESSION['flash']??null; unset($_SESSION['flash']);

$groupLabels=['technology'=>'Technology','app_os'=>'App OS','db_version'=>'DB Version','db_os'=>'DB OS'];
$optsByGroup=[];
foreach($dynOpts as $o) $optsByGroup[$o['option_group']][]=$o;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DevVault Pro — Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700&family=Orbitron:wght@700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#070b14;--surface:#0d1422;--surface2:#111a2e;--surface3:#16213e;
  --border:#1e2d4a;--text:#e8edf5;--muted:#5a7a9a;--accent:#00d4ff;
  --success:#00e676;--danger:#ff3d5a;--amber:#ffd740;--purple:#ea80fc}
body{font-family:'Rajdhani',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;padding:24px}
body::before{content:'';position:fixed;inset:0;
  background-image:linear-gradient(rgba(0,212,255,.02) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,.02) 1px,transparent 1px);
  background-size:40px 40px;pointer-events:none;z-index:0}
.wrap{max-width:960px;margin:0 auto;position:relative;z-index:1}
.page-header{display:flex;align-items:center;gap:12px;margin-bottom:20px}
.btn{display:inline-flex;align-items:center;gap:5px;padding:7px 13px;border-radius:7px;font-size:13px;font-weight:600;font-family:'Rajdhani',sans-serif;cursor:pointer;border:none;text-decoration:none;transition:all .15s}
.btn-ghost{background:var(--surface2);color:var(--muted);border:1px solid var(--border)}
.btn-ghost:hover{color:var(--text)}
.btn-accent{background:var(--accent);color:#000}
.btn-accent:hover{opacity:.85}
.btn-danger{background:rgba(255,61,90,.12);color:var(--danger);border:1px solid rgba(255,61,90,.25)}
.btn-danger:hover{background:rgba(255,61,90,.22)}
.btn-sm{padding:4px 9px;font-size:12px}
.btn:active{transform:scale(.97)}
h1{font-family:'Orbitron',monospace;font-size:18px;color:var(--accent)}
.flash{padding:10px 16px;border-radius:8px;font-size:13px;font-family:'Share Tech Mono',monospace;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.flash-success{background:rgba(0,230,118,.08);border:1px solid rgba(0,230,118,.25);color:var(--success)}
.flash-error{background:rgba(255,61,90,.08);border:1px solid rgba(255,61,90,.25);color:var(--danger)}
.tabs{display:flex;gap:4px;background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:4px;margin-bottom:18px}
.tab{flex:1;text-align:center;padding:9px;border-radius:7px;cursor:pointer;font-size:13px;font-weight:700;font-family:'Rajdhani',sans-serif;border:none;background:none;color:var(--muted);transition:all .15s}
.tab.active{background:var(--accent);color:#000}
.tab:hover:not(.active){background:var(--surface2);color:var(--text)}
.tab-content{display:none}
.tab-content.active{display:block}
.card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:20px;margin-bottom:14px}
.card h2{font-family:'Share Tech Mono',monospace;font-size:11px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid var(--border)}
table.t{width:100%;border-collapse:collapse;font-size:13px}
table.t th{text-align:left;padding:8px 10px;font-family:'Share Tech Mono',monospace;font-size:10px;text-transform:uppercase;letter-spacing:1px;color:var(--muted);border-bottom:1px solid var(--border)}
table.t td{padding:9px 10px;border-bottom:1px solid rgba(30,45,74,.5);font-family:'Share Tech Mono',monospace;font-size:12px;vertical-align:middle}
table.t tr:last-child td{border-bottom:none}
table.t tr:hover td{background:rgba(0,212,255,.02)}
.role-badge{padding:2px 9px;border-radius:20px;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.5px}
.role-admin{background:rgba(234,128,252,.12);color:var(--purple);border:1px solid rgba(234,128,252,.25)}
.role-member{background:rgba(90,122,154,.12);color:var(--muted);border:1px solid var(--border)}
.field{margin-bottom:12px}
.field label{display:block;font-family:'Share Tech Mono',monospace;font-size:10px;text-transform:uppercase;letter-spacing:1px;color:var(--muted);margin-bottom:5px}
input,select{background:var(--surface2);border:1px solid var(--border);border-radius:7px;padding:9px 12px;color:var(--text);font-size:13px;font-family:'Share Tech Mono',monospace;outline:none;transition:border-color .2s;width:100%}
input:focus,select:focus{border-color:var(--accent)}
select option{background:var(--surface2)}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.log-row{display:flex;gap:8px;padding:6px 0;border-bottom:1px solid rgba(30,45,74,.4);font-size:11px;font-family:'Share Tech Mono',monospace;align-items:center}
.log-row:last-child{border-bottom:none}
.log-time{color:var(--muted);min-width:120px;flex-shrink:0}
.log-user{color:var(--accent);min-width:80px;flex-shrink:0}
.log-action{flex:1;color:var(--text)}
.opts-group{margin-bottom:16px}
.opts-group h3{font-family:'Share Tech Mono',monospace;font-size:11px;text-transform:uppercase;letter-spacing:1px;color:var(--accent);margin-bottom:8px}
.opt-pill{display:inline-flex;align-items:center;gap:6px;background:var(--surface2);border:1px solid var(--border);border-radius:20px;padding:4px 10px;margin:3px;font-size:12px;font-family:'Share Tech Mono',monospace}
@media(max-width:600px){.grid2{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="wrap">
  <div class="page-header">
    <a href="index.php" class="btn btn-ghost">← Back</a>
    <h1>⚙ ADMIN PANEL</h1>
  </div>

  <?php if($flash):?><div class="flash flash-<?=$flash['type']?>"><?=htmlspecialchars($flash['msg'])?></div><?php endif;?>

  <div class="tabs">
    <button class="tab active" onclick="showTab('users',this)">👥 Users</button>
    <button class="tab" onclick="showTab('add',this)">➕ Add User</button>
    <button class="tab" onclick="showTab('options',this)">🔧 Dropdown Options</button>
    <button class="tab" onclick="showTab('logs',this)">📋 Activity Log</button>
  </div>

  <!-- USERS -->
  <div class="tab-content active" id="tab-users">
    <div class="card">
      <h2>Team Members (<?=count($users)?>)</h2>
      <table class="t">
        <tr><th>#</th><th>Username</th><th>Role</th><th>Projects</th><th>Joined</th><th>Actions</th></tr>
        <?php foreach($users as $u):?>
        <tr>
          <td><?=$u['id']?></td>
          <td style="font-weight:700;color:var(--text)"><?=htmlspecialchars($u['username'])?></td>
          <td><span class="role-badge role-<?=$u['role']?>"><?=$u['role']?></span></td>
          <td><?=$u['pc']?></td>
          <td style="color:var(--muted)"><?=date('d M Y',strtotime($u['created_at']))?></td>
          <td style="display:flex;gap:5px">
            <?php if($u['id']!==$_SESSION['user_id']):?>
            <form method="POST" style="display:inline">
              <input type="hidden" name="csrf" value="<?=csrf_token()?>">
              <input type="hidden" name="action" value="change_role">
              <input type="hidden" name="uid" value="<?=$u['id']?>">
              <input type="hidden" name="role" value="<?=$u['role']==='admin'?'member':'admin'?>">
              <button type="submit" class="btn btn-ghost btn-sm" onclick="return confirm('Change role?')"><?=$u['role']==='admin'?'↓ Member':'↑ Admin'?></button>
            </form>
            <button class="btn btn-ghost btn-sm" onclick="resetPw(<?=$u['id']?>,'<?=htmlspecialchars($u['username'])?>')">🔑</button>
            <form method="POST" style="display:inline">
              <input type="hidden" name="csrf" value="<?=csrf_token()?>">
              <input type="hidden" name="action" value="delete_user">
              <input type="hidden" name="uid" value="<?=$u['id']?>">
              <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Delete user?')">🗑</button>
            </form>
            <?php else:?><span style="color:var(--muted);font-size:11px">(you)</span><?php endif;?>
          </td>
        </tr>
        <?php endforeach;?>
      </table>
    </div>
  </div>

  <!-- ADD USER -->
  <div class="tab-content" id="tab-add">
    <div class="card">
      <h2>Add New User</h2>
      <form method="POST">
        <input type="hidden" name="csrf" value="<?=csrf_token()?>">
        <input type="hidden" name="action" value="add_user">
        <div class="grid2">
          <div class="field"><label>Username</label><input type="text" name="username" placeholder="john_dev" required></div>
          <div class="field"><label>Password</label><input type="password" name="password" placeholder="Strong password" required></div>
          <div class="field"><label>Role</label>
            <select name="role">
              <option value="member">Member — view + edit</option>
              <option value="admin">Admin — full access + delete</option>
            </select>
          </div>
        </div>
        <button type="submit" class="btn btn-accent">➕ Add User</button>
      </form>
    </div>
  </div>

  <!-- DYNAMIC OPTIONS -->
  <div class="tab-content" id="tab-options">
    <div class="card">
      <h2>Dropdown Options Manager</h2>
      <p style="font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--muted);margin-bottom:16px">
        Yahan se "Other" options manage karo jo project form mein add hote hain.
      </p>
      <?php foreach($groupLabels as $grp=>$lbl):?>
      <div class="opts-group">
        <h3><?=$lbl?></h3>
        <?php foreach($optsByGroup[$grp]??[] as $o):?>
        <span class="opt-pill">
          <?=htmlspecialchars($o['option_value'])?>
          <form method="POST" style="display:inline">
            <input type="hidden" name="csrf" value="<?=csrf_token()?>">
            <input type="hidden" name="action" value="delete_option">
            <input type="hidden" name="oid" value="<?=$o['id']?>">
            <button type="submit" style="background:none;border:none;cursor:pointer;color:var(--danger);font-size:12px;padding:0" onclick="return confirm('Remove this option?')">✕</button>
          </form>
        </span>
        <?php endforeach;?>
        <?php if(empty($optsByGroup[$grp])):?>
        <span style="font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--muted)">No custom options yet</span>
        <?php endif;?>
      </div>
      <?php endforeach;?>
      <p style="font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--muted);margin-top:12px">
        💡 Naye options automatically add hote hain jab project form mein "Other" select karke value enter karo.
      </p>
    </div>
  </div>

  <!-- ACTIVITY LOG -->
  <div class="tab-content" id="tab-logs">
    <div class="card">
      <h2>Activity Log (Last 150)</h2>
      <?php
      $icons=['login'=>'🟢','logout'=>'🔴','add_project'=>'➕','edit_project'=>'✏','delete_project'=>'🗑',
              'view_password'=>'👁','export_csv'=>'📊','export_json'=>'📄','export_report'=>'🖨','change_password'=>'🔑'];
      foreach($logs as $l):
        $icon=$icons[$l['action']]??'•';?>
      <div class="log-row">
        <span class="log-time"><?=date('d M H:i',strtotime($l['created_at']))?></span>
        <span class="log-user"><?=htmlspecialchars($l['username']??'system')?></span>
        <span class="log-action"><?=$icon?> <?=htmlspecialchars($l['action'])?>
          <?php if($l['detail']):?><span style="color:var(--muted)"> — <?=htmlspecialchars($l['detail'])?></span><?php endif;?>
          <?php if($l['ip_address']):?><span style="color:var(--border);margin-left:6px">[<?=htmlspecialchars($l['ip_address'])?>]</span><?php endif;?>
        </span>
      </div>
      <?php endforeach;?>
      <?php if(!$logs):?><p style="color:var(--muted);font-size:12px;font-family:'Share Tech Mono',monospace">No activity yet.</p><?php endif;?>
    </div>
  </div>
</div>

<form method="POST" id="reset-form" style="display:none">
  <input type="hidden" name="csrf" value="<?=csrf_token()?>">
  <input type="hidden" name="action" value="reset_pw">
  <input type="hidden" name="uid" id="r-uid">
  <input type="hidden" name="new_pw" id="r-pw">
</form>

<script>
function showTab(name,btn){
  document.querySelectorAll('.tab-content').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.getElementById('tab-'+name).classList.add('active');
  btn.classList.add('active')}

function resetPw(uid,name){
  const pw=prompt(`New password for "${name}" (min 4 chars):`);
  if(!pw||pw.length<4){if(pw!==null)alert('Too short!');return}
  document.getElementById('r-uid').value=uid;
  document.getElementById('r-pw').value=pw;
  document.getElementById('reset-form').submit()}
</script>
</body>
</html>
