<?php
require_once __DIR__ . '/auth.php';
require_login();
header('Content-Type: application/json');

$action = $_REQUEST['action'] ?? '';

// ── GET: reveal password ──────────────────────────────────────────────────
if ($action === 'get_pw' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $id   = intval($_GET['id'] ?? 0);
    $env  = preg_replace('/[^a-z]/', '', $_GET['env'] ?? '');
    $csrf = $_GET['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $csrf)) {
        echo json_encode(['error' => 'CSRF']); exit;
    }
    $db  = get_db();
    $col = "env_{$env}_password";
    $st  = $db->prepare("SELECT `$col` FROM projects WHERE id=?");
    $st->execute([$id]);
    $row = $st->fetch();
    if (!$row) { echo json_encode(['error' => 'Not found']); exit; }
    log_activity('view_password', $id, $env);
    echo json_encode(['pw' => decrypt_val($row[$col] ?? '')]);
    exit;
}

// ── POST: delete project ──────────────────────────────────────────────────
if ($action === 'delete_project' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!is_admin()) { echo json_encode(['error' => 'Forbidden']); exit; }
    if (!verify_csrf()) { echo json_encode(['error' => 'CSRF']); exit; }
    $id  = intval($_POST['id'] ?? 0);
    $db  = get_db();
    $st  = $db->prepare("SELECT project_name FROM projects WHERE id=?");
    $st->execute([$id]);
    $row = $st->fetch();
    if ($row) {
        $db->prepare("DELETE FROM projects WHERE id=?")->execute([$id]);
        log_activity('delete_project', $id, $row['project_name']);
        backup_json();
        $_SESSION['flash'] = ['type'=>'success','msg'=>"🗑 Project \"{$row['project_name']}\" deleted."];
    }
    header('Location: index.php'); exit;
}

// ── POST: save user preferences ───────────────────────────────────────────
if ($action === 'save_prefs' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { echo json_encode(['error' => 'CSRF']); exit; }
    $accent = substr(preg_replace('/[^#a-fA-F0-9]/', '', $_POST['accent'] ?? '#00d4ff'), 0, 7);
    $theme  = in_array($_POST['theme'] ?? '', ['dark','light']) ? $_POST['theme'] : 'dark';
    $font   = in_array($_POST['font'] ?? '', ['Rajdhani','Share Tech Mono','Orbitron']) ? $_POST['font'] : 'Rajdhani';
    $fs     = max(11, min(18, intval($_POST['fs'] ?? 14)));
    $db = get_db();
    $db->prepare("UPDATE users SET accent_color=?,theme=?,font_family=?,font_size=? WHERE id=?")
       ->execute([$accent, $theme, $font, $fs, $_SESSION['user_id']]);
    $_SESSION['prefs'] = ['accent'=>$accent,'theme'=>$theme,'font_family'=>$font,'font_size'=>$fs];
    echo json_encode(['ok' => true]);
    exit;
}

echo json_encode(['error' => 'Unknown action']);
