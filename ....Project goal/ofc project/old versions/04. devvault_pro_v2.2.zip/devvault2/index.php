<?php
require_once __DIR__ . '/auth.php';
require_login();
$db = get_db();

// Stats
$total  = (int)$db->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$envStats = [];
foreach(['local','staging','production','audit','other'] as $e){
    $st=$db->query("SELECT COUNT(*) FROM projects WHERE env_{$e}_url!='' AND env_{$e}_url IS NOT NULL");
    $envStats[$e]=$st?(int)$st->fetchColumn():0;
}
$statusCounts=[];
foreach(['live','under_development','redevelopment','closed'] as $s){
    $st=$db->prepare("SELECT COUNT(*) FROM projects WHERE current_status=?");$st->execute([$s]);
    $statusCounts[$s]=(int)$st->fetchColumn();
}

// Tech breakdown
$techRows=$db->query("SELECT COALESCE(NULLIF(technology_other,''),technology) as tech,current_status,COUNT(*) as cnt FROM projects GROUP BY tech,current_status ORDER BY tech")->fetchAll();
$techTable=[];
foreach($techRows as $r) $techTable[$r['tech']][$r['current_status']]=(int)$r['cnt'];

// Filters
$q=trim($_GET['q']??''); $status=$_GET['status']??''; $tech=$_GET['tech']??'';
$where=['1=1'];$params=[];
if($q){$where[]='(project_name LIKE ? OR department_name LIKE ? OR description LIKE ? OR app_ip LIKE ? OR nodal_officer_name LIKE ? OR db_ip LIKE ?)';$l="%$q%";$params=array_merge($params,[$l,$l,$l,$l,$l,$l]);}
if($status){$where[]='current_status=?';$params[]=$status;}
if($tech){$where[]='(technology=? OR technology_other=?)';$params=array_merge($params,[$tech,$tech]);}
$st=$db->prepare("SELECT p.*,u.username as creator FROM projects p LEFT JOIN users u ON p.created_by=u.id WHERE ".implode(' AND ',$where)." ORDER BY p.updated_at DESC");
$st->execute($params);$projects=$st->fetchAll();

$flash=$_SESSION['flash']??null;unset($_SESSION['flash']);

$accent  = user_pref('accent','#00d4ff');
$theme   = user_pref('theme','dark');
$fsize   = user_pref('font_size','14');
$ffamily = user_pref('font_family','Rajdhani');

$SL=['live'=>'Live','under_development'=>'Under Dev','redevelopment'=>'Redevelopment','closed'=>'Closed'];
$SC=['live'=>'#00e676','under_development'=>'#ffd740','redevelopment'=>'#40c4ff','closed'=>'#ff3d5a'];
$EC=['local'=>'#40c4ff','staging'=>'#ffd740','production'=>'#00e676','audit'=>'#ea80fc','other'=>'#8c9eff'];
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DevVault Pro</title>
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Orbitron:wght@700;900&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --acc:<?=$accent?>;
  --bg:#070b14;--sur:#0d1422;--sur2:#111a2e;--sur3:#16213e;
  --bdr:#1e2d4a;--tx:#e8edf5;--mt:#5a7a9a;
  --ok:#00e676;--err:#ff3d5a;--amb:#ffd740;--pur:#ea80fc;--blu:#40c4ff;
}
[data-theme="light"]{
  --bg:#f0f4f8;--sur:#ffffff;--sur2:#e8edf5;--sur3:#dde3ed;
  --bdr:#c8d4e0;--tx:#0d1422;--mt:#6b7f96;
}
html{font-size:<?=$fsize?>px}
body{font-family:'<?=$ffamily?>',sans-serif;background:var(--bg);color:var(--tx);min-height:100vh}
body::before{content:'';position:fixed;inset:0;pointer-events:none;z-index:0;
  background-image:linear-gradient(var(--bdr) 1px,transparent 1px),
    linear-gradient(90deg,var(--bdr) 1px,transparent 1px);
  background-size:44px 44px;opacity:.15}

/* ── TOPBAR ── */
.bar{position:sticky;top:0;z-index:200;height:52px;
  background:color-mix(in srgb,var(--bg) 92%,transparent);
  border-bottom:1px solid var(--bdr);backdrop-filter:blur(14px);
  display:flex;align-items:center;padding:0 20px;gap:12px}
.logo{font-family:'Orbitron',monospace;font-size:15px;font-weight:900;
  color:var(--acc);letter-spacing:2px;text-shadow:0 0 16px var(--acc)}
.bar-search{flex:1;max-width:400px;position:relative}
.bar-search input{width:100%;background:var(--sur2);border:1px solid var(--bdr);
  border-radius:8px;padding:7px 12px 7px 34px;color:var(--tx);font-size:13px;
  font-family:'Share Tech Mono',monospace;outline:none;transition:border-color .18s,box-shadow .18s}
.bar-search input:focus{border-color:var(--acc);box-shadow:0 0 0 2px color-mix(in srgb,var(--acc) 10%,transparent)}
.si{position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--mt);font-size:13px;pointer-events:none}
.bar-r{margin-left:auto;display:flex;gap:7px;align-items:center}

.btn{display:inline-flex;align-items:center;gap:5px;padding:6px 13px;border-radius:7px;
  font-size:13px;font-weight:700;font-family:inherit;cursor:pointer;border:none;
  text-decoration:none;transition:all .15s;letter-spacing:.3px;white-space:nowrap}
.btn:active{transform:scale(.97)}
.btn-acc{background:var(--acc);color:#000}
.btn-acc:hover{opacity:.85}
.btn-ghost{background:var(--sur2);color:var(--mt);border:1px solid var(--bdr)}
.btn-ghost:hover{color:var(--tx);border-color:var(--mt)}
.btn-danger{background:color-mix(in srgb,var(--err) 12%,transparent);color:var(--err);border:1px solid color-mix(in srgb,var(--err) 25%,transparent)}
.btn-danger:hover{background:color-mix(in srgb,var(--err) 22%,transparent)}
.btn-sm{padding:4px 9px;font-size:11px}
.btn-icon{width:32px;height:32px;padding:0;justify-content:center;border-radius:8px;font-size:15px}

/* ── CONTENT ── */
.content{padding:16px 20px;position:relative;z-index:1}

/* ── STAT CHIPS ── */
.chips{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}
.chip{display:flex;align-items:center;gap:7px;padding:7px 13px;
  background:var(--sur);border:1px solid var(--bdr);border-radius:8px;
  font-family:'Share Tech Mono',monospace;font-size:12px;cursor:pointer;
  transition:border-color .15s,transform .15s;text-decoration:none;color:var(--tx)}
.chip:hover{border-color:var(--acc);transform:translateY(-1px)}
.chip.active{border-color:var(--acc);background:color-mix(in srgb,var(--acc) 8%,var(--sur))}
.chip-num{font-family:'Orbitron',monospace;font-weight:900;font-size:16px;line-height:1}
.chip-lbl{font-size:10px;color:var(--mt);text-transform:uppercase;letter-spacing:.8px}
.chip-dot{width:8px;height:8px;border-radius:50%}

/* ── PANEL ── */
.panel{background:var(--sur);border:1px solid var(--bdr);border-radius:12px;margin-bottom:14px;overflow:hidden}
.panel-hd{display:flex;align-items:center;gap:10px;padding:11px 16px;border-bottom:1px solid var(--bdr)}
.panel-hd h2{font-family:'Share Tech Mono',monospace;font-size:10px;text-transform:uppercase;
  letter-spacing:1.8px;color:var(--mt);flex:1}
.panel-body{padding:0}

/* ── SUMMARY ROW (stats tables) ── */
.summary-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px}
.sum-tbl{width:100%;border-collapse:collapse;font-size:12px}
.sum-tbl th{font-family:'Share Tech Mono',monospace;font-size:9px;text-transform:uppercase;
  letter-spacing:1px;color:var(--mt);padding:7px 12px;text-align:left;border-bottom:1px solid var(--bdr)}
.sum-tbl td{padding:8px 12px;border-bottom:1px solid color-mix(in srgb,var(--bdr) 50%,transparent);
  font-family:'Share Tech Mono',monospace;font-size:11px}
.sum-tbl tr:last-child td{border-bottom:none}
.sum-tbl tr:hover td{background:color-mix(in srgb,var(--acc) 3%,transparent)}
.num-c{font-family:'Orbitron',monospace;font-weight:700;text-align:center}
.badge{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:20px;
  font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;border:1px solid currentColor}

/* ── TOOLBAR ── */
.toolbar{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap}
.fsel{background:var(--sur2);border:1px solid var(--bdr);border-radius:7px;
  padding:6px 10px;color:var(--tx);font-size:12px;font-family:'Share Tech Mono',monospace;
  outline:none;cursor:pointer}
.fsel:focus{border-color:var(--acc)}
.result-count{margin-left:auto;font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--mt)}

/* ── PROJECT ROW (Activity Log style) ── */
.proj-list{background:var(--sur);border:1px solid var(--bdr);border-radius:12px;overflow:hidden}
.proj-hdr{display:grid;
  grid-template-columns: 28px 2fr 1.2fr 1fr 1.2fr 1.2fr 130px;
  gap:0;padding:7px 14px;border-bottom:1px solid var(--bdr);
  background:var(--sur2)}
.proj-hdr span{font-family:'Share Tech Mono',monospace;font-size:9px;text-transform:uppercase;
  letter-spacing:1.2px;color:var(--mt)}

.proj-row{display:grid;
  grid-template-columns: 28px 2fr 1.2fr 1fr 1.2fr 1.2fr 130px;
  gap:0;padding:10px 14px;border-bottom:1px solid color-mix(in srgb,var(--bdr) 55%,transparent);
  align-items:center;transition:background .12s;cursor:default}
.proj-row:last-child{border-bottom:none}
.proj-row:hover{background:color-mix(in srgb,var(--acc) 4%,var(--sur))}

/* Status indicator (left bar) */
.status-bar{width:3px;height:36px;border-radius:2px;margin:0 auto}

/* Project name cell */
.pname{font-size:14px;font-weight:700;line-height:1.2;margin-bottom:2px}
.pdept{font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--mt)}

/* Env pills */
.env-pills{display:flex;flex-wrap:wrap;gap:4px}
.epill{display:inline-flex;align-items:center;gap:3px;padding:2px 7px;
  border-radius:12px;font-size:9px;font-family:'Share Tech Mono',monospace;
  font-weight:700;text-transform:uppercase;border:1px solid currentColor;cursor:pointer;
  text-decoration:none;transition:opacity .15s}
.epill:hover{opacity:.75}
.edot{width:5px;height:5px;border-radius:50%;background:currentColor}

/* Infra cell */
.infra-kv{display:flex;flex-direction:column;gap:2px}
.kv{display:flex;gap:5px;align-items:center;font-size:11px;font-family:'Share Tech Mono',monospace}
.kv .k{color:var(--mt);font-size:9px;min-width:30px}
.kv .v{color:var(--tx);font-weight:600}
.copy-btn{background:none;border:none;cursor:pointer;color:var(--mt);font-size:10px;
  padding:1px 3px;transition:color .15s;line-height:1}
.copy-btn:hover{color:var(--acc)}

/* Creds cell */
.creds{display:flex;flex-direction:column;gap:3px}
.cred-env{font-family:'Share Tech Mono',monospace;font-size:9px;font-weight:700;
  text-transform:uppercase;letter-spacing:.8px;margin-bottom:1px}
.pw-row{display:flex;align-items:center;gap:4px;font-family:'Share Tech Mono',monospace;font-size:11px}
.pw-mask{color:var(--mt);letter-spacing:2px}
.pw-btn{background:none;border:none;cursor:pointer;color:var(--mt);font-size:10px;
  padding:1px 3px;transition:color .15s;line-height:1}
.pw-btn:hover{color:var(--acc)}

/* Actions cell */
.acts{display:flex;gap:5px;align-items:center;justify-content:flex-end}

/* Notes drawer */
.notes-drawer{display:none;padding:10px 16px 12px 56px;
  background:var(--sur2);border-top:1px solid var(--bdr);
  font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--mt)}
.notes-drawer.open{display:block}
.notes-sec{margin-bottom:6px}
.notes-sec .nt{color:var(--tx);white-space:pre-wrap;margin-top:3px;line-height:1.6}

/* Nodal drawer */
.nodal-drawer{display:none;padding:8px 16px 10px 56px;
  background:var(--sur3);border-top:1px solid var(--bdr);
  display:none;gap:20px;flex-wrap:wrap;font-family:'Share Tech Mono',monospace;font-size:11px}
.nodal-drawer.open{display:flex}
.nodal-kv .nk{font-size:9px;color:var(--mt);text-transform:uppercase;letter-spacing:.8px}
.nodal-kv .nv{font-size:12px;font-weight:700;color:var(--tx);margin-top:2px}

/* Flash */
.flash{padding:10px 14px;border-radius:8px;font-size:12px;font-family:'Share Tech Mono',monospace;
  margin-bottom:12px;display:flex;align-items:center;gap:8px}
.flash-success{background:color-mix(in srgb,var(--ok) 8%,transparent);border:1px solid color-mix(in srgb,var(--ok) 25%,transparent);color:var(--ok)}
.flash-error{background:color-mix(in srgb,var(--err) 8%,transparent);border:1px solid color-mix(in srgb,var(--err) 25%,transparent);color:var(--err)}

/* Empty */
.empty{text-align:center;padding:52px;color:var(--mt)}
.empty .ei{font-size:44px;margin-bottom:10px}
.empty h3{font-size:17px;font-weight:700;color:var(--tx);margin-bottom:6px}
.empty p{font-size:12px;font-family:'Share Tech Mono',monospace}

/* Toast */
.toast{position:fixed;bottom:20px;right:20px;background:var(--sur);border:1px solid var(--bdr);
  border-radius:10px;padding:10px 16px;font-size:12px;font-family:'Share Tech Mono',monospace;
  box-shadow:0 8px 32px rgba(0,0,0,.45);z-index:999;display:none;align-items:center;gap:8px;
  animation:sup .22s ease}
@keyframes sup{from{transform:translateY(14px);opacity:0}to{transform:translateY(0);opacity:1}}

/* Theme panel */
.tpanel{display:none;position:absolute;right:0;top:46px;background:var(--sur);
  border:1px solid var(--bdr);border-radius:12px;padding:16px;width:255px;
  z-index:300;box-shadow:0 8px 32px rgba(0,0,0,.4)}
.tpanel.open{display:block}
.tp-lbl{font-family:'Share Tech Mono',monospace;font-size:9.5px;text-transform:uppercase;
  letter-spacing:1.2px;color:var(--mt);margin-bottom:6px}
.swatches{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:11px}
.sw{width:22px;height:22px;border-radius:5px;border:2px solid transparent;
  cursor:pointer;transition:transform .12s}
.sw:hover,.sw.on{transform:scale(1.22);border-color:#fff}
.tp-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:9px}
.tp-row select,.tp-row input{background:var(--sur2);border:1px solid var(--bdr);
  border-radius:6px;padding:5px 8px;color:var(--tx);font-size:12px;
  font-family:'Share Tech Mono',monospace;outline:none}
.tp-row input[type=range]{width:100px;cursor:pointer;accent-color:var(--acc)}

@media(max-width:960px){
  .proj-hdr,.proj-row{grid-template-columns:28px 2fr 1fr 1fr 130px}
  .proj-hdr span:nth-child(5),.proj-hdr span:nth-child(6),
  .proj-row>*:nth-child(5),.proj-row>*:nth-child(6){display:none}
}
@media(max-width:640px){
  .proj-hdr,.proj-row{grid-template-columns:28px 1fr 90px}
  .proj-hdr span:nth-child(n+3):not(:last-child),
  .proj-row>*:nth-child(n+3):not(:last-child){display:none}
  .summary-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>

<!-- TOPBAR -->
<div class="bar">
  <span class="logo">DEVVAULT</span>
  <form method="GET" class="bar-search" id="sf">
    <span class="si">🔍</span>
    <input type="text" name="q" id="qi" placeholder="Search project, dept, IP..." value="<?=htmlspecialchars($q)?>">
    <?php if($status):?><input type="hidden" name="status" value="<?=htmlspecialchars($status)?>"> <?php endif;?>
    <?php if($tech):?><input type="hidden" name="tech" value="<?=htmlspecialchars($tech)?>">   <?php endif;?>
  </form>
  <div class="bar-r">
    <?php if(can_edit()):?>
    <a href="project_form.php" class="btn btn-acc">＋ Add Project</a>
    <?php endif;?>
    <a href="export.php" class="btn btn-ghost btn-icon" title="Export">📤</a>
    <?php if(is_admin()):?>
    <a href="admin.php" class="btn btn-ghost btn-icon" title="Admin">⚙</a>
    <?php endif;?>
    <div style="position:relative">
      <button class="btn btn-ghost btn-icon" id="tb" onclick="toggleTheme()" title="Theme">🎨</button>
      <div class="tpanel" id="tp">
        <div class="tp-lbl">Accent Color</div>
        <div class="swatches">
          <?php foreach(['#00d4ff','#00e676','#ffd740','#ff3d5a','#ea80fc','#8c9eff','#ff6e40','#40c4ff','#ffffff'] as $c):?>
          <div class="sw <?=$c===$accent?'on':''?>" style="background:<?=$c?>" onclick="setAcc('<?=$c?>')"></div>
          <?php endforeach;?>
        </div>
        <div class="tp-lbl">Custom</div>
        <div class="tp-row" style="margin-bottom:11px">
          <input type="color" id="cc" value="<?=$accent?>" oninput="setAcc(this.value)">
          <span style="font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--mt)" id="chex"><?=$accent?></span>
        </div>
        <div class="tp-lbl">Theme</div>
        <div class="tp-row"><select onchange="setTheme(this.value)">
          <option value="dark" <?=$theme==='dark'?'selected':''?>>🌙 Dark</option>
          <option value="light" <?=$theme==='light'?'selected':''?>>☀ Light</option>
        </select></div>
        <div class="tp-lbl">Font</div>
        <div class="tp-row"><select onchange="setFont(this.value)" id="fsel">
          <?php foreach(['Rajdhani','Share Tech Mono','Orbitron'] as $f):?>
          <option value="<?=$f?>" <?=$ffamily===$f?'selected':''?>><?=$f?></option>
          <?php endforeach;?>
        </select></div>
        <div class="tp-lbl">Font Size: <span id="fsv"><?=$fsize?></span>px</div>
        <div class="tp-row"><input type="range" min="11" max="18" value="<?=$fsize?>" oninput="setFs(this.value)"></div>
        <button class="btn btn-acc" style="width:100%;justify-content:center;margin-top:4px" onclick="savePrefs()">Save Preferences</button>
      </div>
    </div>
    <a href="logout.php" class="btn btn-ghost btn-icon" title="Logout">⏏</a>
  </div>
</div>

<!-- CONTENT -->
<div class="content">

<?php if($flash):?>
<div class="flash flash-<?=$flash['type']?>"><?=htmlspecialchars($flash['msg'])?></div>
<?php endif;?>

<!-- STAT CHIPS -->
<div class="chips">
  <a class="chip <?=!$status&&!$tech&&!$q?'active':''?>" href="index.php">
    <div><div class="chip-num" style="color:var(--acc)"><?=$total?></div><div class="chip-lbl">Total</div></div>
  </a>
  <?php foreach(['live'=>$SC['live'],'under_development'=>$SC['under_development'],'production'=>$EC['production'],'staging'=>$EC['staging']] as $k=>$clr):
    $lbl=isset($SL[$k])?$SL[$k]:ucfirst($k);
    $cnt=isset($statusCounts[$k])?$statusCounts[$k]:($envStats[$k]??0);
    $href=isset($statusCounts[$k])?"index.php?status=$k":"index.php?env=$k";
  ?>
  <a class="chip" href="<?=$href?>" style="border-left:3px solid <?=$clr?>">
    <span class="chip-dot" style="background:<?=$clr?>"></span>
    <div><div class="chip-num" style="color:<?=$clr?>"><?=$cnt?></div><div class="chip-lbl"><?=$lbl?></div></div>
  </a>
  <?php endforeach;?>
</div>

<!-- SUMMARY TABLES -->
<div class="summary-grid">
  <!-- Status breakdown -->
  <div class="panel">
    <div class="panel-hd"><h2>📊 Status Overview</h2></div>
    <div class="panel-body">
      <table class="sum-tbl">
        <tr><th>Status</th><th style="text-align:center">Count</th></tr>
        <?php foreach($SL as $k=>$l):?>
        <tr>
          <td><span class="badge" style="color:<?=$SC[$k]?>;border-color:<?=$SC[$k]?>40"><?=$l?></span></td>
          <td class="num-c" style="color:<?=$SC[$k]?>"><?=$statusCounts[$k]??0?></td>
        </tr>
        <?php endforeach;?>
      </table>
    </div>
  </div>
  <!-- Tech breakdown -->
  <div class="panel">
    <div class="panel-hd"><h2>🛠 Technology Breakdown</h2></div>
    <div class="panel-body">
      <table class="sum-tbl">
        <tr>
          <th>Technology</th>
          <th style="text-align:center;color:<?=$SC['live']?>">Live</th>
          <th style="text-align:center;color:<?=$SC['under_development']?>">Dev</th>
          <th style="text-align:center;color:<?=$SC['redevelopment']?>">Redev</th>
          <th style="text-align:center;color:<?=$SC['closed']?>">Closed</th>
        </tr>
        <?php if(empty($techTable)):?>
        <tr><td colspan="5" style="color:var(--mt);text-align:center;padding:14px">No data</td></tr>
        <?php else: foreach($techTable as $t=>$c):?>
        <tr>
          <td style="font-weight:700"><?=htmlspecialchars($t)?></td>
          <?php foreach(['live','under_development','redevelopment','closed'] as $s):?>
          <td class="num-c" style="color:<?=$SC[$s]?>"><?=$c[$s]??'–'?></td>
          <?php endforeach;?>
        </tr>
        <?php endforeach;endif;?>
      </table>
    </div>
  </div>
</div>

<!-- TOOLBAR -->
<div class="toolbar">
  <select class="fsel" onchange="applyFilter('status',this.value)">
    <option value="">All Status</option>
    <?php foreach($SL as $k=>$l):?>
    <option value="<?=$k?>" <?=$status===$k?'selected':''?>><?=$l?></option>
    <?php endforeach;?>
  </select>
  <select class="fsel" onchange="applyFilter('tech',this.value)">
    <option value="">All Technologies</option>
    <?php foreach(array_keys($techTable) as $t):?>
    <option value="<?=htmlspecialchars($t)?>" <?=($_GET['tech']??'')===$t?'selected':''?>><?=htmlspecialchars($t)?></option>
    <?php endforeach;?>
  </select>
  <?php if($q||$status||$tech):?>
  <a href="index.php" class="btn btn-ghost btn-sm">✕ Clear</a>
  <?php endif;?>
  <span class="result-count"><?=count($projects)?> project<?=count($projects)!==1?'s':''?></span>
</div>

<!-- PROJECT LIST (Activity Log style) -->
<?php if(empty($projects)):?>
<div class="empty">
  <div class="ei">📭</div>
  <h3>No Projects Found</h3>
  <p>Koi project nahi mila<?=$q||$status||$tech?' — filters clear karo':''?></p>
  <?php if(can_edit()):?>
  <a href="project_form.php" class="btn btn-acc" style="margin-top:14px">＋ Add First Project</a>
  <?php endif;?>
</div>
<?php else:?>

<div class="proj-list">
  <!-- Header row -->
  <div class="proj-hdr">
    <span></span>
    <span>Project / Department</span>
    <span>Environments</span>
    <span>Infrastructure</span>
    <span>Credentials</span>
    <span>Tech / Status</span>
    <span style="text-align:right">Actions</span>
  </div>

  <?php foreach($projects as $p):
    $sclr = $SC[$p['current_status']] ?? '#5a7a9a';
    $tl   = $p['technology']==='Other' ? $p['technology_other'] : $p['technology'];
    $envs = ['local','staging','production','audit','other'];
    $activeEnvs = array_filter($envs, fn($e)=>!empty($p["env_{$e}_url"]));
    $activeCreds = array_filter($envs, fn($e)=>!empty($p["env_{$e}_id"]) || !empty($p["env_{$e}_password"]));
  ?>

  <!-- MAIN ROW -->
  <div class="proj-row" id="pr-<?=$p['id']?>">

    <!-- 1. Status bar -->
    <div style="display:flex;align-items:center;justify-content:center">
      <div class="status-bar" style="background:<?=$sclr?>" title="<?=$SL[$p['current_status']]??''?>"></div>
    </div>

    <!-- 2. Project / Department -->
    <div>
      <div class="pname"><?=htmlspecialchars($p['project_name'])?></div>
      <div class="pdept"><?=htmlspecialchars($p['department_name']??'')?></div>
      <?php if($p['description']):?>
      <div style="font-size:10px;color:var(--mt);font-family:'Share Tech Mono',monospace;
        margin-top:3px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;max-width:220px">
        <?=htmlspecialchars($p['description'])?>
      </div>
      <?php endif;?>
    </div>

    <!-- 3. Environments -->
    <div>
      <div class="env-pills">
        <?php foreach($activeEnvs as $env):?>
        <a class="epill" style="color:<?=$EC[$env]?>"
           href="<?=htmlspecialchars($p["env_{$env}_url"])?>" target="_blank" rel="noopener"
           title="<?=htmlspecialchars($p["env_{$env}_url"])?>">
          <span class="edot"></span><?=$env?>
        </a>
        <?php endforeach;?>
        <?php if(empty($activeEnvs)):?>
        <span style="font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--bdr)">—</span>
        <?php endif;?>
      </div>
      <?php if(!empty($p['env_production_admin_url'])||!empty($p['env_staging_admin_url'])):
        $adminUrl=$p['env_production_admin_url']?:$p['env_staging_admin_url'];?>
      <a href="<?=htmlspecialchars($adminUrl)?>" target="_blank" rel="noopener"
        style="font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--mt);
          text-decoration:none;display:inline-flex;align-items:center;gap:3px;margin-top:3px">
        ⚙ admin panel
      </a>
      <?php endif;?>
    </div>

    <!-- 4. Infrastructure -->
    <div class="infra-kv">
      <?php if($p['app_ip']):?>
      <div class="kv">
        <span class="k">app</span>
        <span class="v"><?=htmlspecialchars($p['app_ip'])?></span>
        <button class="copy-btn" onclick="cp('<?=htmlspecialchars($p['app_ip'])?>')" title="Copy">📋</button>
      </div>
      <?php endif;?>
      <?php if($p['db_ip']):?>
      <div class="kv">
        <span class="k">db</span>
        <span class="v"><?=htmlspecialchars($p['db_ip'])?></span>
        <button class="copy-btn" onclick="cp('<?=htmlspecialchars($p['db_ip'])?>')" title="Copy">📋</button>
      </div>
      <?php endif;?>
      <?php if($p['app_os']&&$p['app_os']!=='Other'):?>
      <div class="kv"><span class="k">os</span><span class="v" style="color:var(--mt)"><?=htmlspecialchars($p['app_os'])?></span></div>
      <?php elseif($p['app_os_other']):?>
      <div class="kv"><span class="k">os</span><span class="v" style="color:var(--mt)"><?=htmlspecialchars($p['app_os_other'])?></span></div>
      <?php endif;?>
      <?php if(!$p['app_ip']&&!$p['db_ip']):?>
      <span style="font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--bdr)">—</span>
      <?php endif;?>
    </div>

    <!-- 5. Credentials (per env) -->
    <div class="creds">
      <?php foreach(['production','staging','local','audit','other'] as $env):
        if(empty($p["env_{$env}_id"])&&empty($p["env_{$env}_password"])) continue;?>
      <div>
        <div class="cred-env" style="color:<?=$EC[$env]?>"><?=$env?></div>
        <?php if($p["env_{$env}_id"]):?>
        <div class="pw-row">
          <button class="copy-btn" onclick="cp('<?=htmlspecialchars($p["env_{$env}_id"])?>')" title="Copy ID">📋</button>
          <span style="font-family:'Share Tech Mono',monospace;font-size:10px"><?=htmlspecialchars($p["env_{$env}_id"])?></span>
        </div>
        <?php endif;?>
        <?php if($p["env_{$env}_password"]):?>
        <div class="pw-row">
          <button class="pw-btn" onclick="cpPw(<?=$p['id']?>,'<?=$env?>','<?=csrf_token()?>')" title="Copy">📋</button>
          <span class="pw-mask" id="pw-<?=$p['id']?>-<?=$env?>">••••••</span>
          <button class="pw-btn" onclick="tpw(<?=$p['id']?>,'<?=$env?>','<?=csrf_token()?>')">👁</button>
        </div>
        <?php endif;?>
      </div>
      <?php endforeach;?>
      <?php if(empty($activeCreds)):?>
      <span style="font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--bdr)">—</span>
      <?php endif;?>
    </div>

    <!-- 6. Tech / Status / Meta -->
    <div>
      <div style="display:flex;flex-direction:column;gap:4px">
        <span class="badge" style="color:<?=$sclr?>;border-color:<?=$sclr?>30;align-self:start">
          <?=$SL[$p['current_status']]??$p['current_status']?>
        </span>
        <?php if($tl):?>
        <span style="font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--mt)"><?=htmlspecialchars($tl)?></span>
        <?php endif;?>
        <?php if($p['live_date']):?>
        <span style="font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--bdr)">Live: <?=$p['live_date']?></span>
        <?php endif;?>
        <span style="font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--bdr)"><?=date('d M Y',strtotime($p['updated_at']))?></span>
      </div>
    </div>

    <!-- 7. Actions -->
    <div class="acts">
      <?php if($p['general_remark']||$p['app_infra_remark']||$p['db_remark']):?>
      <button class="btn btn-ghost btn-sm" onclick="togNotes(<?=$p['id']?>)" title="Notes">📝</button>
      <?php endif;?>
      <?php if($p['nodal_officer_name']):?>
      <button class="btn btn-ghost btn-sm" onclick="togNodal(<?=$p['id']?>)" title="Nodal Officer">👤</button>
      <?php endif;?>
      <?php if(can_edit()):?>
      <a href="project_form.php?id=<?=$p['id']?>" class="btn btn-ghost btn-sm">✏</a>
      <?php endif;?>
      <?php if(is_admin()):?>
      <button class="btn btn-danger btn-sm" onclick="delProj(<?=$p['id']?>,'<?=htmlspecialchars($p['project_name'],ENT_QUOTES)?>','<?=csrf_token()?>')">🗑</button>
      <?php endif;?>
    </div>
  </div>

  <!-- Notes drawer -->
  <?php if($p['general_remark']||$p['app_infra_remark']||$p['db_remark']):?>
  <div class="notes-drawer" id="nd-<?=$p['id']?>">
    <?php if($p['general_remark']):?>
    <div class="notes-sec">
      <div style="color:var(--acc);font-size:9px;text-transform:uppercase;letter-spacing:1px;margin-bottom:3px">General Remark</div>
      <div class="nt"><?=htmlspecialchars($p['general_remark'])?></div>
    </div>
    <?php endif;?>
    <?php if($p['app_infra_remark']):?>
    <div class="notes-sec">
      <div style="color:var(--acc);font-size:9px;text-transform:uppercase;letter-spacing:1px;margin-bottom:3px">App Infra</div>
      <div class="nt"><?=htmlspecialchars($p['app_infra_remark'])?></div>
    </div>
    <?php endif;?>
    <?php if($p['db_remark']):?>
    <div class="notes-sec">
      <div style="color:var(--acc);font-size:9px;text-transform:uppercase;letter-spacing:1px;margin-bottom:3px">DB Remark</div>
      <div class="nt"><?=htmlspecialchars($p['db_remark'])?></div>
    </div>
    <?php endif;?>
  </div>
  <?php endif;?>

  <!-- Nodal drawer -->
  <?php if($p['nodal_officer_name']):?>
  <div class="nodal-drawer" id="nod-<?=$p['id']?>">
    <div class="nodal-kv"><div class="nk">Officer</div><div class="nv"><?=htmlspecialchars($p['nodal_officer_name'])?></div></div>
    <?php if($p['nodal_designation']):?><div class="nodal-kv"><div class="nk">Designation</div><div class="nv"><?=htmlspecialchars($p['nodal_designation'])?></div></div><?php endif;?>
    <?php if($p['nodal_contact']):?><div class="nodal-kv"><div class="nk">Contact</div><div class="nv"><?=htmlspecialchars($p['nodal_contact'])?></div></div><?php endif;?>
    <?php if($p['dept_email']):?><div class="nodal-kv"><div class="nk">Email</div><div class="nv"><?=htmlspecialchars($p['dept_email'])?></div></div><?php endif;?>
  </div>
  <?php endif;?>

  <?php endforeach;?>
</div>
<?php endif;?>

</div><!-- /content -->
<div class="toast" id="toast"><span id="tt"></span></div>

<script>
// Search debounce
let st;document.getElementById('qi').addEventListener('input',function(){clearTimeout(st);st=setTimeout(()=>this.closest('form').submit(),500)});

function applyFilter(k,v){const u=new URL(window.location);v?u.searchParams.set(k,v):u.searchParams.delete(k);window.location=u}

function toast(m){const t=document.getElementById('toast');document.getElementById('tt').textContent=m;t.style.display='flex';setTimeout(()=>t.style.display='none',2300)}
function cp(t){navigator.clipboard.writeText(t).then(()=>toast('✅ Copied!'))}

const pvs={};
async function tpw(id,env,csrf){
  const el=document.getElementById(`pw-${id}-${env}`);
  const key=`${id}-${env}`;
  if(pvs[key]){el.textContent='••••••';pvs[key]=false;return}
  const r=await fetch(`api.php?action=get_pw&id=${id}&env=${env}&csrf=${csrf}`);
  const d=await r.json();
  if(d.pw){el.textContent=d.pw;pvs[key]=true}}
async function cpPw(id,env,csrf){
  const r=await fetch(`api.php?action=get_pw&id=${id}&env=${env}&csrf=${csrf}`);
  const d=await r.json();if(d.pw)navigator.clipboard.writeText(d.pw).then(()=>toast('✅ Password copied!'))}

function togNotes(id){const el=document.getElementById('nd-'+id);if(el)el.classList.toggle('open')}
function togNodal(id){const el=document.getElementById('nod-'+id);if(el)el.classList.toggle('open')}

function delProj(id,name,csrf){
  if(!confirm(`Delete "${name}"? This cannot be undone.`))return;
  const f=document.createElement('form');f.method='POST';f.action='api.php';
  f.innerHTML=`<input name="action" value="delete_project"><input name="id" value="${id}"><input name="csrf" value="${csrf}">`;
  document.body.appendChild(f);f.submit()}

// Theme panel
function toggleTheme(){document.getElementById('tp').classList.toggle('open')}
document.addEventListener('click',e=>{if(!e.target.closest('#tb')&&!e.target.closest('#tp'))document.getElementById('tp').classList.remove('open')})
function setAcc(c){document.documentElement.style.setProperty('--acc',c);document.getElementById('cc').value=c;document.getElementById('chex').textContent=c;document.querySelectorAll('.sw').forEach(s=>s.classList.toggle('on',s.style.background===c))}
function setTheme(v){document.documentElement.setAttribute('data-theme',v)}
function setFont(v){document.body.style.fontFamily=`'${v}',sans-serif`}
function setFs(v){document.documentElement.style.setProperty('--acc',getComputedStyle(document.documentElement).getPropertyValue('--acc'));document.documentElement.style.fontSize=v+'px';document.getElementById('fsv').textContent=v}
async function savePrefs(){
  const acc=getComputedStyle(document.documentElement).getPropertyValue('--acc').trim();
  const th=document.documentElement.getAttribute('data-theme');
  const fn=document.getElementById('fsel').value;
  const fs=document.querySelector('input[type=range]').value;
  const r=await fetch('api.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:`action=save_prefs&accent=${encodeURIComponent(acc)}&theme=${th}&font=${encodeURIComponent(fn)}&fs=${fs}&csrf=<?=csrf_token()?>`});
  const d=await r.json();if(d.ok)toast('✅ Preferences saved!')}
</script>
</body>
</html>
