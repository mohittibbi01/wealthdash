<?php
require_once __DIR__ . '/auth.php';
require_login();
require_edit();

$db = get_db();
$id = intval($_GET['id'] ?? 0);
$p  = null; $error = '';

if ($id) {
    $st = $db->prepare("SELECT * FROM projects WHERE id=?");
    $st->execute([$id]); $p = $st->fetch();
    if (!$p) { header('Location: index.php'); exit; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) die('CSRF error');
    foreach (['technology','app_os','db_version','db_os'] as $grp)
        if (($_POST[$grp]??'')==='Other' && !empty($_POST[$grp.'_other']))
            add_option($grp, $_POST[$grp.'_other']);

    $fields = ['department_name','nodal_officer_name','nodal_designation','nodal_contact','dept_email',
        'technology','technology_other','website_app','project_name','description',
        'current_status','last_audit_date','live_date','total_visitor_counter','last_update_date',
        'env_local_url','env_local_admin_url','env_local_id','env_local_remark',
        'env_staging_url','env_staging_admin_url','env_staging_id','env_staging_remark',
        'env_production_url','env_production_admin_url','env_production_id','env_production_remark',
        'env_audit_url','env_audit_admin_url','env_audit_id','env_audit_remark',
        'env_other_url','env_other_admin_url','env_other_id','env_other_remark',
        'app_ip','app_lb_ip','app_os','app_os_other','app_core','app_ram',
        'app_primary_storage','app_secondary_storage','app_hosting_type','app_infra_remark',
        'db_ip','db_name','db_version','db_version_other','db_os','db_os_other',
        'db_hosting_type','db_remark','general_remark'];

    $data = [];
    foreach ($fields as $f) $data[$f] = trim($_POST[$f] ?? '');
    foreach (['local','staging','production','audit','other'] as $env) {
        $key = "env_{$env}_password"; $raw = trim($_POST[$key] ?? '');
        $data[$key] = $raw !== '' ? encrypt_val($raw) : ($p[$key] ?? '');
    }

    if (!$data['project_name']) { $error = 'Project name is required.'; }
    else {
        if ($id) {
            $sets = implode(',', array_map(fn($f)=>"`$f`=?", array_keys($data))).', updated_at=CURRENT_TIMESTAMP';
            $db->prepare("UPDATE projects SET $sets WHERE id=?")->execute([...array_values($data),$id]);
            log_activity('edit_project',$id,$data['project_name']);
        } else {
            $cols = implode(',', array_map(fn($f)=>"`$f`", array_keys($data)));
            $phs  = implode(',', array_fill(0,count($data),'?'));
            $db->prepare("INSERT INTO projects ($cols,created_by) VALUES ($phs,?)")->execute([...array_values($data),$_SESSION['user_id']]);
            log_activity('add_project',(int)$db->lastInsertId(),$data['project_name']);
        }
        backup_json();
        $_SESSION['flash']=['type'=>'success','msg'=>"✅ Project \"{$data['project_name']}\" saved."];
        header('Location: index.php'); exit;
    }
}

$techOpts  = get_options_arr('technology');
$appOsOpts = get_options_arr('app_os');
$dbVerOpts = get_options_arr('db_version');
$dbOsOpts  = get_options_arr('db_os');

$v   = fn($f) => htmlspecialchars($p[$f] ?? $_POST[$f] ?? '');
$sel = fn($f,$val) => ($p[$f] ?? $_POST[$f] ?? '') === $val ? 'selected' : '';

$accent  = user_pref('accent','#00d4ff');
$bg      = user_pref('bg_color','');
$theme   = user_pref('theme','dark');
$fsize   = user_pref('font_size','14');
$ffamily = user_pref('font_family','Rajdhani');

// Section div colors — slightly different for easy recognition
$secColors = [
    'proj' => ['bg'=>'rgba(0,212,255,0.04)',  'bdr'=>'rgba(0,212,255,0.25)',  'hd'=>'rgba(0,212,255,0.08)'],
    'dept' => ['bg'=>'rgba(0,230,118,0.04)',  'bdr'=>'rgba(0,230,118,0.25)',  'hd'=>'rgba(0,230,118,0.08)'],
    'app'  => ['bg'=>'rgba(255,215,64,0.04)', 'bdr'=>'rgba(255,215,64,0.25)', 'hd'=>'rgba(255,215,64,0.08)'],
    'db'   => ['bg'=>'rgba(234,128,252,0.04)','bdr'=>'rgba(234,128,252,0.25)','hd'=>'rgba(234,128,252,0.08)'],
    'env'  => ['bg'=>'rgba(140,158,255,0.04)','bdr'=>'rgba(140,158,255,0.25)','hd'=>'rgba(140,158,255,0.08)'],
    'rem'  => ['bg'=>'rgba(255,61,90,0.03)',  'bdr'=>'rgba(255,61,90,0.20)',  'hd'=>'rgba(255,61,90,0.07)'],
];
// Light theme overrides
$secColorsLight = [
    'proj' => ['bg'=>'#f0fbff', 'bdr'=>'#b3e8f7', 'hd'=>'#ddf4fd'],
    'dept' => ['bg'=>'#f0fff6', 'bdr'=>'#b3f0d0', 'hd'=>'#ddfff0'],
    'app'  => ['bg'=>'#fffdf0', 'bdr'=>'#f7e8b3', 'hd'=>'#fff8dd'],
    'db'   => ['bg'=>'#fdf0ff', 'bdr'=>'#e8b3f7', 'hd'=>'#f8ddff'],
    'env'  => ['bg'=>'#f2f0ff', 'bdr'=>'#c4b3f7', 'hd'=>'#ebe0ff'],
    'rem'  => ['bg'=>'#fff0f2', 'bdr'=>'#f7b3be', 'hd'=>'#ffdde0'],
];
$sc = $theme === 'light' ? $secColorsLight : $secColors;
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DevVault — <?=$p?'Edit':'Add'?> Project</title>
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Orbitron:wght@700;900&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --acc:<?=$accent?>;
  --user-bg:<?=$bg?:'unset'?>;
  --bg:#070b14;--sur:#0d1422;--sur2:#111a2e;--bdr:#1e2d4a;
  --tx:#e8edf5;--mt:#5a7a9a;--ok:#00e676;--err:#ff3d5a;--amb:#ffd740;
}
[data-theme="light"]{
  --bg:#f0f4f8;--sur:#ffffff;--sur2:#e8edf5;--bdr:#c8d4e0;--tx:#0d1422;--mt:#6b7f96;
}
html{font-size:<?=$fsize?>px}
body{font-family:'<?=$ffamily?>',sans-serif;color:var(--tx);min-height:100vh;
  background:var(--user-bg,var(--bg))}
body::before{content:'';position:fixed;inset:0;pointer-events:none;z-index:0;
  background-image:linear-gradient(var(--bdr) 1px,transparent 1px),
  linear-gradient(90deg,var(--bdr) 1px,transparent 1px);
  background-size:44px 44px;opacity:.13}

/* TOPBAR */
.bar{position:sticky;top:0;z-index:200;height:50px;
  background:color-mix(in srgb,var(--bg) 92%,transparent);
  border-bottom:1px solid var(--bdr);backdrop-filter:blur(14px);
  display:flex;align-items:center;padding:0 18px;gap:12px}
.logo{font-family:'Orbitron',monospace;font-size:14px;font-weight:900;
  color:var(--acc);letter-spacing:2px;text-shadow:0 0 14px var(--acc)}
.bar-r{margin-left:auto;display:flex;gap:8px}
.btn{display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:7px;
  font-size:13px;font-weight:700;font-family:inherit;cursor:pointer;border:none;
  text-decoration:none;transition:all .15s;letter-spacing:.3px}
.btn:active{transform:scale(.97)}
.btn-ghost{background:var(--sur2);color:var(--mt);border:1px solid var(--bdr)}
.btn-ghost:hover{color:var(--tx);border-color:var(--mt)}
.btn-save{background:var(--acc);color:#000;padding:8px 22px;font-size:14px}
.btn-save:hover{opacity:.85}
.btn-cancel{background:var(--sur2);color:var(--mt);border:1px solid var(--bdr);padding:8px 16px;font-size:14px}
.btn-cancel:hover{color:var(--tx)}

/* LAYOUT */
.wrap{padding:14px 16px 80px;position:relative;z-index:1;max-width:1200px;margin:0 auto}

/* SECTION CARDS — each with unique tint */
.sec{border-radius:12px;overflow:hidden;margin-bottom:14px;transition:box-shadow .2s}
.sec:focus-within{box-shadow:0 0 0 2px var(--acc)30}
.sec-hd{display:flex;align-items:center;gap:8px;padding:10px 16px;cursor:pointer;user-select:none}
.sec-hd h2{font-family:'Orbitron',monospace;font-size:11px;font-weight:700;
  color:var(--acc);letter-spacing:1.8px;text-transform:uppercase;flex:1}
.chev{color:var(--mt);font-size:11px;transition:transform .2s}
.sec-hd.closed .chev{transform:rotate(-90deg)}
.sec-bd{padding:14px 16px}
.sec-bd.gone{display:none}

/* ROWS */
.row{display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin-bottom:10px}
.row:last-child{margin-bottom:0}
.f{flex:1;min-width:130px;display:flex;flex-direction:column;gap:4px}
.f.w15{flex:1.5}
.f.w2{flex:2}
.f.w3{flex:3}

/* FIELDS */
label,.lbl{display:block;font-family:'Share Tech Mono',monospace;font-size:9.5px;
  text-transform:uppercase;letter-spacing:1.3px;color:var(--mt)}
.req{color:var(--err)}
input,select,textarea{
  background:var(--sur2);border:1px solid var(--bdr);border-radius:7px;
  padding:7px 10px;color:var(--tx);font-size:13px;font-family:'Rajdhani',sans-serif;
  font-weight:500;outline:none;width:100%;transition:border-color .18s,box-shadow .18s}
input:focus,select:focus,textarea:focus{
  border-color:var(--acc);box-shadow:0 0 0 2px color-mix(in srgb,var(--acc) 12%,transparent)}
input::placeholder,textarea::placeholder{color:var(--mt);font-size:12px}
select option{background:var(--sur2)}
textarea{resize:vertical;min-height:70px;line-height:1.5}

/* PASSWORD */
.pw{position:relative}
.pw input{padding-right:34px;font-family:'Share Tech Mono',monospace;letter-spacing:.5px}
.pw-eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);
  background:none;border:none;cursor:pointer;color:var(--mt);font-size:13px;padding:2px;line-height:1}
.pw-eye:hover{color:var(--acc)}

.hint{font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--mt);margin-top:2px}
.cond{display:none!important}
.cond.on{display:flex!important;flex-direction:column;gap:4px}

/* ENV TABLE */
.etbl{width:100%;border-collapse:collapse;min-width:660px}
.etbl th{font-family:'Share Tech Mono',monospace;font-size:9px;text-transform:uppercase;
  letter-spacing:1px;color:var(--mt);padding:5px 7px 8px;text-align:left;border-bottom:1px solid var(--bdr)}
.etbl td{padding:4px 5px;border-bottom:1px solid color-mix(in srgb,var(--bdr) 60%,transparent);vertical-align:middle}
.etbl tr:last-child td{border-bottom:none}
.etbl input{padding:6px 8px;font-size:12px}
.env-nm{font-family:'Share Tech Mono',monospace;font-size:11px;font-weight:700;
  display:flex;align-items:center;gap:5px;white-space:nowrap;padding:4px 8px}
.dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}

/* STICKY FOOTER — only once at bottom */
.form-footer{position:fixed;bottom:0;left:0;right:0;z-index:100;
  background:color-mix(in srgb,var(--bg) 96%,transparent);
  border-top:1px solid var(--bdr);backdrop-filter:blur(14px);
  padding:10px 20px;display:flex;justify-content:flex-end;gap:10px}

/* ERR */
.err{background:color-mix(in srgb,var(--err) 8%,transparent);
  border:1px solid color-mix(in srgb,var(--err) 30%,transparent);
  color:var(--err);padding:9px 14px;border-radius:8px;
  font-size:12px;font-family:'Share Tech Mono',monospace;margin:10px 0}

@media(max-width:600px){.row{flex-direction:column}.f,.f.w15,.f.w2,.f.w3{min-width:0;flex:1}}
</style>
</head>
<body>

<div class="bar">
  <span class="logo">DEVVAULT</span>
  <span style="color:var(--bdr);font-size:18px">|</span>
  <span style="font-size:14px;font-weight:700"><?=$p?'✏ Edit':'＋ Add'?> Project</span>
  <div class="bar-r"><a href="index.php" class="btn btn-ghost">← Back</a></div>
</div>

<div class="wrap">
<?php if($error):?><div class="err">⚠ <?=htmlspecialchars($error)?></div><?php endif;?>

<form method="POST" id="pf">
<input type="hidden" name="csrf" value="<?=csrf_token()?>">

<!-- ═══════════════════════════════════════════════════════
     1. PROJECT INFORMATION  (cyan tint)
════════════════════════════════════════════════════════════ -->
<div class="sec" style="background:<?=$sc['proj']['bg']?>;border:1px solid <?=$sc['proj']['bdr']?>">
  <div class="sec-hd" style="background:<?=$sc['proj']['hd']?>" onclick="tog(this)">
    <h2>🗂 Project Information</h2><span class="chev">▾</span>
  </div>
  <div class="sec-bd">
    <!-- Row 1: Technology + Website/App (dropdown) + Project Name -->
    <div class="row">
      <div class="f w15">
        <label>Technology <span class="req">*</span></label>
        <select name="technology" onchange="showCond(this,'tech-oth')">
          <option value="">— Select Technology —</option>
          <?php foreach($techOpts as $t):?>
          <option value="<?=htmlspecialchars($t)?>" <?=$sel('technology',$t)?>><?=htmlspecialchars($t)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="f cond <?=($p['technology']??'')==='Other'?'on':''?>" id="tech-oth">
        <label>Specify Technology</label>
        <input type="text" name="technology_other" placeholder="Enter tech name" value="<?=$v('technology_other')?>">
        <span class="hint">Auto-saved to dropdown</span>
      </div>
      <div class="f w15">
        <label>Website / Application</label>
        <select name="website_app">
          <option value="">— Select Type —</option>
          <?php foreach(['Website','Application','Both','Mobile App','Portal','API','Other'] as $wa):?>
          <option value="<?=$wa?>" <?=$sel('website_app',$wa)?>><?=$wa?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="f w3">
        <label>Project Name <span class="req">*</span></label>
        <input type="text" name="project_name" placeholder="e.g. Employee Portal" required value="<?=$v('project_name')?>">
      </div>
    </div>
    <!-- Row 2: Description -->
    <div class="row">
      <div class="f">
        <label>Description</label>
        <textarea name="description" rows="2" placeholder="Short description of the project..."><?=$v('description')?></textarea>
      </div>
    </div>
    <!-- Row 3: Status + Audit Date + Live Date + Visitors + Last Update (all in one row) -->
    <div class="row">
      <div class="f w15">
        <label>Current Status</label>
        <select name="current_status" id="ssel" onchange="handleStatus(this.value)">
          <option value="live" <?=$sel('current_status','live')?>>🟢 Live</option>
          <option value="under_development" <?=$sel('current_status','under_development')?>>🟡 Under Development</option>
          <option value="redevelopment" <?=$sel('current_status','redevelopment')?>>🔵 Redevelopment</option>
          <option value="closed" <?=$sel('current_status','closed')?>>🔴 Closed</option>
        </select>
      </div>
      <div class="f">
        <label>Last Audit Date</label>
        <input type="date" name="last_audit_date" value="<?=$v('last_audit_date')?>">
      </div>
      <div class="f" id="live-date-f" style="<?=($p['current_status']??'live')!=='live'?'display:none':''?>">
        <label>Live Date</label>
        <input type="date" name="live_date" value="<?=$v('live_date')?>">
      </div>
      <div class="f" id="visitor-f" style="<?=($p['current_status']??'live')!=='live'?'display:none':''?>">
        <label>Total Visitors</label>
        <input type="text" name="total_visitor_counter" placeholder="e.g. 1,50,000" value="<?=$v('total_visitor_counter')?>">
      </div>
      <div class="f" id="lastupd-f" style="<?=($p['current_status']??'live')!=='live'?'display:none':''?>">
        <label>Last Update Date</label>
        <input type="date" name="last_update_date" value="<?=$v('last_update_date')?>">
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     2. DEPARTMENT INFO  (green tint)
════════════════════════════════════════════════════════════ -->
<div class="sec" style="background:<?=$sc['dept']['bg']?>;border:1px solid <?=$sc['dept']['bdr']?>">
  <div class="sec-hd" style="background:<?=$sc['dept']['hd']?>" onclick="tog(this)">
    <h2>🏢 Department Info</h2><span class="chev">▾</span>
  </div>
  <div class="sec-bd">
    <!-- Row 1: All 5 fields in one row -->
    <div class="row">
      <div class="f w2">
        <label>Department Name</label>
        <input type="text" name="department_name" placeholder="e.g. IT Department" value="<?=$v('department_name')?>">
      </div>
      <div class="f w2">
        <label>Nodal Officer Name</label>
        <input type="text" name="nodal_officer_name" placeholder="Full name" value="<?=$v('nodal_officer_name')?>">
      </div>
      <div class="f">
        <label>Designation</label>
        <input type="text" name="nodal_designation" placeholder="Sr. Developer" value="<?=$v('nodal_designation')?>">
      </div>
      <div class="f">
        <label>Contact No.</label>
        <input type="tel" name="nodal_contact" placeholder="10-digit mobile" value="<?=$v('nodal_contact')?>">
      </div>
      <div class="f w2">
        <label>Department Email</label>
        <input type="email" name="dept_email" placeholder="dept@gov.in" value="<?=$v('dept_email')?>">
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     3. APP INFRASTRUCTURE  (amber tint)
════════════════════════════════════════════════════════════ -->
<div class="sec" style="background:<?=$sc['app']['bg']?>;border:1px solid <?=$sc['app']['bdr']?>">
  <div class="sec-hd" style="background:<?=$sc['app']['hd']?>" onclick="tog(this)">
    <h2>🖥 App Infrastructure</h2><span class="chev">▾</span>
  </div>
  <div class="sec-bd">
    <!-- Row 1: App IP + LB IP + OS + OS-Other -->
    <div class="row">
      <div class="f"><label>App IP</label>
        <input type="text" name="app_ip" placeholder="192.168.x.x" value="<?=$v('app_ip')?>"></div>
      <div class="f"><label>LB IP</label>
        <input type="text" name="app_lb_ip" placeholder="Load Balancer IP" value="<?=$v('app_lb_ip')?>"></div>
      <div class="f w15"><label>OS Version</label>
        <select name="app_os" onchange="showCond(this,'aosos')">
          <option value="">— Select OS —</option>
          <?php foreach($appOsOpts as $o):?>
          <option value="<?=htmlspecialchars($o)?>" <?=$sel('app_os',$o)?>><?=htmlspecialchars($o)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="f cond <?=($p['app_os']??'')==='Other'?'on':''?>" id="aosos">
        <label>Specify OS</label>
        <input type="text" name="app_os_other" placeholder="e.g. Win 2022" value="<?=$v('app_os_other')?>">
        <span class="hint">Auto-saved</span>
      </div>
    </div>
    <!-- Row 2: Core + RAM + Primary + Secondary + Hosting -->
    <div class="row">
      <div class="f"><label>Core</label>
        <input type="text" name="app_core" placeholder="4 vCPU" value="<?=$v('app_core')?>"></div>
      <div class="f"><label>RAM</label>
        <input type="text" name="app_ram" placeholder="8 GB" value="<?=$v('app_ram')?>"></div>
      <div class="f w15"><label>Primary Storage</label>
        <input type="text" name="app_primary_storage" placeholder="100 GB SSD" value="<?=$v('app_primary_storage')?>"></div>
      <div class="f w15"><label>Secondary Storage</label>
        <input type="text" name="app_secondary_storage" placeholder="500 GB HDD" value="<?=$v('app_secondary_storage')?>"></div>
      <div class="f"><label>Hosting</label>
        <select name="app_hosting_type">
          <option value="individual" <?=$sel('app_hosting_type','individual')?>>Individual</option>
          <option value="shared" <?=$sel('app_hosting_type','shared')?>>Shared</option>
        </select>
      </div>
    </div>
    <!-- Row 3: Remark -->
    <div class="row">
      <div class="f"><label>App Infra Remark</label>
        <textarea name="app_infra_remark" rows="2" placeholder="Notes about application infrastructure..."><?=$v('app_infra_remark')?></textarea>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     4. DB INFRASTRUCTURE  (purple tint)
════════════════════════════════════════════════════════════ -->
<div class="sec" style="background:<?=$sc['db']['bg']?>;border:1px solid <?=$sc['db']['bdr']?>">
  <div class="sec-hd" style="background:<?=$sc['db']['hd']?>" onclick="tog(this)">
    <h2>🗄 DB Infrastructure</h2><span class="chev">▾</span>
  </div>
  <div class="sec-bd">
    <!-- Row 1: DB IP + DB Name + DB Version + Version-Other -->
    <div class="row">
      <div class="f"><label>DB IP</label>
        <input type="text" name="db_ip" placeholder="192.168.x.x" value="<?=$v('db_ip')?>"></div>
      <div class="f"><label>DB Name</label>
        <input type="text" name="db_name" placeholder="myapp_db" value="<?=$v('db_name')?>"></div>
      <div class="f w15"><label>DB Version</label>
        <select name="db_version" onchange="showCond(this,'dbvoth')">
          <option value="">— Select DB —</option>
          <?php foreach($dbVerOpts as $o):?>
          <option value="<?=htmlspecialchars($o)?>" <?=$sel('db_version',$o)?>><?=htmlspecialchars($o)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="f cond <?=($p['db_version']??'')==='Other'?'on':''?>" id="dbvoth">
        <label>Specify DB</label>
        <input type="text" name="db_version_other" placeholder="e.g. MongoDB 6" value="<?=$v('db_version_other')?>">
        <span class="hint">Auto-saved</span>
      </div>
    </div>
    <!-- Row 2: DB OS + OS-Other + Hosting -->
    <div class="row">
      <div class="f w15"><label>DB Server OS</label>
        <select name="db_os" onchange="showCond(this,'dbosos')">
          <option value="">— Select OS —</option>
          <?php foreach($dbOsOpts as $o):?>
          <option value="<?=htmlspecialchars($o)?>" <?=$sel('db_os',$o)?>><?=htmlspecialchars($o)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="f cond <?=($p['db_os']??'')==='Other'?'on':''?>" id="dbosos">
        <label>Specify DB OS</label>
        <input type="text" name="db_os_other" placeholder="e.g. RHEL 9" value="<?=$v('db_os_other')?>">
        <span class="hint">Auto-saved</span>
      </div>
      <div class="f"><label>Hosting</label>
        <select name="db_hosting_type">
          <option value="individual" <?=$sel('db_hosting_type','individual')?>>Individual</option>
          <option value="shared" <?=$sel('db_hosting_type','shared')?>>Shared</option>
        </select>
      </div>
    </div>
    <!-- Row 3: DB Remark -->
    <div class="row">
      <div class="f"><label>DB Remark</label>
        <textarea name="db_remark" rows="2" placeholder="Notes about database..."><?=$v('db_remark')?></textarea>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     5. ENVIRONMENT DETAILS  (indigo tint)
════════════════════════════════════════════════════════════ -->
<div class="sec" style="background:<?=$sc['env']['bg']?>;border:1px solid <?=$sc['env']['bdr']?>">
  <div class="sec-hd" style="background:<?=$sc['env']['hd']?>" onclick="tog(this)">
    <h2>🌐 Environment Details</h2><span class="chev">▾</span>
  </div>
  <div class="sec-bd" style="padding:10px 12px;overflow-x:auto">
    <table class="etbl">
      <thead>
        <tr>
          <th style="width:96px">Environment</th>
          <th>URL</th><th>Admin URL</th><th>Login ID</th>
          <th style="width:168px">Password</th><th>Remark</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach(['local'=>['#40c4ff','🔵'],'staging'=>['#ffd740','🟡'],
                     'production'=>['#00e676','🟢'],'audit'=>['#ea80fc','🟣'],
                     'other'=>['#8c9eff','⚪']] as $env=>[$clr,$ico]):
        $ep = fn($f) => htmlspecialchars($p["env_{$env}_{$f}"] ?? '');
        $hasPw = !empty($p["env_{$env}_password"]);
      ?>
      <tr>
        <td><div class="env-nm" style="color:<?=$clr?>">
          <span class="dot" style="background:<?=$clr?>"></span><?=ucfirst($env)?>
        </div></td>
        <td><input type="url" name="env_<?=$env?>_url" placeholder="https://..." value="<?=$ep('url')?>"></td>
        <td><input type="url" name="env_<?=$env?>_admin_url" placeholder="https://.../admin" value="<?=$ep('admin_url')?>"></td>
        <td><input type="text" name="env_<?=$env?>_id" placeholder="username/email" autocomplete="off" value="<?=$ep('id')?>"></td>
        <td><div class="pw">
          <input type="password" name="env_<?=$env?>_password" id="pw<?=$env?>"
            placeholder="<?=$hasPw?'(keep existing)':'password'?>" autocomplete="new-password">
          <button type="button" class="pw-eye" onclick="tpw('pw<?=$env?>')">👁</button>
        </div></td>
        <td><input type="text" name="env_<?=$env?>_remark" placeholder="remark..." value="<?=$ep('remark')?>"></td>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
  </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     6. GENERAL REMARKS  (red tint)
════════════════════════════════════════════════════════════ -->
<div class="sec" style="background:<?=$sc['rem']['bg']?>;border:1px solid <?=$sc['rem']['bdr']?>">
  <div class="sec-hd" style="background:<?=$sc['rem']['hd']?>" onclick="tog(this)">
    <h2>📝 General Remarks</h2><span class="chev">▾</span>
  </div>
  <div class="sec-bd">
    <div class="row">
      <div class="f"><label>Notes / Remarks</label>
        <textarea name="general_remark" rows="5"
          placeholder="SSH commands, deployment steps, API key locations, config details, important notes..."><?=$v('general_remark')?></textarea>
      </div>
    </div>
  </div>
</div>

</form>
</div><!-- /wrap -->

<!-- SINGLE sticky footer -->
<div class="form-footer">
  <a href="index.php" class="btn btn-cancel">✕ Cancel</a>
  <button type="submit" form="pf" class="btn btn-save">💾 Save Project</button>
</div>

<script>
function tog(hd){hd.classList.toggle('closed');hd.nextElementSibling.classList.toggle('gone')}
function showCond(sel,id){
  const el=document.getElementById(id);if(!el)return;
  if(sel.value==='Other'){el.classList.add('on')}else{el.classList.remove('on')}}
function tpw(id){const f=document.getElementById(id);if(f)f.type=f.type==='password'?'text':'password'}
function handleStatus(v){
  const show=v==='live';
  ['live-date-f','visitor-f','lastupd-f'].forEach(id=>{
    const el=document.getElementById(id);if(el)el.style.display=show?'':'none'})}
document.addEventListener('DOMContentLoaded',()=>handleStatus(document.getElementById('ssel').value))
</script>
</body>
</html>
