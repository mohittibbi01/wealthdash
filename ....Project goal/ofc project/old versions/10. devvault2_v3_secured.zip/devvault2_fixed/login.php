<?php
require_once __DIR__ . '/config.php';

ini_set('session.gc_maxlifetime', 360);
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);
// S02: SameSite cookie flag (LAN HTTP, no secure flag)
ini_set('session.cookie_samesite', 'Strict');

if (session_status() === PHP_SESSION_NONE) session_start();
if (isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }

// ── S01: Brute Force Protection helpers ──────────────────────────────────────
function ensure_attempts_table(): void {
    $db = get_db();
    $db->exec("CREATE TABLE IF NOT EXISTS login_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip_address TEXT NOT NULL,
        attempt_count INTEGER DEFAULT 0,
        locked_until DATETIME,
        last_attempt DATETIME
    )");
    // Ensure index for fast lookup
    try { $db->exec("CREATE INDEX IF NOT EXISTS idx_la_ip ON login_attempts(ip_address)"); } catch(Exception $e) {}
}

function get_client_ip(): string {
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function is_ip_locked(string $ip): array {
    $db = get_db();
    $st = $db->prepare("SELECT attempt_count, locked_until, last_attempt FROM login_attempts
                        WHERE ip_address=? AND last_attempt > datetime('now', '-1 hour')");
    $st->execute([$ip]);
    $row = $st->fetch();
    if (!$row) return ['locked' => false, 'minutes_left' => 0];

    if ($row['locked_until'] && strtotime($row['locked_until']) > time()) {
        $mins = ceil((strtotime($row['locked_until']) - time()) / 60);
        return ['locked' => true, 'minutes_left' => $mins];
    }
    return ['locked' => false, 'minutes_left' => 0];
}

function record_failed_attempt(string $ip): void {
    $db = get_db();
    // Check if row exists within the last hour
    $st = $db->prepare("SELECT id, attempt_count FROM login_attempts
                        WHERE ip_address=? AND last_attempt > datetime('now', '-1 hour')");
    $st->execute([$ip]);
    $row = $st->fetch();

    if ($row) {
        $new_count = $row['attempt_count'] + 1;
        $locked_until = null;
        if ($new_count >= 5) {
            $locked_until = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        }
        $db->prepare("UPDATE login_attempts SET attempt_count=?, locked_until=?, last_attempt=datetime('now') WHERE id=?")
           ->execute([$new_count, $locked_until, $row['id']]);
    } else {
        // Delete stale records for this IP first
        $db->prepare("DELETE FROM login_attempts WHERE ip_address=?")->execute([$ip]);
        $db->prepare("INSERT INTO login_attempts (ip_address, attempt_count, last_attempt) VALUES (?, 1, datetime('now'))")
           ->execute([$ip]);
    }
}

function reset_attempts(string $ip): void {
    $db = get_db();
    $db->prepare("DELETE FROM login_attempts WHERE ip_address=?")->execute([$ip]);
}

// ── Log activity without session (for login events) ──────────────────────────
function log_login_event(string $action, string $detail = ''): void {
    // Only log if session is set (login success path)
    if (isset($_SESSION['user_id'])) {
        log_activity($action, null, $detail);
        return;
    }
    // For failures, log directly with user_id=0
    try {
        $db = get_db();
        $ip = get_client_ip();
        $db->prepare("INSERT INTO activity_log (user_id,action,project_id,detail,ip_address) VALUES (?,?,?,?,?)")
           ->execute([0, $action, null, $detail, $ip]);
    } catch (Exception $e) { /* fail silently */ }
}

ensure_attempts_table();

$error = '';
$ip    = get_client_ip();
$lock  = is_ip_locked($ip);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$lock['locked']) {
    $u = trim($_POST['username'] ?? '');
    $p = $_POST['password'] ?? '';
    if ($u && $p) {
        $db = get_db();
        $st = $db->prepare("SELECT * FROM users WHERE username=?");
        $st->execute([$u]);
        $user = $st->fetch();
        if ($user && password_verify($p, $user['password_hash']) && ($user['is_active'] ?? 1)) {
            // S02: Regenerate session ID to prevent session fixation
            session_regenerate_id(true);

            $_SESSION['user_id']          = $user['id'];
            $_SESSION['username']         = $user['username'];
            $_SESSION['role']             = $user['role'];
            $_SESSION['csrf']             = bin2hex(random_bytes(32));
            $_SESSION['password_changed'] = (int)($user['password_changed'] ?? 0);
            $_SESSION['prefs']            = [
                'theme'       => $user['theme'],
                'accent'      => $user['accent_color'],
                'bg_color'    => $user['bg_color'] ?? '',
                'font_size'   => $user['font_size'],
                'font_family' => $user['font_family'],
            ];

            // S04: Log successful login
            log_activity('login_success', null, "Login from IP: {$ip}");
            reset_attempts($ip);

            if ((int)($user['password_changed'] ?? 0) === 0) {
                header('Location: change_password.php?force=1');
            } else {
                header('Location: index.php');
            }
            exit;
        }
        // S01: Record failed attempt
        record_failed_attempt($ip);
        $lock = is_ip_locked($ip); // re-check lock status
        // S04: Log failed login
        log_login_event('login_failure', "Failed attempt for username: {$u} from IP: {$ip}");

        if ($lock['locked']) {
            $error = "Too many failed attempts. Try again after {$lock['minutes_left']} minute(s).";
        } else {
            $db2 = get_db();
            $st2 = $db2->prepare("SELECT attempt_count FROM login_attempts WHERE ip_address=? AND last_attempt > datetime('now', '-1 hour')");
            $st2->execute([$ip]);
            $row2 = $st2->fetch();
            $remaining = max(0, 5 - (int)($row2['attempt_count'] ?? 0));
            $error = 'Invalid username or password.' . ($remaining < 5 ? " ({$remaining} attempt(s) left before lockout)" : '');
        }
    } else {
        $error = 'Please fill all fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DevVault Pro — Login</title>
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#070b14;--surface:#0d1422;--surface2:#111a2e;--border:#1e2d4a;
  --text:#e8edf5;--muted:#5a7a9a;--accent:#00d4ff;--accent2:#0066ff;
  --success:#00e676;--danger:#ff3d5a;
}
body{font-family:'Rajdhani',sans-serif;background:var(--bg);color:var(--text);
  min-height:100vh;display:flex;align-items:center;justify-content:center;
  overflow:hidden;position:relative}
body::before{
  content:'';position:fixed;inset:0;
  background-image:linear-gradient(rgba(0,212,255,.03) 1px,transparent 1px),
    linear-gradient(90deg,rgba(0,212,255,.03) 1px,transparent 1px);
  background-size:40px 40px;pointer-events:none;
  animation:gridMove 20s linear infinite}
@keyframes gridMove{from{background-position:0 0}to{background-position:40px 40px}}
body::after{
  content:'';position:fixed;inset:0;
  background:radial-gradient(ellipse at 30% 50%,rgba(0,102,255,.08) 0%,transparent 60%),
    radial-gradient(ellipse at 70% 50%,rgba(0,212,255,.06) 0%,transparent 60%);
  pointer-events:none}
.wrap{width:100%;max-width:400px;padding:20px;position:relative;z-index:1}
.logo{text-align:center;margin-bottom:32px}
.logo-box{
  width:64px;height:64px;margin:0 auto 14px;
  background:linear-gradient(135deg,var(--accent2),var(--accent));
  border-radius:16px;display:flex;align-items:center;justify-content:center;
  font-size:28px;box-shadow:0 0 40px rgba(0,212,255,.3),0 0 80px rgba(0,102,255,.15);
  animation:pulse 3s ease-in-out infinite}
@keyframes pulse{0%,100%{box-shadow:0 0 40px rgba(0,212,255,.3),0 0 80px rgba(0,102,255,.15)}
  50%{box-shadow:0 0 60px rgba(0,212,255,.5),0 0 100px rgba(0,102,255,.25)}}
.logo h1{font-size:30px;font-weight:700;letter-spacing:2px;
  background:linear-gradient(135deg,var(--accent),#fff);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.logo p{font-family:'Share Tech Mono',monospace;font-size:12px;color:var(--muted);
  margin-top:4px;letter-spacing:1px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:16px;
  padding:28px;position:relative;overflow:hidden}
.card::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,var(--accent),transparent)}
.error{background:rgba(255,61,90,.08);border:1px solid rgba(255,61,90,.25);
  color:var(--danger);padding:10px 14px;border-radius:8px;font-size:13px;
  margin-bottom:18px;font-family:'Share Tech Mono',monospace;display:flex;align-items:center;gap:8px}
.locked-msg{background:rgba(255,61,90,.12);border:1px solid rgba(255,61,90,.4);
  color:var(--danger);padding:16px;border-radius:8px;font-size:14px;
  font-family:'Share Tech Mono',monospace;text-align:center;margin-bottom:18px}
.field{margin-bottom:16px}
.field label{display:block;font-size:12px;font-weight:600;text-transform:uppercase;
  letter-spacing:1.5px;color:var(--muted);margin-bottom:7px;font-family:'Share Tech Mono',monospace}
.field input{width:100%;background:var(--surface2);border:1px solid var(--border);
  border-radius:8px;padding:11px 14px;color:var(--text);font-size:15px;
  font-family:'Rajdhani',sans-serif;font-weight:500;outline:none;
  transition:border-color .2s,box-shadow .2s}
.field input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(0,212,255,.1)}
.field input::placeholder{color:var(--muted)}
.field input:disabled{opacity:.4;cursor:not-allowed}
.btn-login{width:100%;background:linear-gradient(135deg,var(--accent2),var(--accent));
  color:#000;border:none;border-radius:8px;padding:13px;font-size:16px;font-weight:700;
  font-family:'Rajdhani',sans-serif;cursor:pointer;letter-spacing:1px;
  transition:opacity .2s,transform .15s;margin-top:6px;text-transform:uppercase}
.btn-login:hover:not(:disabled){opacity:.88;transform:translateY(-1px)}
.btn-login:active:not(:disabled){transform:translateY(0)}
.btn-login:disabled{opacity:.4;cursor:not-allowed;transform:none}
.hint{text-align:center;margin-top:16px;font-family:'Share Tech Mono',monospace;
  font-size:11px;color:var(--muted)}
.hint span{color:var(--accent)}
</style>
</head>
<body>
<div class="wrap">
  <div class="logo">
    <div class="logo-box">🔐</div>
    <h1>DEVVAULT PRO</h1>
    <p>// CREDENTIAL & PROJECT MANAGER v3.0</p>
  </div>
  <div class="card">
    <?php if ($lock['locked']): ?>
      <div class="locked-msg">
        🔒 Too many failed attempts.<br>
        Try again after <strong><?= $lock['minutes_left'] ?> minute(s)</strong>.
      </div>
    <?php elseif ($error): ?>
      <div class="error">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="field">
        <label>Username</label>
        <input type="text" name="username" placeholder="enter username" autofocus
               autocomplete="username"
               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
               <?= $lock['locked'] ? 'disabled' : '' ?>>
      </div>
      <div class="field">
        <label>Password</label>
        <input type="password" name="password" placeholder="••••••••"
               autocomplete="current-password"
               <?= $lock['locked'] ? 'disabled' : '' ?>>
      </div>
      <button type="submit" class="btn-login" <?= $lock['locked'] ? 'disabled' : '' ?>>→ Sign In</button>
    </form>
  </div>
  <div class="hint">First login: <span>admin</span> / <span>admin123</span> — password change required</div>
</div>
</body>
</html>
