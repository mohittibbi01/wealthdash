<?php
require_once __DIR__ . '/auth.php';
require_login();
require_edit();

$db = get_db();
$id = intval($_GET['id'] ?? 0);
$p  = null;
$error = '';

if ($id) {
    $st = $db->prepare("SELECT * FROM projects WHERE id=?");
    $st->execute([$id]);
    $p = $st->fetch();
    if (!$p) { header('Location: index.php'); exit; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) die('CSRF error');

    foreach (['technology','app_os','db_version','db_os'] as $grp) {
        if (($_POST[$grp] ?? '') === 'Other' && !empty($_POST[$grp.'_other']))
            add_option($grp, $_POST[$grp.'_other']);
    }

    $fields = [
        'department_name','nodal_officer_name','nodal_designation','nodal_contact','dept_email',
        'technology','technology_other','website_app','project_name','description',
        'current_status','last_audit_date','live_date','total_visitor_counter','last_update_date',
        'env_local_url','env_local_admin_url','env_local_id','env_local_remark',
        'env_staging_url','env_staging_admin_url','env_staging_id','env_staging_remark',
        'env_production_url','env_production_admin_url','env_production_id','env_production_remark',
        'env_audit_url','env_audit_admin_url','env_audit_id','env_audit_remark',
        'env_other_url','env_other_admin_url','env_other_id','env_other_remark',
        'app_ip','app_lb_ip','app_os','app_os_other','app_core','app_ram',
        'app_primary_storage','app_secondary_storage','app_hosting_type','app_infra_remark',
        'db_ip','db_name','db_version','db_version_other','db_os','db_os_other',
        'db_hosting_type','db_remark','general_remark',
    ];

    $data = [];
    foreach ($fields as $f) $data[$f] = trim($_POST[$f] ?? '');

    foreach (['local','staging','production','audit','other'] as $env) {
        $key = "env_{$env}_password";
        $raw = trim($_POST[$key] ?? '');
        $data[$key] = $raw !== '' ? encrypt_val($raw) : ($p[$key] ?? '');
    }

    if (!$data['project_name']) {
        $error = 'Project name is required.';
    } else {
        if ($id) {
            $sets = implode(',', array_map(fn($f) => "`$f`=?", array_keys($data))) . ',updated_at=CURRENT_TIMESTAMP';
            $st = $db->prepare("UPDATE projects SET $sets WHERE id=?");
            $st->execute([...array_values($data), $id]);
            log_activity('edit_project', $id, $data['project_name']);
        } else {
            $cols = implode(',', array_map(fn($f) => "`$f`", array_keys($data)));
            $phs  = implode(',', array_fill(0, count($data), '?'));
            $st = $db->prepare("INSERT INTO projects ($cols,created_by) VALUES ($phs,?)");
            $st->execute([...array_values($data), $_SESSION['user_id']]);
            $id = $db->lastInsertId();
            log_activity('add_project', $id, $data['project_name']);
        }
        backup_json();
        $_SESSION['flash'] = ['type'=>'success','msg'=>"✅ Project \"{$data['project_name']}\" saved."];
        header('Location: index.php'); exit;
    }
}

$techOpts  = get_options_arr('technology');
$appOsOpts = get_options_arr('app_os');
$dbVerOpts = get_options_arr('db_version');
$dbOsOpts  = get_options_arr('db_os');

$v   = fn($f) => htmlspecialchars($p[$f] ?? $_POST[$f] ?? '');
$sel = fn($f,$val) => ($p[$f] ?? $_POST[$f] ?? '') === $val ? 'selected' : '';

// User prefs for theme
$accent  = user_pref('accent','#00d4ff');
$theme   = user_pref('theme','dark');
$fsize   = user_pref('font_size','14');
$ffamily = user_pref('font_family','Rajdhani');
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DevVault Pro — <?=$p?'Edit':'Add'?> Project</title>
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Orbitron:wght@700;900&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --accent:<?=$accent?>;
  --fs:<?=$fsize?>px;
  --bg:#070b14;--surface:#0d1422;--surface2:#111a2e;--surface3:#16213e;
  --border:#1e2d4a;--text:#e8edf5;--muted:#5a7a9a;
  --success:#00e676;--danger:#ff3d5a;--amber:#ffd740;
}
[data-theme="light"]{
  --bg:#f0f4f8;--surface:#fff;--surface2:#e8edf5;--surface3:#dde3ed;
  --border:#c8d4e0;--text:#0d1422;--muted:#5a7a9a;
}
html{font-size:var(--fs)}
body{font-family:'<?=$ffamily?>',sans-serif;background:var(--bg);color:var(--text);min-height:100vh}
body::before{content:'';position:fixed;inset:0;
  background-image:linear-gradient(rgba(0,212,255,.018) 1px,transparent 1px),
    linear-gradient(90deg,rgba(0,212,255,.018) 1px,transparent 1px);
  background-size:40px 40px;pointer-events:none;z-index:0}
[data-theme="light"] body::before{opacity:.3}

/* ── TOPBAR ── */
.topbar{position:sticky;top:0;z-index:100;background:rgba(7,11,20,.95);
  border-bottom:1px solid var(--border);backdrop-filter:blur(12px);
  padding:0 20px;height:52px;display:flex;align-items:center;gap:10px}
[data-theme="light"] .topbar{background:rgba(240,244,248,.95)}
.logo-txt{font-family:'Orbitron',monospace;font-size:14px;font-weight:900;
  letter-spacing:2px;color:var(--accent);text-shadow:0 0 16px var(--accent)}
.page-ttl{font-size:15px;font-weight:700}
.topbar-r{margin-left:auto;display:flex;gap:8px;align-items:center}
.btn{display:inline-flex;align-items:center;gap:5px;padding:6px 13px;border-radius:7px;
  font-size:13px;font-weight:600;font-family:'Rajdhani',sans-serif;letter-spacing:.4px;
  cursor:pointer;border:none;text-decoration:none;transition:all .15s;white-space:nowrap}
.btn:active{transform:scale(.97)}
.btn-accent{background:var(--accent);color:#000}
.btn-accent:hover{opacity:.85}
.btn-ghost{background:var(--surface2);color:var(--muted);border:1px solid var(--border)}
.btn-ghost:hover{color:var(--text);border-color:var(--muted)}
.btn-save{background:var(--accent);color:#000;padding:8px 22px;font-size:14px}

/* ── LAYOUT: full-width two-column ── */
.page-body{display:grid;grid-template-columns:1fr 1fr;gap:12px;
  padding:14px 16px;position:relative;z-index:1;align-items:start}
.full-col{grid-column:1/-1}

/* ── SECTION CARDS ── */
.section{background:var(--surface);border:1px solid var(--border);border-radius:12px;overflow:hidden}
.sec-head{padding:11px 14px;border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:8px;cursor:pointer;user-select:none;
  background:linear-gradient(90deg,rgba(0,212,255,.04),transparent)}
.sec-head h2{font-family:'Orbitron',monospace;font-size:11px;font-weight:700;
  letter-spacing:1.8px;color:var(--accent);text-transform:uppercase;flex:1}
.toggle-icon{color:var(--muted);font-size:12px;transition:transform .2s;font-family:'Share Tech Mono',monospace}
.collapsed .toggle-icon{transform:rotate(-90deg)}
.sec-body{padding:12px 14px}
.sec-body.hidden{display:none}

/* ── FORM GRID inside section ── */
.fg{display:grid;gap:8px}
.fg-2{grid-template-columns:1fr 1fr}
.fg-3{grid-template-columns:1fr 1fr 1fr}
.fg-4{grid-template-columns:repeat(4,1fr)}
.fg-5{grid-template-columns:repeat(5,1fr)}
.span2{grid-column:span 2}
.span-all{grid-column:1/-1}

.field{display:flex;flex-direction:column;gap:4px}
.lbl{font-family:'Share Tech Mono',monospace;font-size:9.5px;text-transform:uppercase;
  letter-spacing:1.3px;color:var(--muted)}
.req{color:var(--danger)}

input,select,textarea{
  background:var(--surface2);border:1px solid var(--border);border-radius:7px;
  padding:7px 10px;color:var(--text);font-size:13px;
  font-family:'Rajdhani',sans-serif;font-weight:500;outline:none;width:100%;
  transition:border-color .18s,box-shadow .18s}
input:focus,select:focus,textarea:focus{
  border-color:var(--accent);box-shadow:0 0 0 2px color-mix(in srgb,var(--accent) 15%,transparent)}
input::placeholder,textarea::placeholder{color:var(--muted);font-size:12px}
select option{background:var(--surface2)}
textarea{resize:vertical;min-height:70px;line-height:1.55}

/* password field */
.pw-wrap{position:relative}
.pw-wrap input{padding-right:36px;background:var(--surface2);
  border:1px solid var(--border);font-family:'Share Tech Mono',monospace;
  letter-spacing:.5px}
.pw-toggle{position:absolute;right:8px;top:50%;transform:translateY(-50%);
  background:none;border:none;cursor:pointer;color:var(--muted);font-size:14px;
  padding:2px;transition:color .15s;line-height:1}
.pw-toggle:hover{color:var(--accent)}

.hint{font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--muted);margin-top:2px}
.cond{display:none}
.cond.show{display:flex;flex-direction:column;gap:4px}

/* ── ENV TABLE (compact) ── */
.env-wrap{overflow-x:auto}
.env-tbl{width:100%;border-collapse:collapse;min-width:700px}
.env-tbl th{font-family:'Share Tech Mono',monospace;font-size:9px;text-transform:uppercase;
  letter-spacing:1px;color:var(--muted);padding:6px 6px 8px;text-align:left;
  border-bottom:1px solid var(--border)}
.env-tbl td{padding:5px 5px;border-bottom:1px solid rgba(30,45,74,.4);vertical-align:middle}
.env-tbl tr:last-child td{border-bottom:none}
.env-tbl input{padding:6px 8px;font-size:12px;border-radius:6px}
.env-name{font-family:'Share Tech Mono',monospace;font-size:11px;font-weight:700;
  white-space:nowrap;padding:5px 8px;display:flex;align-items:center;gap:5px}
.env-dot{width:7px;height:7px;border-radius:50%;display:inline-block;flex-shrink:0}

/* ── FORM ACTIONS ── */
.form-footer{display:flex;gap:10px;justify-content:flex-end;
  padding:12px 16px;border-top:1px solid var(--border);
  background:var(--surface);position:sticky;bottom:0;z-index:50}

/* ── ERROR ── */
.err-box{background:rgba(255,61,90,.08);border:1px solid rgba(255,61,90,.3);
  color:var(--danger);padding:10px 14px;border-radius:8px;font-size:12px;
  margin:12px 16px 0;font-family:'Share Tech Mono',monospace}

@media(max-width:900px){.page-body{grid-template-columns:1fr}}
@media(max-width:600px){.fg-2,.fg-3,.fg-4,.fg-5{grid-template-columns:1fr}}
</style>
</head>
<body>

<div class="topbar">
  <span class="logo-txt">DEVVAULT</span>
  <span style="color:var(--border)">|</span>
  <span class="page-ttl"><?=$p?'✏ Edit':'＋ Add'?> Project</span>
  <div class="topbar-r">
    <a href="index.php" class="btn btn-ghost">← Back</a>
  </div>
</div>

<?php if($error):?>
<div class="err-box">⚠ <?=htmlspecialchars($error)?></div>
<?php endif;?>

<form method="POST" id="pf">
<input type="hidden" name="csrf" value="<?=csrf_token()?>">

<div class="page-body">

<!-- ══ LEFT COLUMN ══ -->

<!-- Department Info -->
<div class="section">
  <div class="sec-head" onclick="toggleSec(this)">
    <h2>🏢 Department Info</h2>
    <span class="toggle-icon">▾</span>
  </div>
  <div class="sec-body">
    <div class="fg fg-2">
      <div class="field"><span class="lbl">Department Name</span>
        <input type="text" name="department_name" placeholder="e.g. IT Department" value="<?=$v('department_name')?>">
      </div>
      <div class="field"><span class="lbl">Nodal Officer Name</span>
        <input type="text" name="nodal_officer_name" placeholder="Full name" value="<?=$v('nodal_officer_name')?>">
      </div>
      <div class="field"><span class="lbl">Designation</span>
        <input type="text" name="nodal_designation" placeholder="e.g. Sr. Developer" value="<?=$v('nodal_designation')?>">
      </div>
      <div class="field"><span class="lbl">Contact No.</span>
        <input type="tel" name="nodal_contact" placeholder="10-digit mobile" value="<?=$v('nodal_contact')?>">
      </div>
      <div class="field span2"><span class="lbl">Department Email</span>
        <input type="email" name="dept_email" placeholder="dept@gov.in" value="<?=$v('dept_email')?>">
      </div>
    </div>
  </div>
</div>

<!-- App Infrastructure -->
<div class="section">
  <div class="sec-head" onclick="toggleSec(this)">
    <h2>🖥 App Infrastructure</h2>
    <span class="toggle-icon">▾</span>
  </div>
  <div class="sec-body">
    <div class="fg fg-2">
      <div class="field"><span class="lbl">Application IP</span>
        <input type="text" name="app_ip" placeholder="192.168.x.x" value="<?=$v('app_ip')?>">
      </div>
      <div class="field"><span class="lbl">LB IP Address</span>
        <input type="text" name="app_lb_ip" placeholder="Load Balancer IP" value="<?=$v('app_lb_ip')?>">
      </div>
      <div class="field"><span class="lbl">OS Version</span>
        <select name="app_os" onchange="handleOther(this,'app-os-other')">
          <option value="">— Select OS —</option>
          <?php foreach($appOsOpts as $o):?>
          <option value="<?=htmlspecialchars($o)?>" <?=$sel('app_os',$o)?>><?=htmlspecialchars($o)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="field cond" id="app-os-other" style="<?=($p['app_os']??'')==='Other'?'display:flex;flex-direction:column;gap:4px':''?>">
        <span class="lbl">Specify OS</span>
        <input type="text" name="app_os_other" placeholder="e.g. Win 2022" value="<?=$v('app_os_other')?>">
        <span class="hint">Auto-saved to dropdown</span>
      </div>
      <div class="field"><span class="lbl">Core</span>
        <input type="text" name="app_core" placeholder="e.g. 4 vCPU" value="<?=$v('app_core')?>">
      </div>
      <div class="field"><span class="lbl">RAM</span>
        <input type="text" name="app_ram" placeholder="e.g. 8 GB" value="<?=$v('app_ram')?>">
      </div>
      <div class="field"><span class="lbl">Primary Storage</span>
        <input type="text" name="app_primary_storage" placeholder="e.g. 100 GB SSD" value="<?=$v('app_primary_storage')?>">
      </div>
      <div class="field"><span class="lbl">Secondary Storage</span>
        <input type="text" name="app_secondary_storage" placeholder="e.g. 500 GB HDD" value="<?=$v('app_secondary_storage')?>">
      </div>
      <div class="field"><span class="lbl">Individual / Shared</span>
        <select name="app_hosting_type">
          <option value="individual" <?=$sel('app_hosting_type','individual')?>>Individual</option>
          <option value="shared" <?=$sel('app_hosting_type','shared')?>>Shared</option>
        </select>
      </div>
      <div class="field span2"><span class="lbl">App Infra Remark</span>
        <textarea name="app_infra_remark" rows="2" placeholder="Notes about app infra..."><?=$v('app_infra_remark')?></textarea>
      </div>
    </div>
  </div>
</div>

<!-- DB Infrastructure -->
<div class="section">
  <div class="sec-head" onclick="toggleSec(this)">
    <h2>🗄 DB Infrastructure</h2>
    <span class="toggle-icon">▾</span>
  </div>
  <div class="sec-body">
    <div class="fg fg-2">
      <div class="field"><span class="lbl">DB IP Address</span>
        <input type="text" name="db_ip" placeholder="192.168.x.x" value="<?=$v('db_ip')?>">
      </div>
      <div class="field"><span class="lbl">DB Name</span>
        <input type="text" name="db_name" placeholder="e.g. myapp_db" value="<?=$v('db_name')?>">
      </div>
      <div class="field"><span class="lbl">DB Version</span>
        <select name="db_version" onchange="handleOther(this,'db-ver-other')">
          <option value="">— Select DB —</option>
          <?php foreach($dbVerOpts as $o):?>
          <option value="<?=htmlspecialchars($o)?>" <?=$sel('db_version',$o)?>><?=htmlspecialchars($o)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="field cond" id="db-ver-other" style="<?=($p['db_version']??'')==='Other'?'display:flex;flex-direction:column;gap:4px':''?>">
        <span class="lbl">Specify DB</span>
        <input type="text" name="db_version_other" placeholder="e.g. MongoDB 6.0" value="<?=$v('db_version_other')?>">
        <span class="hint">Auto-saved to dropdown</span>
      </div>
      <div class="field"><span class="lbl">DB Server OS</span>
        <select name="db_os" onchange="handleOther(this,'db-os-other')">
          <option value="">— Select OS —</option>
          <?php foreach($dbOsOpts as $o):?>
          <option value="<?=htmlspecialchars($o)?>" <?=$sel('db_os',$o)?>><?=htmlspecialchars($o)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="field cond" id="db-os-other" style="<?=($p['db_os']??'')==='Other'?'display:flex;flex-direction:column;gap:4px':''?>">
        <span class="lbl">Specify DB OS</span>
        <input type="text" name="db_os_other" placeholder="e.g. RHEL 9" value="<?=$v('db_os_other')?>">
        <span class="hint">Auto-saved to dropdown</span>
      </div>
      <div class="field"><span class="lbl">Shared / Individual</span>
        <select name="db_hosting_type">
          <option value="individual" <?=$sel('db_hosting_type','individual')?>>Individual</option>
          <option value="shared" <?=$sel('db_hosting_type','shared')?>>Shared</option>
        </select>
      </div>
      <div class="field span2"><span class="lbl">DB Remark</span>
        <textarea name="db_remark" rows="2" placeholder="Notes about database..."><?=$v('db_remark')?></textarea>
      </div>
    </div>
  </div>
</div>

<!-- ══ RIGHT COLUMN ══ -->

<!-- Project Info -->
<div class="section" style="grid-row:1/span 2;grid-column:2">
  <div class="sec-head" onclick="toggleSec(this)">
    <h2>🗂 Project Information</h2>
    <span class="toggle-icon">▾</span>
  </div>
  <div class="sec-body">
    <div class="fg fg-2">
      <div class="field"><span class="lbl">Technology <span class="req">*</span></span>
        <select name="technology" onchange="handleOther(this,'tech-other')">
          <option value="">— Select Technology —</option>
          <?php foreach($techOpts as $t):?>
          <option value="<?=htmlspecialchars($t)?>" <?=$sel('technology',$t)?>><?=htmlspecialchars($t)?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="field cond" id="tech-other" style="<?=($p['technology']??'')==='Other'?'display:flex;flex-direction:column;gap:4px':''?>">
        <span class="lbl">Specify Technology</span>
        <input type="text" name="technology_other" placeholder="Enter tech name" value="<?=$v('technology_other')?>">
        <span class="hint">Auto-saved to dropdown</span>
      </div>
      <div class="field"><span class="lbl">Website / Application</span>
        <input type="text" name="website_app" placeholder="Website, Mobile App, Portal..." value="<?=$v('website_app')?>">
      </div>
      <div class="field span2"><span class="lbl">Project Name <span class="req">*</span></span>
        <input type="text" name="project_name" placeholder="e.g. Employee Portal" required value="<?=$v('project_name')?>">
      </div>
      <div class="field span2"><span class="lbl">Description</span>
        <textarea name="description" rows="2" placeholder="Short description..."><?=$v('description')?></textarea>
      </div>

      <!-- Status row — all in one line -->
      <div class="field"><span class="lbl">Current Status</span>
        <select name="current_status" id="status-sel" onchange="handleStatus(this.value)">
          <option value="live" <?=$sel('current_status','live')?>>🟢 Live</option>
          <option value="under_development" <?=$sel('current_status','under_development')?>>🟡 Under Dev</option>
          <option value="redevelopment" <?=$sel('current_status','redevelopment')?>>🔵 Redevelopment</option>
          <option value="closed" <?=$sel('current_status','closed')?>>🔴 Closed</option>
        </select>
      </div>
      <div class="field"><span class="lbl">Last Audit Date</span>
        <input type="date" name="last_audit_date" value="<?=$v('last_audit_date')?>">
      </div>
      <div class="field cond" id="live-date" style="<?=($p['current_status']??'live')==='live'?'display:flex;flex-direction:column;gap:4px':''?>">
        <span class="lbl">Live Date</span>
        <input type="date" name="live_date" value="<?=$v('live_date')?>">
      </div>
      <div class="field cond" id="visitor-cnt" style="<?=($p['current_status']??'live')==='live'?'display:flex;flex-direction:column;gap:4px':''?>">
        <span class="lbl">Total Visitors</span>
        <input type="text" name="total_visitor_counter" placeholder="e.g. 1,50,000" value="<?=$v('total_visitor_counter')?>">
      </div>
      <div class="field cond" id="last-update" style="<?=($p['current_status']??'live')==='live'?'display:flex;flex-direction:column;gap:4px':''?>">
        <span class="lbl">Last Update Date</span>
        <input type="date" name="last_update_date" value="<?=$v('last_update_date')?>">
      </div>
    </div>
  </div>
</div>

<!-- General Remarks (right col) -->
<div class="section" style="grid-column:2">
  <div class="sec-head" onclick="toggleSec(this)">
    <h2>📝 General Remarks</h2>
    <span class="toggle-icon">▾</span>
  </div>
  <div class="sec-body">
    <div class="field">
      <span class="lbl">Notes / Remarks</span>
      <textarea name="general_remark" rows="5"
        placeholder="SSH commands, deployment steps, API key locations, important notes..."><?=$v('general_remark')?></textarea>
    </div>
  </div>
</div>

<!-- ══ ENVIRONMENT TABLE — full width ══ -->
<div class="section full-col">
  <div class="sec-head" onclick="toggleSec(this)">
    <h2>🌐 Environment Details</h2>
    <span class="toggle-icon">▾</span>
  </div>
  <div class="sec-body" style="padding:10px 12px">
    <div class="env-wrap">
      <table class="env-tbl">
        <thead>
          <tr>
            <th style="width:90px">Env</th>
            <th>URL</th>
            <th>Admin URL</th>
            <th>Login ID</th>
            <th style="width:170px">Password</th>
            <th>Remark</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $envList = [
          'local'      => ['#40c4ff','🔵'],
          'staging'    => ['#ffd740','🟡'],
          'production' => ['#00e676','🟢'],
          'audit'      => ['#ea80fc','🟣'],
          'other'      => ['#8c9eff','⚪'],
        ];
        foreach ($envList as $env => [$clr,$icon]):
          $ep = fn($f) => htmlspecialchars($p["env_{$env}_{$f}"] ?? '');
          $hasPw = !empty($p["env_{$env}_password"]);
        ?>
        <tr>
          <td>
            <div class="env-name" style="color:<?=$clr?>">
              <span class="env-dot" style="background:<?=$clr?>"></span>
              <?=ucfirst($env)?>
            </div>
          </td>
          <td><input type="url" name="env_<?=$env?>_url" placeholder="https://..." value="<?=$ep('url')?>"></td>
          <td><input type="url" name="env_<?=$env?>_admin_url" placeholder="https://.../admin" value="<?=$ep('admin_url')?>"></td>
          <td><input type="text" name="env_<?=$env?>_id" placeholder="username/email" autocomplete="off" value="<?=$ep('id')?>"></td>
          <td>
            <div class="pw-wrap">
              <input type="password" name="env_<?=$env?>_password" id="pw-<?=$env?>"
                placeholder="<?=$hasPw?'(keep existing)':'password'?>"
                autocomplete="new-password">
              <button type="button" class="pw-toggle" onclick="tpw('pw-<?=$env?>')">👁</button>
            </div>
          </td>
          <td><input type="text" name="env_<?=$env?>_remark" placeholder="remark..." value="<?=$ep('remark')?>"></td>
        </tr>
        <?php endforeach;?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</div><!-- /page-body -->

<div class="form-footer">
  <a href="index.php" class="btn btn-ghost">✕ Cancel</a>
  <button type="submit" class="btn btn-save">💾 Save Project</button>
</div>
</form>

<script>
function toggleSec(head){
  head.classList.toggle('collapsed');
  head.nextElementSibling.classList.toggle('hidden')}

function handleOther(sel,otherId){
  const el=document.getElementById(otherId);
  if(!el)return;
  el.style.display=sel.value==='Other'?'flex':'none';
  el.style.flexDirection='column';el.style.gap='4px'}

function handleStatus(val){
  const isLive=val==='live';
  ['live-date','visitor-cnt','last-update'].forEach(id=>{
    const el=document.getElementById(id);
    if(el){el.style.display=isLive?'flex':'none';
      el.style.flexDirection='column';el.style.gap='4px'}})}

function tpw(id){
  const f=document.getElementById(id);
  if(f)f.type=f.type==='password'?'text':'password'}

document.addEventListener('DOMContentLoaded',()=>{
  handleStatus(document.getElementById('status-sel').value)})
</script>
</body>
</html>
