<?php
require_once __DIR__ . '/auth.php';
require_login();

$db = get_db();

// Stats
$stats = [];
foreach (['local','staging','production','audit','other'] as $e) {
    $st = $db->prepare("SELECT COUNT(*) FROM projects WHERE LOWER(current_status)!='closed'");
    // count by env having that env url filled
    $col = "env_{$e}_url";
    $st2 = $db->query("SELECT COUNT(*) FROM projects WHERE `$col` != '' AND `$col` IS NOT NULL");
    $stats[$e] = $st2 ? (int)$st2->fetchColumn() : 0;
}
$total = (int)$db->query("SELECT COUNT(*) FROM projects")->fetchColumn();

// Status counts for dashboard table
$statusCounts = [];
foreach (['live','under_development','redevelopment','closed'] as $s) {
    $st = $db->prepare("SELECT COUNT(*) FROM projects WHERE current_status=?");
    $st->execute([$s]);
    $statusCounts[$s] = (int)$st->fetchColumn();
}

// Tech-wise breakdown
$techRows = $db->query("
    SELECT COALESCE(NULLIF(technology_other,''),technology) as tech,
           current_status, COUNT(*) as cnt
    FROM projects
    GROUP BY tech, current_status
    ORDER BY tech
")->fetchAll();

// Build tech table data
$techTable = [];
foreach ($techRows as $r) {
    $techTable[$r['tech']][$r['current_status']] = (int)$r['cnt'];
}

// Search & filter
$q      = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';
$tech   = $_GET['tech'] ?? '';

$where = ['1=1']; $params = [];
if ($q) {
    $where[] = '(project_name LIKE ? OR department_name LIKE ? OR description LIKE ? OR app_ip LIKE ? OR nodal_officer_name LIKE ?)';
    $like = "%$q%";
    $params = array_merge($params, [$like,$like,$like,$like,$like]);
}
if ($status) { $where[] = 'current_status=?'; $params[] = $status; }
if ($tech)   {
    $where[] = '(technology=? OR technology_other=?)';
    $params  = array_merge($params, [$tech, $tech]);
}

$sql = "SELECT * FROM projects WHERE ".implode(' AND ',$where)." ORDER BY updated_at DESC";
$st  = $db->prepare($sql); $st->execute($params);
$projects = $st->fetchAll();

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

// User prefs
$accent  = user_pref('accent','#00d4ff');
$fsize   = user_pref('font_size','14');
$ffamily = user_pref('font_family','Rajdhani');
$theme   = user_pref('theme','dark');

$statusLabels = ['live'=>'Live','under_development'=>'Under Dev','redevelopment'=>'Redevelopment','closed'=>'Closed'];
$statusColors = ['live'=>'#00e676','under_development'=>'#ffd740','redevelopment'=>'#40c4ff','closed'=>'#ff3d5a'];
$envColors    = ['local'=>'#40c4ff','staging'=>'#ffd740','production'=>'#00e676','audit'=>'#ea80fc','other'=>'#8c9eff'];
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DevVault Pro — Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Orbitron:wght@700;900&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --accent:<?=$accent?>;
  --fs:<?=$fsize?>px;
  --bg:#070b14;--surface:#0d1422;--surface2:#111a2e;--surface3:#16213e;
  --border:#1e2d4a;--text:#e8edf5;--muted:#5a7a9a;
  --success:#00e676;--danger:#ff3d5a;--amber:#ffd740;--purple:#ea80fc;--blue:#40c4ff;
}
[data-theme="light"]{
  --bg:#f0f4f8;--surface:#fff;--surface2:#e8edf5;--surface3:#dde3ed;
  --border:#c8d4e0;--text:#0d1422;--muted:#5a7a9a;
}

html{font-size:var(--fs)}
body{font-family:'<?=$ffamily?>',sans-serif;background:var(--bg);color:var(--text);
  min-height:100vh;position:relative}

body::before{content:'';position:fixed;inset:0;
  background-image:linear-gradient(rgba(0,212,255,.02) 1px,transparent 1px),
    linear-gradient(90deg,rgba(0,212,255,.02) 1px,transparent 1px);
  background-size:40px 40px;pointer-events:none;z-index:0}
[data-theme="light"] body::before{opacity:.3}

/* ── TOPBAR ── */
.topbar{
  position:sticky;top:0;z-index:100;
  background:rgba(7,11,20,.92);
  border-bottom:1px solid var(--border);
  backdrop-filter:blur(12px);
  padding:0 24px;height:58px;
  display:flex;align-items:center;gap:12px}
[data-theme="light"] .topbar{background:rgba(240,244,248,.92)}

.logo-text{font-family:'Orbitron',monospace;font-size:16px;font-weight:900;
  letter-spacing:2px;color:var(--accent);white-space:nowrap;flex-shrink:0;
  text-shadow:0 0 20px var(--accent)}

.topbar-search{flex:1;position:relative;max-width:460px}
.topbar-search input{width:100%;background:var(--surface2);border:1px solid var(--border);
  border-radius:8px;padding:8px 14px 8px 36px;color:var(--text);font-size:13px;
  font-family:'Share Tech Mono',monospace;outline:none;transition:border-color .2s,box-shadow .2s}
.topbar-search input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(0,212,255,.08)}
.topbar-search .si{position:absolute;left:11px;top:50%;transform:translateY(-50%);
  color:var(--muted);font-size:14px;pointer-events:none}

.topbar-actions{display:flex;align-items:center;gap:8px;margin-left:auto}

.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:7px;
  font-size:13px;font-weight:600;font-family:'Rajdhani',sans-serif;letter-spacing:.5px;
  cursor:pointer;border:none;text-decoration:none;transition:all .15s;white-space:nowrap}
.btn:active{transform:scale(.97)}
.btn-accent{background:var(--accent);color:#000}
.btn-accent:hover{opacity:.85}
.btn-ghost{background:var(--surface2);color:var(--muted);border:1px solid var(--border)}
.btn-ghost:hover{color:var(--text);border-color:var(--muted)}
.btn-danger{background:rgba(255,61,90,.12);color:var(--danger);border:1px solid rgba(255,61,90,.25)}
.btn-danger:hover{background:rgba(255,61,90,.22)}
.btn-sm{padding:5px 10px;font-size:12px}
.btn-icon{width:32px;height:32px;padding:0;justify-content:center;border-radius:8px}

/* ── CONTENT ── */
.content{padding:20px 24px;position:relative;z-index:1}

/* ── STATS ROW ── */
.stats-row{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:18px}

.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;
  padding:14px 16px;position:relative;overflow:hidden;cursor:pointer;
  transition:border-color .2s,transform .2s}
.stat-card:hover{transform:translateY(-2px)}
.stat-card::after{content:'';position:absolute;bottom:0;left:0;right:0;height:2px;background:var(--clr,var(--accent))}
.stat-card .num{font-family:'Orbitron',monospace;font-size:24px;font-weight:900;
  color:var(--clr,var(--accent));line-height:1;text-shadow:0 0 20px var(--clr,var(--accent))}
.stat-card .lbl{font-family:'Share Tech Mono',monospace;font-size:10px;
  color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-top:5px}

/* ── TOOLBAR ── */
.toolbar{display:flex;align-items:center;gap:8px;margin-bottom:16px;flex-wrap:wrap}
.filter-select{background:var(--surface2);border:1px solid var(--border);border-radius:7px;
  padding:7px 12px;color:var(--text);font-size:13px;font-family:'Share Tech Mono',monospace;
  outline:none;cursor:pointer}
.filter-select:focus{border-color:var(--accent)}

/* ── FLASH ── */
.flash{padding:10px 16px;border-radius:8px;font-size:13px;font-family:'Share Tech Mono',monospace;
  margin-bottom:14px;display:flex;align-items:center;gap:8px}
.flash-success{background:rgba(0,230,118,.08);border:1px solid rgba(0,230,118,.25);color:var(--success)}
.flash-error{background:rgba(255,61,90,.08);border:1px solid rgba(255,61,90,.25);color:var(--danger)}

/* ── CARDS ── */
.cards-list{display:flex;flex-direction:column;gap:12px}

.project-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;
  overflow:hidden;transition:border-color .2s,box-shadow .2s;position:relative}
.project-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;
  background:var(--status-clr,var(--accent))}
.project-card:hover{border-color:var(--accent);box-shadow:0 4px 24px rgba(0,212,255,.08)}

.card-main{display:grid;grid-template-columns:minmax(220px,2fr) repeat(3,1fr) 140px;
  gap:0;align-items:stretch}

.card-col{padding:14px 16px;border-right:1px solid var(--border)}
.card-col:last-child{border-right:none}

.card-col-title{display:flex;flex-direction:column;gap:4px}
.pname{font-size:16px;font-weight:700;letter-spacing:.3px;line-height:1.2}
.pdept{font-size:11px;font-family:'Share Tech Mono',monospace;color:var(--muted)}
.ptags{display:flex;gap:5px;margin-top:6px;flex-wrap:wrap}
.ptag{padding:2px 8px;border-radius:20px;font-size:10px;font-family:'Share Tech Mono',monospace;
  font-weight:600;text-transform:uppercase;letter-spacing:.5px;border:1px solid currentColor}

.col-label{font-family:'Share Tech Mono',monospace;font-size:9px;text-transform:uppercase;
  letter-spacing:1.5px;color:var(--muted);margin-bottom:6px}

.env-grid{display:flex;flex-direction:column;gap:3px}
.env-row{display:flex;align-items:center;gap:6px;font-size:11px}
.env-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
.env-name{font-family:'Share Tech Mono',monospace;color:var(--muted);min-width:70px;font-size:10px}
.env-url{color:var(--accent);text-decoration:none;font-size:11px;font-family:'Share Tech Mono',monospace;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:180px}
.env-url:hover{text-decoration:underline}
.env-na{color:var(--border);font-size:10px;font-style:italic}

.info-kv{display:flex;flex-direction:column;gap:4px}
.kv{display:flex;flex-direction:column;gap:1px}
.kv .k{font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:1px}
.kv .v{font-size:12px;font-weight:600;font-family:'Share Tech Mono',monospace}

.card-actions-col{display:flex;flex-direction:column;gap:6px;justify-content:center;padding:12px}
.pw-reveal{font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--muted);
  cursor:pointer;background:none;border:none;padding:2px 0;transition:color .15s}
.pw-reveal:hover{color:var(--accent)}

/* ── STATUS BADGE ── */
.status-badge{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;
  border-radius:20px;font-size:10px;font-family:'Share Tech Mono',monospace;
  font-weight:600;text-transform:uppercase;letter-spacing:.8px;border:1px solid currentColor}

/* ── DASHBOARD TABLE ── */
.section-title{font-family:'Orbitron',monospace;font-size:13px;font-weight:700;
  color:var(--accent);letter-spacing:2px;text-transform:uppercase;margin-bottom:12px;
  display:flex;align-items:center;gap:8px}
.section-title::after{content:'';flex:1;height:1px;background:var(--border)}

table.dash-table{width:100%;border-collapse:collapse;font-size:13px}
table.dash-table th{text-align:left;padding:8px 12px;font-family:'Share Tech Mono',monospace;
  font-size:10px;text-transform:uppercase;letter-spacing:1px;color:var(--muted);
  border-bottom:1px solid var(--border)}
table.dash-table td{padding:9px 12px;border-bottom:1px solid rgba(30,45,74,.5);
  font-family:'Share Tech Mono',monospace;font-size:12px}
table.dash-table tr:last-child td{border-bottom:none}
table.dash-table tr:hover td{background:rgba(0,212,255,.03)}
table.dash-table .num-cell{font-family:'Orbitron',monospace;font-weight:700;text-align:center}

/* ── THEME PANEL ── */
.theme-panel{display:none;position:absolute;right:0;top:44px;
  background:var(--surface);border:1px solid var(--border);border-radius:12px;
  padding:16px;width:260px;z-index:200;box-shadow:0 8px 32px rgba(0,0,0,.4)}
.theme-panel.open{display:block}
.tp-label{font-size:10px;font-family:'Share Tech Mono',monospace;text-transform:uppercase;
  letter-spacing:1px;color:var(--muted);margin-bottom:7px}
.color-swatches{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px}
.swatch{width:24px;height:24px;border-radius:6px;border:2px solid transparent;
  cursor:pointer;transition:transform .15s}
.swatch:hover,.swatch.active{transform:scale(1.2);border-color:#fff}
.tp-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.tp-row select,.tp-row input{background:var(--surface2);border:1px solid var(--border);
  border-radius:6px;padding:5px 8px;color:var(--text);font-size:12px;
  font-family:'Share Tech Mono',monospace;outline:none}
.tp-row input[type=range]{width:100px;cursor:pointer;accent-color:var(--accent)}

/* ── EMPTY ── */
.empty{text-align:center;padding:60px;color:var(--muted)}
.empty .icon{font-size:48px;margin-bottom:12px}
.empty h3{font-size:18px;font-weight:700;color:var(--text);margin-bottom:6px}
.empty p{font-size:13px;font-family:'Share Tech Mono',monospace}

/* ── TOAST ── */
.toast{position:fixed;bottom:20px;right:20px;background:var(--surface);
  border:1px solid var(--border);border-radius:10px;padding:10px 16px;
  font-size:12px;font-family:'Share Tech Mono',monospace;
  box-shadow:0 8px 32px rgba(0,0,0,.5);z-index:999;display:none;
  align-items:center;gap:8px;animation:slideUp .25s ease}
@keyframes slideUp{from{transform:translateY(16px);opacity:0}to{transform:translateY(0);opacity:1}}

/* ── GRID SECTIONS ── */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px}
.panel{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:16px}

@media(max-width:900px){
  .card-main{grid-template-columns:1fr 1fr}
  .stats-row{grid-template-columns:repeat(3,1fr)}
  .two-col{grid-template-columns:1fr}
}
@media(max-width:600px){
  .card-main{grid-template-columns:1fr}
  .stats-row{grid-template-columns:repeat(2,1fr)}
  .topbar{padding:0 12px}
  .content{padding:14px}
}
</style>
</head>
<body>

<!-- TOPBAR -->
<div class="topbar">
  <span class="logo-text">DEVVAULT</span>

  <form method="GET" class="topbar-search" id="search-form">
    <span class="si">🔍</span>
    <input type="text" name="q" id="q" placeholder="Search project, dept, IP, officer..." value="<?=htmlspecialchars($q)?>">
    <?php if($status):?><input type="hidden" name="status" value="<?=htmlspecialchars($status)?>"> <?php endif;?>
    <?php if($tech):?><input type="hidden" name="tech" value="<?=htmlspecialchars($tech)?>"> <?php endif;?>
  </form>

  <div class="topbar-actions">
    <?php if(can_edit()):?>
    <a href="project_form.php" class="btn btn-accent">＋ Add Project</a>
    <?php endif;?>

    <?php if(is_admin()):?>
    <a href="admin.php" class="btn btn-ghost btn-icon" title="Admin">⚙</a>
    <?php endif;?>

    <a href="export.php" class="btn btn-ghost btn-icon" title="Export">📤</a>

    <div style="position:relative">
      <button class="btn btn-ghost btn-icon" title="Theme" onclick="toggleThemePanel()" id="theme-btn">🎨</button>
      <div class="theme-panel" id="theme-panel">
        <div class="tp-label">Accent Color</div>
        <div class="color-swatches">
          <?php foreach(['#00d4ff','#00e676','#ffd740','#ff3d5a','#ea80fc','#8c9eff','#ff6e40','#40c4ff','#ffffff'] as $c):?>
          <div class="swatch <?=$c===$accent?'active':''?>"
               style="background:<?=$c?>"
               onclick="setAccent('<?=$c?>')"></div>
          <?php endforeach;?>
        </div>
        <div class="tp-label">Custom Color</div>
        <div class="tp-row" style="margin-bottom:12px">
          <input type="color" id="custom-color" value="<?=$accent?>" oninput="setAccent(this.value)">
          <span style="font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--muted)" id="accent-hex"><?=$accent?></span>
        </div>
        <div class="tp-label">Theme</div>
        <div class="tp-row">
          <select onchange="setTheme(this.value)">
            <option value="dark" <?=$theme==='dark'?'selected':''?>>🌙 Dark</option>
            <option value="light" <?=$theme==='light'?'selected':''?>>☀ Light</option>
          </select>
        </div>
        <div class="tp-label">Font Family</div>
        <div class="tp-row">
          <select onchange="setFont(this.value)" id="font-select">
            <?php foreach(['Rajdhani','Share Tech Mono','Orbitron'] as $f):?>
            <option value="<?=$f?>" <?=$ffamily===$f?'selected':''?>><?=$f?></option>
            <?php endforeach;?>
          </select>
        </div>
        <div class="tp-label">Font Size: <span id="fs-val"><?=$fsize?></span>px</div>
        <div class="tp-row">
          <input type="range" min="11" max="18" value="<?=$fsize?>" oninput="setFontSize(this.value)">
        </div>
        <button class="btn btn-accent" style="width:100%;margin-top:4px" onclick="savePrefs()">Save Preferences</button>
      </div>
    </div>

    <a href="logout.php" class="btn btn-ghost btn-icon" title="Logout">⏏</a>
  </div>
</div>

<!-- CONTENT -->
<div class="content">

<?php if($flash):?>
<div class="flash flash-<?=$flash['type']?>"><?=htmlspecialchars($flash['msg'])?></div>
<?php endif;?>

<!-- STATS -->
<div class="stats-row">
  <div class="stat-card" style="--clr:var(--accent)" onclick="window.location='index.php'">
    <div class="num"><?=$total?></div>
    <div class="lbl">Total Projects</div>
  </div>
  <?php foreach(['local'=>$envColors['local'],'staging'=>$envColors['staging'],'production'=>$envColors['production'],'audit'=>$envColors['audit'],'other'=>$envColors['other']] as $env=>$clr):?>
  <div class="stat-card" style="--clr:<?=$clr?>" onclick="window.location='index.php?env=<?=$env?>'">
    <div class="num"><?=$stats[$env]?></div>
    <div class="lbl"><?=ucfirst($env)?></div>
  </div>
  <?php endforeach;?>
</div>

<!-- DASHBOARD TABLES -->
<div class="two-col">
  <!-- Status breakdown -->
  <div class="panel">
    <div class="section-title">📊 Status Overview</div>
    <table class="dash-table">
      <tr><th>Status</th><th style="text-align:center">Count</th></tr>
      <?php foreach($statusLabels as $k=>$lbl):?>
      <tr>
        <td><span class="status-badge" style="color:<?=$statusColors[$k]?>;border-color:<?=$statusColors[$k]?>40"><?=$lbl?></span></td>
        <td class="num-cell" style="color:<?=$statusColors[$k]?>"><?=$statusCounts[$k]??0?></td>
      </tr>
      <?php endforeach;?>
    </table>
  </div>

  <!-- Tech-wise breakdown -->
  <div class="panel">
    <div class="section-title">🛠 Technology Breakdown</div>
    <table class="dash-table">
      <tr>
        <th>Technology</th>
        <th style="text-align:center;color:<?=$statusColors['live']?>">Live</th>
        <th style="text-align:center;color:<?=$statusColors['under_development']?>">Dev</th>
        <th style="text-align:center;color:<?=$statusColors['redevelopment']?>">Redev</th>
        <th style="text-align:center;color:<?=$statusColors['closed']?>">Closed</th>
      </tr>
      <?php if(empty($techTable)):?>
      <tr><td colspan="5" style="color:var(--muted);text-align:center;padding:16px">No data yet</td></tr>
      <?php else: foreach($techTable as $tech=>$counts):?>
      <tr>
        <td style="font-weight:600"><?=htmlspecialchars($tech)?></td>
        <?php foreach(['live','under_development','redevelopment','closed'] as $s):?>
        <td class="num-cell" style="color:<?=$statusColors[$s]?>"><?=$counts[$s]??'–'?></td>
        <?php endforeach;?>
      </tr>
      <?php endforeach; endif;?>
    </table>
  </div>
</div>

<!-- FILTER TOOLBAR -->
<div class="toolbar">
  <select class="filter-select" onchange="applyFilter('status',this.value)">
    <option value="">All Status</option>
    <?php foreach($statusLabels as $k=>$l):?>
    <option value="<?=$k?>" <?=$status===$k?'selected':''?>><?=$l?></option>
    <?php endforeach;?>
  </select>

  <select class="filter-select" onchange="applyFilter('tech',this.value)">
    <option value="">All Technologies</option>
    <?php foreach(array_keys($techTable) as $t):?>
    <option value="<?=htmlspecialchars($t)?>" <?=$_GET['tech']??''===$t?'selected':''?>><?=htmlspecialchars($t)?></option>
    <?php endforeach;?>
  </select>

  <?php if($q||$status||$tech):?>
  <a href="index.php" class="btn btn-ghost btn-sm">✕ Clear Filters</a>
  <?php endif;?>

  <span style="margin-left:auto;font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--muted)">
    <?=count($projects)?> project<?=count($projects)!==1?'s':''?> found
  </span>
</div>

<!-- CARDS -->
<?php if(empty($projects)):?>
<div class="empty">
  <div class="icon">📭</div>
  <h3>No Projects Found</h3>
  <p>Koi project nahi mila — pehla project add karo!</p>
  <?php if(can_edit()):?>
  <a href="project_form.php" class="btn btn-accent" style="margin-top:16px">＋ Add Project</a>
  <?php endif;?>
</div>
<?php else:?>
<div class="cards-list">
<?php foreach($projects as $p):
  $sclr = $statusColors[$p['current_status']] ?? '#5a7a9a';
  $techLabel = $p['technology']==='Other' ? $p['technology_other'] : $p['technology'];
  $envs = [
    'local'      => ['url'=>$p['env_local_url'],      'aurl'=>$p['env_local_admin_url'],      'id'=>$p['env_local_id']],
    'staging'    => ['url'=>$p['env_staging_url'],    'aurl'=>$p['env_staging_admin_url'],    'id'=>$p['env_staging_id']],
    'production' => ['url'=>$p['env_production_url'], 'aurl'=>$p['env_production_admin_url'], 'id'=>$p['env_production_id']],
    'audit'      => ['url'=>$p['env_audit_url'],      'aurl'=>$p['env_audit_admin_url'],      'id'=>$p['env_audit_id']],
    'other'      => ['url'=>$p['env_other_url'],      'aurl'=>$p['env_other_admin_url'],      'id'=>$p['env_other_id']],
  ];
?>
<div class="project-card" style="--status-clr:<?=$sclr?>">
  <div class="card-main">

    <!-- Col 1: Project info -->
    <div class="card-col card-col-title">
      <div class="pname"><?=htmlspecialchars($p['project_name'])?></div>
      <div class="pdept"><?=htmlspecialchars($p['department_name']??'')?></div>
      <div class="ptags">
        <span class="status-badge" style="color:<?=$sclr?>;border-color:<?=$sclr?>40">
          <?=$statusLabels[$p['current_status']]??$p['current_status']?>
        </span>
        <?php if($techLabel):?>
        <span class="ptag" style="color:var(--accent);border-color:var(--accent)40"><?=htmlspecialchars($techLabel)?></span>
        <?php endif;?>
        <?php if($p['website_app']):?>
        <span class="ptag" style="color:var(--muted);border-color:var(--border)"><?=htmlspecialchars($p['website_app'])?></span>
        <?php endif;?>
      </div>
      <?php if($p['description']):?>
      <div style="font-size:11px;color:var(--muted);margin-top:6px;font-family:'Share Tech Mono',monospace;
        overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical">
        <?=htmlspecialchars($p['description'])?>
      </div>
      <?php endif;?>
    </div>

    <!-- Col 2: Environments -->
    <div class="card-col">
      <div class="col-label">Environments</div>
      <div class="env-grid">
        <?php foreach($envs as $ename=>$ed):?>
        <?php if($ed['url']):?>
        <div class="env-row">
          <span class="env-dot" style="background:<?=$envColors[$ename]?>"></span>
          <span class="env-name"><?=$ename?></span>
          <a class="env-url" href="<?=htmlspecialchars($ed['url'])?>" target="_blank" rel="noopener"
             title="<?=htmlspecialchars($ed['url'])?>">
            <?=htmlspecialchars(parse_url($ed['url'],PHP_URL_HOST)?:$ed['url'])?>
          </a>
        </div>
        <?php endif;?>
        <?php endforeach;?>
        <?php if(!array_filter(array_column($envs,'url'))):?>
        <span class="env-na">No URLs added</span>
        <?php endif;?>
      </div>
    </div>

    <!-- Col 3: Server info -->
    <div class="card-col">
      <div class="col-label">Infrastructure</div>
      <div class="info-kv">
        <?php if($p['app_ip']):?>
        <div class="kv">
          <span class="k">App IP</span>
          <span class="v">
            <button class="pw-reveal" onclick="copyText('<?=htmlspecialchars($p['app_ip'])?>')" title="Copy">📋</button>
            <?=htmlspecialchars($p['app_ip'])?>
          </span>
        </div>
        <?php endif;?>
        <?php if($p['app_os']):?>
        <div class="kv">
          <span class="k">App OS</span>
          <span class="v"><?=htmlspecialchars($p['app_os']==='Other'?$p['app_os_other']:$p['app_os'])?></span>
        </div>
        <?php endif;?>
        <?php if($p['db_ip']):?>
        <div class="kv">
          <span class="k">DB IP</span>
          <span class="v">
            <button class="pw-reveal" onclick="copyText('<?=htmlspecialchars($p['db_ip'])?>')" title="Copy">📋</button>
            <?=htmlspecialchars($p['db_ip'])?>
          </span>
        </div>
        <?php endif;?>
        <?php if($p['db_name']):?>
        <div class="kv">
          <span class="k">DB Name</span>
          <span class="v"><?=htmlspecialchars($p['db_name'])?></span>
        </div>
        <?php endif;?>
        <?php if($p['app_ram']):?>
        <div class="kv">
          <span class="k">RAM / Core</span>
          <span class="v"><?=htmlspecialchars($p['app_ram'])?> / <?=htmlspecialchars($p['app_core'])?></span>
        </div>
        <?php endif;?>
      </div>
    </div>

    <!-- Col 4: Credentials quick view -->
    <div class="card-col">
      <div class="col-label">Credentials</div>
      <?php foreach($envs as $ename=>$ed):?>
      <?php if($ed['id'] || ($p["env_{$ename}_password"]??'')):?>
      <div style="margin-bottom:8px">
        <div style="font-family:'Share Tech Mono',monospace;font-size:9px;color:<?=$envColors[$ename]?>;
          text-transform:uppercase;letter-spacing:1px;margin-bottom:3px"><?=$ename?></div>
        <?php if($ed['id']):?>
        <div style="font-size:11px;font-family:'Share Tech Mono',monospace">
          <button class="pw-reveal" onclick="copyText('<?=htmlspecialchars($ed['id'])?>')" style="font-size:10px">📋</button>
          <?=htmlspecialchars($ed['id'])?>
        </div>
        <?php endif;?>
        <?php if($p["env_{$ename}_password"]??''):?>
        <div style="font-size:11px;font-family:'Share Tech Mono',monospace;display:flex;align-items:center;gap:4px">
          <button class="pw-reveal" onclick="copyDecrypted(<?=$p['id']?>,'<?=$ename?>','<?=csrf_token()?>')" title="Copy Password">📋</button>
          <span id="pw-<?=$p['id']?>-<?=$ename?>" class="pw-mask">••••••••</span>
          <button class="pw-reveal" onclick="togglePw(<?=$p['id']?>,'<?=$ename?>','<?=csrf_token()?>')">👁</button>
        </div>
        <?php endif;?>
      </div>
      <?php endif;?>
      <?php endforeach;?>
    </div>

    <!-- Col 5: Actions -->
    <div class="card-actions-col">
      <?php if(can_edit()):?>
      <a href="project_form.php?id=<?=$p['id']?>" class="btn btn-ghost btn-sm">✏ Edit</a>
      <?php endif;?>
      <?php if($p['general_remark']||$p['app_infra_remark']||$p['db_remark']):?>
      <button class="btn btn-ghost btn-sm" onclick="toggleNotes(<?=$p['id']?>)">📝 Notes</button>
      <?php endif;?>
      <?php if($p['nodal_officer_name']):?>
      <button class="btn btn-ghost btn-sm" onclick="toggleNodal(<?=$p['id']?>)" title="Nodal Officer">👤 Nodal</button>
      <?php endif;?>
      <?php if(is_admin()):?>
      <button class="btn btn-danger btn-sm" onclick="deleteProject(<?=$p['id']?>,'<?=htmlspecialchars($p['project_name'])?>','<?=csrf_token()?>')">🗑 Delete</button>
      <?php endif;?>
      <div style="font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--muted);margin-top:4px;text-align:center">
        <?=date('d M Y',strtotime($p['updated_at']))?>
      </div>
    </div>
  </div>

  <!-- Notes panel -->
  <?php $hasNotes=$p['general_remark']||$p['app_infra_remark']||$p['db_remark'];?>
  <?php if($hasNotes):?>
  <div id="notes-<?=$p['id']?>" style="display:none;background:var(--surface2);border-top:1px solid var(--border);padding:12px 16px">
    <?php if($p['general_remark']):?>
    <div style="margin-bottom:8px">
      <div style="font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">General Remark</div>
      <div style="font-size:12px;font-family:'Share Tech Mono',monospace;white-space:pre-wrap;color:var(--text)"><?=htmlspecialchars($p['general_remark'])?></div>
    </div>
    <?php endif;?>
    <?php if($p['app_infra_remark']):?>
    <div style="margin-bottom:8px">
      <div style="font-family:'Share Tech Mono',monospace;font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">App Infra Remark</div>
      <div style="font-size:12px;font-family:'Share Tech Mono',monospace;white-space:pre-wrap;color:var(--text)"><?=htmlspecialchars($p['app_infra_remark'])?></div>
    </div>
    <?php endif;?>
  </div>
  <?php endif;?>

  <!-- Nodal officer panel -->
  <?php if($p['nodal_officer_name']):?>
  <div id="nodal-<?=$p['id']?>" style="display:none;background:var(--surface3);border-top:1px solid var(--border);padding:10px 16px;
    display:none;gap:16px;font-family:'Share Tech Mono',monospace;font-size:11px" class="nodal-panel">
    <div><span style="color:var(--muted)">Officer:</span> <?=htmlspecialchars($p['nodal_officer_name'])?></div>
    <?php if($p['nodal_designation']):?>
    <div><span style="color:var(--muted)">Designation:</span> <?=htmlspecialchars($p['nodal_designation'])?></div>
    <?php endif;?>
    <?php if($p['nodal_contact']):?>
    <div><span style="color:var(--muted)">Contact:</span> <?=htmlspecialchars($p['nodal_contact'])?></div>
    <?php endif;?>
    <?php if($p['dept_email']):?>
    <div><span style="color:var(--muted)">Email:</span> <?=htmlspecialchars($p['dept_email'])?></div>
    <?php endif;?>
  </div>
  <?php endif;?>
</div>
<?php endforeach;?>
</div>
<?php endif;?>

</div><!-- /content -->

<!-- Toast -->
<div class="toast" id="toast"><span id="toast-txt"></span></div>

<script>
// Search debounce
let st;
document.getElementById('q').addEventListener('input',function(){
  clearTimeout(st);st=setTimeout(()=>this.closest('form').submit(),500)});

function applyFilter(key,val){
  const url=new URL(window.location);
  if(val)url.searchParams.set(key,val);else url.searchParams.delete(key);
  window.location=url}

function showToast(msg){
  const t=document.getElementById('toast');
  document.getElementById('toast-txt').textContent=msg;
  t.style.display='flex';setTimeout(()=>t.style.display='none',2500)}

function copyText(t){navigator.clipboard.writeText(t).then(()=>showToast('✅ Copied!'))}

const pwVis={};
async function togglePw(id,env,csrf){
  const el=document.getElementById(`pw-${id}-${env}`);
  if(pwVis[`${id}-${env}`]){el.textContent='••••••••';pwVis[`${id}-${env}`]=false;return}
  const r=await fetch(`api.php?action=get_pw&id=${id}&env=${env}&csrf=${csrf}`);
  const d=await r.json();
  if(d.pw){el.textContent=d.pw;pwVis[`${id}-${env}`]=true}}

async function copyDecrypted(id,env,csrf){
  const r=await fetch(`api.php?action=get_pw&id=${id}&env=${env}&csrf=${csrf}`);
  const d=await r.json();
  if(d.pw)navigator.clipboard.writeText(d.pw).then(()=>showToast('✅ Password copied!'))}

function toggleNotes(id){const el=document.getElementById('notes-'+id);el.style.display=el.style.display==='none'?'block':'none'}

function toggleNodal(id){
  const el=document.getElementById('nodal-'+id);
  el.style.display=el.style.display==='none'||el.style.display===''?'flex':'none'}

function deleteProject(id,name,csrf){
  if(!confirm(`Delete "${name}"? Yeh undo nahi ho sakta.`))return;
  const f=document.createElement('form');f.method='POST';f.action='api.php';
  f.innerHTML=`<input name="action" value="delete_project">
    <input name="id" value="${id}"><input name="csrf" value="${csrf}">`;
  document.body.appendChild(f);f.submit()}

// Theme panel
function toggleThemePanel(){document.getElementById('theme-panel').classList.toggle('open')}
document.addEventListener('click',e=>{
  if(!e.target.closest('#theme-btn')&&!e.target.closest('#theme-panel'))
    document.getElementById('theme-panel').classList.remove('open')})

function setAccent(c){
  document.documentElement.style.setProperty('--accent',c);
  document.getElementById('custom-color').value=c;
  document.getElementById('accent-hex').textContent=c;
  document.querySelectorAll('.swatch').forEach(s=>s.classList.toggle('active',s.style.background===c))}

function setTheme(v){document.documentElement.setAttribute('data-theme',v)}
function setFont(v){document.body.style.fontFamily=`'${v}',sans-serif`}
function setFontSize(v){document.documentElement.style.setProperty('--fs',v+'px');document.getElementById('fs-val').textContent=v}

async function savePrefs(){
  const accent=getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
  const theme=document.documentElement.getAttribute('data-theme');
  const font=document.getElementById('font-select').value;
  const fs=document.querySelector('input[type=range]').value;
  const r=await fetch('api.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:`action=save_prefs&accent=${encodeURIComponent(accent)}&theme=${theme}&font=${encodeURIComponent(font)}&fs=${fs}&csrf=<?=csrf_token()?>`});
  const d=await r.json();
  if(d.ok)showToast('✅ Preferences saved!')}
</script>
</body>
</html>
