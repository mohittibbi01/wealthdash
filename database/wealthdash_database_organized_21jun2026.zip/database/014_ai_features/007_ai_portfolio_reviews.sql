-- ============================================================
-- Table: ai_portfolio_reviews
-- Domain: 014_ai_features  |  Sequence: 007
-- Source: migrations/t380_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t333 (fewer cols). Winner: t380

CREATE TABLE IF NOT EXISTS `ai_portfolio_reviews` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`         int(10) UNSIGNED NOT NULL,
  `portfolio_id`    int(10) UNSIGNED NOT NULL,
  `review_month`    char(7)          NOT NULL COMMENT 'YYYY-MM',
  `review_type`     enum('monthly','quarterly','annual','on_demand') NOT NULL DEFAULT 'monthly',
  `status`          enum('pending','generating','done','error') NOT NULL DEFAULT 'pending',
  `prompt_snapshot` mediumtext       DEFAULT NULL COMMENT 'Portfolio data sent to AI (JSON)',
  `ai_response`     mediumtext       DEFAULT NULL COMMENT 'Raw AI text',
  `parsed_sections` mediumtext       DEFAULT NULL COMMENT 'JSON: {summary, strengths, concerns, actions, score}',
  `portfolio_score` tinyint UNSIGNED DEFAULT NULL COMMENT '0-100 health score',
  `tokens_used`     int UNSIGNED     DEFAULT NULL,
  `model_used`      varchar(50)      DEFAULT NULL,
  `error_message`   text             DEFAULT NULL,
  `generated_at`    datetime         DEFAULT NULL,
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_review_month` (`portfolio_id`, `review_month`, `review_type`),
  KEY `idx_apr_user`      (`user_id`),
  KEY `idx_apr_portfolio` (`portfolio_id`),
  KEY `idx_apr_month`     (`review_month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
