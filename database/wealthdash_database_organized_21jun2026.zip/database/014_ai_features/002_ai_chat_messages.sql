-- ============================================================
-- Table: ai_chat_messages
-- Domain: 014_ai_features  |  Sequence: 002
-- Source: migrations/t381_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ai_chat_messages` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `session_id`   int(10) UNSIGNED NOT NULL,
  `role`         enum('user','assistant') NOT NULL,
  `content`      mediumtext       NOT NULL,
  `tokens_used`  int UNSIGNED     DEFAULT NULL,
  `created_at`   datetime         NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_acm_session` (`session_id`),
  KEY `idx_acm_created` (`created_at`),
  CONSTRAINT `fk_acm_session` FOREIGN KEY (`session_id`) REFERENCES `ai_chat_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
