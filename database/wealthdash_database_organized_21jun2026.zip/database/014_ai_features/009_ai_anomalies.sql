-- ============================================================
-- Table: ai_anomalies
-- Domain: 014_ai_features  |  Sequence: 009
-- Source: 41_pending_tasks.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ai_anomalies (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    anomaly_type VARCHAR(60)  NOT NULL,
    severity     ENUM('info','warning','critical') DEFAULT 'warning',
    title        VARCHAR(200) NOT NULL,
    description  TEXT,
    data_json    TEXT,
    is_dismissed TINYINT(1) NOT NULL DEFAULT 0,
    detected_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dismissed_at DATETIME DEFAULT NULL,
    INDEX idx_user     (user_id),
    INDEX idx_severity (severity),
    INDEX idx_dismissed(is_dismissed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
