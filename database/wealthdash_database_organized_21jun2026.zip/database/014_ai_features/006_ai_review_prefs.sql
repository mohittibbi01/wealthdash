-- ============================================================
-- Table: ai_review_prefs
-- Domain: 014_ai_features  |  Sequence: 006
-- Source: migrations/t380_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ai_review_prefs` (
  `id`                     int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`                int(10) UNSIGNED NOT NULL,
  `auto_generate_monthly`  tinyint(1) NOT NULL DEFAULT 0,
  `notify_on_ready`        tinyint(1) NOT NULL DEFAULT 1,
  `preferred_language`     varchar(10) NOT NULL DEFAULT 'hi-en' COMMENT 'hi-en=Hinglish, en=English',
  `risk_appetite`          enum('conservative','moderate','aggressive') NOT NULL DEFAULT 'moderate',
  `financial_goal`         varchar(255) DEFAULT NULL COMMENT 'Free text: what user wants to achieve',
  `updated_at`             datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_arp_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
