-- ============================================================
-- Table: ai_chat_sessions
-- Domain: 014_ai_features  |  Sequence: 001
-- Source: migrations/t381_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ai_chat_sessions` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      int(10) UNSIGNED NOT NULL,
  `portfolio_id` int(10) UNSIGNED DEFAULT NULL,
  `session_key`  char(36)         NOT NULL COMMENT 'UUID',
  `title`        varchar(200)     DEFAULT NULL COMMENT 'Auto-generated from first message',
  `context_snap` mediumtext       DEFAULT NULL COMMENT 'Portfolio snapshot JSON at session start',
  `message_count` int UNSIGNED    NOT NULL DEFAULT 0,
  `last_activity` datetime        NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at`   datetime         NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_session_key` (`session_key`),
  KEY `idx_acs_user`      (`user_id`),
  KEY `idx_acs_portfolio` (`portfolio_id`),
  KEY `idx_acs_activity`  (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
