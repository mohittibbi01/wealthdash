-- ============================================================
-- Table: ai_narrative_log
-- Domain: 014_ai_features  |  Sequence: 006
-- Source: migrations/t244_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ai_narrative_log (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  month       VARCHAR(7)   NOT NULL COMMENT 'YYYY-MM',
  mode        ENUM('ai','rule_based') NOT NULL DEFAULT 'rule_based',
  narrative   TEXT         NOT NULL,
  stats       JSON         NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_month (user_id, month),
  CONSTRAINT fk_anl_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
