-- ============================================================
-- Table: ai_advisor_sessions
-- Domain: 014_ai_features  |  Sequence: 005
-- Source: migrations/t58_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ai_advisor_sessions (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL,
  session_type  ENUM('full_review','follow_up') NOT NULL DEFAULT 'full_review',
  response_json JSON         NOT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user_type (user_id, session_type, created_at),
  CONSTRAINT fk_aas_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
