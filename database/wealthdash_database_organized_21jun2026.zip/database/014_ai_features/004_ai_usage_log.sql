-- ============================================================
-- Table: ai_usage_log
-- Domain: 014_ai_features  |  Sequence: 004
-- Source: migrations/t381_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ai_usage_log` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      int(10) UNSIGNED NOT NULL,
  `feature`      enum('chat','review','optimizer') NOT NULL DEFAULT 'chat',
  `usage_date`   date             NOT NULL,
  `request_count` smallint UNSIGNED NOT NULL DEFAULT 0,
  `tokens_total` int UNSIGNED     NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usage_user_feature_date` (`user_id`, `feature`, `usage_date`),
  KEY `idx_aul_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
