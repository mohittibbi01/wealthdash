-- ============================================================
-- Table: investor_streaks
-- Domain: 018_journal_gamification  |  Sequence: 002
-- Source: migrations/t242_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS investor_streaks (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id         INT UNSIGNED NOT NULL UNIQUE,
  current_streak  INT UNSIGNED NOT NULL DEFAULT 0,
  longest_streak  INT UNSIGNED NOT NULL DEFAULT 0,
  last_checked    DATETIME     NULL,
  CONSTRAINT fk_is_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
