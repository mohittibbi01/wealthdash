-- ============================================================
-- Table: investment_journal
-- Domain: 018_journal_gamification  |  Sequence: 004
-- Source: 44_v48_sprint_tables.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `investment_journal` (
  `id`                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`              INT UNSIGNED NOT NULL,
  `entry_date`           DATE         NOT NULL,
  `title`                VARCHAR(200) NOT NULL DEFAULT '',
  `body`                 TEXT         NOT NULL,
  `mood`                 ENUM('bullish','bearish','neutral','anxious','confident')
                         NOT NULL DEFAULT 'neutral',
  `tags`                 JSON         DEFAULT NULL
                         COMMENT 'Array of tag strings e.g. ["HDFC Flexi","market"]',
  `linked_fund_id`       INT UNSIGNED DEFAULT NULL,
  `portfolio_change_pct` DECIMAL(6,2) DEFAULT NULL,
  `nifty_change_pct`     DECIMAL(6,2) DEFAULT NULL,
  `is_private`           TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                         ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`, `entry_date`),
  KEY `idx_user_id`   (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
