-- ============================================================
-- Table: user_badges
-- Domain: 018_journal_gamification  |  Sequence: 003
-- Source: migrations/t242_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS user_badges (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  badge_key   VARCHAR(40)  NOT NULL,
  earned_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_badge (user_id, badge_key),
  CONSTRAINT fk_ub_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
