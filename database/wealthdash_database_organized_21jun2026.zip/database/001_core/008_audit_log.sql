-- ============================================================
-- Table: audit_log
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema) — WINNER
-- ============================================================
-- CONFLICT RESOLVED: also defined in migrations/t50_migration.sql
-- (older, simpler — admin_users.php era, superseded duplicate, see
-- router_merge_README.md). That version lacked entity_type,
-- entity_id, old_values, new_values — but live code in
-- api/admin/audit_log.php (already wired to router.php) NEEDS those
-- columns for the change-tracking / JSON diff feature. Base schema
-- version kept as the winner; t50's version discarded entirely.
-- ============================================================

CREATE TABLE IF NOT EXISTS `audit_log` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_entity` (`entity_type`, `entity_id`),
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
