-- ============================================================
-- Table: portfolios
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema)
-- ============================================================
-- Depends on: users
-- CRITICAL: almost every domain table (mutual funds, stocks, FD,
-- bank, EPF, insurance, loans, goals, etc.) has a foreign key to
-- this table via portfolio_id. Must be created right after users,
-- before any domain folder runs.
-- ============================================================

CREATE TABLE IF NOT EXISTS `portfolios` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT 'My Portfolio',
  `description` text DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_portfolio_user` (`user_id`),
  CONSTRAINT `fk_portfolio_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
