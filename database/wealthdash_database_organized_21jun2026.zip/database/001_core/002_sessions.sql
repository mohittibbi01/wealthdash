-- ============================================================
-- Table: sessions
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema)
-- ============================================================
-- PHP native session storage backend (server-side session data).
-- NOT the same as 'user_sessions' (see 015_admin_infra or
-- 001_core/011_user_sessions.sql) which is the user-facing
-- "manage logged-in devices" feature (t387).
-- ============================================================

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `payload` longtext DEFAULT NULL,
  `last_activity` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sess_user` (`user_id`),
  KEY `idx_sess_activity` (`last_activity`),
  CONSTRAINT `fk_sess_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
