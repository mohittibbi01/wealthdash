-- ============================================================
-- Table: referrals
-- Domain: 001_core  |  Sequence: 018
-- ============================================================
-- !! STUB: NOT FOUND in any SQL file — never built, stub placeholder created
-- !! Define the actual schema before running.
-- ============================================================

CREATE TABLE IF NOT EXISTS `referrals` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  -- TODO: define columns
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
