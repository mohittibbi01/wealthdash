-- ============================================================
-- Table: user_kv_settings
-- Domain: 001_core  |  Sequence: 013
-- Source: migrations/t355_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `user_kv_settings` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      int(10) UNSIGNED NOT NULL,
  `portfolio_id` int(10) UNSIGNED DEFAULT NULL,
  `setting_key`  varchar(80)      NOT NULL,
  `setting_value` text            DEFAULT NULL,
  `updated_at`   datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_kv_user_portfolio_key` (`user_id`, `portfolio_id`, `setting_key`),
  KEY `idx_kv_portfolio` (`portfolio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
