-- ============================================================
-- Table: app_settings
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema) — FIXED
-- ============================================================
-- CONFLICT RESOLVED: this table was also defined in
-- migrations/t52_migration.sql (older, simpler — admin_settings.php,
-- superseded duplicate, see router_merge_README.md). Base schema
-- version kept as the winner.
--
-- FIX (21 Jun 2026): live code in api/admin/global_settings.php
-- expects columns setting_group, setting_type, label, description,
-- is_public, is_locked — NONE of these existed in any migration file
-- found (base schema or t52). Added them below so the already-merged
-- t52 routes (gs_list, gs_get, gs_save, etc.) actually work.
-- ============================================================

CREATE TABLE IF NOT EXISTS `app_settings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_val` text DEFAULT NULL,
  `setting_group` varchar(50) NOT NULL DEFAULT 'general',
  `setting_type` enum('text','number','boolean','json','select') NOT NULL DEFAULT 'text',
  `label` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_key` (`setting_key`),
  KEY `idx_settings_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
