-- ============================================================
-- Table: user_documents
-- Domain: 001_core  |  Sequence: 015
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS user_documents (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED  NOT NULL,
  category    VARCHAR(40)   NOT NULL DEFAULT 'other',
  doc_name    VARCHAR(150)  NOT NULL,
  file_path   VARCHAR(255)  NOT NULL COMMENT 'Random filename in storage/documents/<user_id>/',
  file_size   INT UNSIGNED  NOT NULL DEFAULT 0,
  expiry_date DATE          NULL,
  source      ENUM('manual_upload','digilocker') NOT NULL DEFAULT 'manual_upload',
  uploaded_at DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user_category (user_id, category),
  KEY idx_user_expiry   (user_id, expiry_date),
  CONSTRAINT fk_ud_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
