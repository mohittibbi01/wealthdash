-- ============================================================
-- Table: user_sessions
-- Domain: 001_core
-- Source: api/auth/session_security.php (live code, self-creating) — WINNER
-- ============================================================
-- CONFLICT RESOLVED: 3 different schemas found for this table:
--   1. 41_pending_tasks.sql            — close, but missing country, is_current
--   2. migrations/t387_migration.sql   — completely different columns
--                                        (session_id, device_label) — WRONG,
--                                        superseded duplicate (see
--                                        router_merge_README.md)
--   3. api/auth/session_security.php   — the live PHP file creates this
--                                        table itself inline with
--                                        CREATE TABLE IF NOT EXISTS
-- Used #3 as the authoritative source since it's the actual running code.
--
-- This is the user-facing "manage your logged-in devices" feature (t387).
-- NOT the same as 'sessions' (002_sessions.sql) which is PHP's internal
-- session storage.
--
-- Depends on: users
-- ============================================================

CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `session_token` varchar(128) NOT NULL,
  `device_name` varchar(120) DEFAULT NULL,
  `device_type` enum('desktop','mobile','tablet','unknown') NOT NULL DEFAULT 'unknown',
  `browser` varchar(80) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `last_active` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_current` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `idx_user` (`user_id`),
  KEY `idx_token` (`session_token`),
  KEY `idx_active` (`last_active`),
  CONSTRAINT `fk_us_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
