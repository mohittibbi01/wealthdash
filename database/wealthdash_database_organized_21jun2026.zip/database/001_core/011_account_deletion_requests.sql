-- ============================================================
-- Table: account_deletion_requests
-- Domain: 001_core  |  Sequence: 011
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS account_deletion_requests (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL,
  status        ENUM('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
  requested_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  scheduled_for DATETIME     NOT NULL,
  cancelled_at  DATETIME     NULL,
  completed_at  DATETIME     NULL,
  KEY idx_user_status (user_id, status),
  KEY idx_scheduled (scheduled_for),
  CONSTRAINT fk_adr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
