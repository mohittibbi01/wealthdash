-- ============================================================
-- Table: nsc_80c_log
-- Domain: 006_bonds_govt_securities  |  Sequence: 003
-- Source: migrations/t205_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t48 (no comments). Winner: t205 (richer with field comments)

CREATE TABLE IF NOT EXISTS `nsc_80c_log` (
  `id`             int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nsc_scheme_id`  int(10) UNSIGNED NOT NULL COMMENT 'FK → po_schemes.id (scheme_type=NSC)',
  `fy`             varchar(9)       NOT NULL COMMENT 'e.g. 2024-2025',
  `amount`         decimal(12,2)    NOT NULL DEFAULT 0.00 COMMENT 'Interest eligible for 80C this FY',
  `declared_80c`   tinyint(1)       NOT NULL DEFAULT 0   COMMENT '1 = user has declared in ITR',
  `notes`          varchar(255)     DEFAULT NULL,
  `created_at`     datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`     datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nsc_log_scheme_fy` (`nsc_scheme_id`, `fy`),
  KEY `idx_nsc_log_scheme` (`nsc_scheme_id`),
  CONSTRAINT `fk_nsc_log_scheme`
    FOREIGN KEY (`nsc_scheme_id`) REFERENCES `po_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
