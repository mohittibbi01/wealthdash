-- ============================================================
-- Table: govt_securities
-- Domain: 006_bonds_govt_securities  |  Sequence: 009
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS govt_securities (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    security_type ENUM('RBI_FRB','GSEC','TBILL','SDL') NOT NULL,
    security_name VARCHAR(200) NOT NULL,
    isin VARCHAR(20),
    face_value DECIMAL(15,2) NOT NULL DEFAULT 1000.00,
    quantity INT UNSIGNED NOT NULL,
    purchase_price DECIMAL(15,4) NOT NULL,
    purchase_date DATE NOT NULL,
    maturity_date DATE NOT NULL,
    coupon_rate DECIMAL(8,4) DEFAULT NULL COMMENT 'NULL for T-Bills (discount instrument)',
    coupon_frequency ENUM('SEMI_ANNUAL','QUARTERLY','FLOATING') DEFAULT 'SEMI_ANNUAL',
    is_floating TINYINT(1) DEFAULT 0 COMMENT '1 for FRB where rate resets',
    floating_reference VARCHAR(50) DEFAULT NULL COMMENT 'NSS rate / Repo rate reference',
    floating_spread DECIMAL(6,4) DEFAULT NULL COMMENT 'Spread above reference rate',
    platform VARCHAR(100) COMMENT 'RBI Retail Direct/Zerodha/NSE goBID',
    redemption_price DECIMAL(15,4) DEFAULT NULL COMMENT 'For T-Bills = face_value',
    notes TEXT,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_security_type (security_type),
    INDEX idx_maturity (maturity_date),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
