-- ============================================================
-- Table: bond_cashflows
-- Domain: 006_bonds_govt_securities  |  Sequence: 005
-- Source: migrations/t116_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS bond_cashflows (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    bond_id BIGINT UNSIGNED NOT NULL,
    cashflow_type ENUM('COUPON','PRINCIPAL','PARTIAL_REDEMPTION') NOT NULL,
    scheduled_date DATE NOT NULL,
    amount DECIMAL(15,4) NOT NULL,
    received TINYINT(1) DEFAULT 0,
    received_date DATE DEFAULT NULL,
    tds_deducted DECIMAL(10,2) DEFAULT 0.00,
    net_amount DECIMAL(15,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bond_id) REFERENCES bonds(id) ON DELETE CASCADE,
    INDEX idx_bond_id (bond_id),
    INDEX idx_user_id (user_id),
    INDEX idx_scheduled_date (scheduled_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
