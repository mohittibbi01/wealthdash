-- ============================================================
-- Table: po_payout_log
-- Domain: 006_bonds_govt_securities  |  Sequence: 002
-- Source: migrations/t206_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t15 (fewer cols). Winner: t206 (tds_tan, payout_status)

CREATE TABLE IF NOT EXISTS `po_payout_log` (
  `id`            int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `po_scheme_id`  int(10) UNSIGNED NOT NULL,
  `payout_date`   date             NOT NULL COMMENT 'Expected payout date (1st of month/quarter)',
  `payout_type`   enum('monthly','quarterly') NOT NULL DEFAULT 'monthly',
  `amount`        decimal(12,2)    NOT NULL DEFAULT 0.00,
  `tds_deducted`  decimal(10,2)    NOT NULL DEFAULT 0.00,
  `tds_tan`       varchar(20)      DEFAULT NULL COMMENT 'TAN of deductor (SCSS TDS)',
  `is_received`   tinyint(1)       NOT NULL DEFAULT 0,
  `notes`         varchar(255)     DEFAULT NULL,
  `created_at`    datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`    datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ppl_scheme_date` (`po_scheme_id`, `payout_date`),
  KEY `idx_ppl_scheme`   (`po_scheme_id`),
  KEY `idx_ppl_date`     (`payout_date`),
  KEY `idx_ppl_received` (`is_received`),
  CONSTRAINT `fk_ppl_scheme`
    FOREIGN KEY (`po_scheme_id`) REFERENCES `po_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
