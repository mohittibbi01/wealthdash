-- ============================================================
-- Table: gsec_cashflows
-- Domain: 006_bonds_govt_securities  |  Sequence: 008
-- Source: migrations/t118_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS gsec_cashflows (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    security_id BIGINT UNSIGNED NOT NULL,
    cashflow_type ENUM('COUPON','MATURITY','PARTIAL_SALE') NOT NULL,
    scheduled_date DATE NOT NULL,
    coupon_rate_applied DECIMAL(8,4) DEFAULT NULL COMMENT 'Actual rate for floating bonds',
    amount DECIMAL(15,4) NOT NULL,
    received TINYINT(1) DEFAULT 0,
    received_date DATE DEFAULT NULL,
    tds_deducted DECIMAL(10,2) DEFAULT 0.00,
    net_amount DECIMAL(15,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (security_id) REFERENCES govt_securities(id) ON DELETE CASCADE,
    INDEX idx_security_id (security_id),
    INDEX idx_user_id (user_id),
    INDEX idx_scheduled_date (scheduled_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
