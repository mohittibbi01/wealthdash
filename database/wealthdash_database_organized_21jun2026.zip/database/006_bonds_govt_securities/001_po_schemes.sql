-- ============================================================
-- Table: po_schemes
-- Domain: 006_bonds_govt_securities  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `po_schemes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `scheme_type` enum('PPF','NSC','SCSS','MIS','SSY','KVP','TD','RD','NPS_APY') NOT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `post_office` varchar(100) DEFAULT NULL,
  `principal_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `current_value` decimal(14,2) NOT NULL DEFAULT 0.00,
  `interest_rate` decimal(6,3) NOT NULL DEFAULT 0.000,
  `start_date` date NOT NULL,
  `maturity_date` date DEFAULT NULL,
  `maturity_amount` decimal(14,2) DEFAULT NULL,
  `interest_earned` decimal(14,2) NOT NULL DEFAULT 0.00,
  `annual_deposit` decimal(14,2) DEFAULT NULL,
  `status` enum('active','matured','closed','extended') NOT NULL DEFAULT 'active',
  `nominee` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'JSON: sub-tenures, rates etc' CHECK (json_valid(`meta`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_po_portfolio` (`portfolio_id`),
  KEY `idx_po_type` (`scheme_type`),
  CONSTRAINT `fk_po_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
