-- ============================================================
-- Table: yield_curve_reference
-- Domain: 006_bonds_govt_securities  |  Sequence: 010
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS yield_curve_reference (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  tenure_months SMALLINT     NOT NULL UNIQUE,
  tenure_label  VARCHAR(10)  NOT NULL,
  rate          DECIMAL(5,2) NOT NULL,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_tenure (tenure_months)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
