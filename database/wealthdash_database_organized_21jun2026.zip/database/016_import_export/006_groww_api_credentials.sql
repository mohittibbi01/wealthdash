-- ============================================================
-- Table: groww_api_credentials
-- Domain: 016_import_export  |  Sequence: 006
-- Source: migrations/t392_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_api_credentials` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL UNIQUE,
    `access_token`    TEXT         DEFAULT NULL COMMENT 'Encrypted bearer token',
    `refresh_token`   TEXT         DEFAULT NULL COMMENT 'Encrypted refresh token',
    `token_expires_at` DATETIME    DEFAULT NULL,
    `linked_email`    VARCHAR(200) DEFAULT NULL,
    `linked_mobile`   VARCHAR(15)  DEFAULT NULL,
    `scope`           VARCHAR(200) DEFAULT NULL COMMENT 'mf,stocks,profile',
    `status`          ENUM('active','expired','revoked','error') NOT NULL DEFAULT 'active',
    `last_sync_at`    DATETIME     DEFAULT NULL,
    `last_sync_type`  VARCHAR(50)  DEFAULT NULL,
    `error_msg`       VARCHAR(500) DEFAULT NULL,
    `created_at`      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user`   (`user_id`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
