-- ============================================================
-- Table: csv_column_mapping_presets
-- Domain: 016_import_export  |  Sequence: 010
-- Source: migrations/t490_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `csv_column_mapping_presets` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`     INT UNSIGNED NOT NULL,
    `name`        VARCHAR(100) NOT NULL COMMENT 'e.g. My CAMS Format',
    `format_hint` VARCHAR(50)  DEFAULT NULL,
    `mapping_json`TEXT         NOT NULL COMMENT 'JSON column mapping',
    `use_count`   INT UNSIGNED DEFAULT 0,
    `last_used`   DATETIME     DEFAULT NULL,
    `created_at`  DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
