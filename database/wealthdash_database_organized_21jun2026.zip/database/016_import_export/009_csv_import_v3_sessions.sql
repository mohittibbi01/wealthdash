-- ============================================================
-- Table: csv_import_v3_sessions
-- Domain: 016_import_export  |  Sequence: 009
-- Source: migrations/t490_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `csv_import_v3_sessions` (
    `id`                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`           INT UNSIGNED NOT NULL,
    `portfolio_id`      INT UNSIGNED DEFAULT NULL,
    `filename`          VARCHAR(255) DEFAULT NULL,
    `file_size`         INT UNSIGNED DEFAULT NULL,
    `detected_format`   VARCHAR(50)  DEFAULT NULL,
    `format_label`      VARCHAR(100) DEFAULT NULL,
    `confidence`        TINYINT UNSIGNED DEFAULT 0,
    `col_mapping_json`  TEXT         DEFAULT NULL COMMENT 'JSON of column index map',
    `header_row_index`  TINYINT UNSIGNED DEFAULT 0,
    `total_data_rows`   INT UNSIGNED DEFAULT 0,
    `preview_json`      MEDIUMTEXT   DEFAULT NULL COMMENT 'First 10 rows preview',
    `action`            ENUM('detect','import','preview') DEFAULT 'detect',
    `imported`          INT UNSIGNED DEFAULT 0,
    `skipped`           INT UNSIGNED DEFAULT 0,
    `errors`            INT UNSIGNED DEFAULT 0,
    `error_rows_json`   MEDIUMTEXT   DEFAULT NULL,
    `status`            ENUM('detected','previewed','imported','failed') DEFAULT 'detected',
    `created_at`        DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user`       (`user_id`),
    INDEX `idx_portfolio`  (`portfolio_id`),
    INDEX `idx_format`     (`detected_format`),
    INDEX `idx_created`    (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
