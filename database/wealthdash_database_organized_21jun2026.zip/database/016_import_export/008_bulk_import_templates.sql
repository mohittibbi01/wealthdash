-- ============================================================
-- Table: bulk_import_templates
-- Domain: 016_import_export  |  Sequence: 008
-- Source: migrations/t334_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `bulk_import_templates` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `version`         VARCHAR(20)  NOT NULL UNIQUE,
    `asset_type`      VARCHAR(50)  NOT NULL,
    `field_count`     INT UNSIGNED NOT NULL DEFAULT 0,
    `fields_json`     MEDIUMTEXT   NOT NULL COMMENT 'JSON array of field definitions',
    `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
