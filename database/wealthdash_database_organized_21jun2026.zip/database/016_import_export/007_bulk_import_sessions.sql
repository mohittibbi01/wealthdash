-- ============================================================
-- Table: bulk_import_sessions
-- Domain: 016_import_export  |  Sequence: 007
-- Source: migrations/t334_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `bulk_import_sessions` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `import_source`   VARCHAR(50)  NOT NULL DEFAULT 'excel' COMMENT 'excel|csv|api',
    `asset_type`      ENUM('mf','stocks','fd','gold','reits','smallcase','mixed') NOT NULL DEFAULT 'mf',
    `filename`        VARCHAR(255) DEFAULT NULL,
    `status`          ENUM('pending','validating','importing','done','failed','partial') DEFAULT 'pending',
    `total_rows`      INT UNSIGNED DEFAULT 0,
    `valid_rows`      INT UNSIGNED DEFAULT 0,
    `imported`        INT UNSIGNED DEFAULT 0,
    `skipped`         INT UNSIGNED DEFAULT 0,
    `error_count`     INT UNSIGNED DEFAULT 0,
    `validation_log`  MEDIUMTEXT DEFAULT NULL COMMENT 'JSON array of validation errors',
    `import_log`      MEDIUMTEXT DEFAULT NULL COMMENT 'JSON array of import results',
    `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user`      (`user_id`),
    INDEX `idx_portfolio` (`portfolio_id`),
    INDEX `idx_status`    (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
