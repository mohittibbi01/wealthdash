-- ============================================================
-- Table: import_row_changes
-- Domain: 016_import_export  |  Sequence: 002
-- Source: migrations/t336_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `import_row_changes` (
    `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `version_id`    INT UNSIGNED    NOT NULL,
    `table_name`    VARCHAR(60)     NOT NULL,
    `row_id`        INT UNSIGNED    NOT NULL,
    `change_type`   ENUM('insert','update','delete') NOT NULL,
    `old_data`      JSON            DEFAULT NULL,
    `new_data`      JSON            DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_irc_version` (`version_id`),
    KEY `idx_irc_table_row` (`table_name`, `row_id`),
    CONSTRAINT `fk_irc_version` FOREIGN KEY (`version_id`) REFERENCES `import_versions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
