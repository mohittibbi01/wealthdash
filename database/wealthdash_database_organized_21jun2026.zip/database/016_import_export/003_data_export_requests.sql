-- ============================================================
-- Table: data_export_requests
-- Domain: 016_import_export  |  Sequence: 003
-- Source: migrations/t389_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS data_export_requests (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED  NOT NULL,
  filename    VARCHAR(255)  NOT NULL,
  file_size   INT UNSIGNED  NOT NULL DEFAULT 0,
  status      ENUM('processing','ready','expired') NOT NULL DEFAULT 'ready',
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at  DATETIME      NOT NULL,
  KEY idx_user (user_id),
  CONSTRAINT fk_der_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
