-- ============================================================
-- Table: spending_discipline
-- Domain: 016_import_export  |  Sequence: 011
-- Source: 44_v48_sprint_tables.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `spending_discipline` (
  `id`             INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `user_id`        INT UNSIGNED   NOT NULL,
  `monthly_income` DECIMAL(15,2)  NOT NULL DEFAULT 0,
  `target_pct`     DECIMAL(5,2)   NOT NULL DEFAULT 20.00,
  `updated_at`     DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP
                   ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
