-- ============================================================
-- Table: groww_import_sessions
-- Domain: 016_import_export  |  Sequence: 004
-- Source: migrations/t302_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_import_sessions` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `import_type`     ENUM('csv','api','manual') NOT NULL DEFAULT 'csv',
    `filename`        VARCHAR(255) DEFAULT NULL,
    `status`          ENUM('pending','processing','done','failed','partial') NOT NULL DEFAULT 'pending',
    `total_rows`      INT UNSIGNED DEFAULT 0,
    `imported`        INT UNSIGNED DEFAULT 0,
    `skipped`         INT UNSIGNED DEFAULT 0,
    `errors`          INT UNSIGNED DEFAULT 0,
    `mf_count`        INT UNSIGNED DEFAULT 0,
    `stock_count`     INT UNSIGNED DEFAULT 0,
    `error_log`       TEXT DEFAULT NULL,
    `raw_response`    MEDIUMTEXT DEFAULT NULL COMMENT 'Raw JSON/CSV for audit',
    `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user`      (`user_id`),
    INDEX `idx_portfolio` (`portfolio_id`),
    INDEX `idx_status`    (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
