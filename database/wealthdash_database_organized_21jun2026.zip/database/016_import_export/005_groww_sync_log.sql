-- ============================================================
-- Table: groww_sync_log
-- Domain: 016_import_export  |  Sequence: 005
-- Source: migrations/t392_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_sync_log` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `sync_type`       ENUM('mf_holdings','mf_transactions','stock_holdings','stock_transactions','full') NOT NULL,
    `status`          ENUM('running','done','failed','partial') NOT NULL DEFAULT 'running',
    `mf_synced`       INT UNSIGNED DEFAULT 0,
    `stock_synced`    INT UNSIGNED DEFAULT 0,
    `errors`          INT UNSIGNED DEFAULT 0,
    `error_detail`    TEXT DEFAULT NULL,
    `api_calls`       INT UNSIGNED DEFAULT 0,
    `started_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    `completed_at`    DATETIME DEFAULT NULL,
    INDEX `idx_user`  (`user_id`),
    INDEX `idx_date`  (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
