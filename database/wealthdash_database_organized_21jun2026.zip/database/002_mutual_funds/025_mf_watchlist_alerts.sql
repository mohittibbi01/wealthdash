-- ============================================================
-- Table: mf_watchlist_alerts
-- Domain: 002_mutual_funds  |  Sequence: 025
-- Source: migrations/010_watchlist.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_watchlist_alerts (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NOT NULL,
    fund_id         INT UNSIGNED NOT NULL,
    alert_type      ENUM('nav_above','nav_below','return_1y_above','return_3y_above',
                         'sharpe_above','aum_above','expense_below','multi_condition') NOT NULL,
    target_value    DECIMAL(12,4)  DEFAULT NULL,
    conditions_json TEXT           DEFAULT NULL COMMENT 'JSON for multi_condition type',
    is_active       TINYINT(1)     NOT NULL DEFAULT 1,
    last_triggered  DATETIME       DEFAULT NULL,
    snooze_until    DATETIME       DEFAULT NULL,
    created_at      DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user   (user_id),
    INDEX idx_fund   (fund_id),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
