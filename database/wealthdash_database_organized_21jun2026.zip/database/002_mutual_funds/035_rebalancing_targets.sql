-- ============================================================
-- Table: rebalancing_targets
-- Domain: 002_mutual_funds  |  Sequence: 035
-- Source: 18_rebalancing_stepup.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `rebalancing_targets` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`   INT UNSIGNED  NOT NULL,
  `asset_class`    ENUM('equity','debt','gold','cash','international','other') NOT NULL,
  `target_pct`     DECIMAL(5,2)  NOT NULL  COMMENT 'Target allocation % (0-100)',
  `drift_threshold` DECIMAL(5,2) NOT NULL DEFAULT 5.00 COMMENT 'Alert agar actual drift > threshold %',
  `updated_at`     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rebal_portfolio_asset` (`portfolio_id`, `asset_class`),
  CONSTRAINT `fk_rebal_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='User-defined target allocation for rebalancing alerts';
