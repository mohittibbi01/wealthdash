-- ============================================================
-- Table: sip_schedules
-- Domain: 002_mutual_funds  |  Sequence: 031
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `sip_schedules` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `asset_type` enum('mf','stock','nps') NOT NULL DEFAULT 'mf',
  `fund_id` int(10) UNSIGNED DEFAULT NULL,
  `stock_id` int(10) UNSIGNED DEFAULT NULL,
  `nps_scheme_id` int(10) UNSIGNED DEFAULT NULL,
  `folio_number` varchar(50) DEFAULT NULL,
  `sip_amount` decimal(14,2) NOT NULL,
  `swp_amount` decimal(14,2) DEFAULT NULL,
  `sip_type` enum('sip','swp') NOT NULL DEFAULT 'sip',
  `frequency` enum('monthly','quarterly','weekly','yearly') NOT NULL DEFAULT 'monthly',
  `sip_day` tinyint(3) UNSIGNED NOT NULL DEFAULT 1 COMMENT 'Day of month 1-28',
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL COMMENT 'NULL = ongoing',
  `platform` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sip_portfolio` (`portfolio_id`),
  KEY `idx_sip_fund` (`fund_id`),
  CONSTRAINT `fk_sip_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sip_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
