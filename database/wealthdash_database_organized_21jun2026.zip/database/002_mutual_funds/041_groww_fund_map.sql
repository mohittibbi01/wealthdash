-- ============================================================
-- Table: groww_fund_map
-- Domain: 002_mutual_funds  |  Sequence: 041
-- Source: migrations/t302_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_fund_map` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `groww_name`      VARCHAR(300) NOT NULL COMMENT 'Scheme name as Groww exports it',
    `fund_id`         INT UNSIGNED DEFAULT NULL COMMENT 'Resolved WealthDash fund id',
    `scheme_code`     VARCHAR(20)  DEFAULT NULL,
    `isin`            VARCHAR(20)  DEFAULT NULL,
    `is_confirmed`    TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_groww_name` (`groww_name`(200)),
    INDEX `idx_fund_id` (`fund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
