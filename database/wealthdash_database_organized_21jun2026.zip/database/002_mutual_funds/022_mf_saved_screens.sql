-- ============================================================
-- Table: mf_saved_screens
-- Domain: 002_mutual_funds  |  Sequence: 022
-- Source: migrations/015_saved_screens_and_more.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_saved_screens (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    name         VARCHAR(80)  NOT NULL,
    filters_json TEXT         NOT NULL COMMENT 'JSON encoded filter state',
    is_public    TINYINT(1)   NOT NULL DEFAULT 0,
    share_token  VARCHAR(32)  DEFAULT NULL,
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user   (user_id),
    INDEX idx_public (is_public),
    INDEX idx_token  (share_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
