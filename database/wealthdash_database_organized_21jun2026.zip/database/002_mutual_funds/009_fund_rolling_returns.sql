-- ============================================================
-- Table: fund_rolling_returns
-- Domain: 002_mutual_funds  |  Sequence: 009
-- Source: migrations/013_fund_metrics.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fund_rolling_returns (
    id                    BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fund_id               INT UNSIGNED NOT NULL,
    period                ENUM('1Y','3Y','5Y') NOT NULL,
    min_return            DECIMAL(8,4) DEFAULT NULL,
    max_return            DECIMAL(8,4) DEFAULT NULL,
    avg_return            DECIMAL(8,4) DEFAULT NULL,
    median_return         DECIMAL(8,4) DEFAULT NULL,
    positive_periods_pct  DECIMAL(5,2) DEFAULT NULL COMMENT '% of windows with +ve return',
    total_windows         INT UNSIGNED DEFAULT NULL,
    calculated_date       DATE         NOT NULL,
    UNIQUE KEY uk_fund_period_date (fund_id, period, calculated_date),
    INDEX idx_fund (fund_id),
    INDEX idx_period (period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
