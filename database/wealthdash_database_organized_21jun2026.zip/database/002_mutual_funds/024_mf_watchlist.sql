-- ============================================================
-- Table: mf_watchlist
-- Domain: 002_mutual_funds  |  Sequence: 024
-- Source: migrations/010_watchlist.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_watchlist (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    fund_id     INT UNSIGNED NOT NULL,
    notes       VARCHAR(300) DEFAULT NULL,
    added_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_user_fund (user_id, fund_id),
    INDEX idx_user (user_id),
    INDEX idx_fund (fund_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
