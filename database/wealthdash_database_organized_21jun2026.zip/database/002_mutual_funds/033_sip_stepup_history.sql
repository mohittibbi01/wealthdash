-- ============================================================
-- Table: sip_stepup_history
-- Domain: 002_mutual_funds  |  Sequence: 033
-- Source: migrations/t144_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS sip_stepup_history (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    stepup_config_id INT UNSIGNED NOT NULL,
    sip_id           INT UNSIGNED NOT NULL,
    user_id          INT UNSIGNED NOT NULL,
    applied_date     DATE         NOT NULL,
    old_amount       DECIMAL(12,2) NOT NULL,
    new_amount       DECIMAL(12,2) NOT NULL,
    stepup_value     DECIMAL(10,4) NOT NULL,
    stepup_type      ENUM('percentage','fixed_amount') NOT NULL,
    applied_by       ENUM('auto','manual') NOT NULL DEFAULT 'manual',
    notes            TEXT         DEFAULT NULL,
    created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_config (stepup_config_id),
    INDEX idx_sip    (sip_id),
    INDEX idx_user   (user_id),
    INDEX idx_date   (applied_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
