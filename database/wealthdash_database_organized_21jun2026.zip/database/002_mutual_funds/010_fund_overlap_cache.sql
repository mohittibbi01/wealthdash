-- ============================================================
-- Table: fund_overlap_cache
-- Domain: 002_mutual_funds  |  Sequence: 010
-- Source: 15_fund_holdings.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `fund_overlap_cache` (
  `fund_id_a`    INT UNSIGNED NOT NULL,
  `fund_id_b`    INT UNSIGNED NOT NULL,
  `overlap_pct`  DECIMAL(5,2) NOT NULL  COMMENT 'Percentage of portfolio that overlaps (by weight)',
  `common_stocks` SMALLINT    NOT NULL DEFAULT 0,
  `month_year`   DATE         NOT NULL,
  `updated_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`fund_id_a`, `fund_id_b`, `month_year`),
  KEY `idx_oc_a` (`fund_id_a`),
  KEY `idx_oc_b` (`fund_id_b`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Precomputed pairwise fund overlap — recalculate monthly';
