-- ============================================================
-- Table: goal_fund_links
-- Domain: 002_mutual_funds  |  Sequence: 039
-- Source: 01_schema_complete.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: migrations/t139_migration.sql identical schema. Winner: base schema.
-- 
CREATE TABLE IF NOT EXISTS `goal_fund_links` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `goal_id` int(10) UNSIGNED NOT NULL,
  `fund_id` int(10) UNSIGNED DEFAULT NULL,
  `sip_id` int(10) UNSIGNED DEFAULT NULL,
  `link_type` enum('holding','sip') NOT NULL DEFAULT 'holding',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gfl_goal` (`goal_id`),
  CONSTRAINT `fk_gfl_goal` FOREIGN KEY (`goal_id`) REFERENCES `goal_buckets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
