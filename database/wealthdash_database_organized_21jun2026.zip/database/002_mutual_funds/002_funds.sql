-- ============================================================
-- Table: funds
-- Domain: 002_mutual_funds  |  Sequence: 002
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `funds` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `scheme_code` varchar(20) NOT NULL,
  `isin` varchar(20) DEFAULT NULL,
  `isin_reinvest` varchar(20) DEFAULT NULL,
  `fund_house_id` int(10) UNSIGNED DEFAULT NULL,
  `scheme_name` varchar(300) NOT NULL,
  `scheme_type` varchar(100) DEFAULT NULL,
  `scheme_category` varchar(100) DEFAULT NULL,
  `scheme_sub_category` varchar(100) DEFAULT NULL,
  `nav` decimal(14,4) DEFAULT NULL,
  `nav_date` date DEFAULT NULL,
  `return_1y` decimal(8,4) DEFAULT NULL,
  `return_3y` decimal(8,4) DEFAULT NULL,
  `return_5y` decimal(8,4) DEFAULT NULL,
  `return_since` decimal(8,4) DEFAULT NULL,
  `aum_cr` decimal(14,2) DEFAULT NULL,
  `expense_ratio` decimal(5,3) DEFAULT NULL,
  `exit_load_text` text DEFAULT NULL,
  `exit_load_pct` decimal(5,3) DEFAULT NULL,
  `exit_load_days` int(11) DEFAULT NULL,
  `risk_level` varchar(30) DEFAULT NULL,
  `benchmark` varchar(150) DEFAULT NULL,
  `fund_manager` varchar(150) DEFAULT NULL,
  `min_sip_amount` decimal(10,2) DEFAULT NULL,
  `min_lumpsum` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_scheme_code` (`scheme_code`),
  KEY `idx_fund_house` (`fund_house_id`),
  KEY `idx_fund_isin` (`isin`),
  KEY `idx_fund_category` (`scheme_category`),
  KEY `idx_fund_name` (`scheme_name`(100)),
  CONSTRAINT `fk_fund_house` FOREIGN KEY (`fund_house_id`) REFERENCES `fund_houses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
