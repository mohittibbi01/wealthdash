-- ============================================================
-- Table: nav_download_progress
-- Domain: 002_mutual_funds  |  Sequence: 037
-- Source: 42_fix_nav_queue.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 3 versions (01_schema, 42_fix, mf_list.php inline). WINNER: superset built from all — see note in file
-- 
CREATE TABLE IF NOT EXISTS `nav_download_progress` (
  `id`                   int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fund_id`              int(10) UNSIGNED DEFAULT NULL,
  `scheme_code`          varchar(20) NOT NULL,
  `status`               enum('pending','in_progress','completed','error') NOT NULL DEFAULT 'pending',
  `from_date`            date DEFAULT NULL,
  `last_downloaded_date` date DEFAULT NULL,
  `records_saved`        int(11) NOT NULL DEFAULT 0,
  `last_attempt`         datetime DEFAULT NULL,
  `error_message`        text DEFAULT NULL,
  `updated_at`           datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_scheme` (`scheme_code`),
  KEY `idx_ndp_fund` (`fund_id`),
  KEY `idx_ndp_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
