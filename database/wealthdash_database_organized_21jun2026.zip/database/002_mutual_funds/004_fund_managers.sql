-- ============================================================
-- Table: fund_managers
-- Domain: 002_mutual_funds  |  Sequence: 004
-- Source: 16_fund_managers.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 013_fund_metrics.sql also has this table but with fewer columns (since_date vs from_date+to_date). Winner: 16_fund_managers.sql (richer schema)
-- 
CREATE TABLE IF NOT EXISTS `fund_managers` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fund_id`      INT UNSIGNED NOT NULL,
  `manager_name` VARCHAR(200) NOT NULL,
  `from_date`    DATE         NOT NULL,
  `to_date`      DATE         DEFAULT NULL COMMENT 'NULL = currently managing',
  `is_current`   TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_fm_fund`    (`fund_id`),
  KEY `idx_fm_manager` (`manager_name`(100)),
  KEY `idx_fm_current` (`is_current`),
  CONSTRAINT `fk_fm_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Fund manager history — track performance before/after manager change';
