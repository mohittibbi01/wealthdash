-- ============================================================
-- Table: mf_holding_notes
-- Domain: 002_mutual_funds  |  Sequence: 020
-- Source: 14_mf_dividends_notes.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `mf_holding_notes` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` INT UNSIGNED NOT NULL,
  `fund_id`      INT UNSIGNED NOT NULL,
  `folio_number` VARCHAR(50)  DEFAULT NULL,
  `note`         TEXT         NOT NULL,
  `updated_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_note` (`portfolio_id`, `fund_id`, `folio_number`(30)),
  KEY `idx_hn_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_hn_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hn_fund`      FOREIGN KEY (`fund_id`)      REFERENCES `funds`(`id`)      ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Personal notes per MF fund/folio — "Bought on COVID dip", "Goal: retirement"';
