-- ============================================================
-- Table: mf_dividends
-- Domain: 002_mutual_funds  |  Sequence: 018
-- Source: 14_mf_dividends_notes.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 01_schema_complete.sql (basic) and migrations/t314_migration.sql (simplest, user_id+amount only). WINNER: 14_mf_dividends_notes.sql (richest schema — nav_before, nav_after, rate_per_unit). Added user_id + amount as compatibility columns for monthly_pl.php which uses them.
-- 
CREATE TABLE IF NOT EXISTS `mf_dividends` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`   INT UNSIGNED  NOT NULL,
  `fund_id`        INT UNSIGNED  NOT NULL,
  `folio_number`   VARCHAR(50)   DEFAULT NULL,
  `dividend_date`  DATE          NOT NULL,
  `nav_before`     DECIMAL(12,4) DEFAULT NULL COMMENT 'NAV ex-dividend date se pehle',
  `nav_after`      DECIMAL(12,4) DEFAULT NULL COMMENT 'NAV ex-dividend date ke baad',
  `rate_per_unit`  DECIMAL(10,4) NOT NULL    COMMENT 'Dividend rate per unit (₹)',
  `units_held`     DECIMAL(14,4) DEFAULT NULL,
  `amount_received` DECIMAL(14,2) DEFAULT NULL COMMENT 'rate_per_unit * units_held',
  `tds_deducted`   DECIMAL(10,2) DEFAULT 0.00,
  `net_received`   DECIMAL(14,2) DEFAULT NULL COMMENT 'amount_received - tds_deducted',
  `is_reinvested`  TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '1 = Growth/Reinvest plan',
  `created_at`     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dividend` (`portfolio_id`, `fund_id`, `folio_number`(30), `dividend_date`),
  KEY `idx_div_portfolio` (`portfolio_id`),
  KEY `idx_div_fund`      (`fund_id`),
  KEY `idx_div_date`      (`dividend_date`),
  CONSTRAINT `fk_div_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_div_fund`      FOREIGN KEY (`fund_id`)      REFERENCES `funds`(`id`)      ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='MF IDCW / Dividend payout history per folio';
