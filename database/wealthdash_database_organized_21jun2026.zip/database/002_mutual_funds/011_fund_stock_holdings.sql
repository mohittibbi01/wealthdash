-- ============================================================
-- Table: fund_stock_holdings
-- Domain: 002_mutual_funds  |  Sequence: 011
-- Source: 15_fund_holdings.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `fund_stock_holdings` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_id`      INT UNSIGNED  NOT NULL,
  `stock_name`   VARCHAR(300)  NOT NULL,
  `isin`         VARCHAR(15)   DEFAULT NULL,
  `sector`       VARCHAR(100)  DEFAULT NULL  COMMENT 'AMFI disclosure sector name',
  `weight_pct`   DECIMAL(6,3)  NOT NULL      COMMENT 'Percentage of fund portfolio (0-100)',
  `market_cap`   ENUM('large','mid','small','other') DEFAULT NULL,
  `month_year`   DATE          NOT NULL      COMMENT 'First day of disclosure month (e.g. 2026-03-01)',
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fund_stock_month` (`fund_id`, `isin`(15), `month_year`),
  KEY `idx_fsh_fund`      (`fund_id`),
  KEY `idx_fsh_isin`      (`isin`),
  KEY `idx_fsh_sector`    (`sector`(50)),
  KEY `idx_fsh_month`     (`month_year`),
  CONSTRAINT `fk_fsh_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='AMFI monthly portfolio disclosure — stock-level holdings per fund';
