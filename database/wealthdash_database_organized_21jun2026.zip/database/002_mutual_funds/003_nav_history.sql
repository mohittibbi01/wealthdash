-- ============================================================
-- Table: nav_history
-- Domain: 002_mutual_funds  |  Sequence: 003
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nav_history` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fund_id` int(10) UNSIGNED NOT NULL,
  `nav_date` date NOT NULL,
  `nav` decimal(14,4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nav` (`fund_id`, `nav_date`),
  KEY `idx_nav_date` (`nav_date`),
  CONSTRAINT `fk_navh_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
