-- ============================================================
-- Table: mf_transactions
-- Domain: 002_mutual_funds  |  Sequence: 017
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `mf_transactions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `fund_id` int(10) UNSIGNED NOT NULL,
  `folio_number` varchar(50) DEFAULT NULL,
  `txn_type` enum('purchase','redemption','switch_in','switch_out','dividend_reinvest','sip','swp') NOT NULL,
  `txn_date` date NOT NULL,
  `units` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `nav` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `platform` varchar(50) DEFAULT NULL,
  `investment_fy` varchar(10) DEFAULT NULL COMMENT 'e.g. 2024-25',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mft_portfolio` (`portfolio_id`),
  KEY `idx_mft_fund` (`fund_id`),
  KEY `idx_mft_date` (`txn_date`),
  KEY `idx_mft_type` (`txn_type`),
  CONSTRAINT `fk_mft_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`),
  CONSTRAINT `fk_mft_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
