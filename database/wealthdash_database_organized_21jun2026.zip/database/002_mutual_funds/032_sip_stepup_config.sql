-- ============================================================
-- Table: sip_stepup_config
-- Domain: 002_mutual_funds  |  Sequence: 032
-- Source: migrations/t144_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS sip_stepup_config (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sip_id           INT UNSIGNED NOT NULL COMMENT 'References sip_schedules.id',
    user_id          INT UNSIGNED NOT NULL,
    portfolio_id     INT UNSIGNED NOT NULL,
    stepup_type      ENUM('percentage','fixed_amount') NOT NULL DEFAULT 'percentage',
    stepup_value     DECIMAL(10,4) NOT NULL COMMENT 'Percentage OR fixed rupee amount',
    stepup_frequency ENUM('yearly','half_yearly','custom') NOT NULL DEFAULT 'yearly',
    stepup_month     TINYINT UNSIGNED DEFAULT 4  COMMENT 'Month to apply step-up (default April = FY start)',
    custom_interval_months TINYINT UNSIGNED DEFAULT NULL,
    max_sip_amount   DECIMAL(12,2) DEFAULT NULL COMMENT 'Cap the SIP at this amount',
    is_active        TINYINT(1)   NOT NULL DEFAULT 1,
    next_stepup_date DATE         DEFAULT NULL,
    last_stepup_date DATE         DEFAULT NULL,
    last_stepup_from DECIMAL(12,2) DEFAULT NULL,
    last_stepup_to   DECIMAL(12,2) DEFAULT NULL,
    notes            TEXT         DEFAULT NULL,
    created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_sip (sip_id),
    INDEX idx_user  (user_id),
    INDEX idx_next  (next_stepup_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
