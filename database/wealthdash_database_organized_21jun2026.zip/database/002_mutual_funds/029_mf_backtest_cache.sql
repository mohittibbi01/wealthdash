-- ============================================================
-- Table: mf_backtest_cache
-- Domain: 002_mutual_funds  |  Sequence: 029
-- Source: migrations/t234_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `mf_backtest_cache` (
    `id`             INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    `fund_id`        INT UNSIGNED      NOT NULL,
    `period`         VARCHAR(5)        NOT NULL COMMENT '1Y,3Y,5Y,10Y,etc.',
    `monthly_amount` DECIMAL(12,2)     NOT NULL DEFAULT 5000.00,
    `sip_day`        TINYINT UNSIGNED  NOT NULL DEFAULT 1,
    `result_json`    MEDIUMTEXT        NOT NULL COMMENT 'Cached JSON response',
    `nav_count`      INT UNSIGNED      NOT NULL DEFAULT 0 COMMENT 'nav_history rows at cache time',
    `computed_at`    DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_backtest_cache` (`fund_id`, `period`, `monthly_amount`, `sip_day`),
    INDEX `idx_backtest_fund`     (`fund_id`),
    INDEX `idx_backtest_computed` (`computed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Cache for SIP vs Lumpsum backtest results (t234)';
