-- ============================================================
-- Table: goal_mf_links
-- Domain: 002_mutual_funds  |  Sequence: 040
-- Source: migrations/025_goal_buckets.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `goal_mf_links` (
    `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `goal_id`      INT UNSIGNED NOT NULL,
    `portfolio_id` INT UNSIGNED NOT NULL,
    `fund_id`      INT UNSIGNED NOT NULL COMMENT 'mf_holdings.fund_id',
    `allocation_pct` DECIMAL(5,2) DEFAULT 100.00 COMMENT 'What % of this holding counts toward goal',
    `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_goal_mf` (`goal_id`, `fund_id`, `portfolio_id`),
    CONSTRAINT `fk_goal_mf_goal` FOREIGN KEY (`goal_id`) REFERENCES `goals`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
