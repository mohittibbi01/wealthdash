-- ============================================================
-- Table: fund_portfolio_holdings
-- Domain: 002_mutual_funds  |  Sequence: 012
-- Source: migrations/015_saved_screens_and_more.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fund_portfolio_holdings (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fund_id     INT UNSIGNED NOT NULL,
    stock_name  VARCHAR(100) NOT NULL,
    isin        VARCHAR(12)  DEFAULT NULL,
    sector      VARCHAR(60)  DEFAULT NULL,
    weight_pct  DECIMAL(5,2) DEFAULT NULL,
    month_year  VARCHAR(7)   NOT NULL COMMENT 'YYYY-MM',
    UNIQUE KEY uk_fund_stock_month (fund_id, isin, month_year),
    INDEX idx_fund  (fund_id),
    INDEX idx_month (month_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
