-- ============================================================
-- Table: mf_holdings_notes
-- Domain: 002_mutual_funds  |  Sequence: 021
-- Source: migrations/015_saved_screens_and_more.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_holdings_notes (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NOT NULL,
    holding_id INT UNSIGNED NOT NULL,
    note_text  TEXT         NOT NULL,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_user_holding (user_id, holding_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
