-- ============================================================
-- Table: fund_dividends
-- Domain: 002_mutual_funds  |  Sequence: 014
-- Source: migrations/015_saved_screens_and_more.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fund_dividends (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fund_id         INT UNSIGNED NOT NULL,
    record_date     DATE         NOT NULL,
    ex_date         DATE         DEFAULT NULL,
    dividend_per_unit DECIMAL(10,4) NOT NULL,
    UNIQUE KEY uk_fund_date (fund_id, record_date),
    INDEX idx_fund (fund_id),
    INDEX idx_date (record_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
