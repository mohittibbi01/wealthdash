-- ============================================================
-- Table: mf_alert_history
-- Domain: 002_mutual_funds  |  Sequence: 023
-- Source: migrations/010_watchlist.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_alert_history (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    alert_id    INT UNSIGNED    NOT NULL,
    user_id     INT UNSIGNED    NOT NULL,
    fund_id     INT UNSIGNED    NOT NULL,
    trigger_val DECIMAL(12,4)   DEFAULT NULL,
    triggered_at DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_alert  (alert_id),
    INDEX idx_user   (user_id),
    INDEX idx_date   (triggered_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
