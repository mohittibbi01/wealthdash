-- ============================================================
-- Table: benchmark_nav
-- Domain: 002_mutual_funds  |  Sequence: 007
-- Source: migrations/013_fund_metrics.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS benchmark_nav (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code       VARCHAR(30) NOT NULL,
    nav_date   DATE        NOT NULL,
    nav_value  DECIMAL(12,4) NOT NULL,
    UNIQUE KEY uk_code_date (code, nav_date),
    INDEX idx_code (code),
    INDEX idx_date (nav_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
