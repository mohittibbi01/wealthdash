-- ============================================================
-- Table: sip_stepup_nudges
-- Domain: 002_mutual_funds  |  Sequence: 034
-- Source: migrations/t144_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS sip_stepup_nudges (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id          INT UNSIGNED NOT NULL,
    nudge_type       ENUM('salary_hike','fy_start','manual_prompt','anniversary') NOT NULL DEFAULT 'fy_start',
    nudge_date       DATE         NOT NULL,
    is_dismissed     TINYINT(1)   NOT NULL DEFAULT 0,
    is_actioned      TINYINT(1)   NOT NULL DEFAULT 0,
    actioned_sip_ids TEXT         DEFAULT NULL COMMENT 'JSON array of sip_ids that were stepped up',
    created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user   (user_id),
    INDEX idx_date   (nudge_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
