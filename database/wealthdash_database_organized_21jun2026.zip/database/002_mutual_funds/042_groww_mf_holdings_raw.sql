-- ============================================================
-- Table: groww_mf_holdings_raw
-- Domain: 002_mutual_funds  |  Sequence: 042
-- Source: migrations/t392_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_mf_holdings_raw` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `sync_log_id`     INT UNSIGNED NOT NULL,
    `groww_folio`     VARCHAR(100) DEFAULT NULL,
    `groww_scheme_id` VARCHAR(100) DEFAULT NULL,
    `scheme_name`     VARCHAR(300) NOT NULL,
    `isin`            VARCHAR(20)  DEFAULT NULL,
    `units`           DECIMAL(14,4) DEFAULT NULL,
    `nav`             DECIMAL(12,4) DEFAULT NULL,
    `current_value`   DECIMAL(14,2) DEFAULT NULL,
    `invested_value`  DECIMAL(14,2) DEFAULT NULL,
    `fund_id`         INT UNSIGNED DEFAULT NULL COMMENT 'Resolved WD fund_id',
    `is_mapped`       TINYINT(1)   NOT NULL DEFAULT 0,
    `synced_at`       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user`  (`user_id`),
    INDEX `idx_sync`  (`sync_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
