-- ============================================================
-- Table: fund_ter_history
-- Domain: 002_mutual_funds  |  Sequence: 013
-- Source: migrations/015_saved_screens_and_more.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fund_ter_history (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fund_id        INT UNSIGNED NOT NULL,
    ter_pct        DECIMAL(5,3) NOT NULL,
    effective_date DATE         NOT NULL,
    UNIQUE KEY uk_fund_date (fund_id, effective_date),
    INDEX idx_fund (fund_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
