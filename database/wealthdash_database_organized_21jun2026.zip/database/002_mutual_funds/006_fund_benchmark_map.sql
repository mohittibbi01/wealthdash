-- ============================================================
-- Table: fund_benchmark_map
-- Domain: 002_mutual_funds  |  Sequence: 006
-- Source: migrations/013_fund_metrics.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fund_benchmark_map (
    fund_id        INT UNSIGNED NOT NULL PRIMARY KEY,
    benchmark_code VARCHAR(30)  NOT NULL COMMENT 'e.g. NIFTY50, NIFTYMIDCAP150',
    benchmark_name VARCHAR(80)  NOT NULL,
    updated_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_benchmark (benchmark_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
