-- ============================================================
-- Table: mf_holdings
-- Domain: 002_mutual_funds  |  Sequence: 016
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `mf_holdings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `fund_id` int(10) UNSIGNED NOT NULL,
  `folio_number` varchar(50) DEFAULT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `units` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `avg_nav` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `invested_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `current_value` decimal(16,2) NOT NULL DEFAULT 0.00,
  `gain_loss` decimal(16,2) NOT NULL DEFAULT 0.00,
  `xirr` decimal(8,4) DEFAULT NULL,
  `sip_active` tinyint(1) NOT NULL DEFAULT 0,
  `swp_active` tinyint(1) NOT NULL DEFAULT 0,
  `first_investment_date` date DEFAULT NULL,
  `last_transaction_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mfh` (`portfolio_id`, `fund_id`, `folio_number`),
  KEY `idx_mfh_fund` (`fund_id`),
  CONSTRAINT `fk_mfh_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`),
  CONSTRAINT `fk_mfh_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
