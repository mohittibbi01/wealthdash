-- ============================================================
-- Table: benchmark_nav_cache
-- Domain: 002_mutual_funds  |  Sequence: 008
-- Source: migrations/tv11_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `benchmark_nav_cache` (
    `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `symbol`     VARCHAR(20)   NOT NULL COMMENT '^NSEI, ^BSESN, etc.',
    `nav_date`   DATE          NOT NULL,
    `close`      DECIMAL(14,4) NOT NULL,
    `fetched_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_bm_nav`       (`symbol`, `nav_date`),
    INDEX       `idx_bm_symbol`  (`symbol`),
    INDEX       `idx_bm_date`    (`nav_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Benchmark index NAV cache — Nifty 50, Sensex, Midcap etc. (tv11)';
