-- ============================================================
-- Table: import_logs
-- Domain: 002_mutual_funds  |  Sequence: 038
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `import_logs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `portfolio_id` int(10) UNSIGNED DEFAULT NULL,
  `import_type` varchar(50) NOT NULL COMMENT 'csv, cas_pdf, etc',
  `filename` varchar(255) DEFAULT NULL,
  `rows_total` int(11) NOT NULL DEFAULT 0,
  `rows_success` int(11) NOT NULL DEFAULT 0,
  `rows_failed` int(11) NOT NULL DEFAULT 0,
  `status` enum('pending','processing','done','failed') NOT NULL DEFAULT 'pending',
  `error_log` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_il_user` (`user_id`),
  KEY `idx_il_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_il_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
