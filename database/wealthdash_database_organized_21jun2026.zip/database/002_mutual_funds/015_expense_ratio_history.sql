-- ============================================================
-- Table: expense_ratio_history
-- Domain: 002_mutual_funds  |  Sequence: 015
-- Source: 17_expense_history_import_log.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `expense_ratio_history` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_id`        INT UNSIGNED  NOT NULL,
  `expense_ratio`  DECIMAL(6,4)  NOT NULL COMMENT 'TER in % (e.g. 1.05 = 1.05%)',
  `plan_type`      ENUM('direct','regular') NOT NULL DEFAULT 'direct',
  `recorded_date`  DATE          NOT NULL COMMENT 'First day of the month (monthly snapshot)',
  `source`         VARCHAR(100)  DEFAULT 'amfi_website',
  `created_at`     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_exp_fund_month` (`fund_id`, `plan_type`, `recorded_date`),
  KEY `idx_erh_fund` (`fund_id`),
  KEY `idx_erh_date` (`recorded_date`),
  CONSTRAINT `fk_erh_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Monthly TER snapshot — track if expense ratio is rising or falling';
