-- ============================================================
-- Table: nav_proxy_cache
-- Domain: 002_mutual_funds  |  Sequence: 036
-- Source: 19_nav_proxy_cache.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nav_proxy_cache` (
  `fund_id`      INT UNSIGNED NOT NULL,
  `period`       ENUM('1M','3M','6M','1Y','3Y','5Y','ALL') NOT NULL,
  `data_json`    LONGTEXT     NOT NULL COMMENT 'JSON: [{date:"YYYY-MM-DD", nav:"X.XX"}, ...]',
  `data_points`  INT          NOT NULL DEFAULT 0,
  `cached_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `source`       ENUM('nav_history','mfapi') NOT NULL DEFAULT 'nav_history',
  PRIMARY KEY (`fund_id`, `period`),
  KEY `idx_npc_cached_at` (`cached_at`),
  CONSTRAINT `fk_npc_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Server-side cache for NAV chart data — serves screener drawer charts faster';
