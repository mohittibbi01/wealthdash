-- ============================================================
-- Table: fund_ratings
-- Domain: 002_mutual_funds  |  Sequence: 005
-- Source: 23_fund_ratings.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 015_saved_screens_and_more.sql also has this table. Winner: 23_fund_ratings.sql (JSON score_breakdown, FK constraint, fuller schema)
-- 
CREATE TABLE IF NOT EXISTS `fund_ratings` (
  `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fund_id`          INT UNSIGNED NOT NULL,
  `stars`            TINYINT UNSIGNED NOT NULL COMMENT '1-5 star rating',
  `score_total`      DECIMAL(6,4)  DEFAULT NULL COMMENT 'Raw weighted score before rounding',
  `score_breakdown`  JSON          DEFAULT NULL COMMENT '{"returns":2.5,"expense":0.75,"drawdown":0.75,"direct":0.2}',
  `rated_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fr_fund` (`fund_id`),
  KEY `idx_fr_stars` (`stars`),
  KEY `idx_fr_rated` (`rated_at`),
  CONSTRAINT `fk_fr_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='WealthDash internal fund star ratings — recalculated weekly by cron';
