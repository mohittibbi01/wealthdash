-- ============================================================
-- Table: mf_compare_sessions
-- Domain: 002_mutual_funds  |  Sequence: 028
-- Source: migrations/tv12_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_compare_sessions (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    fund_ids    VARCHAR(100) NOT NULL COMMENT 'comma-separated fund IDs, max 5',
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_user (user_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
