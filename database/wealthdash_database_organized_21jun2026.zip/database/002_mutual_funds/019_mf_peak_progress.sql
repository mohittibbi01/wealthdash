-- ============================================================
-- Table: mf_peak_progress
-- Domain: 002_mutual_funds  |  Sequence: 019
-- Source: 01_schema_complete.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 21_peak_nav_setup.sql also has this (missing needs_update status). Winner: 01_schema_complete.sql (has needs_update enum value)
-- 
CREATE TABLE IF NOT EXISTS `mf_peak_progress` (
  `scheme_code` varchar(20) NOT NULL,
  `last_processed_date` date DEFAULT NULL,
  `status` enum('pending','in_progress','completed','needs_update','error') NOT NULL DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`scheme_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
