-- ============================================================
-- Table: smallcase_transactions
-- Domain: 021_broker_integrations  |  Sequence: 012
-- Source: migrations/t120_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smallcase_transactions (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    smallcase_id     INT UNSIGNED NOT NULL,
    user_id          INT UNSIGNED NOT NULL,
    txn_type         ENUM('invest','redeem','rebalance','dividend','switch') NOT NULL DEFAULT 'invest',
    txn_date         DATE         NOT NULL,
    amount           DECIMAL(14,2) NOT NULL DEFAULT 0,
    units_change     DECIMAL(14,4) DEFAULT NULL COMMENT 'For individual stock change in rebalance',
    notes            TEXT          DEFAULT NULL,
    import_source    VARCHAR(50)   DEFAULT 'manual',
    created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_smallcase (smallcase_id),
    INDEX idx_user      (user_id),
    INDEX idx_date      (txn_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
