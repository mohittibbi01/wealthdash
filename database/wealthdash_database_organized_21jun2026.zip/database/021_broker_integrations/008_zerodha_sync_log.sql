-- ============================================================
-- Table: zerodha_sync_log
-- Domain: 021_broker_integrations  |  Sequence: 008
-- Source: migrations/t301_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_sync_log` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `portfolio_id`    INT UNSIGNED DEFAULT NULL,
    `triggered_by`    ENUM('manual','cron','webhook') NOT NULL DEFAULT 'manual',
    `holdings_fetched`INT UNSIGNED DEFAULT 0,
    `holdings_added`  INT UNSIGNED DEFAULT 0,
    `holdings_updated`INT UNSIGNED DEFAULT 0,
    `positions_fetched`INT UNSIGNED DEFAULT 0,
    `status`          ENUM('success','failed','partial') NOT NULL DEFAULT 'success',
    `error_message`   TEXT         DEFAULT NULL,
    `api_calls_made`  TINYINT UNSIGNED DEFAULT 0,
    `duration_ms`     INT UNSIGNED DEFAULT NULL,
    `synced_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_zsync_user`   (`user_id`),
    INDEX `idx_zsync_at`     (`synced_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
