-- ============================================================
-- Table: zerodha_gtt
-- Domain: 021_broker_integrations  |  Sequence: 006
-- Source: migrations/t391_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_gtt` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `gtt_id`          INT UNSIGNED NOT NULL,
    `status`          VARCHAR(20)  DEFAULT NULL,
    `type`            VARCHAR(20)  DEFAULT NULL  COMMENT 'single,two-leg',
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `exchange`        VARCHAR(10)  DEFAULT NULL,
    `trigger_values`  JSON         DEFAULT NULL,
    `last_price`      DECIMAL(14,4) DEFAULT 0,
    `condition`       JSON         DEFAULT NULL,
    `orders`          JSON         DEFAULT NULL,
    `created_at`      DATETIME     DEFAULT NULL,
    `updated_at`      DATETIME     DEFAULT NULL,
    `expires_at`      DATETIME     DEFAULT NULL,
    `synced_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zgtt_user` (`user_id`, `gtt_id`),
    INDEX `idx_zgtt_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
