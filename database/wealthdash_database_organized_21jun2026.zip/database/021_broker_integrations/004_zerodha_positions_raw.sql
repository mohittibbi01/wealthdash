-- ============================================================
-- Table: zerodha_positions_raw
-- Domain: 021_broker_integrations  |  Sequence: 004
-- Source: migrations/t301_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_positions_raw` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `position_type`   ENUM('day','net') NOT NULL DEFAULT 'net',
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `exchange`        VARCHAR(10)  NOT NULL DEFAULT 'NSE',
    `product`         VARCHAR(10)  DEFAULT NULL,
    `quantity`        INT          NOT NULL DEFAULT 0,
    `overnight_quantity` INT       DEFAULT 0,
    `buy_quantity`    INT          DEFAULT 0,
    `sell_quantity`   INT          DEFAULT 0,
    `average_price`   DECIMAL(12,4) DEFAULT 0,
    `last_price`      DECIMAL(12,4) DEFAULT NULL,
    `pnl`             DECIMAL(14,4) DEFAULT NULL,
    `realised`        DECIMAL(14,4) DEFAULT NULL,
    `unrealised`      DECIMAL(14,4) DEFAULT NULL,
    `m2m`             DECIMAL(14,4) DEFAULT NULL,
    `raw_json`        JSON         DEFAULT NULL,
    `synced_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zpos_user_sym` (`user_id`, `position_type`, `tradingsymbol`, `exchange`, `product`),
    INDEX `idx_zpos_user` (`user_id`),
    INDEX `idx_zpos_sync` (`synced_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
