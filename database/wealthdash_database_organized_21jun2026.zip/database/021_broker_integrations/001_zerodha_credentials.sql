-- ============================================================
-- Table: zerodha_credentials
-- Domain: 021_broker_integrations  |  Sequence: 001
-- Source: migrations/t301_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_credentials` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `api_key`         VARCHAR(255) NOT NULL                    COMMENT 'Kite API key (encrypted)',
    `api_secret`      VARCHAR(255) NOT NULL                    COMMENT 'Kite API secret (encrypted)',
    `access_token`    VARCHAR(512) DEFAULT NULL                COMMENT 'Session access token (refreshed daily)',
    `request_token`   VARCHAR(255) DEFAULT NULL                COMMENT 'Last OAuth request token used',
    `token_expiry`    DATETIME     DEFAULT NULL                COMMENT 'Access token valid until (usually next 6am IST)',
    `kite_user_id`    VARCHAR(30)  DEFAULT NULL                COMMENT 'Zerodha client ID e.g. AB1234',
    `kite_user_name`  VARCHAR(100) DEFAULT NULL,
    `login_time`      DATETIME     DEFAULT NULL,
    `is_active`       TINYINT(1)   NOT NULL DEFAULT 1,
    `last_sync_at`    DATETIME     DEFAULT NULL,
    `last_sync_status`ENUM('success','failed','pending') DEFAULT NULL,
    `last_sync_error` TEXT         DEFAULT NULL,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zerodha_user` (`user_id`),
    INDEX `idx_zerodha_active` (`is_active`, `token_expiry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
