-- ============================================================
-- Table: zerodha_margins
-- Domain: 021_broker_integrations  |  Sequence: 007
-- Source: migrations/t391_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_margins` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`     INT UNSIGNED NOT NULL,
    `segment`     VARCHAR(10)  NOT NULL,
    `net`         DECIMAL(14,4) DEFAULT 0,
    `available`   DECIMAL(14,4) DEFAULT 0,
    `used`        DECIMAL(14,4) DEFAULT 0,
    `payin`       DECIMAL(14,4) DEFAULT 0,
    `payout`      DECIMAL(14,4) DEFAULT 0,
    `raw_json`    JSON          DEFAULT NULL,
    `fetched_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zm_user_seg` (`user_id`, `segment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
