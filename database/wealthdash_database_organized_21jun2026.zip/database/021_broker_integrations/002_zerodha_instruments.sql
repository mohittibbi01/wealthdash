-- ============================================================
-- Table: zerodha_instruments
-- Domain: 021_broker_integrations  |  Sequence: 002
-- Source: migrations/t391_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_instruments` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `instrument_token`INT UNSIGNED NOT NULL,
    `exchange_token`  INT UNSIGNED DEFAULT NULL,
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `name`            VARCHAR(200) DEFAULT NULL,
    `last_price`      DECIMAL(14,4) DEFAULT 0,
    `expiry`          DATE          DEFAULT NULL,
    `strike`          DECIMAL(14,4) DEFAULT NULL,
    `tick_size`       DECIMAL(10,4) DEFAULT NULL,
    `lot_size`        INT           DEFAULT 1,
    `instrument_type` VARCHAR(10)  DEFAULT NULL  COMMENT 'EQ,FUT,CE,PE,MF',
    `segment`         VARCHAR(20)  DEFAULT NULL  COMMENT 'NSE,BSE,NFO,CDS',
    `exchange`        VARCHAR(10)  DEFAULT NULL,
    `isin`            VARCHAR(20)  DEFAULT NULL,
    `refreshed_at`    DATETIME     DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zi_token` (`instrument_token`),
    INDEX `idx_zi_symbol` (`tradingsymbol`, `exchange`),
    INDEX `idx_zi_isin`   (`isin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
