-- ============================================================
-- Table: zerodha_quote_snapshots
-- Domain: 021_broker_integrations  |  Sequence: 009
-- Source: migrations/t391_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_quote_snapshots` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `exchange`        VARCHAR(10)  NOT NULL,
    `last_price`      DECIMAL(14,4) DEFAULT 0,
    `net_change`      DECIMAL(14,4) DEFAULT 0,
    `net_change_pct`  DECIMAL(8,4)  DEFAULT 0,
    `volume`          BIGINT UNSIGNED DEFAULT 0,
    `oi`              BIGINT UNSIGNED DEFAULT 0,
    `high`            DECIMAL(14,4) DEFAULT 0,
    `low`             DECIMAL(14,4) DEFAULT 0,
    `open`            DECIMAL(14,4) DEFAULT 0,
    `close`           DECIMAL(14,4) DEFAULT 0,
    `raw_json`        JSON          DEFAULT NULL,
    `fetched_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zqs_user_sym` (`user_id`, `tradingsymbol`, `exchange`),
    INDEX `idx_zqs_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
