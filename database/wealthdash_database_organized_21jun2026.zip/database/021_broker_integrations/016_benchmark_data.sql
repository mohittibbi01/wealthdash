-- ============================================================
-- Table: benchmark_data
-- Domain: 021_broker_integrations  |  Sequence: 016
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS benchmark_data (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    benchmark_name VARCHAR(50) NOT NULL COMMENT 'NIFTY50/SENSEX/NIFTY500',
    data_date DATE NOT NULL,
    close_value DECIMAL(15,4) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_bench_date (benchmark_name, data_date),
    INDEX idx_date (data_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
