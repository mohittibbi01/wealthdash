-- ============================================================
-- Table: zerodha_orders
-- Domain: 021_broker_integrations  |  Sequence: 005
-- Source: migrations/t391_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_orders` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `order_id`        VARCHAR(30)  NOT NULL,
    `exchange_order_id` VARCHAR(30) DEFAULT NULL,
    `parent_order_id` VARCHAR(30)  DEFAULT NULL,
    `status`          VARCHAR(30)  DEFAULT NULL,
    `status_message`  VARCHAR(255) DEFAULT NULL,
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `exchange`        VARCHAR(10)  DEFAULT NULL,
    `instrument_token`INT UNSIGNED DEFAULT NULL,
    `order_type`      VARCHAR(20)  DEFAULT NULL  COMMENT 'MARKET,LIMIT,SL,SL-M',
    `transaction_type`VARCHAR(5)   DEFAULT NULL  COMMENT 'BUY,SELL',
    `product`         VARCHAR(10)  DEFAULT NULL  COMMENT 'CNC,MIS,NRML',
    `validity`        VARCHAR(5)   DEFAULT NULL  COMMENT 'DAY,IOC',
    `quantity`        INT          DEFAULT 0,
    `pending_quantity`INT          DEFAULT 0,
    `filled_quantity` INT          DEFAULT 0,
    `price`           DECIMAL(14,4) DEFAULT 0,
    `trigger_price`   DECIMAL(14,4) DEFAULT 0,
    `average_price`   DECIMAL(14,4) DEFAULT 0,
    `placed_by`       VARCHAR(10)  DEFAULT NULL,
    `variety`         VARCHAR(10)  DEFAULT NULL,
    `order_timestamp` DATETIME     DEFAULT NULL,
    `exchange_timestamp` DATETIME  DEFAULT NULL,
    `raw_json`        JSON         DEFAULT NULL,
    `synced_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zo_order` (`user_id`, `order_id`),
    INDEX `idx_zo_user`   (`user_id`),
    INDEX `idx_zo_symbol` (`tradingsymbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
