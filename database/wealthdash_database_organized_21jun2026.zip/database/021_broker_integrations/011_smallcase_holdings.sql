-- ============================================================
-- Table: smallcase_holdings
-- Domain: 021_broker_integrations  |  Sequence: 011
-- Source: migrations/t120_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smallcase_holdings (
    id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    smallcase_id       INT UNSIGNED NOT NULL,
    user_id            INT UNSIGNED NOT NULL,
    symbol             VARCHAR(30)  NOT NULL,
    company_name       VARCHAR(200) NOT NULL,
    exchange           ENUM('NSE','BSE') NOT NULL DEFAULT 'NSE',
    isin               VARCHAR(20)  DEFAULT NULL,
    quantity           DECIMAL(14,4) NOT NULL DEFAULT 0,
    avg_buy_price      DECIMAL(12,4) NOT NULL DEFAULT 0,
    invested_amount    DECIMAL(14,2) NOT NULL DEFAULT 0,
    current_price      DECIMAL(12,4) DEFAULT NULL,
    current_value      DECIMAL(14,2) DEFAULT NULL,
    weight_pct         DECIMAL(6,2)  DEFAULT NULL COMMENT 'Allocation % in this basket',
    target_weight_pct  DECIMAL(6,2)  DEFAULT NULL,
    sector             VARCHAR(100)  DEFAULT NULL,
    last_price_date    DATE          DEFAULT NULL,
    created_at         DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at         DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_smallcase (smallcase_id),
    INDEX idx_user      (user_id),
    INDEX idx_symbol    (symbol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
