-- ============================================================
-- Table: smallcase_rebalance_history
-- Domain: 021_broker_integrations  |  Sequence: 013
-- Source: migrations/t120_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smallcase_rebalance_history (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    smallcase_id     INT UNSIGNED NOT NULL,
    user_id          INT UNSIGNED NOT NULL,
    rebalance_date   DATE         NOT NULL,
    reason           VARCHAR(200) DEFAULT NULL COMMENT 'e.g. Quarterly rebalance, Stock addition',
    stocks_added     TEXT         DEFAULT NULL COMMENT 'JSON array of symbols added',
    stocks_removed   TEXT         DEFAULT NULL COMMENT 'JSON array of symbols removed',
    stocks_changed   TEXT         DEFAULT NULL COMMENT 'JSON array of weight changes',
    portfolio_value  DECIMAL(14,2) DEFAULT NULL,
    notes            TEXT         DEFAULT NULL,
    created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_smallcase (smallcase_id),
    INDEX idx_user      (user_id),
    INDEX idx_date      (rebalance_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
