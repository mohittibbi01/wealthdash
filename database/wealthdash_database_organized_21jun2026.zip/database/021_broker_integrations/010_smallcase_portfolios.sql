-- ============================================================
-- Table: smallcase_portfolios
-- Domain: 021_broker_integrations  |  Sequence: 010
-- Source: migrations/t120_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smallcase_portfolios (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id          INT UNSIGNED NOT NULL,
    portfolio_id     INT UNSIGNED NOT NULL,
    name             VARCHAR(200) NOT NULL,
    description      TEXT         DEFAULT NULL,
    strategy_type    VARCHAR(100) DEFAULT NULL,
    manager          VARCHAR(100) DEFAULT NULL,
    external_id      VARCHAR(100) DEFAULT NULL COMMENT 'Smallcase basket ID if available',
    invested_amount  DECIMAL(14,2) NOT NULL DEFAULT 0,
    current_value    DECIMAL(14,2) DEFAULT NULL,
    gain_loss        DECIMAL(14,2) DEFAULT NULL,
    gain_loss_pct    DECIMAL(8,4)  DEFAULT NULL,
    xirr             DECIMAL(8,4)  DEFAULT NULL,
    subscription_fee DECIMAL(10,2) DEFAULT 0,
    fee_frequency    ENUM('monthly','quarterly','yearly','one_time') DEFAULT NULL,
    last_rebalanced  DATE          DEFAULT NULL,
    next_rebalance   DATE          DEFAULT NULL,
    is_active        TINYINT(1)    NOT NULL DEFAULT 1,
    notes            TEXT          DEFAULT NULL,
    created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user       (user_id),
    INDEX idx_portfolio  (portfolio_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
