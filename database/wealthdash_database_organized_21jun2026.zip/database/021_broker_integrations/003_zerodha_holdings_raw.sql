-- ============================================================
-- Table: zerodha_holdings_raw
-- Domain: 021_broker_integrations  |  Sequence: 003
-- Source: migrations/t301_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_holdings_raw` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `exchange`        VARCHAR(10)  NOT NULL DEFAULT 'NSE',
    `isin`            VARCHAR(20)  DEFAULT NULL,
    `quantity`        INT          NOT NULL DEFAULT 0,
    `t1_quantity`     INT          NOT NULL DEFAULT 0          COMMENT 'T+1 settlement qty',
    `average_price`   DECIMAL(12,4) NOT NULL DEFAULT 0,
    `last_price`      DECIMAL(12,4) DEFAULT NULL,
    `close_price`     DECIMAL(12,4) DEFAULT NULL,
    `pnl`             DECIMAL(14,4) DEFAULT NULL,
    `day_change`      DECIMAL(12,4) DEFAULT NULL,
    `day_change_pct`  DECIMAL(8,4)  DEFAULT NULL,
    `product`         VARCHAR(10)  DEFAULT NULL                COMMENT 'CNC / MIS',
    `collateral_qty`  INT          DEFAULT 0,
    `collateral_type` VARCHAR(30)  DEFAULT NULL,
    `used_quantity`   INT          DEFAULT 0,
    `realised_quantity` INT        DEFAULT 0,
    `authorised_date` DATE         DEFAULT NULL,
    `raw_json`        JSON         DEFAULT NULL                COMMENT 'Full Kite holding object',
    `synced_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zh_user_symbol` (`user_id`, `tradingsymbol`, `exchange`),
    INDEX `idx_zh_user`   (`user_id`),
    INDEX `idx_zh_isin`   (`isin`),
    INDEX `idx_zh_sync`   (`synced_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
