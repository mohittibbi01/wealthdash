-- ============================================================
-- Table: benchmark_snapshots
-- Domain: 021_broker_integrations  |  Sequence: 015
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS benchmark_snapshots (
  id                      INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id                 INT UNSIGNED NOT NULL UNIQUE,
  age_bracket             VARCHAR(10)  NOT NULL COMMENT '18-24, 25-34, 35-44, 45-54, 55+',
  risk_profile            VARCHAR(30)  NOT NULL,
  savings_rate            DECIMAL(6,2) NULL COMMENT 'percent',
  gain_pct                DECIMAL(7,2) NULL COMMENT 'percent',
  sip_count               SMALLINT     NULL,
  monthly_sip_pct_income  DECIMAL(6,2) NULL COMMENT 'percent',
  num_holdings            SMALLINT     NULL,
  created_at              DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at              DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_cohort (age_bracket, risk_profile),
  CONSTRAINT fk_bs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
