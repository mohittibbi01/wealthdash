-- ============================================================
-- Table: crypto_transactions
-- Domain: 007_crypto  |  Sequence: 003
-- Source: 38_crypto_holdings.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT same files. Winner: 38_ (richer, consistent with crypto_holdings)

CREATE TABLE IF NOT EXISTS `crypto_transactions` (
    `id`           INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `portfolio_id` INT UNSIGNED     NOT NULL,
    `coin_id`      VARCHAR(60)      NOT NULL,
    `coin_symbol`  VARCHAR(20)      NOT NULL,
    `txn_type`     ENUM('BUY','SELL','TRANSFER_IN','TRANSFER_OUT') NOT NULL DEFAULT 'BUY',
    `quantity`     DECIMAL(24,8)    NOT NULL,
    `price_inr`    DECIMAL(20,4)    NOT NULL DEFAULT 0,    -- price per coin in INR at time of txn
    `amount_inr`   DECIMAL(20,2)    NOT NULL DEFAULT 0,    -- total txn value in INR
    `tds_deducted` DECIMAL(10,2)    NOT NULL DEFAULT 0,    -- 1% TDS on sell
    `txn_date`     DATE             NOT NULL,
    `exchange`     VARCHAR(60)      NULL,
    `notes`        TEXT             NULL,
    `created_at`   TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_portfolio` (`portfolio_id`),
    KEY `idx_coin`      (`coin_id`),
    KEY `idx_date`      (`txn_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
