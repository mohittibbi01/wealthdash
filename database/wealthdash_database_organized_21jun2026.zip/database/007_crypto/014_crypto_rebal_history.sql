-- ============================================================
-- Table: crypto_rebal_history
-- Domain: 007_crypto  |  Sequence: 014
-- Source: migrations/tc004_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_rebal_history` (
    `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`   INT UNSIGNED NOT NULL,
    `actions_json`   JSON         DEFAULT NULL,
    `note`           TEXT         DEFAULT NULL,
    `rebalanced_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_crh_portfolio` (`portfolio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
