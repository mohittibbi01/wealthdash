-- ============================================================
-- Table: defi_income_log
-- Domain: 007_crypto  |  Sequence: 012
-- Source: migrations/tc003_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `defi_income_log` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `position_id`   INT UNSIGNED NOT NULL,
    `income_date`   DATE         NOT NULL,
    `income_type`   ENUM('staking','interest','lp_fee','airdrop','bonus','other') NOT NULL DEFAULT 'staking',
    `reward_symbol` VARCHAR(20)  DEFAULT NULL,
    `amount_token`  DECIMAL(28,10) NOT NULL,
    `price_inr`     DECIMAL(20,8)  DEFAULT 0,
    `amount_inr`    DECIMAL(18,4)  DEFAULT 0,
    `notes`         TEXT           DEFAULT NULL,
    `created_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_dil_position` (`position_id`),
    INDEX `idx_dil_date`     (`income_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
