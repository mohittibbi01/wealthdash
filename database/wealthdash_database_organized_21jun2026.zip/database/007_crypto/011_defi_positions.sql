-- ============================================================
-- Table: defi_positions
-- Domain: 007_crypto  |  Sequence: 011
-- Source: migrations/tc003_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `defi_positions` (
    `id`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`           INT UNSIGNED NOT NULL,
    `platform`          VARCHAR(100) NOT NULL,
    `position_type`     ENUM('staking','lending','liquidity','yield_farming','vault','other') NOT NULL DEFAULT 'staking',
    `asset_symbol`      VARCHAR(20)  NOT NULL,
    `asset_name`        VARCHAR(100) DEFAULT NULL,
    `staked_amount`     DECIMAL(28,10) NOT NULL DEFAULT 0,
    `staked_value_inr`  DECIMAL(18,4)  DEFAULT 0,
    `apy_pct`           DECIMAL(8,4)   DEFAULT 0,
    `reward_symbol`     VARCHAR(20)    DEFAULT NULL,
    `chain_name`        VARCHAR(50)    DEFAULT NULL,
    `contract_address`  VARCHAR(100)   DEFAULT NULL,
    `start_date`        DATE           NOT NULL,
    `lockup_days`       SMALLINT UNSIGNED DEFAULT 0,
    `unlock_date`       DATE           DEFAULT NULL,
    `last_income_date`  DATE           DEFAULT NULL,
    `notes`             TEXT           DEFAULT NULL,
    `is_active`         TINYINT(1)     NOT NULL DEFAULT 1,
    `created_at`        DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_defi_user`     (`user_id`, `is_active`),
    INDEX `idx_defi_platform` (`platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
