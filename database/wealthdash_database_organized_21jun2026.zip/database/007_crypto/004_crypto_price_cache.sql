-- ============================================================
-- Table: crypto_price_cache
-- Domain: 007_crypto  |  Sequence: 004
-- Source: 43_fix_crypto_schema.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: 38_, 43_fix_, tc001. Winner: 43_fix_ (fix file = most recent, applied on top)

CREATE TABLE IF NOT EXISTS crypto_price_cache (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  coin_id      VARCHAR(100) NOT NULL,
  symbol       VARCHAR(20)  NOT NULL,
  name         VARCHAR(100) NOT NULL,
  price_inr    DECIMAL(20,4) DEFAULT 0,
  price_usd    DECIMAL(20,8) DEFAULT 0,
  change_24h   DECIMAL(10,4) DEFAULT 0,
  market_cap   BIGINT       DEFAULT 0,
  fetched_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_coin (coin_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
