-- ============================================================
-- Table: vda_tds_log
-- Domain: 007_crypto  |  Sequence: 010
-- Source: migrations/tc002_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `vda_tds_log` (
    `id`                 INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    `portfolio_id`       INT UNSIGNED      NOT NULL,
    `exchange`           VARCHAR(80)       NOT NULL,
    `fy`                 VARCHAR(9)        NOT NULL,
    `total_sale_value`   DECIMAL(20,2)     NOT NULL DEFAULT 0,
    `tds_1pct`           DECIMAL(14,2)     NOT NULL DEFAULT 0,
    `tds_paid`           DECIMAL(14,2)     NOT NULL DEFAULT 0,
    `tds_balance`        DECIMAL(14,2)     NOT NULL DEFAULT 0 COMMENT 'tds_1pct - tds_paid (refund/credit)',
    `form_26as_verified` TINYINT(1)        NOT NULL DEFAULT 0,
    `notes`              VARCHAR(255)      NULL,
    `updated_at`         TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_vda_tds` (`portfolio_id`, `exchange`, `fy`),
    KEY `idx_vda_tds_fy` (`fy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='VDA Section 194S — 1% TDS per exchange per FY summary';
