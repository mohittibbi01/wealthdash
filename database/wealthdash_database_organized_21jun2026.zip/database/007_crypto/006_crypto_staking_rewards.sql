-- ============================================================
-- Table: crypto_staking_rewards
-- Domain: 007_crypto  |  Sequence: 006
-- Source: migrations/t315_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_staking_rewards` (
    `id`             INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    `portfolio_id`   INT UNSIGNED      NOT NULL,
    `coin_id`        VARCHAR(60)       NOT NULL,           -- CoinGecko ID
    `coin_symbol`    VARCHAR(20)       NOT NULL,           -- BTC, ETH …
    `reward_type`    ENUM('STAKING','YIELD','AIRDROP','MINING','INTEREST') NOT NULL DEFAULT 'STAKING',
    `quantity`       DECIMAL(24,8)     NOT NULL DEFAULT 0,
    `price_inr`      DECIMAL(20,4)     NOT NULL DEFAULT 0, -- INR price at reward date
    `value_inr`      DECIMAL(20,2)     NOT NULL DEFAULT 0, -- quantity × price_inr
    `platform`       VARCHAR(80)       NULL,               -- Binance Earn, WazirX etc.
    `reward_date`    DATE              NOT NULL,
    `notes`          TEXT              NULL,
    `created_at`     TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_portfolio` (`portfolio_id`),
    KEY `idx_coin`      (`coin_id`),
    KEY `idx_date`      (`reward_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
