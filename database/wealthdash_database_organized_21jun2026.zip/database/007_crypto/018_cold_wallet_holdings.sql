-- ============================================================
-- Table: cold_wallet_holdings
-- Domain: 007_crypto  |  Sequence: 018
-- Source: migrations/tc006_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS cold_wallet_holdings (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  wallet_id   INT UNSIGNED  NOT NULL,
  coin        VARCHAR(20)   NOT NULL,
  quantity    DECIMAL(24,8) NOT NULL DEFAULT 0,
  buy_price   DECIMAL(18,2) NULL DEFAULT 0,
  value_inr   DECIMAL(18,2) NULL DEFAULT 0,
  notes       VARCHAR(255)  NULL,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_wallet_coin (wallet_id, coin),
  CONSTRAINT fk_cwh_wallet FOREIGN KEY (wallet_id) REFERENCES cold_wallets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
