-- ============================================================
-- Table: crypto_holdings
-- Domain: 007_crypto  |  Sequence: 002
-- Source: 38_crypto_holdings.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: 38_(richest, CoinGecko string ID, portfolio FK), 41_pending_tasks (user_id, no FK), t40 (int coin_id FK). Winner: 38_crypto_holdings.sql

CREATE TABLE IF NOT EXISTS `crypto_holdings` (
    `id`              INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `portfolio_id`    INT UNSIGNED     NOT NULL,
    `coin_id`         VARCHAR(60)      NOT NULL,          -- CoinGecko ID e.g. "bitcoin"
    `coin_symbol`     VARCHAR(20)      NOT NULL,          -- BTC, ETH, etc.
    `coin_name`       VARCHAR(100)     NOT NULL,          -- Bitcoin, Ethereum
    `quantity`        DECIMAL(24,8)    NOT NULL DEFAULT 0,
    `avg_buy_price`   DECIMAL(20,4)    NOT NULL DEFAULT 0, -- INR per coin at purchase
    `total_invested`  DECIMAL(20,2)    NOT NULL DEFAULT 0, -- quantity × avg_buy_price
    `exchange`        VARCHAR(60)      NULL,               -- WazirX, Binance, CoinDCX
    `wallet_address`  VARCHAR(200)     NULL,
    `notes`           TEXT             NULL,
    `created_at`      TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_portfolio` (`portfolio_id`),
    KEY `idx_coin`      (`coin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
