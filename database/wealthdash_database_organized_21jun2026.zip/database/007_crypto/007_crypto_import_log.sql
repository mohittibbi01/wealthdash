-- ============================================================
-- Table: crypto_import_log
-- Domain: 007_crypto  |  Sequence: 007
-- Source: migrations/t317_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_import_log` (
    `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `batch_id`      VARCHAR(36)   NOT NULL COMMENT 'UUID',
    `portfolio_id`  INT UNSIGNED  NOT NULL,
    `user_id`       INT UNSIGNED  NOT NULL,
    `exchange`      VARCHAR(20)   NOT NULL COMMENT 'BINANCE | WAZIRX | COINDCX',
    `filename`      VARCHAR(255)  NOT NULL,
    `rows_parsed`   INT           NOT NULL DEFAULT 0,
    `rows_inserted` INT           NOT NULL DEFAULT 0,
    `rows_skipped`  INT           NOT NULL DEFAULT 0,
    `imported_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_portfolio` (`portfolio_id`),
    KEY `idx_user`      (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='t317 — CSV import audit log';
