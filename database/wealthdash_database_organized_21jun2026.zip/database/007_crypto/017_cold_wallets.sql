-- ============================================================
-- Table: cold_wallets
-- Domain: 007_crypto  |  Sequence: 017
-- Source: migrations/tc006_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS cold_wallets (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED  NOT NULL,
  name        VARCHAR(100)  NOT NULL,
  type        ENUM('hardware','paper','mobile','air_gapped') NOT NULL DEFAULT 'hardware',
  device      VARCHAR(80)   NULL,
  address     VARCHAR(200)  NULL,
  network     VARCHAR(50)   NULL,
  notes       TEXT          NULL,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user (user_id),
  CONSTRAINT fk_cw_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
