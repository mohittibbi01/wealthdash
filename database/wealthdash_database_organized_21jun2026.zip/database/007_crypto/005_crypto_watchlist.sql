-- ============================================================
-- Table: crypto_watchlist
-- Domain: 007_crypto  |  Sequence: 005
-- Source: migrations/t315_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t40 also has this. Winner: t315 (more recent task-ID)

CREATE TABLE IF NOT EXISTS `crypto_watchlist` (
    `id`             INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    `user_id`        INT UNSIGNED      NOT NULL,
    `coin_id`        VARCHAR(60)       NOT NULL,
    `coin_symbol`    VARCHAR(20)       NOT NULL,
    `coin_name`      VARCHAR(100)      NOT NULL,
    `alert_high`     DECIMAL(20,4)     NULL,               -- alert when price > this (INR)
    `alert_low`      DECIMAL(20,4)     NULL,               -- alert when price < this (INR)
    `notes`          VARCHAR(255)      NULL,
    `created_at`     TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_user_coin` (`user_id`, `coin_id`),
    KEY `idx_user`   (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
