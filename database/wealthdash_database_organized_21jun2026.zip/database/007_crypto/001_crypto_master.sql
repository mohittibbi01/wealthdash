-- ============================================================
-- Table: crypto_master
-- Domain: 007_crypto  |  Sequence: 001
-- Source: migrations/t40_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_master` (
    `id`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `coingecko_id`      VARCHAR(100) NOT NULL UNIQUE,
    `symbol`            VARCHAR(20)  NOT NULL,
    `name`              VARCHAR(150) NOT NULL,
    `logo_url`          VARCHAR(500) DEFAULT NULL,
    `current_price_inr` DECIMAL(20,8) DEFAULT 0,
    `price_change_24h`  DECIMAL(10,4) DEFAULT 0,
    `market_cap_inr`    DECIMAL(22,4) DEFAULT 0,
    `volume_24h_inr`    DECIMAL(22,4) DEFAULT 0,
    `ath_inr`           DECIMAL(20,8) DEFAULT NULL,
    `atl_inr`           DECIMAL(20,8) DEFAULT NULL,
    `circulating_supply`DECIMAL(22,4) DEFAULT NULL,
    `total_supply`      DECIMAL(22,4) DEFAULT NULL,
    `rank`              SMALLINT UNSIGNED DEFAULT NULL,
    `price_updated_at`  DATETIME DEFAULT NULL,
    `created_at`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_cm_symbol` (`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
