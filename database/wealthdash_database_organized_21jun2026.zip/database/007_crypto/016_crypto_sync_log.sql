-- ============================================================
-- Table: crypto_sync_log
-- Domain: 007_crypto  |  Sequence: 016
-- Source: migrations/tc005_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_sync_log` (
    `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `user_id`        INT UNSIGNED  NOT NULL,
    `portfolio_id`   INT UNSIGNED  NOT NULL,
    `exchange`       VARCHAR(20)   NOT NULL,
    `status`         ENUM('OK','ERROR','PARTIAL') NOT NULL DEFAULT 'OK',
    `trades_fetched` INT           NOT NULL DEFAULT 0,
    `trades_new`     INT           NOT NULL DEFAULT 0,
    `trades_skipped` INT           NOT NULL DEFAULT 0,
    `error_msg`      TEXT          NULL,
    `synced_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_user`  (`user_id`),
    KEY `idx_synced`(`synced_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='tc005 — Exchange sync run history';
