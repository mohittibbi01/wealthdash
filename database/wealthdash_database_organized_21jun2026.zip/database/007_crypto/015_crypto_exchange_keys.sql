-- ============================================================
-- Table: crypto_exchange_keys
-- Domain: 007_crypto  |  Sequence: 015
-- Source: migrations/tc005_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_exchange_keys` (
    `id`            INT UNSIGNED   NOT NULL AUTO_INCREMENT,
    `user_id`       INT UNSIGNED   NOT NULL,
    `exchange`      VARCHAR(20)    NOT NULL  COMMENT 'BINANCE | WAZIRX',
    `api_key_enc`   TEXT           NOT NULL  COMMENT 'AES-256-GCM encrypted API key',
    `api_secret_enc`TEXT           NOT NULL  COMMENT 'AES-256-GCM encrypted secret',
    `enc_iv`        VARCHAR(64)    NOT NULL  COMMENT 'Base64 IV for decryption',
    `enc_tag`       VARCHAR(64)    NOT NULL  COMMENT 'Base64 GCM auth tag',
    `label`         VARCHAR(80)    NULL,
    `is_active`     TINYINT(1)     NOT NULL DEFAULT 1,
    `last_synced`   DATETIME       NULL,
    `created_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_user_exchange` (`user_id`, `exchange`),
    KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='tc005 — Encrypted exchange API keys';
