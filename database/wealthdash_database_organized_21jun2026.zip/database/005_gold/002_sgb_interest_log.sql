-- ============================================================
-- Table: sgb_interest_log
-- Domain: 005_gold  |  Sequence: 002
-- Source: migrations/t113_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: 4-WAY CONFLICT same files. Winner: t113

CREATE TABLE IF NOT EXISTS `sgb_interest_log` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `sgb_id`       INT UNSIGNED NOT NULL,
    `portfolio_id` INT UNSIGNED NOT NULL,
    `payout_date`  DATE         NOT NULL,
    `period`       VARCHAR(20)  DEFAULT NULL COMMENT 'e.g. HY1 2024-25',
    `units`        DECIMAL(12,4) NOT NULL,
    `rate_pct`     DECIMAL(5,2) NOT NULL,
    `amount`       DECIMAL(12,2) NOT NULL,
    `notes`        VARCHAR(255) DEFAULT NULL,
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_sgb_interest_sgb`  (`sgb_id`),
    INDEX `idx_sgb_interest_port` (`portfolio_id`),
    INDEX `idx_sgb_interest_date` (`payout_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
