-- ============================================================
-- Table: gold_price_cache
-- Domain: 005_gold  |  Sequence: 003
-- Source: migrations/t113_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: 29_sgb_holdings.sql, t113, t394. Winner: t113

CREATE TABLE IF NOT EXISTS `gold_price_cache` (
    `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `source`         VARCHAR(30)  NOT NULL DEFAULT 'ibja',
    `price_24k_gram` DECIMAL(10,2) NOT NULL,
    `price_22k_gram` DECIMAL(10,2) DEFAULT NULL,
    `price_18k_gram` DECIMAL(10,2) DEFAULT NULL,
    `fetched_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `date_for`       DATE         NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_gold_cache_date` (`date_for`, `source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
