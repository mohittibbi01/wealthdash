-- ============================================================
-- Table: physical_gold
-- Domain: 005_gold  |  Sequence: 006
-- Source: migrations/t466_real_estate_physical_gold.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `physical_gold` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`    int(10) UNSIGNED NOT NULL,
  `description`     varchar(150) NOT NULL COMMENT 'e.g. 22K Necklace, Gold Coin 10g',
  `gold_type`       enum('jewellery','coin','bar','biscuit','other') NOT NULL DEFAULT 'jewellery',
  `purity_karat`    tinyint(3) UNSIGNED NOT NULL DEFAULT 22 COMMENT '14,18,22,24',
  `weight_grams`    decimal(10,3) NOT NULL COMMENT 'Net gold weight in grams',
  `purchase_date`   date DEFAULT NULL,
  `purchase_price`  decimal(14,2) DEFAULT NULL COMMENT 'Total cost paid',
  `purchase_rate`   decimal(10,2) DEFAULT NULL COMMENT 'Rate per gram at purchase',
  `current_rate`    decimal(10,2) DEFAULT NULL COMMENT 'Current rate per gram (manual update)',
  `current_value`   decimal(14,2) DEFAULT NULL COMMENT 'Computed or manual; weight * current_rate',
  `storage`         enum('home','locker','bank','other') NOT NULL DEFAULT 'home',
  `is_insured`      tinyint(1) NOT NULL DEFAULT 0,
  `notes`           text DEFAULT NULL,
  `is_active`       tinyint(1) NOT NULL DEFAULT 1,
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`      datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pg_portfolio` (`portfolio_id`),
  KEY `idx_pg_active`    (`is_active`),
  CONSTRAINT `fk_pg_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='t465: Physical gold and jewelry holdings';
