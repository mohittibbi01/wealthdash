-- ============================================================
-- Table: gold_transactions
-- Domain: 005_gold  |  Sequence: 005
-- Source: migrations/t114_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS gold_transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    holding_id BIGINT UNSIGNED NOT NULL,
    transaction_type ENUM('BUY','SELL','SIP') NOT NULL,
    quantity DECIMAL(15,4) NOT NULL,
    price DECIMAL(15,4) NOT NULL,
    transaction_date DATE NOT NULL,
    charges DECIMAL(10,2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (holding_id) REFERENCES gold_holdings(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_holding_id (holding_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
