-- ============================================================
-- Table: intl_transactions
-- Domain: 022_other_investments  |  Sequence: 008
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS intl_transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    stock_id BIGINT UNSIGNED NOT NULL,
    lrs_id BIGINT UNSIGNED DEFAULT NULL,
    transaction_type ENUM('BUY','SELL','DIVIDEND') NOT NULL,
    quantity DECIMAL(15,6) NOT NULL,
    price_foreign DECIMAL(15,4) NOT NULL,
    price_inr DECIMAL(15,4) NOT NULL,
    exchange_rate DECIMAL(10,4) NOT NULL,
    transaction_date DATE NOT NULL,
    charges_foreign DECIMAL(10,4) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (stock_id) REFERENCES international_stocks(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_stock_id (stock_id),
    INDEX idx_date (transaction_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
