-- ============================================================
-- Table: etf_holdings
-- Domain: 022_other_investments  |  Sequence: 002
-- Source: migrations/t37_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `etf_holdings` (
    `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`     INT UNSIGNED NOT NULL,
    `etf_id`           INT UNSIGNED NOT NULL,
    `quantity`         DECIMAL(16,4) NOT NULL DEFAULT 0,
    `avg_buy_price`    DECIMAL(14,4) NOT NULL DEFAULT 0,
    `total_invested`   DECIMAL(18,4) DEFAULT 0,
    `current_value`    DECIMAL(18,4) DEFAULT 0,
    `first_buy_date`   DATE          DEFAULT NULL,
    `broker`           VARCHAR(50)   DEFAULT NULL,
    `notes`            TEXT          DEFAULT NULL,
    `created_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_eh_portfolio_etf` (`portfolio_id`, `etf_id`),
    INDEX `idx_eh_portfolio` (`portfolio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
