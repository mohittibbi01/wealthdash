-- ============================================================
-- Table: pms_holdings
-- Domain: 022_other_investments  |  Sequence: 005
-- Source: migrations/t119_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS pms_holdings (
    id                  INT UNSIGNED    AUTO_INCREMENT PRIMARY KEY,
    user_id             INT UNSIGNED    NOT NULL,
    portfolio_id        INT UNSIGNED    NOT NULL,
    pms_name            VARCHAR(200)    NOT NULL               COMMENT 'e.g. Marcellus CCP, ASK IEP',
    manager_name        VARCHAR(150)    DEFAULT NULL           COMMENT 'PMS provider / AMC name',
    strategy_name       VARCHAR(200)    DEFAULT NULL           COMMENT 'Portfolio strategy name',
    asset_class         ENUM('PMS','AIF_CAT1','AIF_CAT2','AIF_CAT3') NOT NULL DEFAULT 'PMS',
    aif_category        TINYINT(1)      DEFAULT NULL           COMMENT '1, 2 or 3 for AIF',
    investment_date     DATE            NOT NULL,
    invested_amount     DECIMAL(16,2)   NOT NULL DEFAULT 0.00,
    current_value       DECIMAL(16,2)   DEFAULT NULL,
    gain_loss           DECIMAL(16,2)   GENERATED ALWAYS AS (current_value - invested_amount) STORED,
    gain_loss_pct       DECIMAL(8,4)    GENERATED ALWAYS AS (
                            CASE WHEN invested_amount > 0
                                 THEN ((current_value - invested_amount) / invested_amount) * 100
                                 ELSE NULL END
                        ) STORED,
    xirr                DECIMAL(8,4)    DEFAULT NULL           COMMENT 'Stored XIRR %',
    nav_current         DECIMAL(14,4)   DEFAULT NULL,
    nav_date            DATE            DEFAULT NULL,
    units               DECIMAL(14,4)   DEFAULT NULL,
    folio_number        VARCHAR(60)     DEFAULT NULL,
    lock_in_months      INT UNSIGNED    DEFAULT NULL,
    lock_in_end_date    DATE            DEFAULT NULL,
    management_fee_pct  DECIMAL(5,3)    DEFAULT NULL           COMMENT 'Annual mgmt fee %',
    performance_fee_pct DECIMAL(5,3)    DEFAULT NULL           COMMENT 'Performance fee % (hurdle)',
    hurdle_rate_pct     DECIMAL(5,3)    DEFAULT NULL,
    benchmark           VARCHAR(150)    DEFAULT NULL,
    platform            VARCHAR(100)    DEFAULT NULL           COMMENT 'Zerodha, IIFL, Motilal, etc.',
    notes               TEXT            DEFAULT NULL,
    is_active           TINYINT(1)      NOT NULL DEFAULT 1,
    created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_user          (user_id),
    INDEX idx_portfolio     (portfolio_id),
    INDEX idx_asset_class   (asset_class),
    INDEX idx_active        (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
