-- ============================================================
-- Table: pms_nav_history
-- Domain: 022_other_investments  |  Sequence: 007
-- Source: migrations/t119_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS pms_nav_history (
    id          INT UNSIGNED    AUTO_INCREMENT PRIMARY KEY,
    holding_id  INT UNSIGNED    NOT NULL,
    nav_date    DATE            NOT NULL,
    nav         DECIMAL(14,4)   NOT NULL,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uq_nav (holding_id, nav_date),
    INDEX idx_holding (holding_id),
    INDEX idx_date    (nav_date),
    CONSTRAINT fk_pmsnav_holding FOREIGN KEY (holding_id) REFERENCES pms_holdings (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
