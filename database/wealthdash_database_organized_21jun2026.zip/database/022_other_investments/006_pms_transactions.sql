-- ============================================================
-- Table: pms_transactions
-- Domain: 022_other_investments  |  Sequence: 006
-- Source: migrations/t119_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS pms_transactions (
    id              INT UNSIGNED    AUTO_INCREMENT PRIMARY KEY,
    holding_id      INT UNSIGNED    NOT NULL,
    user_id         INT UNSIGNED    NOT NULL,
    portfolio_id    INT UNSIGNED    NOT NULL,
    txn_type        ENUM('investment','withdrawal','dividend','management_fee','performance_fee','nav_update','switch') NOT NULL,
    txn_date        DATE            NOT NULL,
    amount          DECIMAL(16,2)   NOT NULL DEFAULT 0.00,
    nav             DECIMAL(14,4)   DEFAULT NULL,
    units           DECIMAL(14,4)   DEFAULT NULL,
    notes           TEXT            DEFAULT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_holding    (holding_id),
    INDEX idx_user       (user_id),
    INDEX idx_date       (txn_date),
    INDEX idx_type       (txn_type),
    CONSTRAINT fk_pmst_holding FOREIGN KEY (holding_id) REFERENCES pms_holdings (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
