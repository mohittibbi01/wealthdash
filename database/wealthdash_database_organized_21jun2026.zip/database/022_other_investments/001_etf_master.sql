-- ============================================================
-- Table: etf_master
-- Domain: 022_other_investments  |  Sequence: 001
-- Source: migrations/t37_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `etf_master` (
    `id`                  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `symbol`              VARCHAR(20)  NOT NULL,
    `exchange`            VARCHAR(10)  NOT NULL DEFAULT 'NSE',
    `isin`                VARCHAR(20)  DEFAULT NULL,
    `scheme_name`         VARCHAR(200) NOT NULL,
    `amc`                 VARCHAR(100) DEFAULT NULL,
    `category`            VARCHAR(100) DEFAULT NULL  COMMENT 'Equity, Debt, Gold, International, etc.',
    `sub_category`        VARCHAR(100) DEFAULT NULL  COMMENT 'Nifty 50, Banking, IT, etc.',
    `underlying_index`    VARCHAR(100) DEFAULT NULL,
    `benchmark`           VARCHAR(100) DEFAULT NULL,
    `latest_price`        DECIMAL(14,4) DEFAULT 0,
    `nav`                 DECIMAL(14,4) DEFAULT NULL COMMENT 'Declared NAV if different from price',
    `price_change_1d`     DECIMAL(10,4) DEFAULT NULL,
    `price_change_1d_pct` DECIMAL(8,4)  DEFAULT NULL,
    `expense_ratio`       DECIMAL(6,4)  DEFAULT NULL COMMENT 'Annual TER %',
    `tracking_error`      DECIMAL(8,4)  DEFAULT NULL,
    `aum_cr`              DECIMAL(14,4) DEFAULT NULL COMMENT 'AUM in INR crores',
    `avg_volume`          BIGINT UNSIGNED DEFAULT NULL,
    `high_52`             DECIMAL(14,4) DEFAULT NULL,
    `low_52`              DECIMAL(14,4) DEFAULT NULL,
    `dividend_yield`      DECIMAL(8,4)  DEFAULT NULL,
    `returns_1y`          DECIMAL(8,4)  DEFAULT NULL,
    `returns_3y`          DECIMAL(8,4)  DEFAULT NULL,
    `returns_5y`          DECIMAL(8,4)  DEFAULT NULL,
    `is_gold_etf`         TINYINT(1)    DEFAULT 0,
    `is_international`    TINYINT(1)    DEFAULT 0,
    `price_updated_at`    DATETIME      DEFAULT NULL,
    `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_etf_symbol` (`symbol`, `exchange`),
    INDEX `idx_etf_isin`     (`isin`),
    INDEX `idx_etf_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
