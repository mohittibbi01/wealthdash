-- ============================================================
-- Table: etf_transactions
-- Domain: 022_other_investments  |  Sequence: 003
-- Source: migrations/t37_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `etf_transactions` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`  INT UNSIGNED NOT NULL,
    `etf_id`        INT UNSIGNED NOT NULL,
    `type`          ENUM('buy','sell','dividend') NOT NULL DEFAULT 'buy',
    `quantity`      DECIMAL(16,4) NOT NULL,
    `price`         DECIMAL(14,4) NOT NULL DEFAULT 0,
    `total_value`   DECIMAL(18,4) DEFAULT 0,
    `brokerage`     DECIMAL(10,4) DEFAULT 0,
    `broker`        VARCHAR(50)   DEFAULT NULL,
    `txn_date`      DATE          NOT NULL,
    `notes`         TEXT          DEFAULT NULL,
    `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_et_portfolio` (`portfolio_id`),
    INDEX `idx_et_etf`       (`etf_id`),
    INDEX `idx_et_date`      (`txn_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
