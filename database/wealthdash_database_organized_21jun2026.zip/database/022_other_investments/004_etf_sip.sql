-- ============================================================
-- Table: etf_sip
-- Domain: 022_other_investments  |  Sequence: 004
-- Source: migrations/t37_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `etf_sip` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `etf_id`          INT UNSIGNED NOT NULL,
    `monthly_amount`  DECIMAL(12,4) NOT NULL,
    `sip_date`        TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'Day of month 1-28',
    `start_date`      DATE          NOT NULL,
    `end_date`        DATE          DEFAULT NULL,
    `broker`          VARCHAR(50)   DEFAULT NULL,
    `is_active`       TINYINT(1)    NOT NULL DEFAULT 1,
    `last_executed`   DATE          DEFAULT NULL,
    `total_invested`  DECIMAL(18,4) DEFAULT 0,
    `installments`    INT UNSIGNED  DEFAULT 0,
    `notes`           TEXT          DEFAULT NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_esip_portfolio` (`portfolio_id`),
    INDEX `idx_esip_active`    (`is_active`, `sip_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
