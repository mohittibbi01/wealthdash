-- ============================================================
-- Table: loan_tax_claims
-- Domain: 010_loans_credit  |  Sequence: 005
-- Source: migrations/t464_home_loan_emi_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `loan_tax_claims` (
  `id`              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `loan_id`         INT UNSIGNED    NOT NULL,
  `fy`              CHAR(7)         NOT NULL COMMENT 'FY in format 2024-25',
  `interest_paid`   DECIMAL(14,2)   NOT NULL DEFAULT 0 COMMENT 'Total interest paid this FY',
  `principal_paid`  DECIMAL(14,2)   NOT NULL DEFAULT 0 COMMENT 'Total principal paid this FY',
  `sec_24b_claimed` DECIMAL(14,2)   NOT NULL DEFAULT 0 COMMENT 'Sec 24(b) deduction claimed',
  `sec_80c_claimed` DECIMAL(14,2)   NOT NULL DEFAULT 0 COMMENT 'Sec 80C deduction claimed (principal)',
  `under_construction` TINYINT(1)   NOT NULL DEFAULT 0 COMMENT 'Was property under construction this FY',
  `notes`           TEXT            NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ltc_loan_fy` (`loan_id`, `fy`),
  KEY `idx_ltc_loan` (`loan_id`),
  CONSTRAINT `fk_ltc_loan` FOREIGN KEY (`loan_id`) REFERENCES `loan_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Home loan annual tax claim tracker (t464)';
