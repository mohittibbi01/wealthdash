-- ============================================================
-- Table: loan_rate_history
-- Domain: 010_loans_credit  |  Sequence: 004
-- Source: migrations/t464_home_loan_emi_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `loan_rate_history` (
  `id`              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `loan_id`         INT UNSIGNED    NOT NULL,
  `effective_date`  DATE            NOT NULL,
  `old_rate`        DECIMAL(6,3)    NOT NULL,
  `new_rate`        DECIMAL(6,3)    NOT NULL,
  `new_emi`         DECIMAL(12,2)   NULL COMMENT 'New EMI after reset (if tenure fixed)',
  `new_tenure`      INT             NULL COMMENT 'New tenure after reset (if EMI fixed)',
  `base_rate`       DECIMAL(6,3)    NULL COMMENT 'RBI/bank base rate at this time',
  `reason`          VARCHAR(200)    NULL COMMENT 'RBI policy change, annual reset etc.',
  `notes`           TEXT            NULL,
  `created_at`      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lrh_loan`  (`loan_id`),
  KEY `idx_lrh_date`  (`effective_date`),
  CONSTRAINT `fk_lrh_loan` FOREIGN KEY (`loan_id`) REFERENCES `loan_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Home loan interest rate change history (t464)';
