-- ============================================================
-- Table: credit_cards
-- Domain: 010_loans_credit  |  Sequence: 006
-- Source: 44_v48_sprint_tables.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t503_migration.sql. Winner: 44_ (portfolio_id FK, fuller schema)

CREATE TABLE IF NOT EXISTS `credit_cards` (
  `id`            INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED   NOT NULL,
  `card_name`     VARCHAR(100)   NOT NULL,
  `bank_name`     VARCHAR(100)   NOT NULL DEFAULT '',
  `card_type`     VARCHAR(50)    NOT NULL DEFAULT 'credit',
  `credit_limit`  DECIMAL(12,2)  NOT NULL DEFAULT 0,
  `outstanding`   DECIMAL(12,2)  NOT NULL DEFAULT 0,
  `min_payment`   DECIMAL(12,2)  NOT NULL DEFAULT 0,
  `due_date`      DATE           DEFAULT NULL,
  `interest_rate` DECIMAL(5,2)   NOT NULL DEFAULT 36.00
                  COMMENT 'Annual % — typical 36-42%',
  `reward_type`   VARCHAR(50)    NOT NULL DEFAULT 'cashback',
  `reward_rate`   DECIMAL(5,2)   NOT NULL DEFAULT 1.00
                  COMMENT '% cashback or points per Rs 100',
  `annual_fee`    DECIMAL(8,2)   NOT NULL DEFAULT 0,
  `is_active`     TINYINT(1)     NOT NULL DEFAULT 1,
  `notes`         TEXT           DEFAULT NULL,
  `created_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
