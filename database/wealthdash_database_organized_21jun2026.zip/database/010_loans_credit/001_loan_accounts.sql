-- ============================================================
-- Table: loan_accounts
-- Domain: 010_loans_credit  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `loan_accounts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `lender_name` varchar(100) NOT NULL,
  `loan_type` enum('home','personal','vehicle','education','gold','business','other') NOT NULL DEFAULT 'personal',
  `account_number` varchar(50) DEFAULT NULL,
  `principal_amount` decimal(16,2) NOT NULL,
  `outstanding_balance` decimal(16,2) NOT NULL DEFAULT 0.00,
  `interest_rate` decimal(6,3) NOT NULL,
  `rate_type` enum('fixed','floating') NOT NULL DEFAULT 'fixed',
  `emi_amount` decimal(12,2) DEFAULT NULL,
  `tenure_months` int(11) DEFAULT NULL,
  `disbursement_date` date NOT NULL,
  `first_emi_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `prepayment_penalty` decimal(5,3) DEFAULT NULL,
  `status` enum('active','closed','npa') NOT NULL DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_loan_portfolio` (`portfolio_id`),
  KEY `idx_loan_type` (`loan_type`),
  CONSTRAINT `fk_loan_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
