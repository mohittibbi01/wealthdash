-- ============================================================
-- Table: cibil_history
-- Domain: 010_loans_credit  |  Sequence: 007
-- ============================================================
-- NOTE: This table was listed as TODO (40_cibil_history.sql = placeholder)
-- and was NEVER actually implemented in any migration file.
-- Schema below is inferred from the CIBIL feature description.
-- Verify against api/credit/cibil.php before running.
-- ============================================================

CREATE TABLE IF NOT EXISTS `cibil_history` (
  `id`          int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     int(10) UNSIGNED NOT NULL,
  `score`       smallint(5) UNSIGNED NOT NULL,
  `bureau`      enum('CIBIL','Experian','Equifax','CRIF') NOT NULL DEFAULT 'CIBIL',
  `report_date` date NOT NULL,
  `report_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`report_json`)),
  `notes`       text DEFAULT NULL,
  `created_at`  datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cibil_user` (`user_id`),
  KEY `idx_cibil_date` (`report_date`),
  CONSTRAINT `fk_cibil_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
