-- ============================================================
-- Table: loan_prepayments
-- Domain: 010_loans_credit  |  Sequence: 003
-- Source: migrations/t464_home_loan_emi_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `loan_prepayments` (
  `id`              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `loan_id`         INT UNSIGNED    NOT NULL,
  `payment_date`    DATE            NOT NULL,
  `amount`          DECIMAL(14,2)   NOT NULL,
  `mode`            ENUM('full_prepayment','partial_prepayment','balance_transfer') NOT NULL DEFAULT 'partial_prepayment',
  `impact`          ENUM('reduce_tenure','reduce_emi') NOT NULL DEFAULT 'reduce_tenure',
  `emis_saved`      SMALLINT        NULL COMMENT 'Number of EMIs saved (computed)',
  `interest_saved`  DECIMAL(14,2)   NULL COMMENT 'Interest saved (computed)',
  `new_outstanding` DECIMAL(16,2)   NULL COMMENT 'Outstanding after prepayment',
  `new_tenure`      INT             NULL COMMENT 'Remaining tenure after prepayment',
  `new_emi`         DECIMAL(12,2)   NULL COMMENT 'New EMI (if emi was reduced)',
  `penalty_charged` DECIMAL(10,2)   NOT NULL DEFAULT 0,
  `source`          VARCHAR(100)    NULL COMMENT 'Source of funds: savings, bonus, etc.',
  `notes`           TEXT            NULL,
  `created_at`      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lp_loan`   (`loan_id`),
  KEY `idx_lp_date`   (`payment_date`),
  CONSTRAINT `fk_lp_loan` FOREIGN KEY (`loan_id`) REFERENCES `loan_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Loan prepayment log (t464)';
