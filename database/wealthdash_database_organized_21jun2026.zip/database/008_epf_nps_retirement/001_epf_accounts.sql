-- ============================================================
-- Table: epf_accounts
-- Domain: 008_epf_nps_retirement  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `epf_accounts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `uan` varchar(20) DEFAULT NULL,
  `employer_name` varchar(100) NOT NULL,
  `employee_share` decimal(14,2) NOT NULL DEFAULT 0.00,
  `employer_share` decimal(14,2) NOT NULL DEFAULT 0.00,
  `interest_earned` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `interest_rate` decimal(5,3) NOT NULL DEFAULT 8.150 COMMENT 'Current EPF rate %',
  `monthly_contribution` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_updated` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_epf_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_epf_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
