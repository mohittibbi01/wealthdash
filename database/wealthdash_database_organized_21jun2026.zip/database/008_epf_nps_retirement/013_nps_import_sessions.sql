-- ============================================================
-- Table: nps_import_sessions
-- Domain: 008_epf_nps_retirement  |  Sequence: 013
-- Source: migrations/t106_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_import_sessions` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`    int(10) UNSIGNED NOT NULL,
  `user_id`         int(10) UNSIGNED NOT NULL,
  `bank_name`       varchar(80)      DEFAULT NULL COMMENT 'Detected or user-selected bank',
  `statement_from`  date             DEFAULT NULL COMMENT 'Statement period start',
  `statement_to`    date             DEFAULT NULL COMMENT 'Statement period end',
  `raw_filename`    varchar(255)     DEFAULT NULL,
  `total_rows`      int UNSIGNED     NOT NULL DEFAULT 0 COMMENT 'Total rows parsed',
  `detected_rows`   int UNSIGNED     NOT NULL DEFAULT 0 COMMENT 'NPS rows detected',
  `confirmed_rows`  int UNSIGNED     NOT NULL DEFAULT 0 COMMENT 'Rows imported to nps_transactions',
  `status`          enum('pending','reviewed','imported','dismissed') NOT NULL DEFAULT 'pending',
  `import_notes`    varchar(255)     DEFAULT NULL,
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`      datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_nps_imp_portfolio` (`portfolio_id`),
  KEY `idx_nps_imp_user`      (`user_id`),
  KEY `idx_nps_imp_status`    (`status`),
  CONSTRAINT `fk_nps_imp_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
