-- ============================================================
-- Table: nps_holdings
-- Domain: 008_epf_nps_retirement  |  Sequence: 010
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_holdings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `scheme_id` int(10) UNSIGNED NOT NULL,
  `units` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `avg_nav` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `invested_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `current_value` decimal(16,2) NOT NULL DEFAULT 0.00,
  `gain_loss` decimal(16,2) NOT NULL DEFAULT 0.00,
  `gain_pct` decimal(8,4) NOT NULL DEFAULT 0.0000,
  `cagr` decimal(8,4) NOT NULL DEFAULT 0.0000,
  `first_investment_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_npsh` (`portfolio_id`, `scheme_id`),
  KEY `idx_npsh_scheme` (`scheme_id`),
  CONSTRAINT `fk_npsh_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_npsh_scheme` FOREIGN KEY (`scheme_id`) REFERENCES `nps_schemes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
