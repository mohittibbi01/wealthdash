-- ============================================================
-- Table: epf_fy_snapshot
-- Domain: 008_epf_nps_retirement  |  Sequence: 004
-- Source: migrations/t467_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `epf_fy_snapshot` (
  `id`               int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `epf_account_id`   int(10) UNSIGNED NOT NULL,
  `fy_year`          smallint(4)      NOT NULL COMMENT 'FY start year e.g. 2024 for FY24-25',
  `opening_balance`  decimal(16,2)    NOT NULL DEFAULT 0.00,
  `closing_balance`  decimal(16,2)    NOT NULL DEFAULT 0.00,
  `total_ee_contrib` decimal(14,2)    NOT NULL DEFAULT 0.00,
  `total_er_contrib` decimal(14,2)    NOT NULL DEFAULT 0.00,
  `total_vpf`        decimal(14,2)    NOT NULL DEFAULT 0.00,
  `interest_credited`decimal(14,2)    NOT NULL DEFAULT 0.00,
  `created_at`       datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`       datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_epf_snap_fy` (`epf_account_id`, `fy_year`),
  KEY `idx_epfs_account` (`epf_account_id`),
  CONSTRAINT `fk_epfs_account`
    FOREIGN KEY (`epf_account_id`) REFERENCES `epf_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
