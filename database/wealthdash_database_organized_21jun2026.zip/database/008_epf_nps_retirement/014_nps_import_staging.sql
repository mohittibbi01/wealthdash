-- ============================================================
-- Table: nps_import_staging
-- Domain: 008_epf_nps_retirement  |  Sequence: 014
-- Source: migrations/t106_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_import_staging` (
  `id`                int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `session_id`        int(10) UNSIGNED NOT NULL,
  `portfolio_id`      int(10) UNSIGNED NOT NULL,

  -- Raw data from bank statement
  `raw_date`          varchar(30)      DEFAULT NULL,
  `raw_narration`     varchar(500)     DEFAULT NULL,
  `raw_debit`         varchar(30)      DEFAULT NULL,
  `raw_credit`        varchar(30)      DEFAULT NULL,
  `raw_balance`       varchar(30)      DEFAULT NULL,
  `raw_row_number`    int UNSIGNED     DEFAULT NULL COMMENT 'Row number in original file',

  -- Parsed / normalised
  `txn_date`          date             DEFAULT NULL,
  `amount`            decimal(16,2)    DEFAULT NULL,
  `detected_bank`     varchar(80)      DEFAULT NULL,
  `detected_pfm`      varchar(100)     DEFAULT NULL COMMENT 'Detected PFM from narration',
  `detected_tier`     enum('tier1','tier2') DEFAULT 'tier1',
  `detected_contrib`  enum('SELF','EMPLOYER') DEFAULT 'SELF',
  `confidence`        tinyint UNSIGNED NOT NULL DEFAULT 0 COMMENT '0-100 match confidence',
  `match_keywords`    varchar(255)     DEFAULT NULL COMMENT 'Keywords that triggered detection',

  -- User-assigned (review step)
  `scheme_id`         int(10) UNSIGNED DEFAULT NULL,
  `tier`              enum('tier1','tier2') DEFAULT 'tier1',
  `contribution_type` enum('SELF','EMPLOYER') DEFAULT 'SELF',
  `units`             decimal(18,4)    DEFAULT NULL,
  `nav`               decimal(12,4)    DEFAULT NULL,
  `investment_fy`     varchar(10)      DEFAULT NULL,
  `notes`             varchar(255)     DEFAULT NULL,

  -- Import status
  `row_status`        enum('detected','accepted','rejected','imported','duplicate') NOT NULL DEFAULT 'detected',
  `imported_txn_id`   int(10) UNSIGNED DEFAULT NULL COMMENT 'FK to nps_transactions.id after import',

  `created_at`        datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`        datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),

  PRIMARY KEY (`id`),
  KEY `idx_nps_stg_session`   (`session_id`),
  KEY `idx_nps_stg_portfolio` (`portfolio_id`),
  KEY `idx_nps_stg_status`    (`row_status`),
  KEY `idx_nps_stg_date`      (`txn_date`),
  CONSTRAINT `fk_nps_stg_session`
    FOREIGN KEY (`session_id`) REFERENCES `nps_import_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nps_stg_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
