-- ============================================================
-- Table: epfo_passbook
-- Domain: 008_epf_nps_retirement  |  Sequence: 007
-- Source: migrations/t151_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS epfo_passbook (
  id           INT UNSIGNED    NOT NULL AUTO_INCREMENT PRIMARY KEY,
  account_id   INT UNSIGNED    NOT NULL,
  txn_date     DATE            NOT NULL,
  wage_month   VARCHAR(7)      NULL COMMENT 'YYYY-MM',
  type         ENUM('employee','employer','pension','withdrawal','interest','other') NOT NULL DEFAULT 'other',
  amount       DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
  remarks      VARCHAR(255)    NULL,
  created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_account_date (account_id, txn_date),
  CONSTRAINT fk_epfo_pb_acc FOREIGN KEY (account_id) REFERENCES epfo_accounts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
