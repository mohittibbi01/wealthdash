-- ============================================================
-- Table: nps_schemes
-- Domain: 008_epf_nps_retirement  |  Sequence: 009
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_schemes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pfm_name` varchar(100) NOT NULL,
  `scheme_name` varchar(200) NOT NULL,
  `scheme_code` varchar(30) NOT NULL,
  `tier` enum('tier1','tier2') NOT NULL DEFAULT 'tier1',
  `asset_class` enum('E','C','G','A') NOT NULL DEFAULT 'E',
  `nav` decimal(12,4) DEFAULT NULL,
  `nav_date` date DEFAULT NULL,
  `return_1y` decimal(8,4) DEFAULT NULL,
  `return_3y` decimal(8,4) DEFAULT NULL,
  `return_5y` decimal(8,4) DEFAULT NULL,
  `return_since` decimal(8,4) DEFAULT NULL,
  `aum_cr` decimal(14,2) DEFAULT NULL,
  `nav_returns_updated_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nps_code` (`scheme_code`),
  KEY `idx_nps_pfm` (`pfm_name`),
  KEY `idx_nps_tier` (`tier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
