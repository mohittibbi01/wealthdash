-- ============================================================
-- Table: digilocker_connections
-- Domain: 008_epf_nps_retirement  |  Sequence: 017
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS digilocker_connections (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL UNIQUE,
  connected     TINYINT(1)   NOT NULL DEFAULT 0,
  access_token  VARCHAR(500) NULL COMMENT 'Encrypted with WDCrypt when OAuth is wired in',
  connected_at  DATETIME     NULL,
  CONSTRAINT fk_dc_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
