-- ============================================================
-- Table: nps_transactions
-- Domain: 008_epf_nps_retirement  |  Sequence: 011
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_transactions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `scheme_id` int(10) UNSIGNED NOT NULL,
  `txn_type` enum('purchase','redemption','switch_in','switch_out') NOT NULL DEFAULT 'purchase',
  `txn_date` date NOT NULL,
  `units` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `nav` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_npst_portfolio` (`portfolio_id`),
  KEY `idx_npst_scheme` (`scheme_id`),
  KEY `idx_npst_date` (`txn_date`),
  CONSTRAINT `fk_npst_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_npst_scheme` FOREIGN KEY (`scheme_id`) REFERENCES `nps_schemes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
