-- ============================================================
-- Table: nps_nav_history
-- Domain: 008_epf_nps_retirement  |  Sequence: 012
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_nav_history` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `scheme_id` int(10) UNSIGNED NOT NULL,
  `nav_date` date NOT NULL,
  `nav` decimal(12,4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nps_nav` (`scheme_id`, `nav_date`),
  KEY `idx_nps_nav_date` (`nav_date`),
  KEY `idx_nps_nav_scheme` (`scheme_id`),
  CONSTRAINT `fk_nps_nav_scheme` FOREIGN KEY (`scheme_id`) REFERENCES `nps_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
