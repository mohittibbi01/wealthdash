-- ============================================================
-- Table: epf_salary_log
-- Domain: 008_epf_nps_retirement  |  Sequence: 003
-- Source: migrations/t46_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `epf_salary_log` (
  `id`               int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `epf_account_id`   int(10) UNSIGNED NOT NULL,
  `basic_salary`     decimal(14,2)    NOT NULL,
  `effective_date`   date             NOT NULL,
  `vpf_rate`         decimal(5,2)     NOT NULL DEFAULT 0.00,
  `notes`            varchar(255)     DEFAULT NULL,
  `created_at`       datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_salary_log_date` (`epf_account_id`, `effective_date`),
  KEY `idx_sl_account` (`epf_account_id`),
  CONSTRAINT `fk_sl_account`
    FOREIGN KEY (`epf_account_id`) REFERENCES `epf_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
