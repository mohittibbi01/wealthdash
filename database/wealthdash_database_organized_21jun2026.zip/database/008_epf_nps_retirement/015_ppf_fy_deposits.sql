-- ============================================================
-- Table: ppf_fy_deposits
-- Domain: 008_epf_nps_retirement  |  Sequence: 015
-- Source: migrations/t203_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t48 (text instead of JSON, no updated_at). Winner: t203 (JSON with CHECK validity)

CREATE TABLE IF NOT EXISTS `ppf_fy_deposits` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ppf_scheme_id`   int(10) UNSIGNED NOT NULL,
  `fy_year`         int(4) UNSIGNED  NOT NULL,
  `total_deposited` decimal(10,2)    NOT NULL DEFAULT 0.00,
  `entries`         longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
                    CHECK (json_valid(`entries`)),
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`      datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ppf_fy` (`ppf_scheme_id`, `fy_year`),
  KEY `idx_ppf_fy_scheme` (`ppf_scheme_id`),
  CONSTRAINT `fk_ppf_fy_scheme`
    FOREIGN KEY (`ppf_scheme_id`) REFERENCES `po_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
