-- ============================================================
-- Table: epf_monthly_log
-- Domain: 008_epf_nps_retirement  |  Sequence: 002
-- Source: migrations/t467_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: t340, t467, t46. Winner: t467 (richest, detailed column comments)

CREATE TABLE IF NOT EXISTS `epf_monthly_log` (
  `id`                   int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `epf_account_id`       int(10) UNSIGNED NOT NULL,
  `log_month`            date             NOT NULL COMMENT 'YYYY-MM-01',
  `basic_salary`         decimal(14,2)    NOT NULL DEFAULT 0.00,
  `employee_contribution`decimal(10,2)    NOT NULL DEFAULT 0.00 COMMENT 'EPF employee share',
  `employer_contribution`decimal(10,2)    NOT NULL DEFAULT 0.00 COMMENT 'Employer EPF (3.67%)',
  `eps_contribution`     decimal(10,2)    NOT NULL DEFAULT 0.00 COMMENT 'EPS share (8.33%)',
  `vpf_contribution`     decimal(10,2)    NOT NULL DEFAULT 0.00 COMMENT 'VPF (voluntary)',
  `total_credit`         decimal(12,2)    NOT NULL DEFAULT 0.00 COMMENT 'Employee+Employer+VPF',
  `balance_after`        decimal(16,2)    DEFAULT NULL           COMMENT 'EPF balance after this month (if known)',
  `interest_credited`    decimal(12,2)    NOT NULL DEFAULT 0.00 COMMENT 'Interest credited this month (March credit)',
  `source`               enum('manual','epfo_sync','import') NOT NULL DEFAULT 'manual',
  `notes`                varchar(255)     DEFAULT NULL,
  `created_at`           datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`           datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_epf_log_month` (`epf_account_id`, `log_month`),
  KEY `idx_epfl_account` (`epf_account_id`),
  KEY `idx_epfl_month`   (`log_month`),
  CONSTRAINT `fk_epfl_account`
    FOREIGN KEY (`epf_account_id`) REFERENCES `epf_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
