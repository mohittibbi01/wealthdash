-- ============================================================
-- WealthDash — Master Install Script
-- Run this on a fresh database to set up ALL tables + seed data
-- Generated: 21 June 2026
-- ============================================================
-- 
-- USAGE:
--   mysql -u root -p wealthdash < install.sql
--   OR import via phpMyAdmin > Import tab
-- 
-- All CREATE TABLE use IF NOT EXISTS — safe to re-run.
-- Seed files use ON DUPLICATE KEY UPDATE — also safe to re-run.
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ── 001_core ──────────────────────────────────────────────
-- 001_users.sql
-- ============================================================
-- Table: users
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema)
-- ============================================================
-- Core user accounts table. Everything else in the app references
-- this via user_id. Must be the FIRST table created in the entire
-- database.
-- ============================================================

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `theme` varchar(20) NOT NULL DEFAULT 'light',
  `currency` varchar(10) NOT NULL DEFAULT 'INR',
  `avatar_url` varchar(500) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_email` (`email`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_sessions.sql
-- ============================================================
-- Table: sessions
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema)
-- ============================================================
-- PHP native session storage backend (server-side session data).
-- NOT the same as 'user_sessions' (see 015_admin_infra or
-- 001_core/011_user_sessions.sql) which is the user-facing
-- "manage logged-in devices" feature (t387).
-- ============================================================

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `payload` longtext DEFAULT NULL,
  `last_activity` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sess_user` (`user_id`),
  KEY `idx_sess_activity` (`last_activity`),
  CONSTRAINT `fk_sess_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_login_attempts.sql
-- ============================================================
-- Table: login_attempts
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema)
-- ============================================================
-- Tracks every login attempt (success + failure) for rate-limiting
-- and brute-force detection. No FK — email may not match a real user.
-- ============================================================

CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `attempted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `success` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_la_email` (`email`),
  KEY `idx_la_ip` (`ip_address`),
  KEY `idx_la_time` (`attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_otp_tokens.sql
-- ============================================================
-- Table: otp_tokens
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema)
-- ============================================================
-- Depends on: users
-- ============================================================

CREATE TABLE IF NOT EXISTS `otp_tokens` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `token` varchar(10) NOT NULL,
  `purpose` varchar(50) NOT NULL DEFAULT 'login',
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_otp_user` (`user_id`),
  KEY `idx_otp_token` (`token`),
  CONSTRAINT `fk_otp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_password_resets.sql
-- ============================================================
-- Table: password_resets
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema)
-- ============================================================
-- No FK to users — matches by email so a reset can be requested
-- even before confirming the account exists (avoids leaking which
-- emails are registered).
-- ============================================================

CREATE TABLE IF NOT EXISTS `password_resets` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `token` varchar(100) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pr_token` (`token`),
  KEY `idx_pr_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_google_auth.sql
-- ============================================================
-- Table: google_auth
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema)
-- ============================================================
-- Depends on: users
-- Stores Google OAuth tokens for "Sign in with Google" / Drive sync.
-- ============================================================

CREATE TABLE IF NOT EXISTS `google_auth` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `google_id` varchar(100) NOT NULL,
  `access_token` text DEFAULT NULL,
  `refresh_token` text DEFAULT NULL,
  `token_expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_google_id` (`google_id`),
  KEY `idx_gauth_user` (`user_id`),
  CONSTRAINT `fk_gauth_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_app_settings.sql
-- ============================================================
-- Table: app_settings
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema) — FIXED
-- ============================================================
-- CONFLICT RESOLVED: this table was also defined in
-- migrations/t52_migration.sql (older, simpler — admin_settings.php,
-- superseded duplicate, see router_merge_README.md). Base schema
-- version kept as the winner.
--
-- FIX (21 Jun 2026): live code in api/admin/global_settings.php
-- expects columns setting_group, setting_type, label, description,
-- is_public, is_locked — NONE of these existed in any migration file
-- found (base schema or t52). Added them below so the already-merged
-- t52 routes (gs_list, gs_get, gs_save, etc.) actually work.
-- ============================================================

CREATE TABLE IF NOT EXISTS `app_settings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_val` text DEFAULT NULL,
  `setting_group` varchar(50) NOT NULL DEFAULT 'general',
  `setting_type` enum('text','number','boolean','json','select') NOT NULL DEFAULT 'text',
  `label` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_key` (`setting_key`),
  KEY `idx_settings_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_audit_log.sql
-- ============================================================
-- Table: audit_log
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema) — WINNER
-- ============================================================
-- CONFLICT RESOLVED: also defined in migrations/t50_migration.sql
-- (older, simpler — admin_users.php era, superseded duplicate, see
-- router_merge_README.md). That version lacked entity_type,
-- entity_id, old_values, new_values — but live code in
-- api/admin/audit_log.php (already wired to router.php) NEEDS those
-- columns for the change-tracking / JSON diff feature. Base schema
-- version kept as the winner; t50's version discarded entirely.
-- ============================================================

CREATE TABLE IF NOT EXISTS `audit_log` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_entity` (`entity_type`, `entity_id`),
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 009_portfolios.sql
-- ============================================================
-- Table: portfolios
-- Domain: 001_core
-- Source: 01_schema_complete.sql (base schema)
-- ============================================================
-- Depends on: users
-- CRITICAL: almost every domain table (mutual funds, stocks, FD,
-- bank, EPF, insurance, loans, goals, etc.) has a foreign key to
-- this table via portfolio_id. Must be created right after users,
-- before any domain folder runs.
-- ============================================================

CREATE TABLE IF NOT EXISTS `portfolios` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT 'My Portfolio',
  `description` text DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_portfolio_user` (`user_id`),
  CONSTRAINT `fk_portfolio_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 010_user_sessions.sql
-- ============================================================
-- Table: user_sessions
-- Domain: 001_core
-- Source: api/auth/session_security.php (live code, self-creating) — WINNER
-- ============================================================
-- CONFLICT RESOLVED: 3 different schemas found for this table:
--   1. 41_pending_tasks.sql            — close, but missing country, is_current
--   2. migrations/t387_migration.sql   — completely different columns
--                                        (session_id, device_label) — WRONG,
--                                        superseded duplicate (see
--                                        router_merge_README.md)
--   3. api/auth/session_security.php   — the live PHP file creates this
--                                        table itself inline with
--                                        CREATE TABLE IF NOT EXISTS
-- Used #3 as the authoritative source since it's the actual running code.
--
-- This is the user-facing "manage your logged-in devices" feature (t387).
-- NOT the same as 'sessions' (002_sessions.sql) which is PHP's internal
-- session storage.
--
-- Depends on: users
-- ============================================================

CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `session_token` varchar(128) NOT NULL,
  `device_name` varchar(120) DEFAULT NULL,
  `device_type` enum('desktop','mobile','tablet','unknown') NOT NULL DEFAULT 'unknown',
  `browser` varchar(80) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `last_active` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_current` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `idx_user` (`user_id`),
  KEY `idx_token` (`session_token`),
  KEY `idx_active` (`last_active`),
  CONSTRAINT `fk_us_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 011_account_deletion_requests.sql
-- ============================================================
-- Table: account_deletion_requests
-- Domain: 001_core  |  Sequence: 011
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS account_deletion_requests (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL,
  status        ENUM('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
  requested_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  scheduled_for DATETIME     NOT NULL,
  cancelled_at  DATETIME     NULL,
  completed_at  DATETIME     NULL,
  KEY idx_user_status (user_id, status),
  KEY idx_scheduled (scheduled_for),
  CONSTRAINT fk_adr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 012_user_settings.sql
-- ============================================================
-- Table: user_settings
-- Domain: 001_core  |  Sequence: 012
-- Source: migrations/t347_number_format_settings.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS user_settings (
  id                    INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id               INT UNSIGNED NOT NULL,
  number_format         VARCHAR(10)  NOT NULL DEFAULT 'indian'  COMMENT 'indian | international',
  compact_large_numbers TINYINT(1)   NOT NULL DEFAULT 1         COMMENT '1 = show 1.5L/2.3Cr',
  currency_symbol       VARCHAR(5)   NOT NULL DEFAULT '₹',
  decimal_places        TINYINT      NOT NULL DEFAULT 2,
  created_at            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 013_user_kv_settings.sql
-- ============================================================
-- Table: user_kv_settings
-- Domain: 001_core  |  Sequence: 013
-- Source: migrations/t355_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `user_kv_settings` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      int(10) UNSIGNED NOT NULL,
  `portfolio_id` int(10) UNSIGNED DEFAULT NULL,
  `setting_key`  varchar(80)      NOT NULL,
  `setting_value` text            DEFAULT NULL,
  `updated_at`   datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_kv_user_portfolio_key` (`user_id`, `portfolio_id`, `setting_key`),
  KEY `idx_kv_portfolio` (`portfolio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 014_webauthn_credentials.sql
-- ============================================================
-- Table: webauthn_credentials
-- Domain: 001_core  |  Sequence: 014
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS webauthn_credentials (
  id             INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id        INT UNSIGNED  NOT NULL,
  credential_id  VARCHAR(512)  NOT NULL UNIQUE,
  public_key_spki TEXT         NULL COMMENT 'Raw attestation object (base64)',
  device_name    VARCHAR(100)  NOT NULL DEFAULT 'My Device',
  sign_count     INT UNSIGNED  NOT NULL DEFAULT 0,
  created_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_used_at   DATETIME      NULL,
  KEY idx_user (user_id),
  CONSTRAINT fk_wc_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 015_user_documents.sql
-- ============================================================
-- Table: user_documents
-- Domain: 001_core  |  Sequence: 015
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS user_documents (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED  NOT NULL,
  category    VARCHAR(40)   NOT NULL DEFAULT 'other',
  doc_name    VARCHAR(150)  NOT NULL,
  file_path   VARCHAR(255)  NOT NULL COMMENT 'Random filename in storage/documents/<user_id>/',
  file_size   INT UNSIGNED  NOT NULL DEFAULT 0,
  expiry_date DATE          NULL,
  source      ENUM('manual_upload','digilocker') NOT NULL DEFAULT 'manual_upload',
  uploaded_at DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user_category (user_id, category),
  KEY idx_user_expiry   (user_id, expiry_date),
  CONSTRAINT fk_ud_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 016_life_events.sql
-- ============================================================
-- Table: life_events
-- Domain: 001_core  |  Sequence: 016
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS life_events (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id          INT UNSIGNED NOT NULL,
  event_name       VARCHAR(150) NOT NULL,
  event_type       ENUM('milestone','personal','career','family','goal') NOT NULL DEFAULT 'milestone',
  event_date       DATE         NOT NULL,
  financial_impact VARCHAR(255) NULL,
  notes            TEXT         NULL,
  created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user_date (user_id, event_date),
  CONSTRAINT fk_le_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 017_finance_profiles.sql
-- ============================================================
-- Table: finance_profiles
-- Domain: 001_core  |  Sequence: 017
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS finance_profiles (
  id                    INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id               INT UNSIGNED  NOT NULL UNIQUE,
  age                   TINYINT       NULL,
  employment_type       ENUM('salaried','self_employed','business','freelancer','retired') NOT NULL DEFAULT 'salaried',
  annual_income         DECIMAL(14,2) NULL DEFAULT 0,
  tax_slab              VARCHAR(5)    NULL DEFAULT '30',
  risk_profile          ENUM('conservative','moderate','moderately_aggressive','aggressive') NOT NULL DEFAULT 'moderate',
  investment_horizon    ENUM('short','medium','long') NOT NULL DEFAULT 'long',
  monthly_expenses      DECIMAL(12,2) NULL DEFAULT 0,
  monthly_savings       DECIMAL(12,2) NULL DEFAULT 0,
  emergency_fund_months TINYINT       NULL DEFAULT 0,
  dependents            TINYINT       NULL DEFAULT 0,
  has_life_insurance    TINYINT(1)    NOT NULL DEFAULT 0,
  has_health_insurance  TINYINT(1)    NOT NULL DEFAULT 0,
  goals                 JSON          NULL,
  income_sources        JSON          NULL,
  notes                 TEXT          NULL,
  created_at            DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at            DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_fp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 018_referrals.sql
-- ============================================================
-- Table: referrals
-- Domain: 001_core  |  Sequence: 018
-- ============================================================
-- !! STUB: NOT FOUND in any SQL file — never built, stub placeholder created
-- !! Define the actual schema before running.
-- ============================================================

CREATE TABLE IF NOT EXISTS `referrals` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  -- TODO: define columns
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 002_mutual_funds ──────────────────────────────────────
-- 001_fund_houses.sql
-- ============================================================
-- Table: fund_houses
-- Domain: 002_mutual_funds  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `fund_houses` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `short_name` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fh_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_funds.sql
-- ============================================================
-- Table: funds
-- Domain: 002_mutual_funds  |  Sequence: 002
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `funds` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `scheme_code` varchar(20) NOT NULL,
  `isin` varchar(20) DEFAULT NULL,
  `isin_reinvest` varchar(20) DEFAULT NULL,
  `fund_house_id` int(10) UNSIGNED DEFAULT NULL,
  `scheme_name` varchar(300) NOT NULL,
  `scheme_type` varchar(100) DEFAULT NULL,
  `scheme_category` varchar(100) DEFAULT NULL,
  `scheme_sub_category` varchar(100) DEFAULT NULL,
  `nav` decimal(14,4) DEFAULT NULL,
  `nav_date` date DEFAULT NULL,
  `return_1y` decimal(8,4) DEFAULT NULL,
  `return_3y` decimal(8,4) DEFAULT NULL,
  `return_5y` decimal(8,4) DEFAULT NULL,
  `return_since` decimal(8,4) DEFAULT NULL,
  `aum_cr` decimal(14,2) DEFAULT NULL,
  `expense_ratio` decimal(5,3) DEFAULT NULL,
  `exit_load_text` text DEFAULT NULL,
  `exit_load_pct` decimal(5,3) DEFAULT NULL,
  `exit_load_days` int(11) DEFAULT NULL,
  `risk_level` varchar(30) DEFAULT NULL,
  `benchmark` varchar(150) DEFAULT NULL,
  `fund_manager` varchar(150) DEFAULT NULL,
  `min_sip_amount` decimal(10,2) DEFAULT NULL,
  `min_lumpsum` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_scheme_code` (`scheme_code`),
  KEY `idx_fund_house` (`fund_house_id`),
  KEY `idx_fund_isin` (`isin`),
  KEY `idx_fund_category` (`scheme_category`),
  KEY `idx_fund_name` (`scheme_name`(100)),
  CONSTRAINT `fk_fund_house` FOREIGN KEY (`fund_house_id`) REFERENCES `fund_houses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_nav_history.sql
-- ============================================================
-- Table: nav_history
-- Domain: 002_mutual_funds  |  Sequence: 003
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nav_history` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fund_id` int(10) UNSIGNED NOT NULL,
  `nav_date` date NOT NULL,
  `nav` decimal(14,4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nav` (`fund_id`, `nav_date`),
  KEY `idx_nav_date` (`nav_date`),
  CONSTRAINT `fk_navh_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_fund_managers.sql
-- ============================================================
-- Table: fund_managers
-- Domain: 002_mutual_funds  |  Sequence: 004
-- Source: 16_fund_managers.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 013_fund_metrics.sql also has this table but with fewer columns (since_date vs from_date+to_date). Winner: 16_fund_managers.sql (richer schema)
-- 
CREATE TABLE IF NOT EXISTS `fund_managers` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fund_id`      INT UNSIGNED NOT NULL,
  `manager_name` VARCHAR(200) NOT NULL,
  `from_date`    DATE         NOT NULL,
  `to_date`      DATE         DEFAULT NULL COMMENT 'NULL = currently managing',
  `is_current`   TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_fm_fund`    (`fund_id`),
  KEY `idx_fm_manager` (`manager_name`(100)),
  KEY `idx_fm_current` (`is_current`),
  CONSTRAINT `fk_fm_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Fund manager history — track performance before/after manager change';

-- 005_fund_ratings.sql
-- ============================================================
-- Table: fund_ratings
-- Domain: 002_mutual_funds  |  Sequence: 005
-- Source: 23_fund_ratings.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 015_saved_screens_and_more.sql also has this table. Winner: 23_fund_ratings.sql (JSON score_breakdown, FK constraint, fuller schema)
-- 
CREATE TABLE IF NOT EXISTS `fund_ratings` (
  `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fund_id`          INT UNSIGNED NOT NULL,
  `stars`            TINYINT UNSIGNED NOT NULL COMMENT '1-5 star rating',
  `score_total`      DECIMAL(6,4)  DEFAULT NULL COMMENT 'Raw weighted score before rounding',
  `score_breakdown`  JSON          DEFAULT NULL COMMENT '{"returns":2.5,"expense":0.75,"drawdown":0.75,"direct":0.2}',
  `rated_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fr_fund` (`fund_id`),
  KEY `idx_fr_stars` (`stars`),
  KEY `idx_fr_rated` (`rated_at`),
  CONSTRAINT `fk_fr_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='WealthDash internal fund star ratings — recalculated weekly by cron';

-- 006_fund_benchmark_map.sql
-- ============================================================
-- Table: fund_benchmark_map
-- Domain: 002_mutual_funds  |  Sequence: 006
-- Source: migrations/013_fund_metrics.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fund_benchmark_map (
    fund_id        INT UNSIGNED NOT NULL PRIMARY KEY,
    benchmark_code VARCHAR(30)  NOT NULL COMMENT 'e.g. NIFTY50, NIFTYMIDCAP150',
    benchmark_name VARCHAR(80)  NOT NULL,
    updated_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_benchmark (benchmark_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 007_benchmark_nav.sql
-- ============================================================
-- Table: benchmark_nav
-- Domain: 002_mutual_funds  |  Sequence: 007
-- Source: migrations/013_fund_metrics.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS benchmark_nav (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code       VARCHAR(30) NOT NULL,
    nav_date   DATE        NOT NULL,
    nav_value  DECIMAL(12,4) NOT NULL,
    UNIQUE KEY uk_code_date (code, nav_date),
    INDEX idx_code (code),
    INDEX idx_date (nav_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 008_benchmark_nav_cache.sql
-- ============================================================
-- Table: benchmark_nav_cache
-- Domain: 002_mutual_funds  |  Sequence: 008
-- Source: migrations/tv11_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `benchmark_nav_cache` (
    `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `symbol`     VARCHAR(20)   NOT NULL COMMENT '^NSEI, ^BSESN, etc.',
    `nav_date`   DATE          NOT NULL,
    `close`      DECIMAL(14,4) NOT NULL,
    `fetched_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_bm_nav`       (`symbol`, `nav_date`),
    INDEX       `idx_bm_symbol`  (`symbol`),
    INDEX       `idx_bm_date`    (`nav_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Benchmark index NAV cache — Nifty 50, Sensex, Midcap etc. (tv11)';

-- 009_fund_rolling_returns.sql
-- ============================================================
-- Table: fund_rolling_returns
-- Domain: 002_mutual_funds  |  Sequence: 009
-- Source: migrations/013_fund_metrics.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fund_rolling_returns (
    id                    BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fund_id               INT UNSIGNED NOT NULL,
    period                ENUM('1Y','3Y','5Y') NOT NULL,
    min_return            DECIMAL(8,4) DEFAULT NULL,
    max_return            DECIMAL(8,4) DEFAULT NULL,
    avg_return            DECIMAL(8,4) DEFAULT NULL,
    median_return         DECIMAL(8,4) DEFAULT NULL,
    positive_periods_pct  DECIMAL(5,2) DEFAULT NULL COMMENT '% of windows with +ve return',
    total_windows         INT UNSIGNED DEFAULT NULL,
    calculated_date       DATE         NOT NULL,
    UNIQUE KEY uk_fund_period_date (fund_id, period, calculated_date),
    INDEX idx_fund (fund_id),
    INDEX idx_period (period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 010_fund_overlap_cache.sql
-- ============================================================
-- Table: fund_overlap_cache
-- Domain: 002_mutual_funds  |  Sequence: 010
-- Source: 15_fund_holdings.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `fund_overlap_cache` (
  `fund_id_a`    INT UNSIGNED NOT NULL,
  `fund_id_b`    INT UNSIGNED NOT NULL,
  `overlap_pct`  DECIMAL(5,2) NOT NULL  COMMENT 'Percentage of portfolio that overlaps (by weight)',
  `common_stocks` SMALLINT    NOT NULL DEFAULT 0,
  `month_year`   DATE         NOT NULL,
  `updated_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`fund_id_a`, `fund_id_b`, `month_year`),
  KEY `idx_oc_a` (`fund_id_a`),
  KEY `idx_oc_b` (`fund_id_b`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Precomputed pairwise fund overlap — recalculate monthly';

-- 011_fund_stock_holdings.sql
-- ============================================================
-- Table: fund_stock_holdings
-- Domain: 002_mutual_funds  |  Sequence: 011
-- Source: 15_fund_holdings.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `fund_stock_holdings` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_id`      INT UNSIGNED  NOT NULL,
  `stock_name`   VARCHAR(300)  NOT NULL,
  `isin`         VARCHAR(15)   DEFAULT NULL,
  `sector`       VARCHAR(100)  DEFAULT NULL  COMMENT 'AMFI disclosure sector name',
  `weight_pct`   DECIMAL(6,3)  NOT NULL      COMMENT 'Percentage of fund portfolio (0-100)',
  `market_cap`   ENUM('large','mid','small','other') DEFAULT NULL,
  `month_year`   DATE          NOT NULL      COMMENT 'First day of disclosure month (e.g. 2026-03-01)',
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fund_stock_month` (`fund_id`, `isin`(15), `month_year`),
  KEY `idx_fsh_fund`      (`fund_id`),
  KEY `idx_fsh_isin`      (`isin`),
  KEY `idx_fsh_sector`    (`sector`(50)),
  KEY `idx_fsh_month`     (`month_year`),
  CONSTRAINT `fk_fsh_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='AMFI monthly portfolio disclosure — stock-level holdings per fund';

-- 012_fund_portfolio_holdings.sql
-- ============================================================
-- Table: fund_portfolio_holdings
-- Domain: 002_mutual_funds  |  Sequence: 012
-- Source: migrations/015_saved_screens_and_more.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fund_portfolio_holdings (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fund_id     INT UNSIGNED NOT NULL,
    stock_name  VARCHAR(100) NOT NULL,
    isin        VARCHAR(12)  DEFAULT NULL,
    sector      VARCHAR(60)  DEFAULT NULL,
    weight_pct  DECIMAL(5,2) DEFAULT NULL,
    month_year  VARCHAR(7)   NOT NULL COMMENT 'YYYY-MM',
    UNIQUE KEY uk_fund_stock_month (fund_id, isin, month_year),
    INDEX idx_fund  (fund_id),
    INDEX idx_month (month_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 013_fund_ter_history.sql
-- ============================================================
-- Table: fund_ter_history
-- Domain: 002_mutual_funds  |  Sequence: 013
-- Source: migrations/015_saved_screens_and_more.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fund_ter_history (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fund_id        INT UNSIGNED NOT NULL,
    ter_pct        DECIMAL(5,3) NOT NULL,
    effective_date DATE         NOT NULL,
    UNIQUE KEY uk_fund_date (fund_id, effective_date),
    INDEX idx_fund (fund_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 014_fund_dividends.sql
-- ============================================================
-- Table: fund_dividends
-- Domain: 002_mutual_funds  |  Sequence: 014
-- Source: migrations/015_saved_screens_and_more.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fund_dividends (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fund_id         INT UNSIGNED NOT NULL,
    record_date     DATE         NOT NULL,
    ex_date         DATE         DEFAULT NULL,
    dividend_per_unit DECIMAL(10,4) NOT NULL,
    UNIQUE KEY uk_fund_date (fund_id, record_date),
    INDEX idx_fund (fund_id),
    INDEX idx_date (record_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 015_expense_ratio_history.sql
-- ============================================================
-- Table: expense_ratio_history
-- Domain: 002_mutual_funds  |  Sequence: 015
-- Source: 17_expense_history_import_log.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `expense_ratio_history` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `fund_id`        INT UNSIGNED  NOT NULL,
  `expense_ratio`  DECIMAL(6,4)  NOT NULL COMMENT 'TER in % (e.g. 1.05 = 1.05%)',
  `plan_type`      ENUM('direct','regular') NOT NULL DEFAULT 'direct',
  `recorded_date`  DATE          NOT NULL COMMENT 'First day of the month (monthly snapshot)',
  `source`         VARCHAR(100)  DEFAULT 'amfi_website',
  `created_at`     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_exp_fund_month` (`fund_id`, `plan_type`, `recorded_date`),
  KEY `idx_erh_fund` (`fund_id`),
  KEY `idx_erh_date` (`recorded_date`),
  CONSTRAINT `fk_erh_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Monthly TER snapshot — track if expense ratio is rising or falling';

-- 016_mf_holdings.sql
-- ============================================================
-- Table: mf_holdings
-- Domain: 002_mutual_funds  |  Sequence: 016
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `mf_holdings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `fund_id` int(10) UNSIGNED NOT NULL,
  `folio_number` varchar(50) DEFAULT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `units` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `avg_nav` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `invested_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `current_value` decimal(16,2) NOT NULL DEFAULT 0.00,
  `gain_loss` decimal(16,2) NOT NULL DEFAULT 0.00,
  `xirr` decimal(8,4) DEFAULT NULL,
  `sip_active` tinyint(1) NOT NULL DEFAULT 0,
  `swp_active` tinyint(1) NOT NULL DEFAULT 0,
  `first_investment_date` date DEFAULT NULL,
  `last_transaction_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mfh` (`portfolio_id`, `fund_id`, `folio_number`),
  KEY `idx_mfh_fund` (`fund_id`),
  CONSTRAINT `fk_mfh_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`),
  CONSTRAINT `fk_mfh_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 017_mf_transactions.sql
-- ============================================================
-- Table: mf_transactions
-- Domain: 002_mutual_funds  |  Sequence: 017
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `mf_transactions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `fund_id` int(10) UNSIGNED NOT NULL,
  `folio_number` varchar(50) DEFAULT NULL,
  `txn_type` enum('purchase','redemption','switch_in','switch_out','dividend_reinvest','sip','swp') NOT NULL,
  `txn_date` date NOT NULL,
  `units` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `nav` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `platform` varchar(50) DEFAULT NULL,
  `investment_fy` varchar(10) DEFAULT NULL COMMENT 'e.g. 2024-25',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mft_portfolio` (`portfolio_id`),
  KEY `idx_mft_fund` (`fund_id`),
  KEY `idx_mft_date` (`txn_date`),
  KEY `idx_mft_type` (`txn_type`),
  CONSTRAINT `fk_mft_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`),
  CONSTRAINT `fk_mft_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 018_mf_dividends.sql
-- ============================================================
-- Table: mf_dividends
-- Domain: 002_mutual_funds  |  Sequence: 018
-- Source: 14_mf_dividends_notes.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 01_schema_complete.sql (basic) and migrations/t314_migration.sql (simplest, user_id+amount only). WINNER: 14_mf_dividends_notes.sql (richest schema — nav_before, nav_after, rate_per_unit). Added user_id + amount as compatibility columns for monthly_pl.php which uses them.
-- 
CREATE TABLE IF NOT EXISTS `mf_dividends` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`   INT UNSIGNED  NOT NULL,
  `fund_id`        INT UNSIGNED  NOT NULL,
  `folio_number`   VARCHAR(50)   DEFAULT NULL,
  `dividend_date`  DATE          NOT NULL,
  `nav_before`     DECIMAL(12,4) DEFAULT NULL COMMENT 'NAV ex-dividend date se pehle',
  `nav_after`      DECIMAL(12,4) DEFAULT NULL COMMENT 'NAV ex-dividend date ke baad',
  `rate_per_unit`  DECIMAL(10,4) NOT NULL    COMMENT 'Dividend rate per unit (₹)',
  `units_held`     DECIMAL(14,4) DEFAULT NULL,
  `amount_received` DECIMAL(14,2) DEFAULT NULL COMMENT 'rate_per_unit * units_held',
  `tds_deducted`   DECIMAL(10,2) DEFAULT 0.00,
  `net_received`   DECIMAL(14,2) DEFAULT NULL COMMENT 'amount_received - tds_deducted',
  `is_reinvested`  TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '1 = Growth/Reinvest plan',
  `created_at`     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dividend` (`portfolio_id`, `fund_id`, `folio_number`(30), `dividend_date`),
  KEY `idx_div_portfolio` (`portfolio_id`),
  KEY `idx_div_fund`      (`fund_id`),
  KEY `idx_div_date`      (`dividend_date`),
  CONSTRAINT `fk_div_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_div_fund`      FOREIGN KEY (`fund_id`)      REFERENCES `funds`(`id`)      ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='MF IDCW / Dividend payout history per folio';

-- 019_mf_peak_progress.sql
-- ============================================================
-- Table: mf_peak_progress
-- Domain: 002_mutual_funds  |  Sequence: 019
-- Source: 01_schema_complete.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 21_peak_nav_setup.sql also has this (missing needs_update status). Winner: 01_schema_complete.sql (has needs_update enum value)
-- 
CREATE TABLE IF NOT EXISTS `mf_peak_progress` (
  `scheme_code` varchar(20) NOT NULL,
  `last_processed_date` date DEFAULT NULL,
  `status` enum('pending','in_progress','completed','needs_update','error') NOT NULL DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`scheme_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 020_mf_holding_notes.sql
-- ============================================================
-- Table: mf_holding_notes
-- Domain: 002_mutual_funds  |  Sequence: 020
-- Source: 14_mf_dividends_notes.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `mf_holding_notes` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` INT UNSIGNED NOT NULL,
  `fund_id`      INT UNSIGNED NOT NULL,
  `folio_number` VARCHAR(50)  DEFAULT NULL,
  `note`         TEXT         NOT NULL,
  `updated_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_note` (`portfolio_id`, `fund_id`, `folio_number`(30)),
  KEY `idx_hn_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_hn_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hn_fund`      FOREIGN KEY (`fund_id`)      REFERENCES `funds`(`id`)      ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Personal notes per MF fund/folio — "Bought on COVID dip", "Goal: retirement"';

-- 021_mf_holdings_notes.sql
-- ============================================================
-- Table: mf_holdings_notes
-- Domain: 002_mutual_funds  |  Sequence: 021
-- Source: migrations/015_saved_screens_and_more.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_holdings_notes (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NOT NULL,
    holding_id INT UNSIGNED NOT NULL,
    note_text  TEXT         NOT NULL,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_user_holding (user_id, holding_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 022_mf_saved_screens.sql
-- ============================================================
-- Table: mf_saved_screens
-- Domain: 002_mutual_funds  |  Sequence: 022
-- Source: migrations/015_saved_screens_and_more.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_saved_screens (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    name         VARCHAR(80)  NOT NULL,
    filters_json TEXT         NOT NULL COMMENT 'JSON encoded filter state',
    is_public    TINYINT(1)   NOT NULL DEFAULT 0,
    share_token  VARCHAR(32)  DEFAULT NULL,
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user   (user_id),
    INDEX idx_public (is_public),
    INDEX idx_token  (share_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 023_mf_alert_history.sql
-- ============================================================
-- Table: mf_alert_history
-- Domain: 002_mutual_funds  |  Sequence: 023
-- Source: migrations/010_watchlist.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_alert_history (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    alert_id    INT UNSIGNED    NOT NULL,
    user_id     INT UNSIGNED    NOT NULL,
    fund_id     INT UNSIGNED    NOT NULL,
    trigger_val DECIMAL(12,4)   DEFAULT NULL,
    triggered_at DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_alert  (alert_id),
    INDEX idx_user   (user_id),
    INDEX idx_date   (triggered_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 024_mf_watchlist.sql
-- ============================================================
-- Table: mf_watchlist
-- Domain: 002_mutual_funds  |  Sequence: 024
-- Source: migrations/010_watchlist.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_watchlist (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    fund_id     INT UNSIGNED NOT NULL,
    notes       VARCHAR(300) DEFAULT NULL,
    added_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_user_fund (user_id, fund_id),
    INDEX idx_user (user_id),
    INDEX idx_fund (fund_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 025_mf_watchlist_alerts.sql
-- ============================================================
-- Table: mf_watchlist_alerts
-- Domain: 002_mutual_funds  |  Sequence: 025
-- Source: migrations/010_watchlist.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_watchlist_alerts (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NOT NULL,
    fund_id         INT UNSIGNED NOT NULL,
    alert_type      ENUM('nav_above','nav_below','return_1y_above','return_3y_above',
                         'sharpe_above','aum_above','expense_below','multi_condition') NOT NULL,
    target_value    DECIMAL(12,4)  DEFAULT NULL,
    conditions_json TEXT           DEFAULT NULL COMMENT 'JSON for multi_condition type',
    is_active       TINYINT(1)     NOT NULL DEFAULT 1,
    last_triggered  DATETIME       DEFAULT NULL,
    snooze_until    DATETIME       DEFAULT NULL,
    created_at      DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user   (user_id),
    INDEX idx_fund   (fund_id),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 026_fund_watchlist.sql
-- ============================================================
-- Table: fund_watchlist
-- Domain: 002_mutual_funds  |  Sequence: 026
-- Source: 09_watchlist.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `fund_watchlist` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,
  `fund_id`    INT UNSIGNED NOT NULL,
  `notes`      TEXT         DEFAULT NULL  COMMENT 'User ka personal note is fund pe',
  `alert_nav`  DECIMAL(10,4) DEFAULT NULL COMMENT 'Price alert — NAV is level pe pahunche to notify',
  `alert_type` ENUM('above','below') DEFAULT NULL,
  `added_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_fund` (`user_id`, `fund_id`),
  KEY `idx_wl_user`   (`user_id`),
  KEY `idx_wl_fund`   (`fund_id`),
  CONSTRAINT `fk_wl_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)  ON DELETE CASCADE,
  CONSTRAINT `fk_wl_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Fund Watchlist — user ke favourite funds, DB-persistent';

-- 027_mf_nav_history.sql
-- ============================================================
-- Table: mf_nav_history
-- Domain: 002_mutual_funds  |  Sequence: 027
-- Source: migrations/t300_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_nav_history (
  id        INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  mf_id     INT UNSIGNED  NOT NULL,
  nav_date  DATE          NOT NULL,
  nav       DECIMAL(14,4) NOT NULL DEFAULT 0,
  UNIQUE KEY uk_mf_date (mf_id, nav_date),
  KEY idx_mf_id    (mf_id),
  KEY idx_nav_date (nav_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 028_mf_compare_sessions.sql
-- ============================================================
-- Table: mf_compare_sessions
-- Domain: 002_mutual_funds  |  Sequence: 028
-- Source: migrations/tv12_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS mf_compare_sessions (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    fund_ids    VARCHAR(100) NOT NULL COMMENT 'comma-separated fund IDs, max 5',
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_user (user_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 029_mf_backtest_cache.sql
-- ============================================================
-- Table: mf_backtest_cache
-- Domain: 002_mutual_funds  |  Sequence: 029
-- Source: migrations/t234_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `mf_backtest_cache` (
    `id`             INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    `fund_id`        INT UNSIGNED      NOT NULL,
    `period`         VARCHAR(5)        NOT NULL COMMENT '1Y,3Y,5Y,10Y,etc.',
    `monthly_amount` DECIMAL(12,2)     NOT NULL DEFAULT 5000.00,
    `sip_day`        TINYINT UNSIGNED  NOT NULL DEFAULT 1,
    `result_json`    MEDIUMTEXT        NOT NULL COMMENT 'Cached JSON response',
    `nav_count`      INT UNSIGNED      NOT NULL DEFAULT 0 COMMENT 'nav_history rows at cache time',
    `computed_at`    DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_backtest_cache` (`fund_id`, `period`, `monthly_amount`, `sip_day`),
    INDEX `idx_backtest_fund`     (`fund_id`),
    INDEX `idx_backtest_computed` (`computed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Cache for SIP vs Lumpsum backtest results (t234)';

-- 030_nfo_tracker.sql
-- ============================================================
-- Table: nfo_tracker
-- Domain: 002_mutual_funds  |  Sequence: 030
-- Source: 08_nfo_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nfo_tracker` (
  `id`              INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `fund_name`       VARCHAR(300)     NOT NULL,
  `amc`             VARCHAR(200)     NOT NULL,
  `scheme_code`     VARCHAR(50)      DEFAULT NULL COMMENT 'AMFI scheme code — links to funds table after allotment',
  `category`        VARCHAR(100)     DEFAULT NULL COMMENT 'Equity/Debt/Hybrid/Index etc.',
  `nfo_price`       DECIMAL(10,4)   DEFAULT 10.0000 COMMENT 'NFO face value (usually ₹10)',
  `min_investment`  DECIMAL(12,2)   DEFAULT 5000.00,
  `open_date`       DATE             NOT NULL,
  `close_date`      DATE             NOT NULL,
  `allotment_date`  DATE             DEFAULT NULL,
  `status`          ENUM('upcoming','open','closing_soon','closed','allotted') NOT NULL DEFAULT 'upcoming',
  `fund_type`       ENUM('open_ended','close_ended','interval') DEFAULT 'open_ended',
  `tax_saving`      TINYINT(1)       NOT NULL DEFAULT 0 COMMENT '1 = ELSS / 80C eligible',
  `benchmark`       VARCHAR(200)     DEFAULT NULL,
  `fund_manager`    VARCHAR(200)     DEFAULT NULL,
  `amc_website`     VARCHAR(500)     DEFAULT NULL,
  `last_updated`    TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at`      TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nfo_name_open` (`fund_name`(150), `open_date`),
  KEY `idx_nfo_status`     (`status`),
  KEY `idx_nfo_close_date` (`close_date`),
  KEY `idx_nfo_open_date`  (`open_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='NFO Tracker — AMFI se daily fetch, screener mein NFO tab';

-- 031_sip_schedules.sql
-- ============================================================
-- Table: sip_schedules
-- Domain: 002_mutual_funds  |  Sequence: 031
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `sip_schedules` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `asset_type` enum('mf','stock','nps') NOT NULL DEFAULT 'mf',
  `fund_id` int(10) UNSIGNED DEFAULT NULL,
  `stock_id` int(10) UNSIGNED DEFAULT NULL,
  `nps_scheme_id` int(10) UNSIGNED DEFAULT NULL,
  `folio_number` varchar(50) DEFAULT NULL,
  `sip_amount` decimal(14,2) NOT NULL,
  `swp_amount` decimal(14,2) DEFAULT NULL,
  `sip_type` enum('sip','swp') NOT NULL DEFAULT 'sip',
  `frequency` enum('monthly','quarterly','weekly','yearly') NOT NULL DEFAULT 'monthly',
  `sip_day` tinyint(3) UNSIGNED NOT NULL DEFAULT 1 COMMENT 'Day of month 1-28',
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL COMMENT 'NULL = ongoing',
  `platform` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sip_portfolio` (`portfolio_id`),
  KEY `idx_sip_fund` (`fund_id`),
  CONSTRAINT `fk_sip_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sip_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 032_sip_stepup_config.sql
-- ============================================================
-- Table: sip_stepup_config
-- Domain: 002_mutual_funds  |  Sequence: 032
-- Source: migrations/t144_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS sip_stepup_config (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sip_id           INT UNSIGNED NOT NULL COMMENT 'References sip_schedules.id',
    user_id          INT UNSIGNED NOT NULL,
    portfolio_id     INT UNSIGNED NOT NULL,
    stepup_type      ENUM('percentage','fixed_amount') NOT NULL DEFAULT 'percentage',
    stepup_value     DECIMAL(10,4) NOT NULL COMMENT 'Percentage OR fixed rupee amount',
    stepup_frequency ENUM('yearly','half_yearly','custom') NOT NULL DEFAULT 'yearly',
    stepup_month     TINYINT UNSIGNED DEFAULT 4  COMMENT 'Month to apply step-up (default April = FY start)',
    custom_interval_months TINYINT UNSIGNED DEFAULT NULL,
    max_sip_amount   DECIMAL(12,2) DEFAULT NULL COMMENT 'Cap the SIP at this amount',
    is_active        TINYINT(1)   NOT NULL DEFAULT 1,
    next_stepup_date DATE         DEFAULT NULL,
    last_stepup_date DATE         DEFAULT NULL,
    last_stepup_from DECIMAL(12,2) DEFAULT NULL,
    last_stepup_to   DECIMAL(12,2) DEFAULT NULL,
    notes            TEXT         DEFAULT NULL,
    created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_sip (sip_id),
    INDEX idx_user  (user_id),
    INDEX idx_next  (next_stepup_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 033_sip_stepup_history.sql
-- ============================================================
-- Table: sip_stepup_history
-- Domain: 002_mutual_funds  |  Sequence: 033
-- Source: migrations/t144_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS sip_stepup_history (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    stepup_config_id INT UNSIGNED NOT NULL,
    sip_id           INT UNSIGNED NOT NULL,
    user_id          INT UNSIGNED NOT NULL,
    applied_date     DATE         NOT NULL,
    old_amount       DECIMAL(12,2) NOT NULL,
    new_amount       DECIMAL(12,2) NOT NULL,
    stepup_value     DECIMAL(10,4) NOT NULL,
    stepup_type      ENUM('percentage','fixed_amount') NOT NULL,
    applied_by       ENUM('auto','manual') NOT NULL DEFAULT 'manual',
    notes            TEXT         DEFAULT NULL,
    created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_config (stepup_config_id),
    INDEX idx_sip    (sip_id),
    INDEX idx_user   (user_id),
    INDEX idx_date   (applied_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 034_sip_stepup_nudges.sql
-- ============================================================
-- Table: sip_stepup_nudges
-- Domain: 002_mutual_funds  |  Sequence: 034
-- Source: migrations/t144_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS sip_stepup_nudges (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id          INT UNSIGNED NOT NULL,
    nudge_type       ENUM('salary_hike','fy_start','manual_prompt','anniversary') NOT NULL DEFAULT 'fy_start',
    nudge_date       DATE         NOT NULL,
    is_dismissed     TINYINT(1)   NOT NULL DEFAULT 0,
    is_actioned      TINYINT(1)   NOT NULL DEFAULT 0,
    actioned_sip_ids TEXT         DEFAULT NULL COMMENT 'JSON array of sip_ids that were stepped up',
    created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user   (user_id),
    INDEX idx_date   (nudge_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 035_rebalancing_targets.sql
-- ============================================================
-- Table: rebalancing_targets
-- Domain: 002_mutual_funds  |  Sequence: 035
-- Source: 18_rebalancing_stepup.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `rebalancing_targets` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `portfolio_id`   INT UNSIGNED  NOT NULL,
  `asset_class`    ENUM('equity','debt','gold','cash','international','other') NOT NULL,
  `target_pct`     DECIMAL(5,2)  NOT NULL  COMMENT 'Target allocation % (0-100)',
  `drift_threshold` DECIMAL(5,2) NOT NULL DEFAULT 5.00 COMMENT 'Alert agar actual drift > threshold %',
  `updated_at`     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rebal_portfolio_asset` (`portfolio_id`, `asset_class`),
  CONSTRAINT `fk_rebal_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='User-defined target allocation for rebalancing alerts';

-- 036_nav_proxy_cache.sql
-- ============================================================
-- Table: nav_proxy_cache
-- Domain: 002_mutual_funds  |  Sequence: 036
-- Source: 19_nav_proxy_cache.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nav_proxy_cache` (
  `fund_id`      INT UNSIGNED NOT NULL,
  `period`       ENUM('1M','3M','6M','1Y','3Y','5Y','ALL') NOT NULL,
  `data_json`    LONGTEXT     NOT NULL COMMENT 'JSON: [{date:"YYYY-MM-DD", nav:"X.XX"}, ...]',
  `data_points`  INT          NOT NULL DEFAULT 0,
  `cached_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `source`       ENUM('nav_history','mfapi') NOT NULL DEFAULT 'nav_history',
  PRIMARY KEY (`fund_id`, `period`),
  KEY `idx_npc_cached_at` (`cached_at`),
  CONSTRAINT `fk_npc_fund` FOREIGN KEY (`fund_id`) REFERENCES `funds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Server-side cache for NAV chart data — serves screener drawer charts faster';

-- 037_nav_download_progress.sql
-- ============================================================
-- Table: nav_download_progress
-- Domain: 002_mutual_funds  |  Sequence: 037
-- Source: 42_fix_nav_queue.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 3 versions (01_schema, 42_fix, mf_list.php inline). WINNER: superset built from all — see note in file
-- 
CREATE TABLE IF NOT EXISTS `nav_download_progress` (
  `id`                   int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fund_id`              int(10) UNSIGNED DEFAULT NULL,
  `scheme_code`          varchar(20) NOT NULL,
  `status`               enum('pending','in_progress','completed','error') NOT NULL DEFAULT 'pending',
  `from_date`            date DEFAULT NULL,
  `last_downloaded_date` date DEFAULT NULL,
  `records_saved`        int(11) NOT NULL DEFAULT 0,
  `last_attempt`         datetime DEFAULT NULL,
  `error_message`        text DEFAULT NULL,
  `updated_at`           datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_scheme` (`scheme_code`),
  KEY `idx_ndp_fund` (`fund_id`),
  KEY `idx_ndp_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 038_import_logs.sql
-- ============================================================
-- Table: import_logs
-- Domain: 002_mutual_funds  |  Sequence: 038
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `import_logs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `portfolio_id` int(10) UNSIGNED DEFAULT NULL,
  `import_type` varchar(50) NOT NULL COMMENT 'csv, cas_pdf, etc',
  `filename` varchar(255) DEFAULT NULL,
  `rows_total` int(11) NOT NULL DEFAULT 0,
  `rows_success` int(11) NOT NULL DEFAULT 0,
  `rows_failed` int(11) NOT NULL DEFAULT 0,
  `status` enum('pending','processing','done','failed') NOT NULL DEFAULT 'pending',
  `error_log` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_il_user` (`user_id`),
  KEY `idx_il_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_il_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 039_goal_fund_links.sql
-- ============================================================
-- Table: goal_fund_links
-- Domain: 002_mutual_funds  |  Sequence: 039
-- Source: 01_schema_complete.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: migrations/t139_migration.sql identical schema. Winner: base schema.
-- 
CREATE TABLE IF NOT EXISTS `goal_fund_links` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `goal_id` int(10) UNSIGNED NOT NULL,
  `fund_id` int(10) UNSIGNED DEFAULT NULL,
  `sip_id` int(10) UNSIGNED DEFAULT NULL,
  `link_type` enum('holding','sip') NOT NULL DEFAULT 'holding',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gfl_goal` (`goal_id`),
  CONSTRAINT `fk_gfl_goal` FOREIGN KEY (`goal_id`) REFERENCES `goal_buckets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 040_goal_mf_links.sql
-- ============================================================
-- Table: goal_mf_links
-- Domain: 002_mutual_funds  |  Sequence: 040
-- Source: migrations/025_goal_buckets.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `goal_mf_links` (
    `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `goal_id`      INT UNSIGNED NOT NULL,
    `portfolio_id` INT UNSIGNED NOT NULL,
    `fund_id`      INT UNSIGNED NOT NULL COMMENT 'mf_holdings.fund_id',
    `allocation_pct` DECIMAL(5,2) DEFAULT 100.00 COMMENT 'What % of this holding counts toward goal',
    `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_goal_mf` (`goal_id`, `fund_id`, `portfolio_id`),
    CONSTRAINT `fk_goal_mf_goal` FOREIGN KEY (`goal_id`) REFERENCES `goals`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 041_groww_fund_map.sql
-- ============================================================
-- Table: groww_fund_map
-- Domain: 002_mutual_funds  |  Sequence: 041
-- Source: migrations/t302_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_fund_map` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `groww_name`      VARCHAR(300) NOT NULL COMMENT 'Scheme name as Groww exports it',
    `fund_id`         INT UNSIGNED DEFAULT NULL COMMENT 'Resolved WealthDash fund id',
    `scheme_code`     VARCHAR(20)  DEFAULT NULL,
    `isin`            VARCHAR(20)  DEFAULT NULL,
    `is_confirmed`    TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_groww_name` (`groww_name`(200)),
    INDEX `idx_fund_id` (`fund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 042_groww_mf_holdings_raw.sql
-- ============================================================
-- Table: groww_mf_holdings_raw
-- Domain: 002_mutual_funds  |  Sequence: 042
-- Source: migrations/t392_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_mf_holdings_raw` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `sync_log_id`     INT UNSIGNED NOT NULL,
    `groww_folio`     VARCHAR(100) DEFAULT NULL,
    `groww_scheme_id` VARCHAR(100) DEFAULT NULL,
    `scheme_name`     VARCHAR(300) NOT NULL,
    `isin`            VARCHAR(20)  DEFAULT NULL,
    `units`           DECIMAL(14,4) DEFAULT NULL,
    `nav`             DECIMAL(12,4) DEFAULT NULL,
    `current_value`   DECIMAL(14,2) DEFAULT NULL,
    `invested_value`  DECIMAL(14,2) DEFAULT NULL,
    `fund_id`         INT UNSIGNED DEFAULT NULL COMMENT 'Resolved WD fund_id',
    `is_mapped`       TINYINT(1)   NOT NULL DEFAULT 0,
    `synced_at`       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user`  (`user_id`),
    INDEX `idx_sync`  (`sync_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 003_stocks ────────────────────────────────────────────
-- 001_stock_master.sql
-- ============================================================
-- Table: stock_master
-- Domain: 003_stocks  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_master` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `exchange` enum('NSE','BSE') NOT NULL DEFAULT 'NSE',
  `symbol` varchar(30) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `isin` varchar(20) DEFAULT NULL,
  `sector` varchar(100) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `current_price` decimal(12,4) DEFAULT NULL,
  `prev_close` decimal(12,4) DEFAULT NULL,
  `day_change_pct` decimal(8,4) DEFAULT NULL,
  `market_cap` decimal(20,2) DEFAULT NULL,
  `pe_ratio` decimal(10,4) DEFAULT NULL,
  `price_updated_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stock` (`exchange`, `symbol`),
  KEY `idx_stock_isin` (`isin`),
  KEY `idx_stock_sector` (`sector`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_stock_holdings.sql
-- ============================================================
-- Table: stock_holdings
-- Domain: 003_stocks  |  Sequence: 002
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_holdings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `stock_id` int(10) UNSIGNED NOT NULL,
  `quantity` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `avg_price` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `invested_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `current_value` decimal(16,2) NOT NULL DEFAULT 0.00,
  `gain_loss` decimal(16,2) NOT NULL DEFAULT 0.00,
  `gain_pct` decimal(8,4) NOT NULL DEFAULT 0.0000,
  `current_price` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `first_purchase_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sh` (`portfolio_id`, `stock_id`),
  KEY `idx_sh_stock` (`stock_id`),
  CONSTRAINT `fk_sh_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sh_stock` FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_stock_transactions.sql
-- ============================================================
-- Table: stock_transactions
-- Domain: 003_stocks  |  Sequence: 003
-- Source: 01_schema_complete.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: migrations/t39_migration.sql has denormalised version (user_id+symbol text, no FK, REST-style). Winner: base schema (proper FK to stock_master/portfolios)

CREATE TABLE IF NOT EXISTS `stock_transactions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `stock_id` int(10) UNSIGNED NOT NULL,
  `txn_type` enum('buy','sell','bonus','split','rights') NOT NULL DEFAULT 'buy',
  `txn_date` date NOT NULL,
  `quantity` decimal(14,4) NOT NULL,
  `price` decimal(12,4) NOT NULL,
  `brokerage` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_st_portfolio` (`portfolio_id`),
  KEY `idx_st_stock` (`stock_id`),
  KEY `idx_st_date` (`txn_date`),
  CONSTRAINT `fk_st_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_st_stock` FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_stock_dividends.sql
-- ============================================================
-- Table: stock_dividends
-- Domain: 003_stocks  |  Sequence: 004
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_dividends` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `stock_id` int(10) UNSIGNED NOT NULL,
  `ex_date` date NOT NULL,
  `dividend_per_share` decimal(10,4) NOT NULL,
  `shares_held` decimal(14,4) DEFAULT NULL,
  `total_dividend` decimal(14,2) DEFAULT NULL,
  `tds_deducted` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sd_portfolio` (`portfolio_id`),
  KEY `idx_sd_stock` (`stock_id`),
  CONSTRAINT `fk_sd_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sd_stock` FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_stock_corporate_actions.sql
-- ============================================================
-- Table: stock_corporate_actions
-- Domain: 003_stocks  |  Sequence: 005
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_corporate_actions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `stock_id` int(10) UNSIGNED NOT NULL,
  `action_type` enum('split','bonus','rights','merger','demerger') NOT NULL,
  `action_date` date NOT NULL,
  `ratio_from` decimal(10,4) DEFAULT NULL,
  `ratio_to` decimal(10,4) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sca_stock` (`stock_id`),
  CONSTRAINT `fk_sca_stock` FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_stock_price_alerts.sql
-- ============================================================
-- Table: stock_price_alerts
-- Domain: 003_stocks  |  Sequence: 006
-- Source: migrations/t344_t345_stock_alerts.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_price_alerts` (
  `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED  NOT NULL,
  `stock_id`      INT UNSIGNED  NOT NULL,
  `symbol`        VARCHAR(30)   NOT NULL,
  `company_name`  VARCHAR(200)  DEFAULT NULL,
  `alert_type`    ENUM('above','below','pct_up','pct_down') NOT NULL,
  `target_price`  DECIMAL(12,2) NOT NULL,
  `note`          VARCHAR(300)  DEFAULT NULL,
  `is_active`     TINYINT(1)    NOT NULL DEFAULT 1,
  `triggered_at`  DATETIME      DEFAULT NULL,
  `triggered_price` DECIMAL(12,2) DEFAULT NULL,
  `notify_browser` TINYINT(1)   NOT NULL DEFAULT 1,
  `notify_email`   TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_spa_user`   (`user_id`, `is_active`),
  KEY `idx_spa_stock`  (`stock_id`),
  KEY `idx_spa_symbol` (`symbol`),
  CONSTRAINT `fk_spa_user`  FOREIGN KEY (`user_id`)  REFERENCES `users`(`id`)        ON DELETE CASCADE,
  CONSTRAINT `fk_spa_stock` FOREIGN KEY (`stock_id`) REFERENCES `stock_master`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Stock price alerts — NSE/BSE target price notifications';

-- 007_stock_fundamental_history.sql
-- ============================================================
-- Table: stock_fundamental_history
-- Domain: 003_stocks  |  Sequence: 007
-- Source: migrations/t281_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_fundamental_history` (
  `id`             INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `stock_id`       INT UNSIGNED    NOT NULL,
  `symbol`         VARCHAR(30)     NOT NULL,
  `snapshot_date`  DATE            NOT NULL  COMMENT 'Date of this snapshot',
  `pe_ratio`       DECIMAL(10,4)   NULL DEFAULT NULL,
  `pb_ratio`       DECIMAL(10,4)   NULL DEFAULT NULL,
  `eps`            DECIMAL(12,4)   NULL DEFAULT NULL,
  `market_cap`     DECIMAL(22,2)   NULL DEFAULT NULL COMMENT 'Market cap in INR',
  `dividend_yield` DECIMAL(8,4)    NULL DEFAULT NULL,
  `high_52`        DECIMAL(14,4)   NULL DEFAULT NULL,
  `low_52`         DECIMAL(14,4)   NULL DEFAULT NULL,
  `price_on_date`  DECIMAL(12,4)   NULL DEFAULT NULL COMMENT 'LTP at time of snapshot',
  `source`         VARCHAR(30)     NOT NULL DEFAULT 'yahoo'
                   COMMENT 'Data source: yahoo, screener, bse',
  `created_at`     TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sfh_stock_date`  (`stock_id`, `snapshot_date`),
  KEY `idx_sfh_symbol`            (`symbol`),
  KEY `idx_sfh_date`              (`snapshot_date`),
  KEY `idx_sfh_pe`                (`pe_ratio`),
  CONSTRAINT `fk_sfh_stock` FOREIGN KEY (`stock_id`)
      REFERENCES `stock_master` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Historical snapshots of stock fundamental data';

-- 008_stock_fundamentals_cache.sql
-- ============================================================
-- Table: stock_fundamentals_cache
-- Domain: 003_stocks  |  Sequence: 008
-- Source: migrations/t432_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS stock_fundamentals_cache (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    stock_symbol VARCHAR(20) NOT NULL,
    isin VARCHAR(20),
    pe_ratio DECIMAL(10,4) DEFAULT NULL,
    pb_ratio DECIMAL(10,4) DEFAULT NULL,
    eps DECIMAL(15,4) DEFAULT NULL,
    market_cap DECIMAL(25,4) DEFAULT NULL,
    sector VARCHAR(100),
    industry VARCHAR(100),
    data_date DATE NOT NULL,
    source VARCHAR(50) DEFAULT 'NSE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_symbol_date (stock_symbol, data_date),
    INDEX idx_symbol (stock_symbol),
    INDEX idx_date (data_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 009_stock_fundamentals_history.sql
-- ============================================================
-- Table: stock_fundamentals_history
-- Domain: 003_stocks  |  Sequence: 009
-- Source: migrations/t431_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_fundamentals_history` (
    `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `stock_id`         INT UNSIGNED NOT NULL  COMMENT 'FK stock_master.id',
    `period`           VARCHAR(10)  NOT NULL  COMMENT 'e.g. Q3FY25, FY2024',
    `period_type`      ENUM('quarterly','annual') NOT NULL DEFAULT 'quarterly',
    `pe_ratio`         DECIMAL(12,4) DEFAULT NULL,
    `pb_ratio`         DECIMAL(10,4) DEFAULT NULL,
    `market_cap`       DECIMAL(22,4) DEFAULT NULL,
    `eps`              DECIMAL(12,4) DEFAULT NULL,
    `revenue`          DECIMAL(22,4) DEFAULT NULL,
    `net_profit`       DECIMAL(22,4) DEFAULT NULL,
    `roe`              DECIMAL(8,4)  DEFAULT NULL,
    `roce`             DECIMAL(8,4)  DEFAULT NULL,
    `debt_to_equity`   DECIMAL(10,4) DEFAULT NULL,
    `promoter_holding` DECIMAL(6,3)  DEFAULT NULL,
    `fii_holding`      DECIMAL(6,3)  DEFAULT NULL,
    `source`           VARCHAR(30)   DEFAULT NULL,
    `fetched_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_sfh_stock_period` (`stock_id`, `period`, `period_type`),
    INDEX `idx_sfh_stock` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 010_stock_screener_filters.sql
-- ============================================================
-- Table: stock_screener_filters
-- Domain: 003_stocks  |  Sequence: 010
-- Source: migrations/t431_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_screener_filters` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`     INT UNSIGNED NOT NULL,
    `name`        VARCHAR(100) NOT NULL,
    `filter_json` JSON         NOT NULL,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_ssf_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 011_stock_sip.sql
-- ============================================================
-- Table: stock_sip
-- Domain: 003_stocks  |  Sequence: 011
-- Source: migrations/t436_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS stock_sip (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    stock_symbol VARCHAR(20) NOT NULL,
    stock_name VARCHAR(150) NOT NULL,
    exchange VARCHAR(10) DEFAULT 'NSE',
    sip_amount DECIMAL(15,2) NOT NULL COMMENT 'Fixed INR amount per installment',
    frequency ENUM('DAILY','WEEKLY','FORTNIGHTLY','MONTHLY','QUARTERLY') DEFAULT 'MONTHLY',
    sip_day TINYINT UNSIGNED DEFAULT NULL COMMENT 'Day of month (1-28) or day of week (0-6)',
    start_date DATE NOT NULL,
    end_date DATE DEFAULT NULL COMMENT 'NULL = open-ended',
    broker VARCHAR(100),
    is_active TINYINT(1) DEFAULT 1,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_symbol (stock_symbol),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 012_stock_sip_installments.sql
-- ============================================================
-- Table: stock_sip_installments
-- Domain: 003_stocks  |  Sequence: 012
-- Source: migrations/t436_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS stock_sip_installments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sip_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    installment_date DATE NOT NULL,
    quantity DECIMAL(15,6) NOT NULL,
    price DECIMAL(15,4) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    status ENUM('PENDING','EXECUTED','FAILED','SKIPPED') DEFAULT 'PENDING',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sip_id) REFERENCES stock_sip(id) ON DELETE CASCADE,
    INDEX idx_sip_id (sip_id),
    INDEX idx_user_id (user_id),
    INDEX idx_date (installment_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 013_esop_grants.sql
-- ============================================================
-- Table: esop_grants
-- Domain: 003_stocks  |  Sequence: 013
-- Source: migrations/t117_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 31_esop_grants.sql (TODO placeholder, discarded), migrations/019_esop.sql (fewer columns). Winner: t117 (richest — company_symbol, grant_ref, PHANTOM type, currency)

CREATE TABLE IF NOT EXISTS `esop_grants` (
    `id`                     INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`           INT UNSIGNED NOT NULL,
    `company_name`           VARCHAR(200) NOT NULL,
    `company_symbol`         VARCHAR(30)  DEFAULT NULL           COMMENT 'NSE/BSE symbol if listed',
    `grant_type`             ENUM('ESOP','RSU','SAR','PHANTOM')  NOT NULL DEFAULT 'ESOP',
    `grant_date`             DATE         NOT NULL,
    `grant_ref`              VARCHAR(100) DEFAULT NULL           COMMENT 'Internal grant ID / ref',
    `total_options`          INT UNSIGNED NOT NULL               COMMENT 'Total options/units granted',
    `exercise_price`         DECIMAL(12,4) NOT NULL DEFAULT 0   COMMENT '0 for RSU',
    `currency`               CHAR(3)      NOT NULL DEFAULT 'INR',
    `vesting_start`          DATE         NOT NULL,
    `vesting_cliff_months`   SMALLINT UNSIGNED NOT NULL DEFAULT 12,
    `vesting_period_months`  SMALLINT UNSIGNED NOT NULL DEFAULT 48,
    `vesting_schedule`       VARCHAR(100) DEFAULT '1/4 per year' COMMENT 'Human-readable schedule',
    `vesting_type`           ENUM('cliff','graded','custom')    NOT NULL DEFAULT 'graded',
    `current_fmv`            DECIMAL(12,4) DEFAULT NULL         COMMENT 'FMV per share today',
    `fmv_updated_at`         DATETIME     DEFAULT NULL,
    `options_vested`         INT UNSIGNED NOT NULL DEFAULT 0,
    `options_exercised`      INT UNSIGNED NOT NULL DEFAULT 0,
    `options_lapsed`         INT UNSIGNED NOT NULL DEFAULT 0,
    `status`                 ENUM('active','fully_vested','lapsed','exercised_partial','exercised_full','cancelled')
                             NOT NULL DEFAULT 'active',
    `expiry_date`            DATE         DEFAULT NULL           COMMENT 'ESOP exercise window expiry',
    `notes`                  TEXT         DEFAULT NULL,
    `created_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_esop_portfolio` (`portfolio_id`),
    INDEX `idx_esop_status`    (`status`),
    INDEX `idx_esop_grant_date`(`grant_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 014_esop_vesting_events.sql
-- ============================================================
-- Table: esop_vesting_events
-- Domain: 003_stocks  |  Sequence: 014
-- Source: migrations/t117_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 39_esop_vesting_events.sql (TODO placeholder, discarded), migrations/019_esop.sql (fewer columns). Winner: t117 (perquisite_value, perquisite_tax columns)

CREATE TABLE IF NOT EXISTS `esop_vesting_events` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `grant_id`        INT UNSIGNED NOT NULL,
    `vest_date`       DATE         NOT NULL,
    `units_vested`    INT UNSIGNED NOT NULL,
    `fmv_on_vest`     DECIMAL(12,4) DEFAULT NULL COMMENT 'FMV per share on vest date (perquisite value)',
    `perquisite_value`DECIMAL(14,4) DEFAULT NULL COMMENT '(fmv - exercise_price) * units',
    `perquisite_tax`  DECIMAL(14,4) DEFAULT NULL COMMENT 'Estimated tax on perquisite',
    `tax_slab_pct`    DECIMAL(5,2)  DEFAULT NULL,
    `is_exercised`    TINYINT(1)    NOT NULL DEFAULT 0,
    `exercise_date`   DATE          DEFAULT NULL,
    `exercise_price`  DECIMAL(12,4) DEFAULT NULL,
    `units_exercised` INT UNSIGNED  DEFAULT 0,
    `sale_date`       DATE          DEFAULT NULL,
    `sale_price`      DECIMAL(12,4) DEFAULT NULL,
    `units_sold`      INT UNSIGNED  DEFAULT 0,
    `capital_gain`    DECIMAL(14,4) DEFAULT NULL,
    `gain_type`       ENUM('STCG','LTCG') DEFAULT NULL,
    `notes`           VARCHAR(255)  DEFAULT NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_esop_vest_grant`  (`grant_id`),
    INDEX `idx_esop_vest_date`   (`vest_date`),
    INDEX `idx_esop_vest_exercised` (`is_exercised`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 015_esop_exercise_log.sql
-- ============================================================
-- Table: esop_exercise_log
-- Domain: 003_stocks  |  Sequence: 015
-- Source: migrations/t117_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `esop_exercise_log` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `grant_id`        INT UNSIGNED NOT NULL,
    `vesting_event_id`INT UNSIGNED DEFAULT NULL,
    `exercise_date`   DATE         NOT NULL,
    `units`           INT UNSIGNED NOT NULL,
    `exercise_price`  DECIMAL(12,4) NOT NULL,
    `fmv_on_exercise` DECIMAL(12,4) DEFAULT NULL,
    `perquisite_value`DECIMAL(14,4) DEFAULT NULL COMMENT '(fmv - exercise_price) * units',
    `broker_charges`  DECIMAL(10,2) DEFAULT 0,
    `tds_deducted`    DECIMAL(12,4) DEFAULT NULL,
    `sale_date`       DATE          DEFAULT NULL,
    `sale_price`      DECIMAL(12,4) DEFAULT NULL,
    `capital_gain`    DECIMAL(14,4) DEFAULT NULL,
    `gain_type`       ENUM('STCG','LTCG') DEFAULT NULL,
    `notes`           VARCHAR(255)  DEFAULT NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_esop_ex_grant`  (`grant_id`),
    INDEX `idx_esop_ex_date`   (`exercise_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 016_screener_universe.sql
-- ============================================================
-- Table: screener_universe
-- Domain: 003_stocks  |  Sequence: 016
-- Source: migrations/t38_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS screener_universe (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    stock_symbol VARCHAR(20) NOT NULL,
    stock_name VARCHAR(200) NOT NULL,
    isin VARCHAR(20),
    exchange VARCHAR(10) DEFAULT 'NSE',
    sector VARCHAR(100),
    industry VARCHAR(100),
    market_cap DECIMAL(25,4),
    market_cap_category ENUM('LARGE','MID','SMALL','MICRO') DEFAULT NULL,
    pe_ratio DECIMAL(10,4),
    pb_ratio DECIMAL(10,4),
    eps DECIMAL(15,4),
    roe DECIMAL(8,4),
    roce DECIMAL(8,4),
    debt_to_equity DECIMAL(10,4),
    current_ratio DECIMAL(10,4),
    dividend_yield DECIMAL(8,4),
    revenue_growth_1y DECIMAL(8,4),
    profit_growth_1y DECIMAL(8,4),
    price_52w_high DECIMAL(15,4),
    price_52w_low DECIMAL(15,4),
    current_price DECIMAL(15,4),
    avg_volume_30d BIGINT UNSIGNED,
    data_date DATE NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_symbol (stock_symbol),
    INDEX idx_sector (sector),
    INDEX idx_market_cap_cat (market_cap_category),
    INDEX idx_pe (pe_ratio),
    INDEX idx_data_date (data_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 017_screener_filters.sql
-- ============================================================
-- Table: screener_filters
-- Domain: 003_stocks  |  Sequence: 017
-- Source: migrations/t38_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS screener_filters (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    filter_name VARCHAR(100) NOT NULL,
    filter_config JSON NOT NULL COMMENT 'JSON object with filter criteria',
    is_default TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 018_watchlist.sql
-- ============================================================
-- Table: watchlist
-- Domain: 003_stocks  |  Sequence: 018
-- Source: migrations/t435_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS watchlist (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    stock_symbol VARCHAR(20) NOT NULL,
    stock_name VARCHAR(150) NOT NULL,
    exchange VARCHAR(10) DEFAULT 'NSE',
    isin VARCHAR(20),
    buy_target DECIMAL(15,4) DEFAULT NULL COMMENT 'Target buy price',
    sell_target DECIMAL(15,4) DEFAULT NULL COMMENT 'Target sell / exit price',
    stop_loss DECIMAL(15,4) DEFAULT NULL,
    current_price DECIMAL(15,4) DEFAULT NULL,
    rationale TEXT COMMENT 'Why watching this stock',
    sector VARCHAR(100),
    tags VARCHAR(255) COMMENT 'comma-separated custom tags',
    alert_on_buy_target TINYINT(1) DEFAULT 1,
    alert_on_sell_target TINYINT(1) DEFAULT 1,
    alert_on_stop_loss TINYINT(1) DEFAULT 1,
    notes TEXT,
    added_date DATE NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_user_symbol (user_id, stock_symbol),
    INDEX idx_user_id (user_id),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 019_watchlist_price_history.sql
-- ============================================================
-- Table: watchlist_price_history
-- Domain: 003_stocks  |  Sequence: 019
-- Source: migrations/t435_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS watchlist_price_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    watchlist_id BIGINT UNSIGNED NOT NULL,
    price DECIMAL(15,4) NOT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (watchlist_id) REFERENCES watchlist(id) ON DELETE CASCADE,
    INDEX idx_watchlist_id (watchlist_id),
    INDEX idx_recorded_at (recorded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 020_international_stocks.sql
-- ============================================================
-- Table: international_stocks
-- Domain: 003_stocks  |  Sequence: 020
-- Source: migrations/t121_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS international_stocks (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    ticker VARCHAR(20) NOT NULL,
    stock_name VARCHAR(200) NOT NULL,
    exchange VARCHAR(20) NOT NULL COMMENT 'NYSE/NASDAQ/LSE/etc',
    country VARCHAR(5) DEFAULT 'US',
    currency VARCHAR(5) DEFAULT 'USD',
    quantity DECIMAL(15,6) NOT NULL COMMENT 'fractional shares allowed',
    avg_buy_price_foreign DECIMAL(15,4) NOT NULL COMMENT 'in foreign currency',
    avg_buy_price_inr DECIMAL(15,4) NOT NULL COMMENT 'INR at time of purchase',
    current_price_foreign DECIMAL(15,4) DEFAULT NULL,
    current_price_inr DECIMAL(15,4) DEFAULT NULL,
    broker_platform VARCHAR(100) COMMENT 'Vested/Indmoney/Stockal/etc',
    sector VARCHAR(100),
    notes TEXT,
    is_active TINYINT(1) DEFAULT 1,
    last_refreshed TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_ticker (ticker),
    INDEX idx_exchange (exchange),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 021_us_stock_master.sql
-- ============================================================
-- Table: us_stock_master
-- Domain: 003_stocks  |  Sequence: 021
-- Source: migrations/t456_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `us_stock_master` (
    `id`                  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `symbol`              VARCHAR(20)  NOT NULL,
    `exchange`            ENUM('NYSE','NASDAQ','AMEX','OTC') NOT NULL DEFAULT 'NASDAQ',
    `company_name`        VARCHAR(200) DEFAULT NULL,
    `isin`                VARCHAR(20)  DEFAULT NULL,
    `sector`              VARCHAR(100) DEFAULT NULL,
    `industry`            VARCHAR(100) DEFAULT NULL,
    `country`             VARCHAR(50)  DEFAULT 'US',
    `currency`            VARCHAR(5)   NOT NULL DEFAULT 'USD',
    `latest_price_usd`    DECIMAL(14,4) DEFAULT 0,
    `latest_price_inr`    DECIMAL(14,4) DEFAULT 0,
    `pe_ratio`            DECIMAL(12,4) DEFAULT NULL,
    `pb_ratio`            DECIMAL(10,4) DEFAULT NULL,
    `eps_ttm`             DECIMAL(12,4) DEFAULT NULL,
    `market_cap_usd`      DECIMAL(22,4) DEFAULT NULL,
    `high_52_usd`         DECIMAL(14,4) DEFAULT NULL,
    `low_52_usd`          DECIMAL(14,4) DEFAULT NULL,
    `dividend_yield`      DECIMAL(8,4)  DEFAULT NULL,
    `beta`                DECIMAL(8,4)  DEFAULT NULL,
    `price_change_24h_pct`DECIMAL(8,4)  DEFAULT NULL,
    `price_updated_at`    DATETIME      DEFAULT NULL,
    `fundamentals_updated_at` DATETIME  DEFAULT NULL,
    `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_usm_symbol` (`symbol`, `exchange`),
    INDEX `idx_usm_symbol` (`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 022_us_stock_holdings.sql
-- ============================================================
-- Table: us_stock_holdings
-- Domain: 003_stocks  |  Sequence: 022
-- Source: migrations/t456_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `us_stock_holdings` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `stock_id`        INT UNSIGNED NOT NULL  COMMENT 'FK us_stock_master.id',
    `quantity`        DECIMAL(16,6) NOT NULL DEFAULT 0  COMMENT 'Fractional shares supported',
    `avg_buy_price_usd`DECIMAL(14,4) NOT NULL DEFAULT 0,
    `avg_buy_price_inr`DECIMAL(14,4) DEFAULT NULL       COMMENT 'INR equivalent at time of buy',
    `total_invested_usd`DECIMAL(18,4) DEFAULT 0,
    `total_invested_inr`DECIMAL(18,4) DEFAULT 0,
    `current_value_usd` DECIMAL(18,4) DEFAULT 0,
    `current_value_inr` DECIMAL(18,4) DEFAULT 0,
    `broker`           VARCHAR(50)  DEFAULT NULL         COMMENT 'Groww, Vested, INDmoney, etc.',
    `account_type`     ENUM('LRS','GIFT_CITY','DOMESTIC_BROKER','OTHER') DEFAULT 'LRS',
    `first_buy_date`   DATE DEFAULT NULL,
    `notes`            TEXT DEFAULT NULL,
    `created_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_ush_portfolio_stock` (`portfolio_id`, `stock_id`),
    INDEX `idx_ush_portfolio` (`portfolio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 023_us_stock_transactions.sql
-- ============================================================
-- Table: us_stock_transactions
-- Domain: 003_stocks  |  Sequence: 023
-- Source: migrations/t456_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `us_stock_transactions` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `stock_id`        INT UNSIGNED NOT NULL,
    `type`            ENUM('buy','sell','dividend','transfer_in','transfer_out') NOT NULL DEFAULT 'buy',
    `quantity`        DECIMAL(16,6) NOT NULL,
    `price_usd`       DECIMAL(14,4) NOT NULL DEFAULT 0,
    `price_inr`       DECIMAL(14,4) DEFAULT NULL,
    `total_usd`       DECIMAL(18,4) DEFAULT 0,
    `total_inr`       DECIMAL(18,4) DEFAULT 0,
    `usd_inr_rate`    DECIMAL(10,4) DEFAULT NULL         COMMENT 'Exchange rate at transaction time',
    `fee_usd`         DECIMAL(10,4) DEFAULT 0,
    `broker`          VARCHAR(50)   DEFAULT NULL,
    `account_type`    ENUM('LRS','GIFT_CITY','DOMESTIC_BROKER','OTHER') DEFAULT 'LRS',
    `txn_date`        DATE          NOT NULL,
    `notes`           TEXT          DEFAULT NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_ust_portfolio` (`portfolio_id`),
    INDEX `idx_ust_stock`     (`stock_id`),
    INDEX `idx_ust_date`      (`txn_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 024_goal_stock_links.sql
-- ============================================================
-- Table: goal_stock_links
-- Domain: 003_stocks  |  Sequence: 024
-- Source: migrations/025_goal_buckets.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `goal_stock_links` (
    `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `goal_id`      INT UNSIGNED NOT NULL,
    `portfolio_id` INT UNSIGNED NOT NULL,
    `stock_id`     INT UNSIGNED NOT NULL,
    `allocation_pct` DECIMAL(5,2) DEFAULT 100.00,
    `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_goal_stock` (`goal_id`, `stock_id`, `portfolio_id`),
    CONSTRAINT `fk_goal_stock_goal` FOREIGN KEY (`goal_id`) REFERENCES `goals`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 025_groww_stock_holdings_raw.sql
-- ============================================================
-- Table: groww_stock_holdings_raw
-- Domain: 003_stocks  |  Sequence: 025
-- Source: migrations/t392_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_stock_holdings_raw` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `sync_log_id`     INT UNSIGNED NOT NULL,
    `symbol`          VARCHAR(30)  NOT NULL,
    `company_name`    VARCHAR(200) DEFAULT NULL,
    `exchange`        VARCHAR(10)  DEFAULT 'NSE',
    `isin`            VARCHAR(20)  DEFAULT NULL,
    `quantity`        DECIMAL(14,4) DEFAULT NULL,
    `avg_price`       DECIMAL(12,4) DEFAULT NULL,
    `ltp`             DECIMAL(12,4) DEFAULT NULL,
    `invested_value`  DECIMAL(14,2) DEFAULT NULL,
    `current_value`   DECIMAL(14,2) DEFAULT NULL,
    `pnl`             DECIMAL(14,2) DEFAULT NULL,
    `synced_at`       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user`  (`user_id`),
    INDEX `idx_sync`  (`sync_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 004_fd_rd_savings ─────────────────────────────────────
-- 001_bank_accounts.sql
-- ============================================================
-- Table: bank_accounts
-- Domain: 004_fd_rd_savings  |  Sequence: 001
-- Source: migrations/t43_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 01_schema_complete.sql (older, fewer cols). Winner: t43 (user_id, branch, nickname, more account types)

CREATE TABLE IF NOT EXISTS `bank_accounts` (
    `id`               INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `portfolio_id`     INT UNSIGNED     NOT NULL,
    `user_id`          INT UNSIGNED     NOT NULL,
    `bank_name`        VARCHAR(100)     NOT NULL,
    `branch`           VARCHAR(120)     DEFAULT NULL,
    `account_type`     ENUM('savings','current','salary','nre','nro','fcnr','rd','cc') NOT NULL DEFAULT 'savings',
    `account_number`   VARCHAR(30)      DEFAULT NULL COMMENT 'Last 4 digits or masked',
    `ifsc_code`        VARCHAR(15)      DEFAULT NULL,
    `nickname`         VARCHAR(60)      DEFAULT NULL,
    `currency`         VARCHAR(5)       NOT NULL DEFAULT 'INR',
    `opening_balance`  DECIMAL(15,2)    NOT NULL DEFAULT 0.00,
    `current_balance`  DECIMAL(15,2)    NOT NULL DEFAULT 0.00,
    `balance_date`     DATE             DEFAULT NULL COMMENT 'As-of date for current_balance',
    `interest_rate`    DECIMAL(6,3)     DEFAULT NULL COMMENT 'Savings/RD rate p.a.',
    `rd_amount`        DECIMAL(12,2)    DEFAULT NULL COMMENT 'Monthly RD installment',
    `rd_tenure_months` SMALLINT         DEFAULT NULL,
    `rd_start_date`    DATE             DEFAULT NULL,
    `rd_maturity_date` DATE             DEFAULT NULL,
    `is_joint`         TINYINT(1)       NOT NULL DEFAULT 0,
    `joint_holder`     VARCHAR(100)     DEFAULT NULL,
    `nominee`          VARCHAR(100)     DEFAULT NULL,
    `linked_to_demat`  TINYINT(1)       NOT NULL DEFAULT 0,
    `is_primary`       TINYINT(1)       NOT NULL DEFAULT 0,
    `notes`            TEXT             DEFAULT NULL,
    `status`           ENUM('active','closed','dormant') NOT NULL DEFAULT 'active',
    `created_at`       TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_ba_portfolio` (`portfolio_id`),
    KEY `idx_ba_user`      (`user_id`),
    KEY `idx_ba_status`    (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_bank_balance_history.sql
-- ============================================================
-- Table: bank_balance_history
-- Domain: 004_fd_rd_savings  |  Sequence: 002
-- Source: migrations/t43_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 01_schema_complete.sql also defines this. Winner: t43 (source same as bank_accounts, consistent)

CREATE TABLE IF NOT EXISTS `bank_balance_history` (
    `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `account_id`  INT UNSIGNED  NOT NULL,
    `snap_date`   DATE          NOT NULL,
    `balance`     DECIMAL(15,2) NOT NULL,
    `created_at`  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_bbh` (`account_id`, `snap_date`),
    KEY `idx_bbh_account` (`account_id`),
    CONSTRAINT `fk_bbh_account` FOREIGN KEY (`account_id`) REFERENCES `bank_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_bank_transactions.sql
-- ============================================================
-- Table: bank_transactions
-- Domain: 004_fd_rd_savings  |  Sequence: 003
-- Source: migrations/t43_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `bank_transactions` (
    `id`             INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `account_id`     INT UNSIGNED     NOT NULL,
    `user_id`        INT UNSIGNED     NOT NULL,
    `txn_date`       DATE             NOT NULL,
    `value_date`     DATE             DEFAULT NULL,
    `type`           ENUM('credit','debit') NOT NULL,
    `category`       VARCHAR(50)      DEFAULT NULL
        COMMENT 'salary, rent, emi, utilities, transfer, fd_maturity, interest, other',
    `amount`         DECIMAL(15,2)    NOT NULL,
    `balance_after`  DECIMAL(15,2)    DEFAULT NULL,
    `description`    VARCHAR(255)     DEFAULT NULL,
    `ref_number`     VARCHAR(60)      DEFAULT NULL,
    `created_at`     TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bt_account`  (`account_id`),
    KEY `idx_bt_user`     (`user_id`),
    KEY `idx_bt_date`     (`txn_date`),
    CONSTRAINT `fk_bt_account` FOREIGN KEY (`account_id`) REFERENCES `bank_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_fd_accounts.sql
-- ============================================================
-- Table: fd_accounts
-- Domain: 004_fd_rd_savings  |  Sequence: 004
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `fd_accounts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `fd_type` enum('cumulative','non_cumulative','tax_saver','flexi','senior_citizen') NOT NULL DEFAULT 'cumulative',
  `principal_amount` decimal(14,2) NOT NULL,
  `interest_rate` decimal(6,3) NOT NULL,
  `compounding` enum('monthly','quarterly','half_yearly','yearly','at_maturity') NOT NULL DEFAULT 'quarterly',
  `start_date` date NOT NULL,
  `maturity_date` date NOT NULL,
  `maturity_amount` decimal(14,2) DEFAULT NULL,
  `interest_earned` decimal(14,2) NOT NULL DEFAULT 0.00,
  `status` enum('active','matured','broken','renewed') NOT NULL DEFAULT 'active',
  `auto_renew` tinyint(1) NOT NULL DEFAULT 0,
  `folio_number` varchar(50) DEFAULT NULL,
  `nominee` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fd_portfolio` (`portfolio_id`),
  KEY `idx_fd_maturity` (`maturity_date`),
  CONSTRAINT `fk_fd_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_fd_interest_accruals.sql
-- ============================================================
-- Table: fd_interest_accruals
-- Domain: 004_fd_rd_savings  |  Sequence: 005
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `fd_interest_accruals` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fd_id` int(10) UNSIGNED NOT NULL,
  `accrual_date` date NOT NULL,
  `interest_amount` decimal(14,2) NOT NULL,
  `cumulative_interest` decimal(14,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fdia_fd` (`fd_id`),
  CONSTRAINT `fk_fdia_fd` FOREIGN KEY (`fd_id`) REFERENCES `fd_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_fd_interest_log.sql
-- ============================================================
-- Table: fd_interest_log
-- Domain: 004_fd_rd_savings  |  Sequence: 006
-- Source: 41_pending_tasks.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fd_interest_log (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    fd_id        INT UNSIGNED NOT NULL,
    credit_date  DATE NOT NULL,
    interest_earned DECIMAL(12,2) NOT NULL,
    tds_deducted DECIMAL(10,2) DEFAULT 0,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_date (credit_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 007_fd_maturity_alerts.sql
-- ============================================================
-- Table: fd_maturity_alerts
-- Domain: 004_fd_rd_savings  |  Sequence: 007
-- Source: 41_pending_tasks.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fd_maturity_alerts (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    fd_id        INT UNSIGNED NOT NULL,
    alert_days   TINYINT UNSIGNED NOT NULL,
    is_sent      TINYINT(1) NOT NULL DEFAULT 0,
    sent_at      DATETIME DEFAULT NULL,
    is_dismissed TINYINT(1) NOT NULL DEFAULT 0,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_fd_days (fd_id, alert_days),
    INDEX idx_user (user_id),
    INDEX idx_sent (is_sent)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 008_fd_market_rates.sql
-- ============================================================
-- Table: fd_market_rates
-- Domain: 004_fd_rd_savings  |  Sequence: 008
-- Source: 41_pending_tasks.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fd_market_rates (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    bank_name      VARCHAR(80)  NOT NULL,
    tenure_label   VARCHAR(30)  NOT NULL,
    rate_general   DECIMAL(5,2) NOT NULL,
    rate_senior    DECIMAL(5,2) NOT NULL,
    effective_date DATE DEFAULT (CURDATE()),
    source_url     VARCHAR(300) DEFAULT NULL,
    updated_at     DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 009_fd_rate_history.sql
-- ============================================================
-- Table: fd_rate_history
-- Domain: 004_fd_rd_savings  |  Sequence: 009
-- Source: migrations/42_fd_rate_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fd_rate_history (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    bank_name       VARCHAR(120)  NOT NULL,
    tenure_months   SMALLINT UNSIGNED NOT NULL,
    rate_regular    DECIMAL(5,2) NOT NULL,
    rate_senior     DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    effective_date  DATE         NOT NULL,
    recorded_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_bank_tenure (bank_name, tenure_months),
    INDEX idx_date        (effective_date),
    INDEX idx_recorded    (recorded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='t421 — FD Rate Tracker history';

-- 010_fd_bank_rates.sql
-- ============================================================
-- Table: fd_bank_rates
-- Domain: 004_fd_rd_savings  |  Sequence: 010
-- Source: migrations/42_fd_rate_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fd_bank_rates (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    bank_name       VARCHAR(120)  NOT NULL,
    bank_type       ENUM('public','private_large','private','small_finance','government','cooperative')
                    NOT NULL DEFAULT 'private',
    tenure_months   SMALLINT UNSIGNED NOT NULL,
    rate_regular    DECIMAL(5,2) NOT NULL,
    rate_senior     DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    min_amount      INT UNSIGNED NOT NULL DEFAULT 1000,
    is_special      TINYINT(1)   NOT NULL DEFAULT 0,
    is_active       TINYINT(1)   NOT NULL DEFAULT 1,
    effective_date  DATE         NOT NULL,
    source_url      VARCHAR(300) DEFAULT NULL,
    notes           VARCHAR(200) DEFAULT NULL,
    updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_bank_tenure (bank_name, tenure_months),
    INDEX idx_tenure      (tenure_months),
    INDEX idx_bank_type   (bank_type),
    INDEX idx_rate_reg    (rate_regular DESC),
    INDEX idx_effective   (effective_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='t421 — FD Rate Tracker: market rates per bank per tenure';

-- 011_savings_accounts.sql
-- ============================================================
-- Table: savings_accounts
-- Domain: 004_fd_rd_savings  |  Sequence: 011
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `savings_accounts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_number` varchar(30) DEFAULT NULL,
  `account_type` varchar(20) NOT NULL DEFAULT 'savings',
  `current_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance_date` date DEFAULT NULL,
  `interest_rate` decimal(5,3) NOT NULL DEFAULT 4.000,
  `annual_interest_earned` decimal(12,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sa_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_sa_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 012_savings_interest.sql
-- ============================================================
-- Table: savings_interest
-- Domain: 004_fd_rd_savings  |  Sequence: 012
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `savings_interest` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `account_id` int(10) UNSIGNED NOT NULL,
  `interest_date` date NOT NULL,
  `interest_amount` decimal(12,2) NOT NULL,
  `balance_after` decimal(14,2) DEFAULT NULL,
  `interest_fy` varchar(10) NOT NULL COMMENT 'e.g. 2024-25',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_si_acct_date` (`account_id`, `interest_date`),
  CONSTRAINT `fk_si_account` FOREIGN KEY (`account_id`) REFERENCES `savings_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 013_savings_interest_log.sql
-- ============================================================
-- Table: savings_interest_log
-- Domain: 004_fd_rd_savings  |  Sequence: 013
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `savings_interest_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `account_id` int(10) UNSIGNED NOT NULL,
  `log_date` date NOT NULL,
  `balance` decimal(14,2) NOT NULL,
  `interest_earned` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sil_account` (`account_id`),
  CONSTRAINT `fk_sil_sa` FOREIGN KEY (`account_id`) REFERENCES `savings_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 014_rd_accounts.sql
-- ============================================================
-- Table: rd_accounts
-- Domain: 004_fd_rd_savings  |  Sequence: 014
-- Source: migrations/t45_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `rd_accounts` (
  `id`                  int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`        int(10) UNSIGNED NOT NULL,
  `bank_name`           varchar(100)     NOT NULL,
  `account_number`      varchar(30)      DEFAULT NULL,
  `monthly_installment` decimal(12,2)    NOT NULL,
  `interest_rate`       decimal(5,2)     NOT NULL,
  `tenure_months`       smallint         NOT NULL,
  `start_date`          date             NOT NULL,
  `maturity_date`       date             NOT NULL,
  `maturity_amount`     decimal(16,2)    DEFAULT NULL,
  `status`              enum('active','matured','closed') NOT NULL DEFAULT 'active',
  `nominee`             varchar(100)     DEFAULT NULL,
  `notes`               varchar(255)     DEFAULT NULL,
  `created_at`          datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`          datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_rd_portfolio` (`portfolio_id`),
  KEY `idx_rd_status`    (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 015_rd_installments.sql
-- ============================================================
-- Table: rd_installments
-- Domain: 004_fd_rd_savings  |  Sequence: 015
-- Source: migrations/t45_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `rd_installments` (
  `id`             int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `rd_account_id`  int(10) UNSIGNED NOT NULL,
  `due_date`       date             NOT NULL,
  `paid_date`      date             DEFAULT NULL,
  `amount`         decimal(12,2)    NOT NULL,
  `status`         enum('paid','pending','missed') NOT NULL DEFAULT 'pending',
  `created_at`     datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rd_due` (`rd_account_id`,`due_date`),
  KEY `idx_rdi_account` (`rd_account_id`),
  CONSTRAINT `fk_rdi_account` FOREIGN KEY (`rd_account_id`) REFERENCES `rd_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 016_sweep_fds.sql
-- ============================================================
-- Table: sweep_fds
-- Domain: 004_fd_rd_savings  |  Sequence: 016
-- Source: migrations/t422_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `sweep_fds` (
  `id`                  int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`        int(10) UNSIGNED NOT NULL,
  `bank_name`           varchar(100)     NOT NULL,
  `savings_account_id`  int(10) UNSIGNED DEFAULT NULL,
  `principal`           decimal(14,2)    NOT NULL,
  `interest_rate`       decimal(5,2)     NOT NULL,
  `sweep_date`          date             NOT NULL,
  `maturity_date`       date             NOT NULL,
  `sweep_threshold`     decimal(14,2)    DEFAULT NULL COMMENT 'Savings balance at which sweep triggered',
  `auto_reverse`        tinyint(1)       NOT NULL DEFAULT 1 COMMENT '1=auto-broken when balance low',
  `status`              enum('active','matured','broken','renewed') NOT NULL DEFAULT 'active',
  `current_value`       decimal(14,2)    DEFAULT NULL,
  `amount_received`     decimal(14,2)    DEFAULT NULL,
  `broken_date`         date             DEFAULT NULL,
  `notes`               varchar(255)     DEFAULT NULL,
  `created_at`          datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`          datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_swp_portfolio` (`portfolio_id`),
  KEY `idx_swp_status`    (`status`),
  KEY `idx_swp_maturity`  (`maturity_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 005_gold ──────────────────────────────────────────────
-- 001_sgb_holdings.sql
-- ============================================================
-- Table: sgb_holdings
-- Domain: 005_gold  |  Sequence: 001
-- Source: migrations/t113_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: 4-WAY CONFLICT: 29_sgb_holdings.sql, 017_sgb.sql, t113, t394. Winner: t113 (isin, nse_symbol, richest schema)

CREATE TABLE IF NOT EXISTS `sgb_holdings` (
    `id`                      INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`            INT UNSIGNED NOT NULL,
    `series_name`             VARCHAR(100) NOT NULL              COMMENT 'e.g. SGB 2019-20 Series II',
    `tranche_code`            VARCHAR(30)  DEFAULT NULL,
    `isin`                    VARCHAR(20)  DEFAULT NULL,
    `nse_symbol`              VARCHAR(30)  DEFAULT NULL,
    `issue_date`              DATE         NOT NULL,
    `maturity_date`           DATE         NOT NULL              COMMENT '8 years from issue_date',
    `units`                   DECIMAL(12,4) NOT NULL,
    `issue_price`             DECIMAL(10,2) NOT NULL             COMMENT 'INR per gram at issue',
    `total_invested`          DECIMAL(14,2) NOT NULL,
    `coupon_rate`             DECIMAL(5,2) NOT NULL DEFAULT 2.50 COMMENT '% p.a. on issue price',
    `interest_payout`         ENUM('semi-annual','annual') NOT NULL DEFAULT 'semi-annual',
    `last_interest_date`      DATE         DEFAULT NULL,
    `next_interest_date`      DATE         DEFAULT NULL,
    `total_interest_received` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    `current_nav`             DECIMAL(10,2) DEFAULT NULL         COMMENT 'Gold price per gram today',
    `current_value`           DECIMAL(14,2) DEFAULT NULL,
    `nav_updated_at`          DATETIME     DEFAULT NULL,
    `nse_price`               DECIMAL(10,2) DEFAULT NULL         COMMENT 'Exchange-traded price',
    `nse_updated_at`          DATETIME     DEFAULT NULL,
    `tax_exemption`           TINYINT(1)   NOT NULL DEFAULT 1    COMMENT '1=LTCG exempt on maturity',
    `is_active`               TINYINT(1)   NOT NULL DEFAULT 1,
    `notes`                   TEXT         DEFAULT NULL,
    `created_at`              DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`              DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_sgb_portfolio`  (`portfolio_id`),
    INDEX `idx_sgb_maturity`   (`maturity_date`),
    INDEX `idx_sgb_series`     (`series_name`),
    INDEX `idx_sgb_active`     (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_sgb_interest_log.sql
-- ============================================================
-- Table: sgb_interest_log
-- Domain: 005_gold  |  Sequence: 002
-- Source: migrations/t113_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: 4-WAY CONFLICT same files. Winner: t113

CREATE TABLE IF NOT EXISTS `sgb_interest_log` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `sgb_id`       INT UNSIGNED NOT NULL,
    `portfolio_id` INT UNSIGNED NOT NULL,
    `payout_date`  DATE         NOT NULL,
    `period`       VARCHAR(20)  DEFAULT NULL COMMENT 'e.g. HY1 2024-25',
    `units`        DECIMAL(12,4) NOT NULL,
    `rate_pct`     DECIMAL(5,2) NOT NULL,
    `amount`       DECIMAL(12,2) NOT NULL,
    `notes`        VARCHAR(255) DEFAULT NULL,
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_sgb_interest_sgb`  (`sgb_id`),
    INDEX `idx_sgb_interest_port` (`portfolio_id`),
    INDEX `idx_sgb_interest_date` (`payout_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_gold_price_cache.sql
-- ============================================================
-- Table: gold_price_cache
-- Domain: 005_gold  |  Sequence: 003
-- Source: migrations/t113_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: 29_sgb_holdings.sql, t113, t394. Winner: t113

CREATE TABLE IF NOT EXISTS `gold_price_cache` (
    `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `source`         VARCHAR(30)  NOT NULL DEFAULT 'ibja',
    `price_24k_gram` DECIMAL(10,2) NOT NULL,
    `price_22k_gram` DECIMAL(10,2) DEFAULT NULL,
    `price_18k_gram` DECIMAL(10,2) DEFAULT NULL,
    `fetched_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `date_for`       DATE         NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_gold_cache_date` (`date_for`, `source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_gold_holdings.sql
-- ============================================================
-- Table: gold_holdings
-- Domain: 005_gold  |  Sequence: 004
-- Source: migrations/t114_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS gold_holdings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    gold_type ENUM('PHYSICAL','DIGITAL','ETF','FUND') NOT NULL,
    sub_type VARCHAR(50) COMMENT 'coins/bar/jewellery for physical; mmtc/augmont for digital; ticker for ETF',
    name VARCHAR(150) NOT NULL,
    quantity DECIMAL(15,4) NOT NULL COMMENT 'grams for physical/digital, units for ETF/fund',
    buy_price DECIMAL(15,4) NOT NULL COMMENT 'per gram or per unit',
    buy_date DATE NOT NULL,
    making_charges DECIMAL(10,2) DEFAULT 0.00 COMMENT 'for jewellery only',
    purity VARCHAR(10) DEFAULT '24K' COMMENT '24K/22K/18K',
    folio_number VARCHAR(50) DEFAULT NULL COMMENT 'for ETF/fund',
    dp_id VARCHAR(50) DEFAULT NULL COMMENT 'for ETF in demat',
    custodian VARCHAR(100) DEFAULT NULL COMMENT 'for digital gold',
    notes TEXT,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_gold_type (gold_type),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_gold_transactions.sql
-- ============================================================
-- Table: gold_transactions
-- Domain: 005_gold  |  Sequence: 005
-- Source: migrations/t114_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS gold_transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    holding_id BIGINT UNSIGNED NOT NULL,
    transaction_type ENUM('BUY','SELL','SIP') NOT NULL,
    quantity DECIMAL(15,4) NOT NULL,
    price DECIMAL(15,4) NOT NULL,
    transaction_date DATE NOT NULL,
    charges DECIMAL(10,2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (holding_id) REFERENCES gold_holdings(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_holding_id (holding_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_physical_gold.sql
-- ============================================================
-- Table: physical_gold
-- Domain: 005_gold  |  Sequence: 006
-- Source: migrations/t466_real_estate_physical_gold.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `physical_gold` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`    int(10) UNSIGNED NOT NULL,
  `description`     varchar(150) NOT NULL COMMENT 'e.g. 22K Necklace, Gold Coin 10g',
  `gold_type`       enum('jewellery','coin','bar','biscuit','other') NOT NULL DEFAULT 'jewellery',
  `purity_karat`    tinyint(3) UNSIGNED NOT NULL DEFAULT 22 COMMENT '14,18,22,24',
  `weight_grams`    decimal(10,3) NOT NULL COMMENT 'Net gold weight in grams',
  `purchase_date`   date DEFAULT NULL,
  `purchase_price`  decimal(14,2) DEFAULT NULL COMMENT 'Total cost paid',
  `purchase_rate`   decimal(10,2) DEFAULT NULL COMMENT 'Rate per gram at purchase',
  `current_rate`    decimal(10,2) DEFAULT NULL COMMENT 'Current rate per gram (manual update)',
  `current_value`   decimal(14,2) DEFAULT NULL COMMENT 'Computed or manual; weight * current_rate',
  `storage`         enum('home','locker','bank','other') NOT NULL DEFAULT 'home',
  `is_insured`      tinyint(1) NOT NULL DEFAULT 0,
  `notes`           text DEFAULT NULL,
  `is_active`       tinyint(1) NOT NULL DEFAULT 1,
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`      datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pg_portfolio` (`portfolio_id`),
  KEY `idx_pg_active`    (`is_active`),
  CONSTRAINT `fk_pg_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='t465: Physical gold and jewelry holdings';

-- ── 006_bonds_govt_securities ─────────────────────────────
-- 001_po_schemes.sql
-- ============================================================
-- Table: po_schemes
-- Domain: 006_bonds_govt_securities  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `po_schemes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `scheme_type` enum('PPF','NSC','SCSS','MIS','SSY','KVP','TD','RD','NPS_APY') NOT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `post_office` varchar(100) DEFAULT NULL,
  `principal_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `current_value` decimal(14,2) NOT NULL DEFAULT 0.00,
  `interest_rate` decimal(6,3) NOT NULL DEFAULT 0.000,
  `start_date` date NOT NULL,
  `maturity_date` date DEFAULT NULL,
  `maturity_amount` decimal(14,2) DEFAULT NULL,
  `interest_earned` decimal(14,2) NOT NULL DEFAULT 0.00,
  `annual_deposit` decimal(14,2) DEFAULT NULL,
  `status` enum('active','matured','closed','extended') NOT NULL DEFAULT 'active',
  `nominee` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'JSON: sub-tenures, rates etc' CHECK (json_valid(`meta`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_po_portfolio` (`portfolio_id`),
  KEY `idx_po_type` (`scheme_type`),
  CONSTRAINT `fk_po_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_po_payout_log.sql
-- ============================================================
-- Table: po_payout_log
-- Domain: 006_bonds_govt_securities  |  Sequence: 002
-- Source: migrations/t206_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t15 (fewer cols). Winner: t206 (tds_tan, payout_status)

CREATE TABLE IF NOT EXISTS `po_payout_log` (
  `id`            int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `po_scheme_id`  int(10) UNSIGNED NOT NULL,
  `payout_date`   date             NOT NULL COMMENT 'Expected payout date (1st of month/quarter)',
  `payout_type`   enum('monthly','quarterly') NOT NULL DEFAULT 'monthly',
  `amount`        decimal(12,2)    NOT NULL DEFAULT 0.00,
  `tds_deducted`  decimal(10,2)    NOT NULL DEFAULT 0.00,
  `tds_tan`       varchar(20)      DEFAULT NULL COMMENT 'TAN of deductor (SCSS TDS)',
  `is_received`   tinyint(1)       NOT NULL DEFAULT 0,
  `notes`         varchar(255)     DEFAULT NULL,
  `created_at`    datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`    datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ppl_scheme_date` (`po_scheme_id`, `payout_date`),
  KEY `idx_ppl_scheme`   (`po_scheme_id`),
  KEY `idx_ppl_date`     (`payout_date`),
  KEY `idx_ppl_received` (`is_received`),
  CONSTRAINT `fk_ppl_scheme`
    FOREIGN KEY (`po_scheme_id`) REFERENCES `po_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_nsc_80c_log.sql
-- ============================================================
-- Table: nsc_80c_log
-- Domain: 006_bonds_govt_securities  |  Sequence: 003
-- Source: migrations/t205_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t48 (no comments). Winner: t205 (richer with field comments)

CREATE TABLE IF NOT EXISTS `nsc_80c_log` (
  `id`             int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nsc_scheme_id`  int(10) UNSIGNED NOT NULL COMMENT 'FK → po_schemes.id (scheme_type=NSC)',
  `fy`             varchar(9)       NOT NULL COMMENT 'e.g. 2024-2025',
  `amount`         decimal(12,2)    NOT NULL DEFAULT 0.00 COMMENT 'Interest eligible for 80C this FY',
  `declared_80c`   tinyint(1)       NOT NULL DEFAULT 0   COMMENT '1 = user has declared in ITR',
  `notes`          varchar(255)     DEFAULT NULL,
  `created_at`     datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`     datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nsc_log_scheme_fy` (`nsc_scheme_id`, `fy`),
  KEY `idx_nsc_log_scheme` (`nsc_scheme_id`),
  CONSTRAINT `fk_nsc_log_scheme`
    FOREIGN KEY (`nsc_scheme_id`) REFERENCES `po_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_bonds.sql
-- ============================================================
-- Table: bonds
-- Domain: 006_bonds_govt_securities  |  Sequence: 004
-- Source: migrations/t116_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS bonds (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    bond_type ENUM('NCD','BOND','DEBENTURE','COMMERCIAL_PAPER') NOT NULL,
    listing_type ENUM('LISTED','UNLISTED') NOT NULL DEFAULT 'LISTED',
    issuer_name VARCHAR(200) NOT NULL,
    isin VARCHAR(20),
    series VARCHAR(50),
    face_value DECIMAL(15,2) NOT NULL DEFAULT 1000.00,
    quantity INT UNSIGNED NOT NULL,
    purchase_price DECIMAL(15,4) NOT NULL,
    purchase_date DATE NOT NULL,
    maturity_date DATE NOT NULL,
    coupon_rate DECIMAL(8,4) NOT NULL COMMENT 'Annual interest rate %',
    coupon_frequency ENUM('MONTHLY','QUARTERLY','SEMI_ANNUAL','ANNUAL','CUMULATIVE','ON_MATURITY') DEFAULT 'ANNUAL',
    credit_rating VARCHAR(20) COMMENT 'AAA/AA+/etc',
    rating_agency VARCHAR(50),
    secured TINYINT(1) DEFAULT 1,
    broker VARCHAR(100),
    dp_id VARCHAR(50),
    redemption_type ENUM('BULLET','CALLABLE','PUTTABLE','STEP_UP') DEFAULT 'BULLET',
    notes TEXT,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_bond_type (bond_type),
    INDEX idx_listing (listing_type),
    INDEX idx_maturity (maturity_date),
    INDEX idx_isin (isin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_bond_cashflows.sql
-- ============================================================
-- Table: bond_cashflows
-- Domain: 006_bonds_govt_securities  |  Sequence: 005
-- Source: migrations/t116_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS bond_cashflows (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    bond_id BIGINT UNSIGNED NOT NULL,
    cashflow_type ENUM('COUPON','PRINCIPAL','PARTIAL_REDEMPTION') NOT NULL,
    scheduled_date DATE NOT NULL,
    amount DECIMAL(15,4) NOT NULL,
    received TINYINT(1) DEFAULT 0,
    received_date DATE DEFAULT NULL,
    tds_deducted DECIMAL(10,2) DEFAULT 0.00,
    net_amount DECIMAL(15,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bond_id) REFERENCES bonds(id) ON DELETE CASCADE,
    INDEX idx_bond_id (bond_id),
    INDEX idx_user_id (user_id),
    INDEX idx_scheduled_date (scheduled_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_bonds_54ec.sql
-- ============================================================
-- Table: bonds_54ec
-- Domain: 006_bonds_govt_securities  |  Sequence: 006
-- Source: migrations/t134_54ec_bonds.sql
-- ============================================================
-- CONFLICT RESOLVED: Note: 27_54ec_bonds.sql was TODO placeholder (discarded)

CREATE TABLE IF NOT EXISTS `bonds_54ec` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`         INT UNSIGNED NOT NULL,
  `bond_issuer`     ENUM('REC','NHAI','PFC','IRFC','OTHER') NOT NULL DEFAULT 'REC',
  `issuer_name`     VARCHAR(100) NOT NULL DEFAULT '',          -- custom name if OTHER
  `investment_date` DATE NOT NULL,
  `maturity_date`   DATE NOT NULL,
  `face_value`      DECIMAL(14,2) NOT NULL DEFAULT 10000.00,  -- per bond ₹10,000
  `num_bonds`       INT UNSIGNED NOT NULL DEFAULT 1,
  `total_invested`  DECIMAL(14,2) NOT NULL,                   -- num_bonds × face_value
  `interest_rate`   DECIMAL(5,2) NOT NULL DEFAULT 5.00,       -- p.a.
  `interest_freq`   ENUM('annual','cumulative') NOT NULL DEFAULT 'annual',
  `ltcg_exempted`   DECIMAL(14,2) NOT NULL DEFAULT 0.00,      -- original LTCG claim
  `sale_asset_date` DATE NULL,                                -- date of original asset sale
  `folio_number`    VARCHAR(80) NULL,
  `notes`           TEXT NULL,
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_54ec_user` (`user_id`),
  INDEX `idx_54ec_maturity` (`maturity_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 008_gsec_cashflows.sql
-- ============================================================
-- Table: gsec_cashflows
-- Domain: 006_bonds_govt_securities  |  Sequence: 008
-- Source: migrations/t118_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS gsec_cashflows (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    security_id BIGINT UNSIGNED NOT NULL,
    cashflow_type ENUM('COUPON','MATURITY','PARTIAL_SALE') NOT NULL,
    scheduled_date DATE NOT NULL,
    coupon_rate_applied DECIMAL(8,4) DEFAULT NULL COMMENT 'Actual rate for floating bonds',
    amount DECIMAL(15,4) NOT NULL,
    received TINYINT(1) DEFAULT 0,
    received_date DATE DEFAULT NULL,
    tds_deducted DECIMAL(10,2) DEFAULT 0.00,
    net_amount DECIMAL(15,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (security_id) REFERENCES govt_securities(id) ON DELETE CASCADE,
    INDEX idx_security_id (security_id),
    INDEX idx_user_id (user_id),
    INDEX idx_scheduled_date (scheduled_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_note_54ec_bonds_alias.sql
-- ============================================================
-- NOTE: 54ec_bonds / bond_holdings
-- Domain: 006_bonds_govt_securities
-- ============================================================
-- These two table names appeared in legacy SQL placeholders but
-- were NEVER actually implemented. The real implementation is:
--   bonds_54ec  →  see 007_bonds_54ec.sql in this folder
--   bond_holdings → bond data is stored within the bonds table
--                   (see 004_bonds.sql), no separate holdings table
-- ============================================================
SELECT '54ec_bonds and bond_holdings were legacy placeholder names — actual tables are bonds_54ec and bonds' AS info;

-- 009_govt_securities.sql
-- ============================================================
-- Table: govt_securities
-- Domain: 006_bonds_govt_securities  |  Sequence: 009
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS govt_securities (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    security_type ENUM('RBI_FRB','GSEC','TBILL','SDL') NOT NULL,
    security_name VARCHAR(200) NOT NULL,
    isin VARCHAR(20),
    face_value DECIMAL(15,2) NOT NULL DEFAULT 1000.00,
    quantity INT UNSIGNED NOT NULL,
    purchase_price DECIMAL(15,4) NOT NULL,
    purchase_date DATE NOT NULL,
    maturity_date DATE NOT NULL,
    coupon_rate DECIMAL(8,4) DEFAULT NULL COMMENT 'NULL for T-Bills (discount instrument)',
    coupon_frequency ENUM('SEMI_ANNUAL','QUARTERLY','FLOATING') DEFAULT 'SEMI_ANNUAL',
    is_floating TINYINT(1) DEFAULT 0 COMMENT '1 for FRB where rate resets',
    floating_reference VARCHAR(50) DEFAULT NULL COMMENT 'NSS rate / Repo rate reference',
    floating_spread DECIMAL(6,4) DEFAULT NULL COMMENT 'Spread above reference rate',
    platform VARCHAR(100) COMMENT 'RBI Retail Direct/Zerodha/NSE goBID',
    redemption_price DECIMAL(15,4) DEFAULT NULL COMMENT 'For T-Bills = face_value',
    notes TEXT,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_security_type (security_type),
    INDEX idx_maturity (maturity_date),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 010_yield_curve_reference.sql
-- ============================================================
-- Table: yield_curve_reference
-- Domain: 006_bonds_govt_securities  |  Sequence: 010
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS yield_curve_reference (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  tenure_months SMALLINT     NOT NULL UNIQUE,
  tenure_label  VARCHAR(10)  NOT NULL,
  rate          DECIMAL(5,2) NOT NULL,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_tenure (tenure_months)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 007_crypto ────────────────────────────────────────────
-- 001_crypto_master.sql
-- ============================================================
-- Table: crypto_master
-- Domain: 007_crypto  |  Sequence: 001
-- Source: migrations/t40_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_master` (
    `id`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `coingecko_id`      VARCHAR(100) NOT NULL UNIQUE,
    `symbol`            VARCHAR(20)  NOT NULL,
    `name`              VARCHAR(150) NOT NULL,
    `logo_url`          VARCHAR(500) DEFAULT NULL,
    `current_price_inr` DECIMAL(20,8) DEFAULT 0,
    `price_change_24h`  DECIMAL(10,4) DEFAULT 0,
    `market_cap_inr`    DECIMAL(22,4) DEFAULT 0,
    `volume_24h_inr`    DECIMAL(22,4) DEFAULT 0,
    `ath_inr`           DECIMAL(20,8) DEFAULT NULL,
    `atl_inr`           DECIMAL(20,8) DEFAULT NULL,
    `circulating_supply`DECIMAL(22,4) DEFAULT NULL,
    `total_supply`      DECIMAL(22,4) DEFAULT NULL,
    `rank`              SMALLINT UNSIGNED DEFAULT NULL,
    `price_updated_at`  DATETIME DEFAULT NULL,
    `created_at`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_cm_symbol` (`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_crypto_holdings.sql
-- ============================================================
-- Table: crypto_holdings
-- Domain: 007_crypto  |  Sequence: 002
-- Source: 38_crypto_holdings.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: 38_(richest, CoinGecko string ID, portfolio FK), 41_pending_tasks (user_id, no FK), t40 (int coin_id FK). Winner: 38_crypto_holdings.sql

CREATE TABLE IF NOT EXISTS `crypto_holdings` (
    `id`              INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `portfolio_id`    INT UNSIGNED     NOT NULL,
    `coin_id`         VARCHAR(60)      NOT NULL,          -- CoinGecko ID e.g. "bitcoin"
    `coin_symbol`     VARCHAR(20)      NOT NULL,          -- BTC, ETH, etc.
    `coin_name`       VARCHAR(100)     NOT NULL,          -- Bitcoin, Ethereum
    `quantity`        DECIMAL(24,8)    NOT NULL DEFAULT 0,
    `avg_buy_price`   DECIMAL(20,4)    NOT NULL DEFAULT 0, -- INR per coin at purchase
    `total_invested`  DECIMAL(20,2)    NOT NULL DEFAULT 0, -- quantity × avg_buy_price
    `exchange`        VARCHAR(60)      NULL,               -- WazirX, Binance, CoinDCX
    `wallet_address`  VARCHAR(200)     NULL,
    `notes`           TEXT             NULL,
    `created_at`      TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_portfolio` (`portfolio_id`),
    KEY `idx_coin`      (`coin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_crypto_transactions.sql
-- ============================================================
-- Table: crypto_transactions
-- Domain: 007_crypto  |  Sequence: 003
-- Source: 38_crypto_holdings.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT same files. Winner: 38_ (richer, consistent with crypto_holdings)

CREATE TABLE IF NOT EXISTS `crypto_transactions` (
    `id`           INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `portfolio_id` INT UNSIGNED     NOT NULL,
    `coin_id`      VARCHAR(60)      NOT NULL,
    `coin_symbol`  VARCHAR(20)      NOT NULL,
    `txn_type`     ENUM('BUY','SELL','TRANSFER_IN','TRANSFER_OUT') NOT NULL DEFAULT 'BUY',
    `quantity`     DECIMAL(24,8)    NOT NULL,
    `price_inr`    DECIMAL(20,4)    NOT NULL DEFAULT 0,    -- price per coin in INR at time of txn
    `amount_inr`   DECIMAL(20,2)    NOT NULL DEFAULT 0,    -- total txn value in INR
    `tds_deducted` DECIMAL(10,2)    NOT NULL DEFAULT 0,    -- 1% TDS on sell
    `txn_date`     DATE             NOT NULL,
    `exchange`     VARCHAR(60)      NULL,
    `notes`        TEXT             NULL,
    `created_at`   TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_portfolio` (`portfolio_id`),
    KEY `idx_coin`      (`coin_id`),
    KEY `idx_date`      (`txn_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_crypto_price_cache.sql
-- ============================================================
-- Table: crypto_price_cache
-- Domain: 007_crypto  |  Sequence: 004
-- Source: 43_fix_crypto_schema.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: 38_, 43_fix_, tc001. Winner: 43_fix_ (fix file = most recent, applied on top)

CREATE TABLE IF NOT EXISTS crypto_price_cache (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  coin_id      VARCHAR(100) NOT NULL,
  symbol       VARCHAR(20)  NOT NULL,
  name         VARCHAR(100) NOT NULL,
  price_inr    DECIMAL(20,4) DEFAULT 0,
  price_usd    DECIMAL(20,8) DEFAULT 0,
  change_24h   DECIMAL(10,4) DEFAULT 0,
  market_cap   BIGINT       DEFAULT 0,
  fetched_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_coin (coin_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 005_crypto_watchlist.sql
-- ============================================================
-- Table: crypto_watchlist
-- Domain: 007_crypto  |  Sequence: 005
-- Source: migrations/t315_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t40 also has this. Winner: t315 (more recent task-ID)

CREATE TABLE IF NOT EXISTS `crypto_watchlist` (
    `id`             INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    `user_id`        INT UNSIGNED      NOT NULL,
    `coin_id`        VARCHAR(60)       NOT NULL,
    `coin_symbol`    VARCHAR(20)       NOT NULL,
    `coin_name`      VARCHAR(100)      NOT NULL,
    `alert_high`     DECIMAL(20,4)     NULL,               -- alert when price > this (INR)
    `alert_low`      DECIMAL(20,4)     NULL,               -- alert when price < this (INR)
    `notes`          VARCHAR(255)      NULL,
    `created_at`     TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_user_coin` (`user_id`, `coin_id`),
    KEY `idx_user`   (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_crypto_staking_rewards.sql
-- ============================================================
-- Table: crypto_staking_rewards
-- Domain: 007_crypto  |  Sequence: 006
-- Source: migrations/t315_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_staking_rewards` (
    `id`             INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    `portfolio_id`   INT UNSIGNED      NOT NULL,
    `coin_id`        VARCHAR(60)       NOT NULL,           -- CoinGecko ID
    `coin_symbol`    VARCHAR(20)       NOT NULL,           -- BTC, ETH …
    `reward_type`    ENUM('STAKING','YIELD','AIRDROP','MINING','INTEREST') NOT NULL DEFAULT 'STAKING',
    `quantity`       DECIMAL(24,8)     NOT NULL DEFAULT 0,
    `price_inr`      DECIMAL(20,4)     NOT NULL DEFAULT 0, -- INR price at reward date
    `value_inr`      DECIMAL(20,2)     NOT NULL DEFAULT 0, -- quantity × price_inr
    `platform`       VARCHAR(80)       NULL,               -- Binance Earn, WazirX etc.
    `reward_date`    DATE              NOT NULL,
    `notes`          TEXT              NULL,
    `created_at`     TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_portfolio` (`portfolio_id`),
    KEY `idx_coin`      (`coin_id`),
    KEY `idx_date`      (`reward_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_crypto_import_log.sql
-- ============================================================
-- Table: crypto_import_log
-- Domain: 007_crypto  |  Sequence: 007
-- Source: migrations/t317_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_import_log` (
    `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `batch_id`      VARCHAR(36)   NOT NULL COMMENT 'UUID',
    `portfolio_id`  INT UNSIGNED  NOT NULL,
    `user_id`       INT UNSIGNED  NOT NULL,
    `exchange`      VARCHAR(20)   NOT NULL COMMENT 'BINANCE | WAZIRX | COINDCX',
    `filename`      VARCHAR(255)  NOT NULL,
    `rows_parsed`   INT           NOT NULL DEFAULT 0,
    `rows_inserted` INT           NOT NULL DEFAULT 0,
    `rows_skipped`  INT           NOT NULL DEFAULT 0,
    `imported_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_portfolio` (`portfolio_id`),
    KEY `idx_user`      (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='t317 — CSV import audit log';

-- 008_crypto_tax_reports.sql
-- ============================================================
-- Table: crypto_tax_reports
-- Domain: 007_crypto  |  Sequence: 008
-- Source: migrations/t42_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS crypto_tax_reports (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  fy          VARCHAR(7)   NOT NULL COMMENT 'e.g. 2024-25',
  label       VARCHAR(100) NOT NULL DEFAULT 'Crypto Tax',
  trades      JSON         NOT NULL,
  summary     JSON         NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_user_fy (user_id, fy),
  CONSTRAINT fk_ctx_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 009_vda_transactions.sql
-- ============================================================
-- Table: vda_transactions
-- Domain: 007_crypto  |  Sequence: 009
-- Source: migrations/tc002_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `vda_transactions` (
    `id`                     INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    `portfolio_id`           INT UNSIGNED      NOT NULL,

    -- Asset identification
    `coin_symbol`            VARCHAR(20)       NOT NULL COMMENT 'BTC, ETH, SOL etc.',
    `coin_name`              VARCHAR(100)      NULL,
    `coingecko_id`           VARCHAR(80)       NULL     COMMENT 'For price lookup',

    -- Transaction type
    `txn_type`               ENUM('BUY','SELL','GIFT_RECEIVED','GIFT_GIVEN','MINING','STAKING','AIRDROP') NOT NULL DEFAULT 'BUY',

    -- BUY leg
    `buy_date`               DATE              NULL,
    `buy_quantity`           DECIMAL(24,8)     NULL     DEFAULT 0,
    `buy_price_inr`          DECIMAL(20,4)     NULL     DEFAULT 0 COMMENT 'Per unit INR at purchase',
    `buy_cost_inr`           DECIMAL(20,2)     NULL     DEFAULT 0 COMMENT 'Total cost = qty × price + fees',
    `buy_fees_inr`           DECIMAL(14,2)     NULL     DEFAULT 0 COMMENT 'Exchange fees on buy',
    `buy_exchange`           VARCHAR(80)       NULL     COMMENT 'WazirX, CoinDCX, Binance, etc.',

    -- SELL leg
    `sell_date`              DATE              NULL,
    `sell_quantity`          DECIMAL(24,8)     NULL     DEFAULT 0,
    `sell_price_inr`         DECIMAL(20,4)     NULL     DEFAULT 0 COMMENT 'Per unit INR at sale',
    `sell_proceeds_inr`      DECIMAL(20,2)     NULL     DEFAULT 0 COMMENT 'Total proceeds = qty × price',
    `sell_fees_inr`          DECIMAL(14,2)     NULL     DEFAULT 0 COMMENT 'Exchange fees on sell',
    `sell_exchange`          VARCHAR(80)       NULL,

    -- Tax computation (115BBH)
    `cost_of_acquisition`    DECIMAL(20,2)     NULL     DEFAULT 0 COMMENT 'Only allowable deduction',
    `gross_proceeds`         DECIMAL(20,2)     NULL     DEFAULT 0,
    `gain_loss_inr`          DECIMAL(20,2)     NULL     DEFAULT 0 COMMENT 'gain_loss = proceeds - COA (fees NOT deductible)',
    `is_gain`                TINYINT(1)        NULL     DEFAULT 1 COMMENT '1=gain, 0=loss',
    `tax_30pct`              DECIMAL(14,2)     NULL     DEFAULT 0 COMMENT 'Flat 30% on gain only; loss = 0 tax',
    `cess_4pct`              DECIMAL(14,2)     NULL     DEFAULT 0 COMMENT '4% Health & Education cess on tax',
    `total_tax_payable`      DECIMAL(14,2)     NULL     DEFAULT 0 COMMENT 'tax_30pct + cess_4pct',

    -- TDS (Section 194S)
    `tds_deducted`           DECIMAL(14,2)     NOT NULL DEFAULT 0 COMMENT '1% TDS deducted by exchange',
    `tds_date`               DATE              NULL,
    `tds_certificate_no`     VARCHAR(50)       NULL,

    -- FY tagging
    `fy`                     VARCHAR(9)        NOT NULL COMMENT 'YYYY-YYYY e.g. 2024-2025',
    `fy_quarter`             TINYINT UNSIGNED  NULL     COMMENT 'Q1-Q4 within FY',

    -- Metadata
    `txn_hash`               VARCHAR(100)      NULL     COMMENT 'Blockchain txn hash if available',
    `notes`                  TEXT              NULL,
    `created_at`             TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`             TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (`id`),
    KEY `idx_vda_portfolio`  (`portfolio_id`),
    KEY `idx_vda_coin`       (`coin_symbol`),
    KEY `idx_vda_fy`         (`fy`),
    KEY `idx_vda_buy_date`   (`buy_date`),
    KEY `idx_vda_sell_date`  (`sell_date`),
    KEY `idx_vda_type`       (`txn_type`),
    CONSTRAINT `fk_vda_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='VDA (Virtual Digital Assets) transactions — Section 115BBH tax tracker';

-- 010_vda_tds_log.sql
-- ============================================================
-- Table: vda_tds_log
-- Domain: 007_crypto  |  Sequence: 010
-- Source: migrations/tc002_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `vda_tds_log` (
    `id`                 INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    `portfolio_id`       INT UNSIGNED      NOT NULL,
    `exchange`           VARCHAR(80)       NOT NULL,
    `fy`                 VARCHAR(9)        NOT NULL,
    `total_sale_value`   DECIMAL(20,2)     NOT NULL DEFAULT 0,
    `tds_1pct`           DECIMAL(14,2)     NOT NULL DEFAULT 0,
    `tds_paid`           DECIMAL(14,2)     NOT NULL DEFAULT 0,
    `tds_balance`        DECIMAL(14,2)     NOT NULL DEFAULT 0 COMMENT 'tds_1pct - tds_paid (refund/credit)',
    `form_26as_verified` TINYINT(1)        NOT NULL DEFAULT 0,
    `notes`              VARCHAR(255)      NULL,
    `updated_at`         TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_vda_tds` (`portfolio_id`, `exchange`, `fy`),
    KEY `idx_vda_tds_fy` (`fy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='VDA Section 194S — 1% TDS per exchange per FY summary';

-- 011_defi_positions.sql
-- ============================================================
-- Table: defi_positions
-- Domain: 007_crypto  |  Sequence: 011
-- Source: migrations/tc003_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `defi_positions` (
    `id`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`           INT UNSIGNED NOT NULL,
    `platform`          VARCHAR(100) NOT NULL,
    `position_type`     ENUM('staking','lending','liquidity','yield_farming','vault','other') NOT NULL DEFAULT 'staking',
    `asset_symbol`      VARCHAR(20)  NOT NULL,
    `asset_name`        VARCHAR(100) DEFAULT NULL,
    `staked_amount`     DECIMAL(28,10) NOT NULL DEFAULT 0,
    `staked_value_inr`  DECIMAL(18,4)  DEFAULT 0,
    `apy_pct`           DECIMAL(8,4)   DEFAULT 0,
    `reward_symbol`     VARCHAR(20)    DEFAULT NULL,
    `chain_name`        VARCHAR(50)    DEFAULT NULL,
    `contract_address`  VARCHAR(100)   DEFAULT NULL,
    `start_date`        DATE           NOT NULL,
    `lockup_days`       SMALLINT UNSIGNED DEFAULT 0,
    `unlock_date`       DATE           DEFAULT NULL,
    `last_income_date`  DATE           DEFAULT NULL,
    `notes`             TEXT           DEFAULT NULL,
    `is_active`         TINYINT(1)     NOT NULL DEFAULT 1,
    `created_at`        DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_defi_user`     (`user_id`, `is_active`),
    INDEX `idx_defi_platform` (`platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 012_defi_income_log.sql
-- ============================================================
-- Table: defi_income_log
-- Domain: 007_crypto  |  Sequence: 012
-- Source: migrations/tc003_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `defi_income_log` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `position_id`   INT UNSIGNED NOT NULL,
    `income_date`   DATE         NOT NULL,
    `income_type`   ENUM('staking','interest','lp_fee','airdrop','bonus','other') NOT NULL DEFAULT 'staking',
    `reward_symbol` VARCHAR(20)  DEFAULT NULL,
    `amount_token`  DECIMAL(28,10) NOT NULL,
    `price_inr`     DECIMAL(20,8)  DEFAULT 0,
    `amount_inr`    DECIMAL(18,4)  DEFAULT 0,
    `notes`         TEXT           DEFAULT NULL,
    `created_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_dil_position` (`position_id`),
    INDEX `idx_dil_date`     (`income_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 013_crypto_rebal_targets.sql
-- ============================================================
-- Table: crypto_rebal_targets
-- Domain: 007_crypto  |  Sequence: 013
-- Source: migrations/tc004_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_rebal_targets` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id` INT UNSIGNED NOT NULL,
    `coin_id`      INT UNSIGNED NOT NULL,
    `target_pct`   DECIMAL(6,3) NOT NULL DEFAULT 0,
    `is_active`    TINYINT(1)   NOT NULL DEFAULT 1,
    `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_crt_portfolio_coin` (`portfolio_id`, `coin_id`),
    INDEX `idx_crt_portfolio` (`portfolio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 014_crypto_rebal_history.sql
-- ============================================================
-- Table: crypto_rebal_history
-- Domain: 007_crypto  |  Sequence: 014
-- Source: migrations/tc004_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_rebal_history` (
    `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`   INT UNSIGNED NOT NULL,
    `actions_json`   JSON         DEFAULT NULL,
    `note`           TEXT         DEFAULT NULL,
    `rebalanced_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_crh_portfolio` (`portfolio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 015_crypto_exchange_keys.sql
-- ============================================================
-- Table: crypto_exchange_keys
-- Domain: 007_crypto  |  Sequence: 015
-- Source: migrations/tc005_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_exchange_keys` (
    `id`            INT UNSIGNED   NOT NULL AUTO_INCREMENT,
    `user_id`       INT UNSIGNED   NOT NULL,
    `exchange`      VARCHAR(20)    NOT NULL  COMMENT 'BINANCE | WAZIRX',
    `api_key_enc`   TEXT           NOT NULL  COMMENT 'AES-256-GCM encrypted API key',
    `api_secret_enc`TEXT           NOT NULL  COMMENT 'AES-256-GCM encrypted secret',
    `enc_iv`        VARCHAR(64)    NOT NULL  COMMENT 'Base64 IV for decryption',
    `enc_tag`       VARCHAR(64)    NOT NULL  COMMENT 'Base64 GCM auth tag',
    `label`         VARCHAR(80)    NULL,
    `is_active`     TINYINT(1)     NOT NULL DEFAULT 1,
    `last_synced`   DATETIME       NULL,
    `created_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_user_exchange` (`user_id`, `exchange`),
    KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='tc005 — Encrypted exchange API keys';

-- 016_crypto_sync_log.sql
-- ============================================================
-- Table: crypto_sync_log
-- Domain: 007_crypto  |  Sequence: 016
-- Source: migrations/tc005_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `crypto_sync_log` (
    `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `user_id`        INT UNSIGNED  NOT NULL,
    `portfolio_id`   INT UNSIGNED  NOT NULL,
    `exchange`       VARCHAR(20)   NOT NULL,
    `status`         ENUM('OK','ERROR','PARTIAL') NOT NULL DEFAULT 'OK',
    `trades_fetched` INT           NOT NULL DEFAULT 0,
    `trades_new`     INT           NOT NULL DEFAULT 0,
    `trades_skipped` INT           NOT NULL DEFAULT 0,
    `error_msg`      TEXT          NULL,
    `synced_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_user`  (`user_id`),
    KEY `idx_synced`(`synced_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='tc005 — Exchange sync run history';

-- 017_cold_wallets.sql
-- ============================================================
-- Table: cold_wallets
-- Domain: 007_crypto  |  Sequence: 017
-- Source: migrations/tc006_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS cold_wallets (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED  NOT NULL,
  name        VARCHAR(100)  NOT NULL,
  type        ENUM('hardware','paper','mobile','air_gapped') NOT NULL DEFAULT 'hardware',
  device      VARCHAR(80)   NULL,
  address     VARCHAR(200)  NULL,
  network     VARCHAR(50)   NULL,
  notes       TEXT          NULL,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user (user_id),
  CONSTRAINT fk_cw_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 018_cold_wallet_holdings.sql
-- ============================================================
-- Table: cold_wallet_holdings
-- Domain: 007_crypto  |  Sequence: 018
-- Source: migrations/tc006_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS cold_wallet_holdings (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  wallet_id   INT UNSIGNED  NOT NULL,
  coin        VARCHAR(20)   NOT NULL,
  quantity    DECIMAL(24,8) NOT NULL DEFAULT 0,
  buy_price   DECIMAL(18,2) NULL DEFAULT 0,
  value_inr   DECIMAL(18,2) NULL DEFAULT 0,
  notes       VARCHAR(255)  NULL,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_wallet_coin (wallet_id, coin),
  CONSTRAINT fk_cwh_wallet FOREIGN KEY (wallet_id) REFERENCES cold_wallets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 019_category_rules.sql
-- ============================================================
-- Table: category_rules
-- Domain: 007_crypto  |  Sequence: 019
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS category_rules (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  keyword     VARCHAR(80)  NOT NULL,
  category    VARCHAR(60)  NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_keyword (user_id, keyword),
  CONSTRAINT fk_cr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 008_epf_nps_retirement ────────────────────────────────
-- 001_epf_accounts.sql
-- ============================================================
-- Table: epf_accounts
-- Domain: 008_epf_nps_retirement  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `epf_accounts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `uan` varchar(20) DEFAULT NULL,
  `employer_name` varchar(100) NOT NULL,
  `employee_share` decimal(14,2) NOT NULL DEFAULT 0.00,
  `employer_share` decimal(14,2) NOT NULL DEFAULT 0.00,
  `interest_earned` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `interest_rate` decimal(5,3) NOT NULL DEFAULT 8.150 COMMENT 'Current EPF rate %',
  `monthly_contribution` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_updated` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_epf_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_epf_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_epf_monthly_log.sql
-- ============================================================
-- Table: epf_monthly_log
-- Domain: 008_epf_nps_retirement  |  Sequence: 002
-- Source: migrations/t467_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: t340, t467, t46. Winner: t467 (richest, detailed column comments)

CREATE TABLE IF NOT EXISTS `epf_monthly_log` (
  `id`                   int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `epf_account_id`       int(10) UNSIGNED NOT NULL,
  `log_month`            date             NOT NULL COMMENT 'YYYY-MM-01',
  `basic_salary`         decimal(14,2)    NOT NULL DEFAULT 0.00,
  `employee_contribution`decimal(10,2)    NOT NULL DEFAULT 0.00 COMMENT 'EPF employee share',
  `employer_contribution`decimal(10,2)    NOT NULL DEFAULT 0.00 COMMENT 'Employer EPF (3.67%)',
  `eps_contribution`     decimal(10,2)    NOT NULL DEFAULT 0.00 COMMENT 'EPS share (8.33%)',
  `vpf_contribution`     decimal(10,2)    NOT NULL DEFAULT 0.00 COMMENT 'VPF (voluntary)',
  `total_credit`         decimal(12,2)    NOT NULL DEFAULT 0.00 COMMENT 'Employee+Employer+VPF',
  `balance_after`        decimal(16,2)    DEFAULT NULL           COMMENT 'EPF balance after this month (if known)',
  `interest_credited`    decimal(12,2)    NOT NULL DEFAULT 0.00 COMMENT 'Interest credited this month (March credit)',
  `source`               enum('manual','epfo_sync','import') NOT NULL DEFAULT 'manual',
  `notes`                varchar(255)     DEFAULT NULL,
  `created_at`           datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`           datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_epf_log_month` (`epf_account_id`, `log_month`),
  KEY `idx_epfl_account` (`epf_account_id`),
  KEY `idx_epfl_month`   (`log_month`),
  CONSTRAINT `fk_epfl_account`
    FOREIGN KEY (`epf_account_id`) REFERENCES `epf_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_epf_salary_log.sql
-- ============================================================
-- Table: epf_salary_log
-- Domain: 008_epf_nps_retirement  |  Sequence: 003
-- Source: migrations/t46_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `epf_salary_log` (
  `id`               int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `epf_account_id`   int(10) UNSIGNED NOT NULL,
  `basic_salary`     decimal(14,2)    NOT NULL,
  `effective_date`   date             NOT NULL,
  `vpf_rate`         decimal(5,2)     NOT NULL DEFAULT 0.00,
  `notes`            varchar(255)     DEFAULT NULL,
  `created_at`       datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_salary_log_date` (`epf_account_id`, `effective_date`),
  KEY `idx_sl_account` (`epf_account_id`),
  CONSTRAINT `fk_sl_account`
    FOREIGN KEY (`epf_account_id`) REFERENCES `epf_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_epf_fy_snapshot.sql
-- ============================================================
-- Table: epf_fy_snapshot
-- Domain: 008_epf_nps_retirement  |  Sequence: 004
-- Source: migrations/t467_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `epf_fy_snapshot` (
  `id`               int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `epf_account_id`   int(10) UNSIGNED NOT NULL,
  `fy_year`          smallint(4)      NOT NULL COMMENT 'FY start year e.g. 2024 for FY24-25',
  `opening_balance`  decimal(16,2)    NOT NULL DEFAULT 0.00,
  `closing_balance`  decimal(16,2)    NOT NULL DEFAULT 0.00,
  `total_ee_contrib` decimal(14,2)    NOT NULL DEFAULT 0.00,
  `total_er_contrib` decimal(14,2)    NOT NULL DEFAULT 0.00,
  `total_vpf`        decimal(14,2)    NOT NULL DEFAULT 0.00,
  `interest_credited`decimal(14,2)    NOT NULL DEFAULT 0.00,
  `created_at`       datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`       datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_epf_snap_fy` (`epf_account_id`, `fy_year`),
  KEY `idx_epfs_account` (`epf_account_id`),
  CONSTRAINT `fk_epfs_account`
    FOREIGN KEY (`epf_account_id`) REFERENCES `epf_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_epf_tax_log.sql
-- ============================================================
-- Table: epf_tax_log
-- Domain: 008_epf_nps_retirement  |  Sequence: 005
-- Source: migrations/t469_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `epf_tax_log` (
  `id`                      int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `epf_account_id`          int(10) UNSIGNED NOT NULL,
  `fy_year`                 smallint(4)      NOT NULL COMMENT 'FY start year e.g. 2024 for FY24-25',
  `annual_ee_contribution`  decimal(14,2)    NOT NULL DEFAULT 0.00
    COMMENT 'Total employee EPF+VPF contribution this FY',
  `annual_er_contribution`  decimal(14,2)    NOT NULL DEFAULT 0.00
    COMMENT 'Total employer EPF contribution this FY',
  `threshold_ee`            decimal(14,2)    NOT NULL DEFAULT 250000.00
    COMMENT '2.5L normal / 5L for govt employees',
  `taxable_ee_excess`       decimal(14,2)    NOT NULL DEFAULT 0.00
    COMMENT 'Employee contribution above threshold',
  `epf_interest_fy`         decimal(14,2)    NOT NULL DEFAULT 0.00
    COMMENT 'Total interest credited this FY',
  `taxable_interest`        decimal(14,2)    NOT NULL DEFAULT 0.00
    COMMENT 'Interest on excess taxable contribution',
  `estimated_tax_30pct`     decimal(12,2)    NOT NULL DEFAULT 0.00
    COMMENT 'Estimated tax @ 30% slab (worst case)',
  `is_govt_employee`        tinyint(1)       NOT NULL DEFAULT 0
    COMMENT '1 = govt employee, threshold is 5L',
  `notes`                   varchar(255)     DEFAULT NULL,
  `created_at`              datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`              datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_epf_tax_fy` (`epf_account_id`, `fy_year`),
  KEY `idx_epf_tax_account` (`epf_account_id`),
  CONSTRAINT `fk_epf_tax_account`
    FOREIGN KEY (`epf_account_id`) REFERENCES `epf_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_epfo_accounts.sql
-- ============================================================
-- Table: epfo_accounts
-- Domain: 008_epf_nps_retirement  |  Sequence: 006
-- Source: migrations/t151_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS epfo_accounts (
  id                  INT UNSIGNED    NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id             INT UNSIGNED    NOT NULL,
  uan                 VARCHAR(12)     NOT NULL,
  member_id           VARCHAR(30)     NULL,
  member_name         VARCHAR(120)    NULL,
  establishment_name  VARCHAR(200)    NULL,
  balance_employee    DECIMAL(14,2)   NOT NULL DEFAULT 0.00,
  balance_employer    DECIMAL(14,2)   NOT NULL DEFAULT 0.00,
  balance_total       DECIMAL(14,2)   NOT NULL DEFAULT 0.00,
  last_sync_at        DATETIME        NULL,
  created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_uan (user_id, uan),
  KEY idx_user_id (user_id),
  CONSTRAINT fk_epfo_acc_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_epfo_passbook.sql
-- ============================================================
-- Table: epfo_passbook
-- Domain: 008_epf_nps_retirement  |  Sequence: 007
-- Source: migrations/t151_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS epfo_passbook (
  id           INT UNSIGNED    NOT NULL AUTO_INCREMENT PRIMARY KEY,
  account_id   INT UNSIGNED    NOT NULL,
  txn_date     DATE            NOT NULL,
  wage_month   VARCHAR(7)      NULL COMMENT 'YYYY-MM',
  type         ENUM('employee','employer','pension','withdrawal','interest','other') NOT NULL DEFAULT 'other',
  amount       DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
  remarks      VARCHAR(255)    NULL,
  created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_account_date (account_id, txn_date),
  CONSTRAINT fk_epfo_pb_acc FOREIGN KEY (account_id) REFERENCES epfo_accounts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_gratuity_accounts.sql
-- ============================================================
-- Table: gratuity_accounts
-- Domain: 008_epf_nps_retirement  |  Sequence: 008
-- Source: migrations/t341_gratuity_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `gratuity_accounts` (
  `id`                 int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`       int(10) UNSIGNED NOT NULL,
  `employer_name`      varchar(100)     NOT NULL,
  `designation`        varchar(100)     DEFAULT NULL,
  `joining_date`       date             NOT NULL,
  `last_drawn_salary`  decimal(12,2)    NOT NULL DEFAULT 0.00 COMMENT 'Monthly Basic+DA at separation',
  `separation_date`    date             DEFAULT NULL COMMENT 'NULL = still employed',
  `separation_type`    enum('employed','resigned','retired','terminated','death','disability') NOT NULL DEFAULT 'employed',
  `actual_gratuity`    decimal(14,2)    DEFAULT NULL COMMENT 'Actual amount received (if separated)',
  `is_govt_employee`   tinyint(1)       NOT NULL DEFAULT 0 COMMENT 'Affects tax exemption limit',
  `is_covered_by_act`  tinyint(1)       NOT NULL DEFAULT 1 COMMENT 'Payment of Gratuity Act 1972',
  `notes`              text             DEFAULT NULL,
  `is_active`          tinyint(1)       NOT NULL DEFAULT 1,
  `created_at`         datetime         NOT NULL DEFAULT current_timestamp(),
  `updated_at`         datetime         NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gratuity_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_gratuity_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 009_nps_schemes.sql
-- ============================================================
-- Table: nps_schemes
-- Domain: 008_epf_nps_retirement  |  Sequence: 009
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_schemes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pfm_name` varchar(100) NOT NULL,
  `scheme_name` varchar(200) NOT NULL,
  `scheme_code` varchar(30) NOT NULL,
  `tier` enum('tier1','tier2') NOT NULL DEFAULT 'tier1',
  `asset_class` enum('E','C','G','A') NOT NULL DEFAULT 'E',
  `nav` decimal(12,4) DEFAULT NULL,
  `nav_date` date DEFAULT NULL,
  `return_1y` decimal(8,4) DEFAULT NULL,
  `return_3y` decimal(8,4) DEFAULT NULL,
  `return_5y` decimal(8,4) DEFAULT NULL,
  `return_since` decimal(8,4) DEFAULT NULL,
  `aum_cr` decimal(14,2) DEFAULT NULL,
  `nav_returns_updated_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nps_code` (`scheme_code`),
  KEY `idx_nps_pfm` (`pfm_name`),
  KEY `idx_nps_tier` (`tier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 010_nps_holdings.sql
-- ============================================================
-- Table: nps_holdings
-- Domain: 008_epf_nps_retirement  |  Sequence: 010
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_holdings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `scheme_id` int(10) UNSIGNED NOT NULL,
  `units` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `avg_nav` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `invested_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `current_value` decimal(16,2) NOT NULL DEFAULT 0.00,
  `gain_loss` decimal(16,2) NOT NULL DEFAULT 0.00,
  `gain_pct` decimal(8,4) NOT NULL DEFAULT 0.0000,
  `cagr` decimal(8,4) NOT NULL DEFAULT 0.0000,
  `first_investment_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_npsh` (`portfolio_id`, `scheme_id`),
  KEY `idx_npsh_scheme` (`scheme_id`),
  CONSTRAINT `fk_npsh_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_npsh_scheme` FOREIGN KEY (`scheme_id`) REFERENCES `nps_schemes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 011_nps_transactions.sql
-- ============================================================
-- Table: nps_transactions
-- Domain: 008_epf_nps_retirement  |  Sequence: 011
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_transactions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `scheme_id` int(10) UNSIGNED NOT NULL,
  `txn_type` enum('purchase','redemption','switch_in','switch_out') NOT NULL DEFAULT 'purchase',
  `txn_date` date NOT NULL,
  `units` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `nav` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_npst_portfolio` (`portfolio_id`),
  KEY `idx_npst_scheme` (`scheme_id`),
  KEY `idx_npst_date` (`txn_date`),
  CONSTRAINT `fk_npst_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_npst_scheme` FOREIGN KEY (`scheme_id`) REFERENCES `nps_schemes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 012_nps_nav_history.sql
-- ============================================================
-- Table: nps_nav_history
-- Domain: 008_epf_nps_retirement  |  Sequence: 012
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_nav_history` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `scheme_id` int(10) UNSIGNED NOT NULL,
  `nav_date` date NOT NULL,
  `nav` decimal(12,4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nps_nav` (`scheme_id`, `nav_date`),
  KEY `idx_nps_nav_date` (`nav_date`),
  KEY `idx_nps_nav_scheme` (`scheme_id`),
  CONSTRAINT `fk_nps_nav_scheme` FOREIGN KEY (`scheme_id`) REFERENCES `nps_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 013_nps_import_sessions.sql
-- ============================================================
-- Table: nps_import_sessions
-- Domain: 008_epf_nps_retirement  |  Sequence: 013
-- Source: migrations/t106_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_import_sessions` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`    int(10) UNSIGNED NOT NULL,
  `user_id`         int(10) UNSIGNED NOT NULL,
  `bank_name`       varchar(80)      DEFAULT NULL COMMENT 'Detected or user-selected bank',
  `statement_from`  date             DEFAULT NULL COMMENT 'Statement period start',
  `statement_to`    date             DEFAULT NULL COMMENT 'Statement period end',
  `raw_filename`    varchar(255)     DEFAULT NULL,
  `total_rows`      int UNSIGNED     NOT NULL DEFAULT 0 COMMENT 'Total rows parsed',
  `detected_rows`   int UNSIGNED     NOT NULL DEFAULT 0 COMMENT 'NPS rows detected',
  `confirmed_rows`  int UNSIGNED     NOT NULL DEFAULT 0 COMMENT 'Rows imported to nps_transactions',
  `status`          enum('pending','reviewed','imported','dismissed') NOT NULL DEFAULT 'pending',
  `import_notes`    varchar(255)     DEFAULT NULL,
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`      datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_nps_imp_portfolio` (`portfolio_id`),
  KEY `idx_nps_imp_user`      (`user_id`),
  KEY `idx_nps_imp_status`    (`status`),
  CONSTRAINT `fk_nps_imp_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 014_nps_import_staging.sql
-- ============================================================
-- Table: nps_import_staging
-- Domain: 008_epf_nps_retirement  |  Sequence: 014
-- Source: migrations/t106_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nps_import_staging` (
  `id`                int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `session_id`        int(10) UNSIGNED NOT NULL,
  `portfolio_id`      int(10) UNSIGNED NOT NULL,

  -- Raw data from bank statement
  `raw_date`          varchar(30)      DEFAULT NULL,
  `raw_narration`     varchar(500)     DEFAULT NULL,
  `raw_debit`         varchar(30)      DEFAULT NULL,
  `raw_credit`        varchar(30)      DEFAULT NULL,
  `raw_balance`       varchar(30)      DEFAULT NULL,
  `raw_row_number`    int UNSIGNED     DEFAULT NULL COMMENT 'Row number in original file',

  -- Parsed / normalised
  `txn_date`          date             DEFAULT NULL,
  `amount`            decimal(16,2)    DEFAULT NULL,
  `detected_bank`     varchar(80)      DEFAULT NULL,
  `detected_pfm`      varchar(100)     DEFAULT NULL COMMENT 'Detected PFM from narration',
  `detected_tier`     enum('tier1','tier2') DEFAULT 'tier1',
  `detected_contrib`  enum('SELF','EMPLOYER') DEFAULT 'SELF',
  `confidence`        tinyint UNSIGNED NOT NULL DEFAULT 0 COMMENT '0-100 match confidence',
  `match_keywords`    varchar(255)     DEFAULT NULL COMMENT 'Keywords that triggered detection',

  -- User-assigned (review step)
  `scheme_id`         int(10) UNSIGNED DEFAULT NULL,
  `tier`              enum('tier1','tier2') DEFAULT 'tier1',
  `contribution_type` enum('SELF','EMPLOYER') DEFAULT 'SELF',
  `units`             decimal(18,4)    DEFAULT NULL,
  `nav`               decimal(12,4)    DEFAULT NULL,
  `investment_fy`     varchar(10)      DEFAULT NULL,
  `notes`             varchar(255)     DEFAULT NULL,

  -- Import status
  `row_status`        enum('detected','accepted','rejected','imported','duplicate') NOT NULL DEFAULT 'detected',
  `imported_txn_id`   int(10) UNSIGNED DEFAULT NULL COMMENT 'FK to nps_transactions.id after import',

  `created_at`        datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`        datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),

  PRIMARY KEY (`id`),
  KEY `idx_nps_stg_session`   (`session_id`),
  KEY `idx_nps_stg_portfolio` (`portfolio_id`),
  KEY `idx_nps_stg_status`    (`row_status`),
  KEY `idx_nps_stg_date`      (`txn_date`),
  CONSTRAINT `fk_nps_stg_session`
    FOREIGN KEY (`session_id`) REFERENCES `nps_import_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nps_stg_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 015_ppf_fy_deposits.sql
-- ============================================================
-- Table: ppf_fy_deposits
-- Domain: 008_epf_nps_retirement  |  Sequence: 015
-- Source: migrations/t203_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t48 (text instead of JSON, no updated_at). Winner: t203 (JSON with CHECK validity)

CREATE TABLE IF NOT EXISTS `ppf_fy_deposits` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ppf_scheme_id`   int(10) UNSIGNED NOT NULL,
  `fy_year`         int(4) UNSIGNED  NOT NULL,
  `total_deposited` decimal(10,2)    NOT NULL DEFAULT 0.00,
  `entries`         longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
                    CHECK (json_valid(`entries`)),
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`      datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ppf_fy` (`ppf_scheme_id`, `fy_year`),
  KEY `idx_ppf_fy_scheme` (`ppf_scheme_id`),
  CONSTRAINT `fk_ppf_fy_scheme`
    FOREIGN KEY (`ppf_scheme_id`) REFERENCES `po_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 016_retirement_plans.sql
-- ============================================================
-- Table: retirement_plans
-- Domain: 008_epf_nps_retirement  |  Sequence: 016
-- Source: migrations/tg003_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS retirement_plans (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED  NOT NULL,
  plan_name   VARCHAR(100)  NOT NULL DEFAULT 'My Retirement Plan',
  inputs      JSON          NOT NULL COMMENT 'Calculator input parameters',
  results     JSON          NOT NULL COMMENT 'Last calculated results',
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_user_id (user_id),
  CONSTRAINT fk_ret_plan_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 017_digilocker_connections.sql
-- ============================================================
-- Table: digilocker_connections
-- Domain: 008_epf_nps_retirement  |  Sequence: 017
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS digilocker_connections (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL UNIQUE,
  connected     TINYINT(1)   NOT NULL DEFAULT 0,
  access_token  VARCHAR(500) NULL COMMENT 'Encrypted with WDCrypt when OAuth is wired in',
  connected_at  DATETIME     NULL,
  CONSTRAINT fk_dc_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 009_insurance ─────────────────────────────────────────
-- 001_insurance_policies.sql
-- ============================================================
-- Table: insurance_policies
-- Domain: 009_insurance  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: 32_insurance_policies.sql (TODO placeholder), t122_migration.sql (simpler). Winner: base schema (has policy_type enum, premium_mode, FK)

CREATE TABLE IF NOT EXISTS `insurance_policies` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `policy_number` varchar(50) DEFAULT NULL,
  `insurer_name` varchar(100) NOT NULL,
  `policy_type` enum('term','health','ulip','endowment','money_back','vehicle','home','travel','other') NOT NULL DEFAULT 'term',
  `insured_name` varchar(100) DEFAULT NULL,
  `sum_assured` decimal(16,2) NOT NULL DEFAULT 0.00,
  `premium_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `premium_frequency` enum('monthly','quarterly','half_yearly','yearly','single') NOT NULL DEFAULT 'yearly',
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `maturity_date` date DEFAULT NULL,
  `maturity_amount` decimal(16,2) DEFAULT NULL,
  `surrender_value` decimal(16,2) DEFAULT NULL,
  `status` enum('active','lapsed','surrendered','matured','claimed') NOT NULL DEFAULT 'active',
  `nominee` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ins_portfolio` (`portfolio_id`),
  KEY `idx_ins_type` (`policy_type`),
  CONSTRAINT `fk_ins_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_ulip_policies.sql
-- ============================================================
-- Table: ulip_policies
-- Domain: 009_insurance  |  Sequence: 002
-- Source: migrations/t323_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ulip_policies (
  id                  INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id             INT UNSIGNED  NOT NULL,
  policy_name         VARCHAR(150)  NOT NULL,
  insurer             VARCHAR(100)  NULL,
  policy_number       VARCHAR(60)   NULL,
  premium_amount      DECIMAL(12,2) NOT NULL DEFAULT 0,
  premium_frequency   ENUM('monthly','quarterly','half_yearly','annual') NOT NULL DEFAULT 'annual',
  sum_assured         DECIMAL(16,2) NOT NULL DEFAULT 0,
  start_date          DATE          NULL,
  maturity_date       DATE          NULL,
  current_fund_value  DECIMAL(16,2) NOT NULL DEFAULT 0,
  total_premium_paid  DECIMAL(16,2) NOT NULL DEFAULT 0,
  lock_in_years       TINYINT       NOT NULL DEFAULT 5,
  status              ENUM('active','surrendered','matured','lapsed') NOT NULL DEFAULT 'active',
  notes               TEXT          NULL,
  created_at          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME      NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_user (user_id),
  CONSTRAINT fk_ulip_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_ulip_fund_values.sql
-- ============================================================
-- Table: ulip_fund_values
-- Domain: 009_insurance  |  Sequence: 003
-- Source: migrations/t323_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ulip_fund_values (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ulip_id     INT UNSIGNED  NOT NULL,
  fund_name   VARCHAR(150)  NOT NULL,
  units       DECIMAL(14,4) NOT NULL DEFAULT 0,
  nav         DECIMAL(12,4) NOT NULL DEFAULT 0,
  value_date  DATE          NOT NULL,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ulip (ulip_id, value_date),
  CONSTRAINT fk_ufv_ulip FOREIGN KEY (ulip_id) REFERENCES ulip_policies(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_ulip_switches.sql
-- ============================================================
-- Table: ulip_switches
-- Domain: 009_insurance  |  Sequence: 004
-- Source: migrations/t461_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ulip_switches (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ulip_id     INT UNSIGNED  NOT NULL,
  from_fund   VARCHAR(150)  NOT NULL,
  to_fund     VARCHAR(150)  NOT NULL,
  amount      DECIMAL(14,2) NOT NULL DEFAULT 0,
  switch_date DATE          NOT NULL,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ulip (ulip_id, switch_date),
  CONSTRAINT fk_usw_ulip FOREIGN KEY (ulip_id) REFERENCES ulip_policies(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_premium_payments.sql
-- ============================================================
-- Table: premium_payments
-- Domain: 009_insurance  |  Sequence: 005
-- Source: migrations/t462_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS premium_payments (
  id             INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id        INT UNSIGNED  NOT NULL,
  policy_id      INT UNSIGNED  NOT NULL,
  due_date       DATE          NOT NULL,
  amount         DECIMAL(12,2) NOT NULL DEFAULT 0,
  paid_date      DATE          NOT NULL,
  payment_method VARCHAR(30)   NULL,
  notes          VARCHAR(255)  NULL,
  created_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_policy_due (user_id, policy_id, due_date),
  KEY idx_user_paid (user_id, paid_date),
  CONSTRAINT fk_pp_user   FOREIGN KEY (user_id)   REFERENCES users(id)               ON DELETE CASCADE,
  CONSTRAINT fk_pp_policy FOREIGN KEY (policy_id) REFERENCES insurance_policies(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_health_insurance_members.sql
-- ============================================================
-- Table: health_insurance_members
-- Domain: 009_insurance  |  Sequence: 006
-- Source: migrations/t460_health_insurance_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `health_insurance_members` (
  `id`            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `policy_id`     INT UNSIGNED    NOT NULL,
  `member_name`   VARCHAR(100)    NOT NULL,
  `relation`      ENUM('self','spouse','son','daughter','father','mother','father_in_law','mother_in_law','other') NOT NULL DEFAULT 'self',
  `dob`           DATE            NULL,
  `age`           TINYINT UNSIGNED NULL,
  `gender`        ENUM('male','female','other') NULL,
  `pre_existing`  TEXT            NULL COMMENT 'Pre-existing conditions (comma-sep)',
  `sum_insured`   DECIMAL(12,2)   NULL COMMENT 'Individual SI if not floater',
  `notes`         TEXT            NULL,
  `created_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_him_policy`  (`policy_id`),
  CONSTRAINT `fk_him_policy` FOREIGN KEY (`policy_id`) REFERENCES `insurance_policies`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Members covered under health insurance policies (t460)';

-- 007_health_insurance_claims.sql
-- ============================================================
-- Table: health_insurance_claims
-- Domain: 009_insurance  |  Sequence: 007
-- Source: migrations/t460_health_insurance_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `health_insurance_claims` (
  `id`              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `policy_id`       INT UNSIGNED    NOT NULL,
  `member_id`       INT UNSIGNED    NULL COMMENT 'FK to health_insurance_members',
  `claim_number`    VARCHAR(60)     NULL,
  `claim_type`      ENUM('cashless','reimbursement') NOT NULL DEFAULT 'reimbursement',
  `claim_date`      DATE            NOT NULL,
  `hospital_name`   VARCHAR(150)    NULL,
  `diagnosis`       VARCHAR(200)    NULL,
  `admission_date`  DATE            NULL,
  `discharge_date`  DATE            NULL,
  `claimed_amount`  DECIMAL(14,2)   NOT NULL DEFAULT 0,
  `approved_amount` DECIMAL(14,2)   NULL,
  `settled_amount`  DECIMAL(14,2)   NULL,
  `deducted_amount` DECIMAL(14,2)   NULL COMMENT 'Copay + deductible applied',
  `status`          ENUM('submitted','under_review','approved','partially_approved','rejected','settled','withdrawn') NOT NULL DEFAULT 'submitted',
  `settlement_date` DATE            NULL,
  `rejection_reason`VARCHAR(300)    NULL,
  `documents_submitted` TEXT        NULL COMMENT 'Documents list',
  `notes`           TEXT            NULL,
  `created_at`      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_hic_policy`  (`policy_id`),
  KEY `idx_hic_member`  (`member_id`),
  KEY `idx_hic_status`  (`status`),
  KEY `idx_hic_date`    (`claim_date`),
  CONSTRAINT `fk_hic_policy` FOREIGN KEY (`policy_id`) REFERENCES `insurance_policies`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hic_member` FOREIGN KEY (`member_id`) REFERENCES `health_insurance_members`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Health insurance claims tracker (t460)';

-- ── 010_loans_credit ──────────────────────────────────────
-- 001_loan_accounts.sql
-- ============================================================
-- Table: loan_accounts
-- Domain: 010_loans_credit  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `loan_accounts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `lender_name` varchar(100) NOT NULL,
  `loan_type` enum('home','personal','vehicle','education','gold','business','other') NOT NULL DEFAULT 'personal',
  `account_number` varchar(50) DEFAULT NULL,
  `principal_amount` decimal(16,2) NOT NULL,
  `outstanding_balance` decimal(16,2) NOT NULL DEFAULT 0.00,
  `interest_rate` decimal(6,3) NOT NULL,
  `rate_type` enum('fixed','floating') NOT NULL DEFAULT 'fixed',
  `emi_amount` decimal(12,2) DEFAULT NULL,
  `tenure_months` int(11) DEFAULT NULL,
  `disbursement_date` date NOT NULL,
  `first_emi_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `prepayment_penalty` decimal(5,3) DEFAULT NULL,
  `status` enum('active','closed','npa') NOT NULL DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_loan_portfolio` (`portfolio_id`),
  KEY `idx_loan_type` (`loan_type`),
  CONSTRAINT `fk_loan_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_loans.sql
-- ============================================================
-- Table: loans
-- Domain: 010_loans_credit  |  Sequence: 002
-- Source: migrations/t123_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 28_loans.sql (older). Winner: t123 (richer schema)

CREATE TABLE IF NOT EXISTS loans (
  id                    INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id               INT UNSIGNED  NOT NULL,
  loan_name             VARCHAR(150)  NOT NULL,
  loan_type             ENUM('home','personal','education','vehicle','gold','other') NOT NULL DEFAULT 'personal',
  lender                VARCHAR(100)  NULL,
  loan_amount           DECIMAL(16,2) NOT NULL DEFAULT 0,
  outstanding_principal DECIMAL(16,2) NOT NULL DEFAULT 0,
  interest_rate         DECIMAL(6,2)  NOT NULL DEFAULT 0,
  tenure_months         SMALLINT      NOT NULL DEFAULT 12,
  emi_amount            DECIMAL(12,2) NOT NULL DEFAULT 0,
  emi_date              TINYINT       NOT NULL DEFAULT 5,
  start_date            DATE          NULL,
  end_date              DATE          NULL,
  total_paid            DECIMAL(16,2) NOT NULL DEFAULT 0,
  status                ENUM('active','closed','written_off') NOT NULL DEFAULT 'active',
  notes                 TEXT          NULL,
  created_at            DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at            DATETIME      NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_user_type (user_id, loan_type),
  KEY idx_user_status (user_id, status),
  CONSTRAINT fk_loan_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_loan_prepayments.sql
-- ============================================================
-- Table: loan_prepayments
-- Domain: 010_loans_credit  |  Sequence: 003
-- Source: migrations/t464_home_loan_emi_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `loan_prepayments` (
  `id`              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `loan_id`         INT UNSIGNED    NOT NULL,
  `payment_date`    DATE            NOT NULL,
  `amount`          DECIMAL(14,2)   NOT NULL,
  `mode`            ENUM('full_prepayment','partial_prepayment','balance_transfer') NOT NULL DEFAULT 'partial_prepayment',
  `impact`          ENUM('reduce_tenure','reduce_emi') NOT NULL DEFAULT 'reduce_tenure',
  `emis_saved`      SMALLINT        NULL COMMENT 'Number of EMIs saved (computed)',
  `interest_saved`  DECIMAL(14,2)   NULL COMMENT 'Interest saved (computed)',
  `new_outstanding` DECIMAL(16,2)   NULL COMMENT 'Outstanding after prepayment',
  `new_tenure`      INT             NULL COMMENT 'Remaining tenure after prepayment',
  `new_emi`         DECIMAL(12,2)   NULL COMMENT 'New EMI (if emi was reduced)',
  `penalty_charged` DECIMAL(10,2)   NOT NULL DEFAULT 0,
  `source`          VARCHAR(100)    NULL COMMENT 'Source of funds: savings, bonus, etc.',
  `notes`           TEXT            NULL,
  `created_at`      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lp_loan`   (`loan_id`),
  KEY `idx_lp_date`   (`payment_date`),
  CONSTRAINT `fk_lp_loan` FOREIGN KEY (`loan_id`) REFERENCES `loan_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Loan prepayment log (t464)';

-- 004_loan_rate_history.sql
-- ============================================================
-- Table: loan_rate_history
-- Domain: 010_loans_credit  |  Sequence: 004
-- Source: migrations/t464_home_loan_emi_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `loan_rate_history` (
  `id`              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `loan_id`         INT UNSIGNED    NOT NULL,
  `effective_date`  DATE            NOT NULL,
  `old_rate`        DECIMAL(6,3)    NOT NULL,
  `new_rate`        DECIMAL(6,3)    NOT NULL,
  `new_emi`         DECIMAL(12,2)   NULL COMMENT 'New EMI after reset (if tenure fixed)',
  `new_tenure`      INT             NULL COMMENT 'New tenure after reset (if EMI fixed)',
  `base_rate`       DECIMAL(6,3)    NULL COMMENT 'RBI/bank base rate at this time',
  `reason`          VARCHAR(200)    NULL COMMENT 'RBI policy change, annual reset etc.',
  `notes`           TEXT            NULL,
  `created_at`      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lrh_loan`  (`loan_id`),
  KEY `idx_lrh_date`  (`effective_date`),
  CONSTRAINT `fk_lrh_loan` FOREIGN KEY (`loan_id`) REFERENCES `loan_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Home loan interest rate change history (t464)';

-- 005_loan_tax_claims.sql
-- ============================================================
-- Table: loan_tax_claims
-- Domain: 010_loans_credit  |  Sequence: 005
-- Source: migrations/t464_home_loan_emi_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `loan_tax_claims` (
  `id`              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `loan_id`         INT UNSIGNED    NOT NULL,
  `fy`              CHAR(7)         NOT NULL COMMENT 'FY in format 2024-25',
  `interest_paid`   DECIMAL(14,2)   NOT NULL DEFAULT 0 COMMENT 'Total interest paid this FY',
  `principal_paid`  DECIMAL(14,2)   NOT NULL DEFAULT 0 COMMENT 'Total principal paid this FY',
  `sec_24b_claimed` DECIMAL(14,2)   NOT NULL DEFAULT 0 COMMENT 'Sec 24(b) deduction claimed',
  `sec_80c_claimed` DECIMAL(14,2)   NOT NULL DEFAULT 0 COMMENT 'Sec 80C deduction claimed (principal)',
  `under_construction` TINYINT(1)   NOT NULL DEFAULT 0 COMMENT 'Was property under construction this FY',
  `notes`           TEXT            NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ltc_loan_fy` (`loan_id`, `fy`),
  KEY `idx_ltc_loan` (`loan_id`),
  CONSTRAINT `fk_ltc_loan` FOREIGN KEY (`loan_id`) REFERENCES `loan_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Home loan annual tax claim tracker (t464)';

-- 006_credit_cards.sql
-- ============================================================
-- Table: credit_cards
-- Domain: 010_loans_credit  |  Sequence: 006
-- Source: 44_v48_sprint_tables.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t503_migration.sql. Winner: 44_ (portfolio_id FK, fuller schema)

CREATE TABLE IF NOT EXISTS `credit_cards` (
  `id`            INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED   NOT NULL,
  `card_name`     VARCHAR(100)   NOT NULL,
  `bank_name`     VARCHAR(100)   NOT NULL DEFAULT '',
  `card_type`     VARCHAR(50)    NOT NULL DEFAULT 'credit',
  `credit_limit`  DECIMAL(12,2)  NOT NULL DEFAULT 0,
  `outstanding`   DECIMAL(12,2)  NOT NULL DEFAULT 0,
  `min_payment`   DECIMAL(12,2)  NOT NULL DEFAULT 0,
  `due_date`      DATE           DEFAULT NULL,
  `interest_rate` DECIMAL(5,2)   NOT NULL DEFAULT 36.00
                  COMMENT 'Annual % — typical 36-42%',
  `reward_type`   VARCHAR(50)    NOT NULL DEFAULT 'cashback',
  `reward_rate`   DECIMAL(5,2)   NOT NULL DEFAULT 1.00
                  COMMENT '% cashback or points per Rs 100',
  `annual_fee`    DECIMAL(8,2)   NOT NULL DEFAULT 0,
  `is_active`     TINYINT(1)     NOT NULL DEFAULT 1,
  `notes`         TEXT           DEFAULT NULL,
  `created_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_cibil_history.sql
-- ============================================================
-- Table: cibil_history
-- Domain: 010_loans_credit  |  Sequence: 007
-- ============================================================
-- NOTE: This table was listed as TODO (40_cibil_history.sql = placeholder)
-- and was NEVER actually implemented in any migration file.
-- Schema below is inferred from the CIBIL feature description.
-- Verify against api/credit/cibil.php before running.
-- ============================================================

CREATE TABLE IF NOT EXISTS `cibil_history` (
  `id`          int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     int(10) UNSIGNED NOT NULL,
  `score`       smallint(5) UNSIGNED NOT NULL,
  `bureau`      enum('CIBIL','Experian','Equifax','CRIF') NOT NULL DEFAULT 'CIBIL',
  `report_date` date NOT NULL,
  `report_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`report_json`)),
  `notes`       text DEFAULT NULL,
  `created_at`  datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cibil_user` (`user_id`),
  KEY `idx_cibil_date` (`report_date`),
  CONSTRAINT `fk_cibil_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 011_property ──────────────────────────────────────────
-- 001_real_estate.sql
-- ============================================================
-- Table: real_estate
-- Domain: 011_property  |  Sequence: 001
-- Source: migrations/t466_real_estate_physical_gold.sql
-- ============================================================
-- Note: 37_real_estate.sql was a TODO placeholder (discarded).
-- Actual implementation found in t466.
-- ============================================================

CREATE TABLE IF NOT EXISTS `real_estate` (
  `id`                  int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`        int(10) UNSIGNED NOT NULL,
  `property_name`       varchar(150) NOT NULL COMMENT 'e.g. 2BHK Malviya Nagar',
  `property_type`       enum('residential','commercial','plot','agricultural','other') NOT NULL DEFAULT 'residential',
  `address`             text DEFAULT NULL,
  `city`                varchar(80) DEFAULT NULL,
  `state`               varchar(80) DEFAULT NULL,
  `purchase_date`       date NOT NULL,
  `purchase_price`      decimal(18,2) NOT NULL COMMENT 'Total cost including stamp duty, registration',
  `current_value`       decimal(18,2) NOT NULL COMMENT 'Self-assessed current market value',
  `last_valued_date`    date DEFAULT NULL COMMENT 'When was current_value last updated',
  `is_self_occupied`    tinyint(1) NOT NULL DEFAULT 0,
  `monthly_rental`      decimal(12,2) DEFAULT NULL COMMENT 'Monthly rental income (if let out)',
  `annual_expenses`     decimal(12,2) DEFAULT NULL COMMENT 'Annual maintenance, property tax, etc.',
  `outstanding_loan`    decimal(18,2) DEFAULT NULL COMMENT 'Linked home loan outstanding (manual)',
  `loan_account_id`     int(10) UNSIGNED DEFAULT NULL COMMENT 'FK to loan_accounts if available',
  `ownership_pct`       decimal(5,2) NOT NULL DEFAULT 100.00 COMMENT 'Your ownership percentage',
  `notes`               text DEFAULT NULL,
  `is_active`           tinyint(1) NOT NULL DEFAULT 1,
  `created_at`          datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`          datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_re_portfolio`   (`portfolio_id`),
  KEY `idx_re_type`        (`property_type`),
  KEY `idx_re_active`      (`is_active`),
  CONSTRAINT `fk_re_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='t466: Real estate holdings';

-- 002_properties.sql
-- ============================================================
-- Table: properties
-- Domain: 011_property  |  Sequence: 002
-- Source: migrations/t463_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS properties (
  id               INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id          INT UNSIGNED  NOT NULL,
  property_name    VARCHAR(150)  NOT NULL,
  property_type    ENUM('residential','commercial','land','agricultural','other') NOT NULL DEFAULT 'residential',
  address          VARCHAR(255)  NULL,
  area_sqft        DECIMAL(10,2) NULL,
  purchase_price   DECIMAL(16,2) NOT NULL DEFAULT 0,
  purchase_date    DATE          NULL,
  loan_outstanding DECIMAL(16,2) NOT NULL DEFAULT 0,
  monthly_rental   DECIMAL(12,2) NOT NULL DEFAULT 0,
  status           ENUM('active','sold') NOT NULL DEFAULT 'active',
  notes            TEXT          NULL,
  created_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME      NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_user_type   (user_id, property_type),
  KEY idx_user_status (user_id, status),
  CONSTRAINT fk_prop_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_property_valuations.sql
-- ============================================================
-- Table: property_valuations
-- Domain: 011_property  |  Sequence: 003
-- Source: migrations/t463_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS property_valuations (
  id              INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  property_id     INT UNSIGNED  NOT NULL,
  current_value   DECIMAL(16,2) NOT NULL DEFAULT 0,
  valuation_date  DATE          NOT NULL,
  source          VARCHAR(50)   NULL DEFAULT 'manual',
  notes           VARCHAR(255)  NULL,
  created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_property_date (property_id, valuation_date),
  CONSTRAINT fk_pv_property FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_property_assets.sql
-- ============================================================
-- Table: property_assets
-- Domain: 011_property  |  Sequence: 004
-- Source: migrations/t138_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `property_assets` (
  `id`               int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`          int(10) UNSIGNED NOT NULL,
  `property_name`    varchar(200)     NOT NULL,
  `property_type`    enum('residential','commercial','land','other') NOT NULL DEFAULT 'residential',
  `address`          varchar(500)     DEFAULT NULL,
  `purchase_date`    date             NOT NULL,
  `purchase_price`   decimal(16,2)    NOT NULL,
  `improvement_cost` decimal(14,2)    NOT NULL DEFAULT 0.00,
  `improvement_fy`   varchar(9)       DEFAULT NULL,
  `sale_date`        date             DEFAULT NULL,
  `sale_price`       decimal(16,2)    NOT NULL DEFAULT 0.00,
  `fmv_2001`         decimal(16,2)    NOT NULL DEFAULT 0.00 COMMENT 'FMV as of 2001-02 if purchased before 2001',
  `is_active`        tinyint(1)       NOT NULL DEFAULT 1,
  `notes`            varchar(255)     DEFAULT NULL,
  `created_at`       datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`       datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pa_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_reits_invits_master.sql
-- ============================================================
-- Table: reits_invits_master
-- Domain: 011_property  |  Sequence: 005
-- Source: migrations/t115_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS reits_invits_master (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    symbol      VARCHAR(30)  NOT NULL UNIQUE,
    name        VARCHAR(200) NOT NULL,
    trust_type  ENUM('REIT','InvIT') NOT NULL,
    exchange    VARCHAR(10)  NOT NULL DEFAULT 'NSE',
    isin        VARCHAR(20)  DEFAULT NULL,
    sector      VARCHAR(100) DEFAULT NULL,
    sponsor     VARCHAR(200) DEFAULT NULL,
    is_active   TINYINT(1)   NOT NULL DEFAULT 1,
    INDEX idx_type (trust_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_reits_invits.sql
-- ============================================================
-- Table: reits_invits
-- Domain: 011_property  |  Sequence: 006
-- Source: migrations/t115_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS reits_invits (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id          INT UNSIGNED NOT NULL,
    portfolio_id     INT UNSIGNED NOT NULL,
    symbol           VARCHAR(30)  NOT NULL,
    name             VARCHAR(200) NOT NULL,
    trust_type       ENUM('REIT','InvIT') NOT NULL DEFAULT 'REIT',
    exchange         ENUM('NSE','BSE') NOT NULL DEFAULT 'NSE',
    isin             VARCHAR(20)  DEFAULT NULL,
    units            DECIMAL(14,4) NOT NULL DEFAULT 0,
    avg_buy_price    DECIMAL(12,4) NOT NULL DEFAULT 0,
    total_invested   DECIMAL(14,2) NOT NULL DEFAULT 0,
    current_price    DECIMAL(12,4) DEFAULT NULL,
    current_value    DECIMAL(14,2) DEFAULT NULL,
    gain_loss        DECIMAL(14,2) DEFAULT NULL,
    gain_loss_pct    DECIMAL(8,4)  DEFAULT NULL,
    last_price_date  DATE          DEFAULT NULL,
    notes            TEXT          DEFAULT NULL,
    created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user   (user_id),
    INDEX idx_portfolio (portfolio_id),
    INDEX idx_symbol (symbol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_reits_invits_transactions.sql
-- ============================================================
-- Table: reits_invits_transactions
-- Domain: 011_property  |  Sequence: 007
-- Source: migrations/t115_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS reits_invits_transactions (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    holding_id       INT UNSIGNED NOT NULL,
    user_id          INT UNSIGNED NOT NULL,
    portfolio_id     INT UNSIGNED NOT NULL,
    symbol           VARCHAR(30)  NOT NULL,
    transaction_type ENUM('BUY','SELL','DIVIDEND','DISTRIBUTION') NOT NULL,
    txn_date         DATE         NOT NULL,
    units            DECIMAL(14,4) NOT NULL,
    price            DECIMAL(12,4) NOT NULL,
    amount           DECIMAL(14,2) NOT NULL,
    brokerage        DECIMAL(10,2) DEFAULT 0,
    notes            TEXT          DEFAULT NULL,
    created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_holding (holding_id),
    INDEX idx_user    (user_id),
    INDEX idx_date    (txn_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_reits_invits_distributions.sql
-- ============================================================
-- Table: reits_invits_distributions
-- Domain: 011_property  |  Sequence: 008
-- Source: migrations/t115_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS reits_invits_distributions (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    holding_id       INT UNSIGNED NOT NULL,
    user_id          INT UNSIGNED NOT NULL,
    symbol           VARCHAR(30)  NOT NULL,
    dist_type        ENUM('dividend','interest','SPD','return_of_capital') NOT NULL DEFAULT 'dividend',
    ex_date          DATE         NOT NULL,
    pay_date         DATE         DEFAULT NULL,
    per_unit_amount  DECIMAL(10,4) NOT NULL,
    units_held       DECIMAL(14,4) NOT NULL,
    total_amount     DECIMAL(12,2) NOT NULL,
    tds_deducted     DECIMAL(10,2) DEFAULT 0,
    net_amount       DECIMAL(12,2) NOT NULL,
    notes            TEXT          DEFAULT NULL,
    created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_holding (holding_id),
    INDEX idx_user    (user_id),
    INDEX idx_ex_date (ex_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 012_goals_budget ──────────────────────────────────────
-- 001_investment_goals.sql
-- ============================================================
-- Table: investment_goals
-- Domain: 012_goals_budget  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `investment_goals` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `target_amount` decimal(16,2) NOT NULL,
  `target_date` date NOT NULL,
  `current_saved` decimal(16,2) NOT NULL DEFAULT 0.00,
  `monthly_sip_needed` decimal(14,2) DEFAULT NULL,
  `expected_return_pct` decimal(5,2) NOT NULL DEFAULT 12.00,
  `priority` enum('high','medium','low') NOT NULL DEFAULT 'medium',
  `color` varchar(7) NOT NULL DEFAULT '#2563EB',
  `icon` varchar(30) DEFAULT 'target',
  `linked_fund_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`linked_fund_ids`)),
  `linked_stock_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`linked_stock_ids`)),
  `linked_fd_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`linked_fd_ids`)),
  `is_achieved` tinyint(1) NOT NULL DEFAULT 0,
  `achieved_at` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ig_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_ig_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_goal_contributions.sql
-- ============================================================
-- Table: goal_contributions
-- Domain: 012_goals_budget  |  Sequence: 002
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `goal_contributions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `goal_id` int(10) UNSIGNED NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `contribution_date` date NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gc_goal` (`goal_id`),
  CONSTRAINT `fk_gc_goal` FOREIGN KEY (`goal_id`) REFERENCES `investment_goals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_goal_buckets.sql
-- ============================================================
-- Table: goal_buckets
-- Domain: 012_goals_budget  |  Sequence: 003
-- Source: 01_schema_complete.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: 33_goal_buckets (TODO), t139 (identical). Winner: base schema

CREATE TABLE IF NOT EXISTS `goal_buckets` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) NOT NULL,
  `emoji` varchar(10) NOT NULL DEFAULT '🎯',
  `color` varchar(7) NOT NULL DEFAULT '#6366f1',
  `target_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `target_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_achieved` tinyint(1) NOT NULL DEFAULT 0,
  `achieved_at` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gb_user` (`user_id`),
  CONSTRAINT `fk_gb_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_goals.sql
-- ============================================================
-- Table: goals
-- Domain: 012_goals_budget  |  Sequence: 004
-- Source: migrations/025_goal_buckets.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 41_pending_tasks (simpler). Winner: 025_ (goal_timeline, risk_tolerance cols)

CREATE TABLE IF NOT EXISTS `goals` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `goal_name`       VARCHAR(120) NOT NULL,
    `goal_type`       ENUM('retirement','education','home','vehicle','emergency','vacation','wedding','business','other') DEFAULT 'other',
    `target_amount`   DECIMAL(16,2) NOT NULL,
    `target_date`     DATE NOT NULL,
    `current_amount`  DECIMAL(16,2) NOT NULL DEFAULT 0,
    `monthly_sip`     DECIMAL(12,2) DEFAULT NULL COMMENT 'Recommended monthly SIP to reach goal',
    `expected_return` DECIMAL(5,2)  DEFAULT 12.00 COMMENT 'Expected CAGR %',
    `inflation_rate`  DECIMAL(5,2)  DEFAULT 6.00,
    `priority`        TINYINT UNSIGNED NOT NULL DEFAULT 2 COMMENT '1=High 2=Medium 3=Low',
    `color`           VARCHAR(20)   DEFAULT '#3b82f6',
    `emoji`           VARCHAR(10)   DEFAULT '🎯',
    `status`          ENUM('active','achieved','paused','cancelled') NOT NULL DEFAULT 'active',
    `notes`           TEXT DEFAULT NULL,
    `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_goals_user` (`user_id`),
    CONSTRAINT `fk_goals_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_goal_holdings.sql
-- ============================================================
-- Table: goal_holdings
-- Domain: 012_goals_budget  |  Sequence: 005
-- Source: 41_pending_tasks.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS goal_holdings (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    goal_id       INT UNSIGNED NOT NULL,
    user_id       INT UNSIGNED NOT NULL,
    asset_type    ENUM('mf','fd','nps','stock','crypto','other') NOT NULL,
    asset_id      INT UNSIGNED NOT NULL,
    allocated_pct DECIMAL(5,2) DEFAULT 100.00,
    notes         VARCHAR(200),
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_goal_asset (goal_id, asset_type, asset_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 006_goal_checkins.sql
-- ============================================================
-- Table: goal_checkins
-- Domain: 012_goals_budget  |  Sequence: 006
-- Source: migrations/tg005_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS goal_checkins (
  id           INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  goal_id      INT UNSIGNED  NOT NULL,
  user_id      INT UNSIGNED  NOT NULL,
  amount       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  checkin_date DATE          NOT NULL,
  notes        VARCHAR(255)  NULL,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_goal_date   (goal_id, checkin_date),
  KEY idx_user_date   (user_id, checkin_date),
  CONSTRAINT fk_gc_goal FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE CASCADE,
  CONSTRAINT fk_gc_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_goal_notifications.sql
-- ============================================================
-- Table: goal_notifications
-- Domain: 012_goals_budget  |  Sequence: 007
-- Source: migrations/t358_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS goal_notifications (
  id            INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED  NOT NULL,
  goal_id       INT UNSIGNED  NOT NULL,
  milestone_pct SMALLINT      NOT NULL COMMENT 'Positive = % achieved, Negative = days left',
  message       VARCHAR(255)  NOT NULL,
  emoji         VARCHAR(8)    NULL,
  is_read       TINYINT(1)    NOT NULL DEFAULT 0,
  created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_goal_milestone (user_id, goal_id, milestone_pct),
  KEY idx_user_read (user_id, is_read),
  CONSTRAINT fk_gn_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_gn_goal FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_goal_plan_meta.sql
-- ============================================================
-- Table: goal_plan_meta
-- Domain: 012_goals_budget  |  Sequence: 008
-- Source: migrations/t61_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS goal_plan_meta (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  goal_id          INT UNSIGNED NOT NULL UNIQUE,
  user_id          INT UNSIGNED NOT NULL,
  priority         ENUM('high','medium','low') NOT NULL DEFAULT 'medium',
  existing_corpus  DECIMAL(16,2) NOT NULL DEFAULT 0,
  created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_user (user_id),
  CONSTRAINT fk_gpm_goal FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE CASCADE,
  CONSTRAINT fk_gpm_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 009_ai_goal_coach_nudges.sql
-- ============================================================
-- Table: ai_goal_coach_nudges
-- Domain: 012_goals_budget  |  Sequence: 009
-- Source: migrations/t385_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ai_goal_coach_nudges (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  nudge_date  DATE         NOT NULL,
  nudges_json JSON         NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_date (user_id, nudge_date),
  CONSTRAINT fk_gcn_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 010_daily_checkins.sql
-- ============================================================
-- Table: daily_checkins
-- Domain: 012_goals_budget  |  Sequence: 010
-- Source: migrations/t242_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS daily_checkins (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL,
  checkin_date  DATE         NOT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_date (user_id, checkin_date),
  CONSTRAINT fk_dci_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 011_budget_plans.sql
-- ============================================================
-- Table: budget_plans
-- Domain: 012_goals_budget  |  Sequence: 011
-- Source: migrations/t471_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS budget_plans (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  month       VARCHAR(7)   NOT NULL COMMENT 'YYYY-MM',
  plan_json   JSON         NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_month (user_id, month),
  CONSTRAINT fk_bp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 012_budget_actuals.sql
-- ============================================================
-- Table: budget_actuals
-- Domain: 012_goals_budget  |  Sequence: 012
-- Source: migrations/t471_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS budget_actuals (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED  NOT NULL,
  category    VARCHAR(60)   NOT NULL,
  txn_type    ENUM('income','expense','savings') NOT NULL DEFAULT 'expense',
  amount      DECIMAL(12,2) NOT NULL DEFAULT 0,
  txn_date    DATE          NOT NULL,
  description VARCHAR(255)  NULL,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user_month  (user_id, txn_date),
  KEY idx_user_cat    (user_id, category),
  CONSTRAINT fk_ba_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 013_bucket_strategy_presets.sql
-- ============================================================
-- Table: bucket_strategy_presets
-- Domain: 012_goals_budget  |  Sequence: 013
-- Source: migrations/t355_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `bucket_strategy_presets` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      int(10) UNSIGNED NOT NULL,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `preset_name`  varchar(100)     NOT NULL DEFAULT 'My Strategy',
  `bucket1_pct`  tinyint UNSIGNED NOT NULL DEFAULT 10 COMMENT 'Safety  0-2yr %',
  `bucket2_pct`  tinyint UNSIGNED NOT NULL DEFAULT 20 COMMENT 'Stable  2-5yr %',
  `bucket3_pct`  tinyint UNSIGNED NOT NULL DEFAULT 70 COMMENT 'Growth  5yr+  %',
  `is_active`    tinyint(1)       NOT NULL DEFAULT 1,
  `created_at`   datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`   datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_bsp_portfolio` (`portfolio_id`),
  KEY `idx_bsp_user`      (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 014_education_plans.sql
-- ============================================================
-- Table: education_plans
-- Domain: 012_goals_budget  |  Sequence: 014
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS education_plans (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  child_name  VARCHAR(80)  NOT NULL,
  target_age  TINYINT      NOT NULL DEFAULT 18,
  inputs      JSON         NOT NULL,
  results     JSON         NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_child (user_id, child_name),
  CONSTRAINT fk_edu_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 015_goal_bucket_contributions.sql
-- ============================================================
-- Table: goal_bucket_contributions
-- Domain: 012_goals_budget  |  Sequence: 015
-- Source: migrations/t139_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `goal_bucket_contributions` (
  `id`                int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `bucket_id`         int(10) UNSIGNED NOT NULL,
  `amount`            decimal(14,2) NOT NULL,
  `contribution_date` date NOT NULL,
  `note`              varchar(255) DEFAULT NULL,
  `created_at`        datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gbc_bucket`  (`bucket_id`),
  KEY `idx_gbc_date`    (`contribution_date`),
  CONSTRAINT `fk_gbc_bucket` FOREIGN KEY (`bucket_id`) REFERENCES `goal_buckets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 016_mc_simulations.sql
-- ============================================================
-- Table: mc_simulations
-- Domain: 012_goals_budget  |  Sequence: 016
-- Source: migrations/tg001_mc_simulations.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `mc_simulations` (
  `id`                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`         INT UNSIGNED NOT NULL,
  `goal_id`              INT UNSIGNED DEFAULT NULL COMMENT 'Optional link to investment_goals',
  `label`                VARCHAR(150) NOT NULL DEFAULT 'Simulation',
  `target_amount`        DECIMAL(16,2) NOT NULL,
  `current_saved`        DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `monthly_contrib`      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `annual_return`        DECIMAL(6,2)  NOT NULL COMMENT 'Expected annual return %',
  `annual_volatility`    DECIMAL(6,2)  NOT NULL COMMENT 'Annual std dev %',
  `months`               SMALLINT UNSIGNED NOT NULL,
  `iterations`           INT UNSIGNED  NOT NULL DEFAULT 5000,
  `inflation_pct`        DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
  `sip_stepup_pct`       DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
  `success_probability`  DECIMAL(5,1)  NOT NULL COMMENT '% of simulations that hit target',
  `p10`                  DECIMAL(16,2) DEFAULT NULL COMMENT '10th percentile final value',
  `p50`                  DECIMAL(16,2) DEFAULT NULL COMMENT 'Median final value',
  `p90`                  DECIMAL(16,2) DEFAULT NULL COMMENT '90th percentile final value',
  `result_json`          LONGTEXT      DEFAULT NULL COMMENT 'Full result including fan chart data',
  `created_at`           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_mc_portfolio` (`portfolio_id`),
  INDEX `idx_mc_goal`      (`goal_id`),
  INDEX `idx_mc_created`   (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Monte Carlo goal probability simulation results — tg001';

-- 017_investment_calendar_events.sql
-- ============================================================
-- Table: investment_calendar_events
-- Domain: 012_goals_budget  |  Sequence: 017
-- Source: 26_investment_calendar.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `investment_calendar_events` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`      INT UNSIGNED DEFAULT NULL      COMMENT 'NULL = global/static event visible to all',
    `event_date`   DATE         NOT NULL,
    `event_type`   ENUM(
                     'tax_deadline',
                     'sebi_compliance',
                     'rbi_policy',
                     'budget',
                     'sgb_window',
                     'nfo_open',
                     'nfo_close',
                     'advance_tax',
                     'custom'
                   ) NOT NULL DEFAULT 'custom',
    `title`        VARCHAR(200) NOT NULL,
    `description`  TEXT         DEFAULT NULL,
    `icon`         VARCHAR(10)  DEFAULT '📅'     COMMENT 'Emoji icon for display',
    `color`        VARCHAR(20)  DEFAULT '#3b82f6' COMMENT 'Hex color for calendar cell',
    `is_important` TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_ice_date`    (`event_date`),
    KEY `idx_ice_user`    (`user_id`),
    KEY `idx_ice_type`    (`event_type`),
    CONSTRAINT `fk_ice_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Investment Calendar — FY 2025-26 events + user custom reminders';

-- 018_milestone_log.sql
-- ============================================================
-- Table: milestone_log
-- Domain: 012_goals_budget  |  Sequence: 018
-- Source: migrations/t500_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `milestone_log` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `milestone`   VARCHAR(80)  NOT NULL,
    `description` TEXT         DEFAULT NULL,
    `achieved_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `achieved_by` INT UNSIGNED DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 019_annual_reviews.sql
-- ============================================================
-- Table: annual_reviews
-- Domain: 012_goals_budget  |  Sequence: 019
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS annual_reviews (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL,
  review_year   SMALLINT     NOT NULL,
  checked_items JSON         NOT NULL DEFAULT ('[]'),
  notes         TEXT         NULL,
  completed_at  DATETIME     NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_year (user_id, review_year),
  CONSTRAINT fk_ar_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 013_tax ───────────────────────────────────────────────
-- 001_ais_entries.sql
-- ============================================================
-- Table: ais_entries
-- Domain: 013_tax  |  Sequence: 001
-- Source: migrations/t136_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ais_entries` (
  `id`                   int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`              int(10) UNSIGNED NOT NULL,
  `fy_year`              smallint(4)      NOT NULL,
  `category`             enum('salary','interest','dividend','mutual_fund_redemption','property_sale','rental_income','other_income','tds_deducted','advance_tax','self_assessment_tax','refund','other') NOT NULL DEFAULT 'other',
  `description`          varchar(255)     DEFAULT NULL,
  `reported_amount`      decimal(16,2)    NOT NULL DEFAULT 0.00,
  `user_declared_amount` decimal(16,2)    DEFAULT NULL,
  `deductor_name`        varchar(150)     DEFAULT NULL,
  `tds_deducted`         decimal(12,2)    NOT NULL DEFAULT 0.00,
  `transaction_date`     date             DEFAULT NULL,
  `feedback_status`      enum('accepted','incorrect','not_mine','duplicate','other') NOT NULL DEFAULT 'accepted',
  `notes`                varchar(255)     DEFAULT NULL,
  `created_at`           datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`           datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ais_user_fy` (`user_id`, `fy_year`),
  KEY `idx_ais_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_tax_80c_manual_entries.sql
-- ============================================================
-- Table: tax_80c_manual_entries
-- Domain: 013_tax  |  Sequence: 002
-- Source: migrations/t48_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `tax_80c_manual_entries` (
  `id`          int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     int(10) UNSIGNED NOT NULL,
  `fy_year`     smallint(4)      NOT NULL COMMENT 'FY start year e.g. 2024 for FY2024-25',
  `category`    enum('lic_premium','elss','home_loan_principal','tuition_fee',
                     'nsc_purchase','sukanya_samridhi','stamp_duty',
                     'unit_linked_insurance','other') NOT NULL DEFAULT 'other',
  `section`     enum('80C','80CCD(1B)','80D','80E') NOT NULL DEFAULT '80C',
  `amount`      decimal(12,2)    NOT NULL,
  `description` varchar(255)     DEFAULT NULL,
  `is_active`   tinyint(1)       NOT NULL DEFAULT 1,
  `created_at`  datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`  datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_80c_user_fy` (`user_id`, `fy_year`),
  KEY `idx_80c_section` (`section`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_tax_lots.sql
-- ============================================================
-- Table: tax_lots
-- Domain: 013_tax  |  Sequence: 003
-- Source: migrations/t39_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS tax_lots (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    stock_symbol VARCHAR(20) NOT NULL,
    stock_name VARCHAR(100) NOT NULL,
    buy_transaction_id BIGINT UNSIGNED,
    sell_transaction_id BIGINT UNSIGNED DEFAULT NULL,
    quantity DECIMAL(15,4) NOT NULL,
    buy_price DECIMAL(15,4) NOT NULL,
    sell_price DECIMAL(15,4) DEFAULT NULL,
    buy_date DATE NOT NULL,
    sell_date DATE DEFAULT NULL,
    gain_loss DECIMAL(15,4) DEFAULT NULL,
    tax_category ENUM('STCG','LTCG','UNREALIZED') DEFAULT 'UNREALIZED',
    financial_year VARCHAR(10) COMMENT 'e.g. 2024-25',
    grandfathered_price DECIMAL(15,4) DEFAULT NULL,
    INDEX idx_user_fy (user_id, financial_year),
    INDEX idx_symbol (stock_symbol),
    INDEX idx_category (tax_category),
    INDEX idx_sell_date (sell_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_leave_encashment.sql
-- ============================================================
-- Table: leave_encashment
-- Domain: 013_tax  |  Sequence: 004
-- Source: migrations/t49_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `leave_encashment` (
  `id`                   int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`              int(10) UNSIGNED NOT NULL,
  `encashment_date`      date             NOT NULL,
  `employer_type`        enum('govt','private') NOT NULL DEFAULT 'private',
  `amount_received`      decimal(14,2)    NOT NULL,
  `avg_10month_salary`   decimal(14,2)    NOT NULL DEFAULT 0.00,
  `leave_balance_days`   int              NOT NULL DEFAULT 0,
  `exempt_amount`        decimal(14,2)    NOT NULL DEFAULT 0.00,
  `taxable_amount`       decimal(14,2)    NOT NULL DEFAULT 0.00,
  `notes`                varchar(255)     DEFAULT NULL,
  `created_at`           datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_le_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_lta_entries.sql
-- ============================================================
-- Table: lta_entries
-- Domain: 013_tax  |  Sequence: 005
-- Source: migrations/t49_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `lta_entries` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`         int(10) UNSIGNED NOT NULL,
  `travel_date`     date             NOT NULL,
  `destination`     varchar(150)     NOT NULL,
  `mode_of_travel`  enum('air','train','bus','other') NOT NULL DEFAULT 'train',
  `actual_fare`     decimal(12,2)    NOT NULL,
  `is_claimed`      tinyint(1)       NOT NULL DEFAULT 0,
  `claim_amount`    decimal(12,2)    NOT NULL DEFAULT 0.00,
  `exempt_amount`   decimal(12,2)    NOT NULL DEFAULT 0.00,
  `taxable_amount`  decimal(12,2)    NOT NULL DEFAULT 0.00,
  `notes`           varchar(255)     DEFAULT NULL,
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_lta_user_date` (`user_id`,`travel_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_us_lrs_tracker.sql
-- ============================================================
-- Table: us_lrs_tracker
-- Domain: 013_tax  |  Sequence: 006
-- Source: migrations/t456_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `us_lrs_tracker` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `financial_year`  VARCHAR(10)  NOT NULL  COMMENT 'e.g. FY2024-25',
    `remitted_usd`    DECIMAL(14,4) NOT NULL DEFAULT 0,
    `remitted_inr`    DECIMAL(18,4) NOT NULL DEFAULT 0,
    `limit_usd`       DECIMAL(14,4) NOT NULL DEFAULT 250000  COMMENT 'RBI LRS limit: $250,000/yr',
    `notes`           TEXT DEFAULT NULL,
    `updated_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_ulrs_user_fy` (`user_id`, `financial_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_lrs_remittances.sql
-- ============================================================
-- Table: lrs_remittances
-- Domain: 013_tax  |  Sequence: 007
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS lrs_remittances (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    remittance_date DATE NOT NULL,
    amount_inr DECIMAL(15,2) NOT NULL,
    amount_foreign DECIMAL(15,4) NOT NULL,
    currency VARCHAR(5) DEFAULT 'USD',
    exchange_rate DECIMAL(10,4) NOT NULL,
    purpose VARCHAR(200) COMMENT 'Investment/Education/Travel/etc',
    bank_name VARCHAR(100),
    forex_charges DECIMAL(10,2) DEFAULT 0.00,
    tcs_paid DECIMAL(10,2) DEFAULT 0.00 COMMENT 'TCS @ 20% above 7L threshold',
    financial_year VARCHAR(10),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_fy (financial_year),
    INDEX idx_date (remittance_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 014_ai_features ───────────────────────────────────────
-- 001_ai_chat_sessions.sql
-- ============================================================
-- Table: ai_chat_sessions
-- Domain: 014_ai_features  |  Sequence: 001
-- Source: migrations/t381_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ai_chat_sessions` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      int(10) UNSIGNED NOT NULL,
  `portfolio_id` int(10) UNSIGNED DEFAULT NULL,
  `session_key`  char(36)         NOT NULL COMMENT 'UUID',
  `title`        varchar(200)     DEFAULT NULL COMMENT 'Auto-generated from first message',
  `context_snap` mediumtext       DEFAULT NULL COMMENT 'Portfolio snapshot JSON at session start',
  `message_count` int UNSIGNED    NOT NULL DEFAULT 0,
  `last_activity` datetime        NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at`   datetime         NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_session_key` (`session_key`),
  KEY `idx_acs_user`      (`user_id`),
  KEY `idx_acs_portfolio` (`portfolio_id`),
  KEY `idx_acs_activity`  (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_ai_chat_history.sql
-- ============================================================
-- Table: ai_chat_history
-- Domain: 014_ai_features  |  Sequence: 002
-- Source: migrations/t330_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t381 also has related table. This (t330) is the chatbot history. Using t330.

CREATE TABLE IF NOT EXISTS ai_chat_history (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED    NOT NULL,
  role        ENUM('user','assistant') NOT NULL,
  message     TEXT            NOT NULL,
  context_id  VARCHAR(40)     NULL,
  created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user_ctx     (user_id, context_id),
  KEY idx_user_created (user_id, created_at),
  CONSTRAINT fk_chat_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_ai_chat_messages.sql
-- ============================================================
-- Table: ai_chat_messages
-- Domain: 014_ai_features  |  Sequence: 002
-- Source: migrations/t381_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ai_chat_messages` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `session_id`   int(10) UNSIGNED NOT NULL,
  `role`         enum('user','assistant') NOT NULL,
  `content`      mediumtext       NOT NULL,
  `tokens_used`  int UNSIGNED     DEFAULT NULL,
  `created_at`   datetime         NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_acm_session` (`session_id`),
  KEY `idx_acm_created` (`created_at`),
  CONSTRAINT `fk_acm_session` FOREIGN KEY (`session_id`) REFERENCES `ai_chat_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_ai_chat_history.sql
-- ============================================================
-- Table: ai_chat_history
-- Domain: 014_ai_features  |  Sequence: 003
-- Source: migrations/t330_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ai_chat_history (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED    NOT NULL,
  role        ENUM('user','assistant') NOT NULL,
  message     TEXT            NOT NULL,
  context_id  VARCHAR(40)     NULL,
  created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user_ctx     (user_id, context_id),
  KEY idx_user_created (user_id, created_at),
  CONSTRAINT fk_chat_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_ai_chat_messages.sql
-- ============================================================
-- Table: ai_chat_messages
-- Domain: 014_ai_features  |  Sequence: 003
-- Source: migrations/t381_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ai_chat_messages` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `session_id`   int(10) UNSIGNED NOT NULL,
  `role`         enum('user','assistant') NOT NULL,
  `content`      mediumtext       NOT NULL,
  `tokens_used`  int UNSIGNED     DEFAULT NULL,
  `created_at`   datetime         NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_acm_session` (`session_id`),
  KEY `idx_acm_created` (`created_at`),
  CONSTRAINT `fk_acm_session` FOREIGN KEY (`session_id`) REFERENCES `ai_chat_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_ai_usage_log.sql
-- ============================================================
-- Table: ai_usage_log
-- Domain: 014_ai_features  |  Sequence: 004
-- Source: migrations/t381_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ai_usage_log` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      int(10) UNSIGNED NOT NULL,
  `feature`      enum('chat','review','optimizer') NOT NULL DEFAULT 'chat',
  `usage_date`   date             NOT NULL,
  `request_count` smallint UNSIGNED NOT NULL DEFAULT 0,
  `tokens_total` int UNSIGNED     NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usage_user_feature_date` (`user_id`, `feature`, `usage_date`),
  KEY `idx_aul_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_ai_advisor_sessions.sql
-- ============================================================
-- Table: ai_advisor_sessions
-- Domain: 014_ai_features  |  Sequence: 005
-- Source: migrations/t58_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ai_advisor_sessions (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL,
  session_type  ENUM('full_review','follow_up') NOT NULL DEFAULT 'full_review',
  response_json JSON         NOT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user_type (user_id, session_type, created_at),
  CONSTRAINT fk_aas_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_ai_portfolio_reviews.sql
-- ============================================================
-- Table: ai_portfolio_reviews
-- Domain: 014_ai_features  |  Sequence: 005
-- Source: migrations/t380_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t333 (fewer cols, no portfolio_id FK). Winner: t380 (portfolio_id, enum review_type)

CREATE TABLE IF NOT EXISTS `ai_portfolio_reviews` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`         int(10) UNSIGNED NOT NULL,
  `portfolio_id`    int(10) UNSIGNED NOT NULL,
  `review_month`    char(7)          NOT NULL COMMENT 'YYYY-MM',
  `review_type`     enum('monthly','quarterly','annual','on_demand') NOT NULL DEFAULT 'monthly',
  `status`          enum('pending','generating','done','error') NOT NULL DEFAULT 'pending',
  `prompt_snapshot` mediumtext       DEFAULT NULL COMMENT 'Portfolio data sent to AI (JSON)',
  `ai_response`     mediumtext       DEFAULT NULL COMMENT 'Raw AI text',
  `parsed_sections` mediumtext       DEFAULT NULL COMMENT 'JSON: {summary, strengths, concerns, actions, score}',
  `portfolio_score` tinyint UNSIGNED DEFAULT NULL COMMENT '0-100 health score',
  `tokens_used`     int UNSIGNED     DEFAULT NULL,
  `model_used`      varchar(50)      DEFAULT NULL,
  `error_message`   text             DEFAULT NULL,
  `generated_at`    datetime         DEFAULT NULL,
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_review_month` (`portfolio_id`, `review_month`, `review_type`),
  KEY `idx_apr_user`      (`user_id`),
  KEY `idx_apr_portfolio` (`portfolio_id`),
  KEY `idx_apr_month`     (`review_month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_ai_narrative_log.sql
-- ============================================================
-- Table: ai_narrative_log
-- Domain: 014_ai_features  |  Sequence: 006
-- Source: migrations/t244_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ai_narrative_log (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  month       VARCHAR(7)   NOT NULL COMMENT 'YYYY-MM',
  mode        ENUM('ai','rule_based') NOT NULL DEFAULT 'rule_based',
  narrative   TEXT         NOT NULL,
  stats       JSON         NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_month (user_id, month),
  CONSTRAINT fk_anl_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_ai_review_prefs.sql
-- ============================================================
-- Table: ai_review_prefs
-- Domain: 014_ai_features  |  Sequence: 006
-- Source: migrations/t380_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ai_review_prefs` (
  `id`                     int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`                int(10) UNSIGNED NOT NULL,
  `auto_generate_monthly`  tinyint(1) NOT NULL DEFAULT 0,
  `notify_on_ready`        tinyint(1) NOT NULL DEFAULT 1,
  `preferred_language`     varchar(10) NOT NULL DEFAULT 'hi-en' COMMENT 'hi-en=Hinglish, en=English',
  `risk_appetite`          enum('conservative','moderate','aggressive') NOT NULL DEFAULT 'moderate',
  `financial_goal`         varchar(255) DEFAULT NULL COMMENT 'Free text: what user wants to achieve',
  `updated_at`             datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_arp_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_ai_portfolio_reviews.sql
-- ============================================================
-- Table: ai_portfolio_reviews
-- Domain: 014_ai_features  |  Sequence: 007
-- Source: migrations/t380_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t333 (fewer cols). Winner: t380

CREATE TABLE IF NOT EXISTS `ai_portfolio_reviews` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`         int(10) UNSIGNED NOT NULL,
  `portfolio_id`    int(10) UNSIGNED NOT NULL,
  `review_month`    char(7)          NOT NULL COMMENT 'YYYY-MM',
  `review_type`     enum('monthly','quarterly','annual','on_demand') NOT NULL DEFAULT 'monthly',
  `status`          enum('pending','generating','done','error') NOT NULL DEFAULT 'pending',
  `prompt_snapshot` mediumtext       DEFAULT NULL COMMENT 'Portfolio data sent to AI (JSON)',
  `ai_response`     mediumtext       DEFAULT NULL COMMENT 'Raw AI text',
  `parsed_sections` mediumtext       DEFAULT NULL COMMENT 'JSON: {summary, strengths, concerns, actions, score}',
  `portfolio_score` tinyint UNSIGNED DEFAULT NULL COMMENT '0-100 health score',
  `tokens_used`     int UNSIGNED     DEFAULT NULL,
  `model_used`      varchar(50)      DEFAULT NULL,
  `error_message`   text             DEFAULT NULL,
  `generated_at`    datetime         DEFAULT NULL,
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_review_month` (`portfolio_id`, `review_month`, `review_type`),
  KEY `idx_apr_user`      (`user_id`),
  KEY `idx_apr_portfolio` (`portfolio_id`),
  KEY `idx_apr_month`     (`review_month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_ai_review_prefs.sql
-- ============================================================
-- Table: ai_review_prefs
-- Domain: 014_ai_features  |  Sequence: 008
-- Source: migrations/t380_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `ai_review_prefs` (
  `id`                     int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`                int(10) UNSIGNED NOT NULL,
  `auto_generate_monthly`  tinyint(1) NOT NULL DEFAULT 0,
  `notify_on_ready`        tinyint(1) NOT NULL DEFAULT 1,
  `preferred_language`     varchar(10) NOT NULL DEFAULT 'hi-en' COMMENT 'hi-en=Hinglish, en=English',
  `risk_appetite`          enum('conservative','moderate','aggressive') NOT NULL DEFAULT 'moderate',
  `financial_goal`         varchar(255) DEFAULT NULL COMMENT 'Free text: what user wants to achieve',
  `updated_at`             datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_arp_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 009_ai_anomalies.sql
-- ============================================================
-- Table: ai_anomalies
-- Domain: 014_ai_features  |  Sequence: 009
-- Source: 41_pending_tasks.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ai_anomalies (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    anomaly_type VARCHAR(60)  NOT NULL,
    severity     ENUM('info','warning','critical') DEFAULT 'warning',
    title        VARCHAR(200) NOT NULL,
    description  TEXT,
    data_json    TEXT,
    is_dismissed TINYINT(1) NOT NULL DEFAULT 0,
    detected_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dismissed_at DATETIME DEFAULT NULL,
    INDEX idx_user     (user_id),
    INDEX idx_severity (severity),
    INDEX idx_dismissed(is_dismissed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 010_ai_weekly_digests.sql
-- ============================================================
-- Table: ai_weekly_digests
-- Domain: 014_ai_features  |  Sequence: 010
-- Source: migrations/t329_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ai_weekly_digests (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  week_key    VARCHAR(8)   NOT NULL COMMENT 'ISO week: YYYY-WW',
  digest_json JSON         NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_week (user_id, week_key),
  KEY idx_user_id (user_id),
  CONSTRAINT fk_wd_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 011_anomaly_log.sql
-- ============================================================
-- Table: anomaly_log
-- Domain: 014_ai_features  |  Sequence: 011
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS anomaly_log (
  id           INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id      INT UNSIGNED  NOT NULL,
  scan_date    DATE          NOT NULL,
  anomaly_type VARCHAR(60)   NOT NULL,
  txn_date     DATE          NULL,
  fund_name    VARCHAR(150)  NULL,
  txn_type     VARCHAR(30)   NULL,
  amount       DECIMAL(14,2) NULL,
  reason       VARCHAR(255)  NULL,
  severity     ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
  resolved     TINYINT(1)    NOT NULL DEFAULT 0,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user_scan     (user_id, scan_date),
  KEY idx_user_resolved (user_id, resolved),
  CONSTRAINT fk_al_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 015_admin_infra ───────────────────────────────────────
-- 001_migration_log.sql
-- ============================================================
-- Table: migration_log
-- Domain: 015_admin_infra  |  Sequence: 001
-- Source: migrations/t417_migration_log.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `migration_log` (
  `id`           INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `filename`     VARCHAR(255)    NOT NULL COMMENT 'SQL file name (relative path)',
  `checksum`     VARCHAR(64)     NOT NULL COMMENT 'SHA-256 of file contents at run time',
  `batch`        SMALLINT        NOT NULL DEFAULT 1 COMMENT 'Batch number — increments per run',
  `executed_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `duration_ms`  INT             NULL     COMMENT 'Execution time in milliseconds',
  `notes`        TEXT            NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_filename` (`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_api_keys.sql
-- ============================================================
-- Table: api_keys
-- Domain: 015_admin_infra  |  Sequence: 002
-- Source: migrations/t504_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `api_keys` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `key_name` varchar(100) NOT NULL COMMENT 'e.g. My App, Home Automation',
  `api_key` varchar(64) NOT NULL COMMENT 'SHA-256 hex — shown only once at creation',
  `key_prefix` varchar(8) NOT NULL COMMENT 'First 8 chars — shown in list for identification',
  `scopes` varchar(500) NOT NULL DEFAULT 'portfolio:read' COMMENT 'CSV of allowed scopes',
  `rate_limit` int(10) UNSIGNED NOT NULL DEFAULT 60 COMMENT 'Requests per minute',
  `last_used_at` datetime DEFAULT NULL,
  `last_ip` varchar(45) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `expires_at` datetime DEFAULT NULL COMMENT 'NULL = never expires',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_api_key` (`api_key`),
  KEY `idx_apikey_user` (`user_id`),
  KEY `idx_apikey_prefix` (`key_prefix`),
  CONSTRAINT `fk_apikey_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_api_rate_limit.sql
-- ============================================================
-- Table: api_rate_limit
-- Domain: 015_admin_infra  |  Sequence: 003
-- Source: migrations/t504_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `api_rate_limit` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `api_key_id` int(10) UNSIGNED NOT NULL,
  `window_start` datetime NOT NULL,
  `request_count` int(10) UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rl_key_window` (`api_key_id`, `window_start`),
  KEY `idx_rl_window` (`window_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_api_request_log.sql
-- ============================================================
-- Table: api_request_log
-- Domain: 015_admin_infra  |  Sequence: 004
-- Source: migrations/t504_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `api_request_log` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `api_key_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `method` varchar(10) NOT NULL,
  `endpoint` varchar(200) NOT NULL,
  `status_code` smallint(5) UNSIGNED NOT NULL DEFAULT 200,
  `response_ms` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `requested_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_apirl_key` (`api_key_id`),
  KEY `idx_apirl_user` (`user_id`),
  KEY `idx_apirl_req` (`requested_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_external_api_keys.sql
-- ============================================================
-- Table: external_api_keys
-- Domain: 015_admin_infra  |  Sequence: 005
-- Source: migrations/t335_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `external_api_keys` (
    `id`            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `user_id`       INT UNSIGNED    NOT NULL,
    `name`          VARCHAR(80)     NOT NULL COMMENT 'e.g. My Excel Sheet, HomeAssistant',
    `key_prefix`    VARCHAR(12)     NOT NULL COMMENT 'Public prefix e.g. wdx_ab12cd',
    `key_hash`      VARCHAR(255)    NOT NULL COMMENT 'bcrypt hash of full key',
    `scopes`        JSON            NOT NULL COMMENT 'Array of allowed scopes',
    `rate_limit`    SMALLINT UNSIGNED NOT NULL DEFAULT 60 COMMENT 'Requests per minute',
    `last_used_at`  DATETIME        DEFAULT NULL,
    `last_ip`       VARCHAR(45)     DEFAULT NULL,
    `use_count`     BIGINT UNSIGNED NOT NULL DEFAULT 0,
    `expires_at`    DATE            DEFAULT NULL COMMENT 'NULL = never',
    `is_active`     TINYINT(1)      NOT NULL DEFAULT 1,
    `created_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_eak_prefix` (`key_prefix`),
    KEY `idx_eak_user`   (`user_id`),
    KEY `idx_eak_active` (`is_active`),
    CONSTRAINT `fk_eak_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_external_api_rate.sql
-- ============================================================
-- Table: external_api_rate
-- Domain: 015_admin_infra  |  Sequence: 006
-- Source: migrations/t335_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `external_api_rate` (
    `key_id`     INT UNSIGNED  NOT NULL,
    `window`     DATETIME      NOT NULL COMMENT 'Truncated to minute',
    `hits`       SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    PRIMARY KEY (`key_id`, `window`),
    CONSTRAINT `fk_ear_key` FOREIGN KEY (`key_id`) REFERENCES `external_api_keys`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_rate_limit_buckets.sql
-- ============================================================
-- Table: rate_limit_buckets
-- Domain: 015_admin_infra  |  Sequence: 007
-- Source: migrations/t331_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t332 identical. Winner: t331

CREATE TABLE IF NOT EXISTS rate_limit_buckets (
  bucket_key   VARCHAR(180) NOT NULL PRIMARY KEY,
  requests     SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  window_start INT UNSIGNED NOT NULL,
  KEY idx_window (window_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_rate_limit_log.sql
-- ============================================================
-- Table: rate_limit_log
-- Domain: 015_admin_infra  |  Sequence: 008
-- Source: migrations/t243_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS rate_limit_log (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NULL,
  action     VARCHAR(80)  NOT NULL,
  ip         VARCHAR(45)  NULL,
  hit_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_action_time (action, hit_at),
  KEY idx_user_action (user_id, action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 009_db_backups.sql
-- ============================================================
-- Table: db_backups
-- Domain: 015_admin_infra  |  Sequence: 009
-- Source: migrations/t211_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `db_backups` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `filepath` varchar(500) NOT NULL COMMENT 'Relative path from APP_ROOT/backups/',
  `file_size` bigint(20) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Bytes',
  `tables_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `rows_count` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `status` enum('pending','running','done','failed') NOT NULL DEFAULT 'pending',
  `notes` varchar(500) DEFAULT NULL,
  `error_msg` text DEFAULT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dbbackup_status` (`status`),
  KEY `idx_dbbackup_created` (`created_at`),
  CONSTRAINT `fk_dbbackup_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 010_db_backup_log.sql
-- ============================================================
-- Table: db_backup_log
-- Domain: 015_admin_infra  |  Sequence: 010
-- Source: migrations/t53_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `db_backup_log` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `filename`    VARCHAR(255) NOT NULL,
    `size_bytes`  BIGINT DEFAULT NULL,
    `tables`      INT DEFAULT NULL,
    `triggered_by` INT UNSIGNED DEFAULT NULL,
    `method`      ENUM('manual','cron','auto') NOT NULL DEFAULT 'manual',
    `status`      ENUM('completed','failed','in_progress') NOT NULL DEFAULT 'completed',
    `error_msg`   TEXT DEFAULT NULL,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_dbl_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 011_load_test_runs.sql
-- ============================================================
-- Table: load_test_runs
-- Domain: 015_admin_infra  |  Sequence: 011
-- Source: migrations/t415_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `load_test_runs` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `run_id`          VARCHAR(36)  NOT NULL,
    `scenario`        VARCHAR(80)  NOT NULL,
    `concurrency`     SMALLINT     NOT NULL DEFAULT 10,
    `duration_sec`    INT          NOT NULL,
    `total_requests`  INT UNSIGNED NOT NULL,
    `success_count`   INT UNSIGNED NOT NULL,
    `error_count`     INT UNSIGNED NOT NULL,
    `avg_ms`          FLOAT        DEFAULT NULL,
    `p50_ms`          FLOAT        DEFAULT NULL,
    `p95_ms`          FLOAT        DEFAULT NULL,
    `p99_ms`          FLOAT        DEFAULT NULL,
    `max_ms`          FLOAT        DEFAULT NULL,
    `rps`             FLOAT        DEFAULT NULL COMMENT 'Requests per second',
    `triggered_by`    INT UNSIGNED DEFAULT NULL,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_ltr_run`     (`run_id`),
    KEY `idx_ltr_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 012_perf_request_log.sql
-- ============================================================
-- Table: perf_request_log
-- Domain: 015_admin_infra  |  Sequence: 012
-- Source: migrations/t308_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `perf_request_log` (
    `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `action`       VARCHAR(100)    NOT NULL,
    `user_id`      INT UNSIGNED    DEFAULT NULL,
    `duration_ms`  FLOAT           NOT NULL,
    `memory_bytes` INT UNSIGNED    DEFAULT NULL,
    `db_queries`   SMALLINT        DEFAULT NULL,
    `status_code`  SMALLINT        DEFAULT 200,
    `ip_address`   VARCHAR(45)     DEFAULT NULL,
    `created_at`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_prl_action`  (`action`),
    KEY `idx_prl_created` (`created_at`),
    KEY `idx_prl_duration`(`duration_ms`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 013_perf_hourly_stats.sql
-- ============================================================
-- Table: perf_hourly_stats
-- Domain: 015_admin_infra  |  Sequence: 013
-- Source: migrations/t308_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `perf_hourly_stats` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `hour`          DATETIME     NOT NULL COMMENT 'Truncated to hour',
    `action`        VARCHAR(100) NOT NULL DEFAULT '__all__',
    `request_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `avg_ms`        FLOAT        DEFAULT NULL,
    `p95_ms`        FLOAT        DEFAULT NULL,
    `max_ms`        FLOAT        DEFAULT NULL,
    `error_count`   INT UNSIGNED NOT NULL DEFAULT 0,
    `avg_memory_mb` FLOAT        DEFAULT NULL,
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_phs_hour_action` (`hour`, `action`),
    KEY `idx_phs_hour` (`hour`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 014_perf_baselines.sql
-- ============================================================
-- Table: perf_baselines
-- Domain: 015_admin_infra  |  Sequence: 014
-- Source: migrations/t412_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `perf_baselines` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `action`      VARCHAR(100) NOT NULL,
    `baseline_ms` FLOAT        NOT NULL,
    `threshold_ms`FLOAT        NOT NULL,
    `measured_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_pb_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 015_perf_slow_alerts.sql
-- ============================================================
-- Table: perf_slow_alerts
-- Domain: 015_admin_infra  |  Sequence: 015
-- Source: migrations/t308_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `perf_slow_alerts` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `action`      VARCHAR(100) NOT NULL,
    `duration_ms` FLOAT        NOT NULL,
    `threshold_ms`FLOAT        NOT NULL,
    `user_id`     INT UNSIGNED DEFAULT NULL,
    `ip_address`  VARCHAR(45)  DEFAULT NULL,
    `context`     TEXT         DEFAULT NULL,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_psa_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 016_system_health_log.sql
-- ============================================================
-- Table: system_health_log
-- Domain: 015_admin_infra  |  Sequence: 016
-- Source: migrations/t51_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `system_health_log` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `snap_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `php_memory`   INT UNSIGNED DEFAULT NULL COMMENT 'bytes',
    `db_size_mb`   DECIMAL(10,2) DEFAULT NULL,
    `slow_queries` INT UNSIGNED DEFAULT NULL,
    `cache_hits`   INT UNSIGNED DEFAULT NULL,
    `cache_misses` INT UNSIGNED DEFAULT NULL,
    `active_users` INT UNSIGNED DEFAULT NULL,
    `error_count`  INT UNSIGNED DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_shl_snap` (`snap_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 017_audit_retention_config.sql
-- ============================================================
-- Table: audit_retention_config
-- Domain: 015_admin_infra  |  Sequence: 017
-- Source: migrations/t307_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `audit_retention_config` (
    `id`               TINYINT UNSIGNED NOT NULL DEFAULT 1,
    `retention_days`   INT UNSIGNED NOT NULL DEFAULT 365,
    `auto_purge`       TINYINT(1) NOT NULL DEFAULT 0,
    `last_purge_at`    DATETIME DEFAULT NULL,
    `rows_purged`      BIGINT UNSIGNED NOT NULL DEFAULT 0,
    `updated_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 018_cron_run_log.sql
-- ============================================================
-- Table: cron_run_log
-- Domain: 015_admin_infra  |  Sequence: 018
-- Source: migrations/t309_cron_job_dashboard.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `cron_run_log` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `job_name`    VARCHAR(80)  NOT NULL COMMENT 'e.g. update_nav_daily',
  `started_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `finished_at` DATETIME     NULL,
  `status`      ENUM('running','success','warning','failed') NOT NULL DEFAULT 'running',
  `duration_ms` INT UNSIGNED NULL     COMMENT 'Execution time in milliseconds',
  `records`     INT UNSIGNED NULL     COMMENT 'Records processed',
  `message`     TEXT         NULL     COMMENT 'Summary / error message',
  PRIMARY KEY (`id`),
  KEY `idx_cron_job_started` (`job_name`, `started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 019_error_events.sql
-- ============================================================
-- Table: error_events
-- Domain: 015_admin_infra  |  Sequence: 019
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `error_events` (
    `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `fingerprint`  VARCHAR(64)     NOT NULL COMMENT 'SHA1 of type+file+line',
    `error_type`   VARCHAR(80)     NOT NULL COMMENT 'E_ERROR, E_WARNING, Exception, etc.',
    `message`      TEXT            NOT NULL,
    `file`         VARCHAR(300)    DEFAULT NULL,
    `line`         INT UNSIGNED    DEFAULT NULL,
    `stack_trace`  TEXT            DEFAULT NULL,
    `url`          VARCHAR(500)    DEFAULT NULL,
    `user_id`      INT UNSIGNED    DEFAULT NULL,
    `ip_address`   VARCHAR(45)     DEFAULT NULL,
    `user_agent`   VARCHAR(300)    DEFAULT NULL,
    `env`          VARCHAR(20)     DEFAULT NULL,
    `first_seen`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `last_seen`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `count`        INT UNSIGNED    NOT NULL DEFAULT 1,
    `is_resolved`  TINYINT(1)      NOT NULL DEFAULT 0,
    `resolved_at`  DATETIME        DEFAULT NULL,
    `resolved_by`  INT UNSIGNED    DEFAULT NULL,
    `notes`        TEXT            DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_ee_fingerprint` (`fingerprint`),
    KEY `idx_ee_type`       (`error_type`),
    KEY `idx_ee_resolved`   (`is_resolved`),
    KEY `idx_ee_last_seen`  (`last_seen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 020_db_query_log.sql
-- ============================================================
-- Table: db_query_log
-- Domain: 015_admin_infra  |  Sequence: 020
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `db_query_log` (
    `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`     INT UNSIGNED    NOT NULL,
    `query_text`  TEXT            NOT NULL,
    `rows_affected` INT DEFAULT NULL,
    `exec_ms`     FLOAT DEFAULT NULL,
    `is_success`  TINYINT(1) NOT NULL DEFAULT 1,
    `error_msg`   TEXT DEFAULT NULL,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_dql_user` (`user_id`),
    KEY `idx_dql_created` (`created_at`),
    CONSTRAINT `fk_dql_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 021_db_restore_log.sql
-- ============================================================
-- Table: db_restore_log
-- Domain: 015_admin_infra  |  Sequence: 021
-- Source: migrations/t211_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `db_restore_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `backup_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'NULL if manual upload',
  `filename` varchar(255) NOT NULL,
  `status` enum('pending','running','done','failed') NOT NULL DEFAULT 'pending',
  `tables_restored` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `error_msg` text DEFAULT NULL,
  `restored_by` int(10) UNSIGNED NOT NULL,
  `started_at` datetime NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dbrestore_status` (`status`),
  KEY `idx_dbrestore_started` (`started_at`),
  CONSTRAINT `fk_dbrestore_user` FOREIGN KEY (`restored_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 022_dedup_review_log.sql
-- ============================================================
-- Table: dedup_review_log
-- Domain: 015_admin_infra  |  Sequence: 022
-- Source: migrations/t479_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `dedup_review_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_type` enum('mf','stocks','nps') NOT NULL,
  `txn_id` int(10) UNSIGNED NOT NULL,
  `action` enum('merged','dismissed','kept') NOT NULL,
  `reviewed_by` int(10) UNSIGNED NOT NULL,
  `reviewed_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_dedup_txn` (`asset_type`, `txn_id`),
  KEY `idx_dedup_user` (`reviewed_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 023_test_run_log.sql
-- ============================================================
-- Table: test_run_log
-- Domain: 015_admin_infra  |  Sequence: 023
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `test_run_log` (
    `id`           INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `run_id`       VARCHAR(36)     NOT NULL COMMENT 'UUID per run',
    `suite`        VARCHAR(60)     NOT NULL COMMENT 'unit | integration | e2e | perf',
    `test_name`    VARCHAR(120)    NOT NULL,
    `status`       ENUM('pass','fail','skip','error') NOT NULL,
    `duration_ms`  FLOAT           DEFAULT NULL,
    `message`      TEXT            DEFAULT NULL,
    `triggered_by` INT UNSIGNED    DEFAULT NULL,
    `created_at`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_trl_run`     (`run_id`),
    KEY `idx_trl_suite`   (`suite`),
    KEY `idx_trl_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 024_validation_rules.sql
-- ============================================================
-- Table: validation_rules
-- Domain: 015_admin_infra  |  Sequence: 024
-- Source: migrations/t480_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `validation_rules` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `rule_key` varchar(100) NOT NULL COMMENT 'e.g. mf_units_min, stock_price_max',
  `asset_type` enum('mf','stocks','nps','fd','savings','gold','realestate','crypto','all') NOT NULL DEFAULT 'all',
  `field_name` varchar(100) NOT NULL,
  `rule_type` enum('min','max','required','regex','enum','date_past','date_future','positive','nonzero') NOT NULL,
  `rule_value` varchar(500) DEFAULT NULL COMMENT 'numeric threshold or regex pattern or enum CSV',
  `error_msg` varchar(500) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rule_key` (`rule_key`),
  KEY `idx_vr_asset` (`asset_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 025_validation_violations.sql
-- ============================================================
-- Table: validation_violations
-- Domain: 015_admin_infra  |  Sequence: 025
-- Source: migrations/t480_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `validation_violations` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `asset_type` varchar(50) NOT NULL,
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `rule_key` varchar(100) NOT NULL,
  `field_name` varchar(100) NOT NULL,
  `bad_value` varchar(500) DEFAULT NULL,
  `error_msg` varchar(500) NOT NULL,
  `is_resolved` tinyint(1) NOT NULL DEFAULT 0,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_vv_portfolio` (`portfolio_id`),
  KEY `idx_vv_asset` (`asset_type`),
  KEY `idx_vv_resolved` (`is_resolved`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 026_automation_rules.sql
-- ============================================================
-- Table: automation_rules
-- Domain: 015_admin_infra  |  Sequence: 026
-- ============================================================
-- !! STUB: NOT FOUND in any SQL file — never built, stub placeholder
-- !! Define the actual schema before running.
-- ============================================================

CREATE TABLE IF NOT EXISTS `automation_rules` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  -- TODO: define columns
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 027_external_api_log.sql
-- ============================================================
-- Table: external_api_log
-- Domain: 015_admin_infra  |  Sequence: 027
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `external_api_log` (
    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `key_id`     INT UNSIGNED    NOT NULL,
    `endpoint`   VARCHAR(120)    NOT NULL,
    `method`     VARCHAR(8)      NOT NULL DEFAULT 'GET',
    `status`     SMALLINT        NOT NULL DEFAULT 200,
    `duration_ms`FLOAT           DEFAULT NULL,
    `ip_address` VARCHAR(45)     DEFAULT NULL,
    `created_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_eal_key`     (`key_id`),
    KEY `idx_eal_created` (`created_at`),
    CONSTRAINT `fk_eal_key` FOREIGN KEY (`key_id`) REFERENCES `external_api_keys`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 016_import_export ─────────────────────────────────────
-- 001_import_versions.sql
-- ============================================================
-- Table: import_versions
-- Domain: 016_import_export  |  Sequence: 001
-- Source: migrations/t336_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `import_versions` (
    `id`            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `user_id`       INT UNSIGNED    NOT NULL,
    `portfolio_id`  INT UNSIGNED    NOT NULL,
    `import_type`   VARCHAR(40)     NOT NULL COMMENT 'mf_csv, stocks_csv, fd_manual, cas_pdf, etc.',
    `label`         VARCHAR(120)    NOT NULL,
    `snapshot_data` LONGTEXT        NOT NULL COMMENT 'JSON snapshot of affected rows before import',
    `affected_table`VARCHAR(60)     NOT NULL,
    `affected_ids`  JSON            NOT NULL COMMENT 'Array of inserted/modified row IDs',
    `rows_added`    INT UNSIGNED    NOT NULL DEFAULT 0,
    `rows_modified` INT UNSIGNED    NOT NULL DEFAULT 0,
    `rows_deleted`  INT UNSIGNED    NOT NULL DEFAULT 0,
    `file_name`     VARCHAR(255)    DEFAULT NULL,
    `file_hash`     VARCHAR(64)     DEFAULT NULL COMMENT 'SHA256 of original file',
    `status`        ENUM('active','undone','partial') NOT NULL DEFAULT 'active',
    `undone_at`     DATETIME        DEFAULT NULL,
    `undone_by`     INT UNSIGNED    DEFAULT NULL,
    `created_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_iv_user`       (`user_id`),
    KEY `idx_iv_portfolio`  (`portfolio_id`),
    KEY `idx_iv_type`       (`import_type`),
    KEY `idx_iv_status`     (`status`),
    CONSTRAINT `fk_iv_user`      FOREIGN KEY (`user_id`)      REFERENCES `users`(`id`)      ON DELETE CASCADE,
    CONSTRAINT `fk_iv_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_import_row_changes.sql
-- ============================================================
-- Table: import_row_changes
-- Domain: 016_import_export  |  Sequence: 002
-- Source: migrations/t336_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `import_row_changes` (
    `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `version_id`    INT UNSIGNED    NOT NULL,
    `table_name`    VARCHAR(60)     NOT NULL,
    `row_id`        INT UNSIGNED    NOT NULL,
    `change_type`   ENUM('insert','update','delete') NOT NULL,
    `old_data`      JSON            DEFAULT NULL,
    `new_data`      JSON            DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_irc_version` (`version_id`),
    KEY `idx_irc_table_row` (`table_name`, `row_id`),
    CONSTRAINT `fk_irc_version` FOREIGN KEY (`version_id`) REFERENCES `import_versions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_data_export_requests.sql
-- ============================================================
-- Table: data_export_requests
-- Domain: 016_import_export  |  Sequence: 003
-- Source: migrations/t389_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS data_export_requests (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED  NOT NULL,
  filename    VARCHAR(255)  NOT NULL,
  file_size   INT UNSIGNED  NOT NULL DEFAULT 0,
  status      ENUM('processing','ready','expired') NOT NULL DEFAULT 'ready',
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at  DATETIME      NOT NULL,
  KEY idx_user (user_id),
  CONSTRAINT fk_der_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_groww_import_sessions.sql
-- ============================================================
-- Table: groww_import_sessions
-- Domain: 016_import_export  |  Sequence: 004
-- Source: migrations/t302_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_import_sessions` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `import_type`     ENUM('csv','api','manual') NOT NULL DEFAULT 'csv',
    `filename`        VARCHAR(255) DEFAULT NULL,
    `status`          ENUM('pending','processing','done','failed','partial') NOT NULL DEFAULT 'pending',
    `total_rows`      INT UNSIGNED DEFAULT 0,
    `imported`        INT UNSIGNED DEFAULT 0,
    `skipped`         INT UNSIGNED DEFAULT 0,
    `errors`          INT UNSIGNED DEFAULT 0,
    `mf_count`        INT UNSIGNED DEFAULT 0,
    `stock_count`     INT UNSIGNED DEFAULT 0,
    `error_log`       TEXT DEFAULT NULL,
    `raw_response`    MEDIUMTEXT DEFAULT NULL COMMENT 'Raw JSON/CSV for audit',
    `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user`      (`user_id`),
    INDEX `idx_portfolio` (`portfolio_id`),
    INDEX `idx_status`    (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_groww_sync_log.sql
-- ============================================================
-- Table: groww_sync_log
-- Domain: 016_import_export  |  Sequence: 005
-- Source: migrations/t392_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_sync_log` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `sync_type`       ENUM('mf_holdings','mf_transactions','stock_holdings','stock_transactions','full') NOT NULL,
    `status`          ENUM('running','done','failed','partial') NOT NULL DEFAULT 'running',
    `mf_synced`       INT UNSIGNED DEFAULT 0,
    `stock_synced`    INT UNSIGNED DEFAULT 0,
    `errors`          INT UNSIGNED DEFAULT 0,
    `error_detail`    TEXT DEFAULT NULL,
    `api_calls`       INT UNSIGNED DEFAULT 0,
    `started_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    `completed_at`    DATETIME DEFAULT NULL,
    INDEX `idx_user`  (`user_id`),
    INDEX `idx_date`  (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_groww_api_credentials.sql
-- ============================================================
-- Table: groww_api_credentials
-- Domain: 016_import_export  |  Sequence: 006
-- Source: migrations/t392_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_api_credentials` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL UNIQUE,
    `access_token`    TEXT         DEFAULT NULL COMMENT 'Encrypted bearer token',
    `refresh_token`   TEXT         DEFAULT NULL COMMENT 'Encrypted refresh token',
    `token_expires_at` DATETIME    DEFAULT NULL,
    `linked_email`    VARCHAR(200) DEFAULT NULL,
    `linked_mobile`   VARCHAR(15)  DEFAULT NULL,
    `scope`           VARCHAR(200) DEFAULT NULL COMMENT 'mf,stocks,profile',
    `status`          ENUM('active','expired','revoked','error') NOT NULL DEFAULT 'active',
    `last_sync_at`    DATETIME     DEFAULT NULL,
    `last_sync_type`  VARCHAR(50)  DEFAULT NULL,
    `error_msg`       VARCHAR(500) DEFAULT NULL,
    `created_at`      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user`   (`user_id`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_bulk_import_sessions.sql
-- ============================================================
-- Table: bulk_import_sessions
-- Domain: 016_import_export  |  Sequence: 007
-- Source: migrations/t334_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `bulk_import_sessions` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `import_source`   VARCHAR(50)  NOT NULL DEFAULT 'excel' COMMENT 'excel|csv|api',
    `asset_type`      ENUM('mf','stocks','fd','gold','reits','smallcase','mixed') NOT NULL DEFAULT 'mf',
    `filename`        VARCHAR(255) DEFAULT NULL,
    `status`          ENUM('pending','validating','importing','done','failed','partial') DEFAULT 'pending',
    `total_rows`      INT UNSIGNED DEFAULT 0,
    `valid_rows`      INT UNSIGNED DEFAULT 0,
    `imported`        INT UNSIGNED DEFAULT 0,
    `skipped`         INT UNSIGNED DEFAULT 0,
    `error_count`     INT UNSIGNED DEFAULT 0,
    `validation_log`  MEDIUMTEXT DEFAULT NULL COMMENT 'JSON array of validation errors',
    `import_log`      MEDIUMTEXT DEFAULT NULL COMMENT 'JSON array of import results',
    `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user`      (`user_id`),
    INDEX `idx_portfolio` (`portfolio_id`),
    INDEX `idx_status`    (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_bulk_import_templates.sql
-- ============================================================
-- Table: bulk_import_templates
-- Domain: 016_import_export  |  Sequence: 008
-- Source: migrations/t334_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `bulk_import_templates` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `version`         VARCHAR(20)  NOT NULL UNIQUE,
    `asset_type`      VARCHAR(50)  NOT NULL,
    `field_count`     INT UNSIGNED NOT NULL DEFAULT 0,
    `fields_json`     MEDIUMTEXT   NOT NULL COMMENT 'JSON array of field definitions',
    `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 009_csv_import_v3_sessions.sql
-- ============================================================
-- Table: csv_import_v3_sessions
-- Domain: 016_import_export  |  Sequence: 009
-- Source: migrations/t490_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `csv_import_v3_sessions` (
    `id`                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`           INT UNSIGNED NOT NULL,
    `portfolio_id`      INT UNSIGNED DEFAULT NULL,
    `filename`          VARCHAR(255) DEFAULT NULL,
    `file_size`         INT UNSIGNED DEFAULT NULL,
    `detected_format`   VARCHAR(50)  DEFAULT NULL,
    `format_label`      VARCHAR(100) DEFAULT NULL,
    `confidence`        TINYINT UNSIGNED DEFAULT 0,
    `col_mapping_json`  TEXT         DEFAULT NULL COMMENT 'JSON of column index map',
    `header_row_index`  TINYINT UNSIGNED DEFAULT 0,
    `total_data_rows`   INT UNSIGNED DEFAULT 0,
    `preview_json`      MEDIUMTEXT   DEFAULT NULL COMMENT 'First 10 rows preview',
    `action`            ENUM('detect','import','preview') DEFAULT 'detect',
    `imported`          INT UNSIGNED DEFAULT 0,
    `skipped`           INT UNSIGNED DEFAULT 0,
    `errors`            INT UNSIGNED DEFAULT 0,
    `error_rows_json`   MEDIUMTEXT   DEFAULT NULL,
    `status`            ENUM('detected','previewed','imported','failed') DEFAULT 'detected',
    `created_at`        DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user`       (`user_id`),
    INDEX `idx_portfolio`  (`portfolio_id`),
    INDEX `idx_format`     (`detected_format`),
    INDEX `idx_created`    (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 010_csv_column_mapping_presets.sql
-- ============================================================
-- Table: csv_column_mapping_presets
-- Domain: 016_import_export  |  Sequence: 010
-- Source: migrations/t490_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `csv_column_mapping_presets` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`     INT UNSIGNED NOT NULL,
    `name`        VARCHAR(100) NOT NULL COMMENT 'e.g. My CAMS Format',
    `format_hint` VARCHAR(50)  DEFAULT NULL,
    `mapping_json`TEXT         NOT NULL COMMENT 'JSON column mapping',
    `use_count`   INT UNSIGNED DEFAULT 0,
    `last_used`   DATETIME     DEFAULT NULL,
    `created_at`  DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 011_spending_discipline.sql
-- ============================================================
-- Table: spending_discipline
-- Domain: 016_import_export  |  Sequence: 011
-- Source: 44_v48_sprint_tables.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `spending_discipline` (
  `id`             INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `user_id`        INT UNSIGNED   NOT NULL,
  `monthly_income` DECIMAL(15,2)  NOT NULL DEFAULT 0,
  `target_pct`     DECIMAL(5,2)   NOT NULL DEFAULT 20.00,
  `updated_at`     DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP
                   ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 017_reports_sharing ───────────────────────────────────
-- 001_report_shares.sql
-- ============================================================
-- Table: report_shares
-- Domain: 017_reports_sharing  |  Sequence: 001
-- Source: migrations/t378_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS report_shares (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  channel     ENUM('whatsapp','email') NOT NULL,
  report_type VARCHAR(40)  NOT NULL DEFAULT 'summary',
  recipient   VARCHAR(150) NULL,
  success     TINYINT(1)   NOT NULL DEFAULT 1,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user (user_id),
  CONSTRAINT fk_rs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_report_share_tokens.sql
-- ============================================================
-- Table: report_share_tokens
-- Domain: 017_reports_sharing  |  Sequence: 002
-- Source: migrations/t378_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS report_share_tokens (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  token       VARCHAR(64)  NOT NULL UNIQUE,
  expires_at  DATETIME     NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_token (token),
  CONSTRAINT fk_rst_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_scheduled_reports.sql
-- ============================================================
-- Table: scheduled_reports
-- Domain: 017_reports_sharing  |  Sequence: 003
-- Source: migrations/t379_scheduled_reports.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `scheduled_reports` (
    `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`       INT UNSIGNED NOT NULL,
    `report_type`   ENUM('net_worth','portfolio_summary','fy_gains','fd_summary','sip_summary','full_report') NOT NULL DEFAULT 'portfolio_summary',
    `frequency`     ENUM('daily','weekly','monthly') NOT NULL DEFAULT 'monthly',
    `day_of_week`   TINYINT UNSIGNED DEFAULT NULL COMMENT '0=Sun,1=Mon,...,6=Sat — used when frequency=weekly',
    `day_of_month`  TINYINT UNSIGNED DEFAULT NULL COMMENT '1-28 — used when frequency=monthly',
    `send_hour`     TINYINT UNSIGNED NOT NULL DEFAULT 8 COMMENT 'Hour in IST (0-23) to send the report',
    `email`         VARCHAR(320) DEFAULT NULL COMMENT 'Override email; NULL = use account email',
    `is_active`     TINYINT(1) NOT NULL DEFAULT 1,
    `last_sent_at`  DATETIME DEFAULT NULL,
    `next_send_at`  DATETIME DEFAULT NULL,
    `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_sr_user`      (`user_id`),
    KEY `idx_sr_next_send` (`next_send_at`, `is_active`),
    CONSTRAINT `fk_sr_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_comparison_snapshots.sql
-- ============================================================
-- Table: comparison_snapshots
-- Domain: 017_reports_sharing  |  Sequence: 004
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `comparison_snapshots` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      int(10) UNSIGNED NOT NULL,
  `snapshot_key` varchar(40)      NOT NULL COMMENT 'e.g. epf_nps_ppf_2024-25',
  `payload`      mediumtext       NOT NULL COMMENT 'JSON snapshot of comparison',
  `expires_at`   datetime         NOT NULL,
  `created_at`   datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_snap_user_key` (`user_id`, `snapshot_key`),
  KEY `idx_snap_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_morning_briefings.sql
-- ============================================================
-- Table: morning_briefings
-- Domain: 017_reports_sharing  |  Sequence: 005
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS morning_briefings (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id        INT UNSIGNED NOT NULL,
  briefing_date  DATE         NOT NULL,
  briefing_json  JSON         NOT NULL,
  created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_date (user_id, briefing_date),
  CONSTRAINT fk_mb_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 018_journal_gamification ──────────────────────────────
-- 001_journal_entries.sql
-- ============================================================
-- Table: journal_entries
-- Domain: 018_journal_gamification  |  Sequence: 001
-- Source: migrations/th001_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS journal_entries (
  id              INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id         INT UNSIGNED  NOT NULL,
  entry_date      DATE          NOT NULL,
  title           VARCHAR(150)  NOT NULL DEFAULT 'Journal Entry',
  content         TEXT          NOT NULL,
  mood            ENUM('confident','optimistic','neutral','anxious','fearful','excited','regretful') NOT NULL DEFAULT 'neutral',
  tags            VARCHAR(255)  NULL COMMENT 'comma-separated',
  related_action  VARCHAR(40)   NULL,
  created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME      NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_user_date (user_id, entry_date),
  FULLTEXT KEY ft_content (title, content),
  CONSTRAINT fk_je_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_investor_streaks.sql
-- ============================================================
-- Table: investor_streaks
-- Domain: 018_journal_gamification  |  Sequence: 002
-- Source: migrations/t242_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS investor_streaks (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id         INT UNSIGNED NOT NULL UNIQUE,
  current_streak  INT UNSIGNED NOT NULL DEFAULT 0,
  longest_streak  INT UNSIGNED NOT NULL DEFAULT 0,
  last_checked    DATETIME     NULL,
  CONSTRAINT fk_is_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_user_badges.sql
-- ============================================================
-- Table: user_badges
-- Domain: 018_journal_gamification  |  Sequence: 003
-- Source: migrations/t242_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS user_badges (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  badge_key   VARCHAR(40)  NOT NULL,
  earned_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_badge (user_id, badge_key),
  CONSTRAINT fk_ub_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_investment_journal.sql
-- ============================================================
-- Table: investment_journal
-- Domain: 018_journal_gamification  |  Sequence: 004
-- Source: 44_v48_sprint_tables.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `investment_journal` (
  `id`                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`              INT UNSIGNED NOT NULL,
  `entry_date`           DATE         NOT NULL,
  `title`                VARCHAR(200) NOT NULL DEFAULT '',
  `body`                 TEXT         NOT NULL,
  `mood`                 ENUM('bullish','bearish','neutral','anxious','confident')
                         NOT NULL DEFAULT 'neutral',
  `tags`                 JSON         DEFAULT NULL
                         COMMENT 'Array of tag strings e.g. ["HDFC Flexi","market"]',
  `linked_fund_id`       INT UNSIGNED DEFAULT NULL,
  `portfolio_change_pct` DECIMAL(6,2) DEFAULT NULL,
  `nifty_change_pct`     DECIMAL(6,2) DEFAULT NULL,
  `is_private`           TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                         ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`, `entry_date`),
  KEY `idx_user_id`   (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_corporate_actions.sql
-- ============================================================
-- Table: corporate_actions
-- Domain: 018_journal_gamification  |  Sequence: 005
-- Source: migrations/t434_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `corporate_actions` (
    `id`                  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`        INT UNSIGNED NOT NULL,
    `stock_id`            INT UNSIGNED NOT NULL,
    `type`                ENUM('bonus','split','dividend','rights','buyback','merger','demerger') NOT NULL,
    `ex_date`             DATE         NOT NULL,
    `record_date`         DATE         DEFAULT NULL,
    `bonus_ratio`         VARCHAR(20)  DEFAULT NULL   COMMENT 'e.g. 1:1, 1:2',
    `split_old`           SMALLINT UNSIGNED DEFAULT NULL COMMENT 'old face value',
    `split_new`           SMALLINT UNSIGNED DEFAULT NULL COMMENT 'new face value',
    `dividend_per_share`  DECIMAL(10,4) DEFAULT NULL,
    `rights_ratio`        VARCHAR(20)  DEFAULT NULL,
    `rights_price`        DECIMAL(12,4) DEFAULT NULL,
    `is_applied`          TINYINT(1)   NOT NULL DEFAULT 0,
    `applied_at`          DATETIME     DEFAULT NULL,
    `notes`               TEXT         DEFAULT NULL,
    `created_at`          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_ca_portfolio` (`portfolio_id`),
    INDEX `idx_ca_stock`     (`stock_id`),
    INDEX `idx_ca_date`      (`ex_date`),
    INDEX `idx_ca_pending`   (`is_applied`, `ex_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 019_notifications_alerts ──────────────────────────────
-- 001_notifications.sql
-- ============================================================
-- Table: notifications
-- Domain: 019_notifications_alerts  |  Sequence: 001
-- Source: 10_notifications.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t373 also. Winner: 10_ (original numbered schema)

CREATE TABLE IF NOT EXISTS `notifications` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED  NOT NULL,
  `type`         ENUM('nav_alert','fd_maturity','sip_reminder','drawdown','nfo_closing','system','goal','tax') NOT NULL,
  `title`        VARCHAR(300)  NOT NULL,
  `body`         TEXT          NOT NULL,
  `link_url`     VARCHAR(500)  DEFAULT NULL COMMENT 'Click pe kahan jaaye',
  `is_read`      TINYINT(1)    NOT NULL DEFAULT 0,
  `triggered_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `read_at`      DATETIME      DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notif_user_unread` (`user_id`, `is_read`, `triggered_at`),
  KEY `idx_notif_type`        (`type`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Notifications Center — sab alerts ek jagah';

-- 002_notification_prefs.sql
-- ============================================================
-- Table: notification_prefs
-- Domain: 019_notifications_alerts  |  Sequence: 002
-- Source: 10_notifications.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `notification_prefs` (
  `user_id`         INT UNSIGNED NOT NULL,
  `nav_alerts`      TINYINT(1)   NOT NULL DEFAULT 1,
  `fd_maturity`     TINYINT(1)   NOT NULL DEFAULT 1,
  `sip_reminder`    TINYINT(1)   NOT NULL DEFAULT 1,
  `drawdown_alerts` TINYINT(1)   NOT NULL DEFAULT 1,
  `nfo_alerts`      TINYINT(1)   NOT NULL DEFAULT 1,
  `tax_reminders`   TINYINT(1)   NOT NULL DEFAULT 1,
  `updated_at`      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_np_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_price_alerts.sql
-- ============================================================
-- Table: price_alerts (originally stock_price_alerts)
-- Domain: 019_notifications_alerts  |  Sequence: 003
-- Source: migrations/t344_t345_stock_alerts.sql
-- ============================================================
-- Note: Original table name was stock_price_alerts — kept as
-- price_alerts here for consistency with the notifications domain.
-- If your codebase uses stock_price_alerts, rename accordingly.
-- ============================================================

CREATE TABLE IF NOT EXISTS `price_alerts` (
  `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED  NOT NULL,
  `stock_id`      INT UNSIGNED  NOT NULL,
  `symbol`        VARCHAR(30)   NOT NULL,
  `company_name`  VARCHAR(200)  DEFAULT NULL,
  `alert_type`    ENUM('above','below','pct_up','pct_down') NOT NULL,
  `target_price`  DECIMAL(12,2) NOT NULL,
  `note`          VARCHAR(300)  DEFAULT NULL,
  `is_active`     TINYINT(1)    NOT NULL DEFAULT 1,
  `triggered_at`  DATETIME      DEFAULT NULL,
  `triggered_price` DECIMAL(12,2) DEFAULT NULL,
  `notify_browser` TINYINT(1)   NOT NULL DEFAULT 1,
  `notify_email`   TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_spa_user`   (`user_id`, `is_active`),
  KEY `idx_spa_stock`  (`stock_id`),
  KEY `idx_spa_symbol` (`symbol`),
  CONSTRAINT `fk_spa_user`  FOREIGN KEY (`user_id`)  REFERENCES `users`(`id`)        ON DELETE CASCADE,
  CONSTRAINT `fk_spa_stock` FOREIGN KEY (`stock_id`) REFERENCES `stock_master`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Stock price alerts — NSE/BSE target price notifications';

-- 004_smart_alerts.sql
-- ============================================================
-- Table: smart_alerts
-- Domain: 019_notifications_alerts  |  Sequence: 004
-- Source: migrations/t404_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smart_alerts (
  id            INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED  NOT NULL,
  alert_type    VARCHAR(40)   NOT NULL,
  dedup_key     VARCHAR(150)  NOT NULL,
  icon          VARCHAR(8)    NULL,
  message       VARCHAR(255)  NOT NULL,
  severity      ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
  relevant_date DATE          NULL,
  is_read       TINYINT(1)    NOT NULL DEFAULT 0,
  created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_dedup (user_id, dedup_key),
  KEY idx_user_read (user_id, is_read),
  CONSTRAINT fk_sa_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_smart_alert_settings.sql
-- ============================================================
-- Table: smart_alert_settings
-- Domain: 019_notifications_alerts  |  Sequence: 005
-- Source: migrations/t404_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smart_alert_settings (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id         INT UNSIGNED NOT NULL UNIQUE,
  sip_due         TINYINT(1)   NOT NULL DEFAULT 1,
  insurance_due   TINYINT(1)   NOT NULL DEFAULT 1,
  loan_emi_due    TINYINT(1)   NOT NULL DEFAULT 1,
  drawdown_alert  TINYINT(1)   NOT NULL DEFAULT 1,
  gain_alert      TINYINT(1)   NOT NULL DEFAULT 1,
  goal_milestone  TINYINT(1)   NOT NULL DEFAULT 1,
  CONSTRAINT fk_sas_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_nudge_dismissals.sql
-- ============================================================
-- Table: nudge_dismissals
-- Domain: 019_notifications_alerts  |  Sequence: 006
-- Source: 44_v48_sprint_tables.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nudge_dismissals` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED NOT NULL,
  `nudge_id`     VARCHAR(60)  NOT NULL,
  `dismissed_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_nudge` (`user_id`, `nudge_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 020_dashboard_ui ──────────────────────────────────────
-- 001_dashboard_layouts.sql
-- ============================================================
-- Table: dashboard_layouts
-- Domain: 020_dashboard_ui  |  Sequence: 001
-- Source: migrations/t297_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS dashboard_layouts (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL UNIQUE,
  layout      JSON         NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_dl_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_dashboard_widget_layouts.sql
-- ============================================================
-- Table: dashboard_widget_layouts
-- Domain: 020_dashboard_ui  |  Sequence: 002
-- Source: migrations/t55_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS dashboard_widget_layouts (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL UNIQUE,
  layout_json JSON         NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_dwl_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_overview_card_prefs.sql
-- ============================================================
-- Table: overview_card_prefs
-- Domain: 020_dashboard_ui  |  Sequence: 003
-- Source: migrations/t445_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS overview_card_prefs (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL UNIQUE,
  card_order  JSON         NOT NULL,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ocp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_user_onboarding.sql
-- ============================================================
-- Table: user_onboarding
-- Domain: 020_dashboard_ui  |  Sequence: 004
-- Source: migrations/t454_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t240 fewer cols. Winner: t454

CREATE TABLE IF NOT EXISTS user_onboarding (
  id                INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id           INT UNSIGNED NOT NULL UNIQUE,
  completed_steps   JSON         NOT NULL DEFAULT ('[]'),
  skipped           TINYINT(1)   NOT NULL DEFAULT 0,
  wizard_completed  TINYINT(1)   NOT NULL DEFAULT 0,
  wizard_data       JSON         NULL,
  started_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ob_user_wizard FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_net_worth_snapshots.sql
-- ============================================================
-- Table: net_worth_snapshots
-- Domain: 020_dashboard_ui  |  Sequence: 005
-- Source: 20_networth_timeline.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `net_worth_snapshots` (
  `id`            int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`       int(10) UNSIGNED NOT NULL,
  `snapshot_date` date NOT NULL COMMENT '1st of each month',
  `total_value`   decimal(20,2) NOT NULL DEFAULT 0.00,
  `mf_value`      decimal(20,2) NOT NULL DEFAULT 0.00,
  `stock_value`   decimal(20,2) NOT NULL DEFAULT 0.00,
  `fd_value`      decimal(20,2) NOT NULL DEFAULT 0.00,
  `savings_value` decimal(20,2) NOT NULL DEFAULT 0.00,
  `nps_value`     decimal(20,2) NOT NULL DEFAULT 0.00,
  `po_value`      decimal(20,2) NOT NULL DEFAULT 0.00,
  `gold_value`    decimal(20,2) NOT NULL DEFAULT 0.00,
  `other_value`   decimal(20,2) NOT NULL DEFAULT 0.00,
  `created_at`    datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nws` (`user_id`, `snapshot_date`),
  KEY `idx_nws_user` (`user_id`),
  CONSTRAINT `fk_nws_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Monthly net worth snapshots for timeline chart (t207)';

-- 006_networth_snapshots.sql
-- ============================================================
-- Table: networth_snapshots
-- Domain: 020_dashboard_ui  |  Sequence: 006
-- Source: 41_pending_tasks.sql
-- ============================================================
-- NOTE: Possible duplicate of net_worth_snapshots — both exist, keeping both with note

CREATE TABLE IF NOT EXISTS networth_snapshots (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id       INT UNSIGNED NOT NULL,
    snapshot_date DATE NOT NULL,
    mf_value      DECIMAL(15,2) DEFAULT 0,
    fd_value      DECIMAL(15,2) DEFAULT 0,
    nps_value     DECIMAL(15,2) DEFAULT 0,
    stock_value   DECIMAL(15,2) DEFAULT 0,
    crypto_value  DECIMAL(15,2) DEFAULT 0,
    other_value   DECIMAL(15,2) DEFAULT 0,
    total_value   DECIMAL(15,2) NOT NULL,
    UNIQUE KEY uk_user_date (user_id, snapshot_date),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 007_portfolio_snapshots.sql
-- ============================================================
-- Table: portfolio_snapshots
-- Domain: 020_dashboard_ui  |  Sequence: 007
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS portfolio_snapshots (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    snapshot_date DATE NOT NULL,
    portfolio_value DECIMAL(20,4) NOT NULL,
    invested_value DECIMAL(20,4) NOT NULL,
    xirr DECIMAL(8,4) DEFAULT NULL COMMENT 'XIRR %',
    twrr DECIMAL(8,4) DEFAULT NULL COMMENT 'Time-weighted return %',
    nifty50_value DECIMAL(15,4) DEFAULT NULL COMMENT 'Nifty 50 on same date',
    nifty50_returns DECIMAL(8,4) DEFAULT NULL COMMENT 'Nifty 50 equivalent % returns',
    alpha DECIMAL(8,4) DEFAULT NULL COMMENT 'portfolio_returns - benchmark_returns',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_user_date (user_id, snapshot_date),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_nse_index_snapshots.sql
-- ============================================================
-- Table: nse_index_snapshots
-- Domain: 020_dashboard_ui  |  Sequence: 008
-- Source: migrations/t222_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nse_index_snapshots` (
  `id`            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `index_name`    VARCHAR(100)    NOT NULL  COMMENT 'e.g. NIFTY 50',
  `index_key`     VARCHAR(60)     NOT NULL  COMMENT 'NSE indexSymbol key',
  `snapshot_date` DATE            NOT NULL  COMMENT 'Trading date',
  `last_value`    DECIMAL(12,2)   NOT NULL  DEFAULT 0.00,
  `open`          DECIMAL(12,2)   NULL DEFAULT NULL,
  `high`          DECIMAL(12,2)   NULL DEFAULT NULL,
  `low`           DECIMAL(12,2)   NULL DEFAULT NULL,
  `prev_close`    DECIMAL(12,2)   NULL DEFAULT NULL,
  `change_val`    DECIMAL(10,2)   NULL DEFAULT NULL,
  `change_pct`    DECIMAL(8,4)    NULL DEFAULT NULL,
  `advances`      SMALLINT        NULL DEFAULT NULL,
  `declines`      SMALLINT        NULL DEFAULT NULL,
  `unchanged`     SMALLINT        NULL DEFAULT NULL,
  `year_high`     DECIMAL(12,2)   NULL DEFAULT NULL,
  `year_low`      DECIMAL(12,2)   NULL DEFAULT NULL,
  `created_at`    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_index_date` (`index_name`, `snapshot_date`),
  KEY `idx_nis_date`  (`snapshot_date`),
  KEY `idx_nis_name`  (`index_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Daily NSE index snapshots — Nifty 50, Bank Nifty, etc.';

-- 009_market_pe_history.sql
-- ============================================================
-- Table: market_pe_history
-- Domain: 020_dashboard_ui  |  Sequence: 009
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS market_pe_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    index_name VARCHAR(50) NOT NULL COMMENT 'NIFTY50/NIFTY500/SENSEX',
    data_date DATE NOT NULL,
    pe_ratio DECIMAL(10,4) NOT NULL,
    pb_ratio DECIMAL(10,4) DEFAULT NULL,
    div_yield DECIMAL(8,4) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_index_date (index_name, data_date),
    INDEX idx_date (data_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 010_sector_rotation_cache.sql
-- ============================================================
-- Table: sector_rotation_cache
-- Domain: 020_dashboard_ui  |  Sequence: 010
-- Source: 25_sector_rotation.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `sector_rotation_cache` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `sector_name`  VARCHAR(100) NOT NULL          COMMENT 'e.g. Banking, IT, Pharma, FMCG',
    `sector_slug`  VARCHAR(60)  NOT NULL          COMMENT 'URL-safe slug e.g. banking, it',
    `ret_1m`       DECIMAL(8,4) DEFAULT NULL      COMMENT '1-month avg return %',
    `ret_3m`       DECIMAL(8,4) DEFAULT NULL      COMMENT '3-month avg return %',
    `ret_6m`       DECIMAL(8,4) DEFAULT NULL      COMMENT '6-month avg return %',
    `ret_1y`       DECIMAL(8,4) DEFAULT NULL      COMMENT '1-year avg return %',
    `fund_count`   SMALLINT UNSIGNED DEFAULT 0    COMMENT 'Number of funds in this sector',
    `top_fund_id`  INT UNSIGNED DEFAULT NULL      COMMENT 'Best performing fund in sector',
    `data_source`  ENUM('category_proxy','amfi_holdings') NOT NULL DEFAULT 'category_proxy',
    `computed_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_sr_sector` (`sector_slug`),
    KEY `idx_sr_ret1y` (`ret_1y`),
    CONSTRAINT `fk_sr_top_fund` FOREIGN KEY (`top_fund_id`) REFERENCES `funds`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Sector rotation cache — daily computed sector performance';

-- 011_sector_rotation_history.sql
-- ============================================================
-- Table: sector_rotation_history
-- Domain: 020_dashboard_ui  |  Sequence: 011
-- Source: 25_sector_rotation.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `sector_rotation_history` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `sector_slug`  VARCHAR(60)  NOT NULL,
    `period_date`  DATE         NOT NULL          COMMENT 'Snapshot date',
    `ret_1m`       DECIMAL(8,4) DEFAULT NULL,
    `ret_3m`       DECIMAL(8,4) DEFAULT NULL,
    `ret_1y`       DECIMAL(8,4) DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_srh_sector_date` (`sector_slug`, `period_date`),
    KEY `idx_srh_date` (`period_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Sector rotation time-series — for trend line charts';

-- 012_usd_inr_rate_cache.sql
-- ============================================================
-- Table: usd_inr_rate_cache
-- Domain: 020_dashboard_ui  |  Sequence: 012
-- Source: migrations/t456_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `usd_inr_rate_cache` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `rate`        DECIMAL(10,4) NOT NULL,
    `source`      VARCHAR(30)   NOT NULL,
    `date_for`    DATE          NOT NULL,
    `fetched_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_urc_date` (`date_for`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 021_broker_integrations ───────────────────────────────
-- 001_zerodha_credentials.sql
-- ============================================================
-- Table: zerodha_credentials
-- Domain: 021_broker_integrations  |  Sequence: 001
-- Source: migrations/t301_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_credentials` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `api_key`         VARCHAR(255) NOT NULL                    COMMENT 'Kite API key (encrypted)',
    `api_secret`      VARCHAR(255) NOT NULL                    COMMENT 'Kite API secret (encrypted)',
    `access_token`    VARCHAR(512) DEFAULT NULL                COMMENT 'Session access token (refreshed daily)',
    `request_token`   VARCHAR(255) DEFAULT NULL                COMMENT 'Last OAuth request token used',
    `token_expiry`    DATETIME     DEFAULT NULL                COMMENT 'Access token valid until (usually next 6am IST)',
    `kite_user_id`    VARCHAR(30)  DEFAULT NULL                COMMENT 'Zerodha client ID e.g. AB1234',
    `kite_user_name`  VARCHAR(100) DEFAULT NULL,
    `login_time`      DATETIME     DEFAULT NULL,
    `is_active`       TINYINT(1)   NOT NULL DEFAULT 1,
    `last_sync_at`    DATETIME     DEFAULT NULL,
    `last_sync_status`ENUM('success','failed','pending') DEFAULT NULL,
    `last_sync_error` TEXT         DEFAULT NULL,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zerodha_user` (`user_id`),
    INDEX `idx_zerodha_active` (`is_active`, `token_expiry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_zerodha_instruments.sql
-- ============================================================
-- Table: zerodha_instruments
-- Domain: 021_broker_integrations  |  Sequence: 002
-- Source: migrations/t391_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_instruments` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `instrument_token`INT UNSIGNED NOT NULL,
    `exchange_token`  INT UNSIGNED DEFAULT NULL,
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `name`            VARCHAR(200) DEFAULT NULL,
    `last_price`      DECIMAL(14,4) DEFAULT 0,
    `expiry`          DATE          DEFAULT NULL,
    `strike`          DECIMAL(14,4) DEFAULT NULL,
    `tick_size`       DECIMAL(10,4) DEFAULT NULL,
    `lot_size`        INT           DEFAULT 1,
    `instrument_type` VARCHAR(10)  DEFAULT NULL  COMMENT 'EQ,FUT,CE,PE,MF',
    `segment`         VARCHAR(20)  DEFAULT NULL  COMMENT 'NSE,BSE,NFO,CDS',
    `exchange`        VARCHAR(10)  DEFAULT NULL,
    `isin`            VARCHAR(20)  DEFAULT NULL,
    `refreshed_at`    DATETIME     DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zi_token` (`instrument_token`),
    INDEX `idx_zi_symbol` (`tradingsymbol`, `exchange`),
    INDEX `idx_zi_isin`   (`isin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_zerodha_holdings_raw.sql
-- ============================================================
-- Table: zerodha_holdings_raw
-- Domain: 021_broker_integrations  |  Sequence: 003
-- Source: migrations/t301_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_holdings_raw` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `exchange`        VARCHAR(10)  NOT NULL DEFAULT 'NSE',
    `isin`            VARCHAR(20)  DEFAULT NULL,
    `quantity`        INT          NOT NULL DEFAULT 0,
    `t1_quantity`     INT          NOT NULL DEFAULT 0          COMMENT 'T+1 settlement qty',
    `average_price`   DECIMAL(12,4) NOT NULL DEFAULT 0,
    `last_price`      DECIMAL(12,4) DEFAULT NULL,
    `close_price`     DECIMAL(12,4) DEFAULT NULL,
    `pnl`             DECIMAL(14,4) DEFAULT NULL,
    `day_change`      DECIMAL(12,4) DEFAULT NULL,
    `day_change_pct`  DECIMAL(8,4)  DEFAULT NULL,
    `product`         VARCHAR(10)  DEFAULT NULL                COMMENT 'CNC / MIS',
    `collateral_qty`  INT          DEFAULT 0,
    `collateral_type` VARCHAR(30)  DEFAULT NULL,
    `used_quantity`   INT          DEFAULT 0,
    `realised_quantity` INT        DEFAULT 0,
    `authorised_date` DATE         DEFAULT NULL,
    `raw_json`        JSON         DEFAULT NULL                COMMENT 'Full Kite holding object',
    `synced_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zh_user_symbol` (`user_id`, `tradingsymbol`, `exchange`),
    INDEX `idx_zh_user`   (`user_id`),
    INDEX `idx_zh_isin`   (`isin`),
    INDEX `idx_zh_sync`   (`synced_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_zerodha_positions_raw.sql
-- ============================================================
-- Table: zerodha_positions_raw
-- Domain: 021_broker_integrations  |  Sequence: 004
-- Source: migrations/t301_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_positions_raw` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `position_type`   ENUM('day','net') NOT NULL DEFAULT 'net',
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `exchange`        VARCHAR(10)  NOT NULL DEFAULT 'NSE',
    `product`         VARCHAR(10)  DEFAULT NULL,
    `quantity`        INT          NOT NULL DEFAULT 0,
    `overnight_quantity` INT       DEFAULT 0,
    `buy_quantity`    INT          DEFAULT 0,
    `sell_quantity`   INT          DEFAULT 0,
    `average_price`   DECIMAL(12,4) DEFAULT 0,
    `last_price`      DECIMAL(12,4) DEFAULT NULL,
    `pnl`             DECIMAL(14,4) DEFAULT NULL,
    `realised`        DECIMAL(14,4) DEFAULT NULL,
    `unrealised`      DECIMAL(14,4) DEFAULT NULL,
    `m2m`             DECIMAL(14,4) DEFAULT NULL,
    `raw_json`        JSON         DEFAULT NULL,
    `synced_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zpos_user_sym` (`user_id`, `position_type`, `tradingsymbol`, `exchange`, `product`),
    INDEX `idx_zpos_user` (`user_id`),
    INDEX `idx_zpos_sync` (`synced_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_zerodha_orders.sql
-- ============================================================
-- Table: zerodha_orders
-- Domain: 021_broker_integrations  |  Sequence: 005
-- Source: migrations/t391_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_orders` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `order_id`        VARCHAR(30)  NOT NULL,
    `exchange_order_id` VARCHAR(30) DEFAULT NULL,
    `parent_order_id` VARCHAR(30)  DEFAULT NULL,
    `status`          VARCHAR(30)  DEFAULT NULL,
    `status_message`  VARCHAR(255) DEFAULT NULL,
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `exchange`        VARCHAR(10)  DEFAULT NULL,
    `instrument_token`INT UNSIGNED DEFAULT NULL,
    `order_type`      VARCHAR(20)  DEFAULT NULL  COMMENT 'MARKET,LIMIT,SL,SL-M',
    `transaction_type`VARCHAR(5)   DEFAULT NULL  COMMENT 'BUY,SELL',
    `product`         VARCHAR(10)  DEFAULT NULL  COMMENT 'CNC,MIS,NRML',
    `validity`        VARCHAR(5)   DEFAULT NULL  COMMENT 'DAY,IOC',
    `quantity`        INT          DEFAULT 0,
    `pending_quantity`INT          DEFAULT 0,
    `filled_quantity` INT          DEFAULT 0,
    `price`           DECIMAL(14,4) DEFAULT 0,
    `trigger_price`   DECIMAL(14,4) DEFAULT 0,
    `average_price`   DECIMAL(14,4) DEFAULT 0,
    `placed_by`       VARCHAR(10)  DEFAULT NULL,
    `variety`         VARCHAR(10)  DEFAULT NULL,
    `order_timestamp` DATETIME     DEFAULT NULL,
    `exchange_timestamp` DATETIME  DEFAULT NULL,
    `raw_json`        JSON         DEFAULT NULL,
    `synced_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zo_order` (`user_id`, `order_id`),
    INDEX `idx_zo_user`   (`user_id`),
    INDEX `idx_zo_symbol` (`tradingsymbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_zerodha_gtt.sql
-- ============================================================
-- Table: zerodha_gtt
-- Domain: 021_broker_integrations  |  Sequence: 006
-- Source: migrations/t391_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_gtt` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `gtt_id`          INT UNSIGNED NOT NULL,
    `status`          VARCHAR(20)  DEFAULT NULL,
    `type`            VARCHAR(20)  DEFAULT NULL  COMMENT 'single,two-leg',
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `exchange`        VARCHAR(10)  DEFAULT NULL,
    `trigger_values`  JSON         DEFAULT NULL,
    `last_price`      DECIMAL(14,4) DEFAULT 0,
    `condition`       JSON         DEFAULT NULL,
    `orders`          JSON         DEFAULT NULL,
    `created_at`      DATETIME     DEFAULT NULL,
    `updated_at`      DATETIME     DEFAULT NULL,
    `expires_at`      DATETIME     DEFAULT NULL,
    `synced_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zgtt_user` (`user_id`, `gtt_id`),
    INDEX `idx_zgtt_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_zerodha_margins.sql
-- ============================================================
-- Table: zerodha_margins
-- Domain: 021_broker_integrations  |  Sequence: 007
-- Source: migrations/t391_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_margins` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`     INT UNSIGNED NOT NULL,
    `segment`     VARCHAR(10)  NOT NULL,
    `net`         DECIMAL(14,4) DEFAULT 0,
    `available`   DECIMAL(14,4) DEFAULT 0,
    `used`        DECIMAL(14,4) DEFAULT 0,
    `payin`       DECIMAL(14,4) DEFAULT 0,
    `payout`      DECIMAL(14,4) DEFAULT 0,
    `raw_json`    JSON          DEFAULT NULL,
    `fetched_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zm_user_seg` (`user_id`, `segment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_zerodha_sync_log.sql
-- ============================================================
-- Table: zerodha_sync_log
-- Domain: 021_broker_integrations  |  Sequence: 008
-- Source: migrations/t301_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_sync_log` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `portfolio_id`    INT UNSIGNED DEFAULT NULL,
    `triggered_by`    ENUM('manual','cron','webhook') NOT NULL DEFAULT 'manual',
    `holdings_fetched`INT UNSIGNED DEFAULT 0,
    `holdings_added`  INT UNSIGNED DEFAULT 0,
    `holdings_updated`INT UNSIGNED DEFAULT 0,
    `positions_fetched`INT UNSIGNED DEFAULT 0,
    `status`          ENUM('success','failed','partial') NOT NULL DEFAULT 'success',
    `error_message`   TEXT         DEFAULT NULL,
    `api_calls_made`  TINYINT UNSIGNED DEFAULT 0,
    `duration_ms`     INT UNSIGNED DEFAULT NULL,
    `synced_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_zsync_user`   (`user_id`),
    INDEX `idx_zsync_at`     (`synced_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 009_zerodha_quote_snapshots.sql
-- ============================================================
-- Table: zerodha_quote_snapshots
-- Domain: 021_broker_integrations  |  Sequence: 009
-- Source: migrations/t391_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `zerodha_quote_snapshots` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `tradingsymbol`   VARCHAR(50)  NOT NULL,
    `exchange`        VARCHAR(10)  NOT NULL,
    `last_price`      DECIMAL(14,4) DEFAULT 0,
    `net_change`      DECIMAL(14,4) DEFAULT 0,
    `net_change_pct`  DECIMAL(8,4)  DEFAULT 0,
    `volume`          BIGINT UNSIGNED DEFAULT 0,
    `oi`              BIGINT UNSIGNED DEFAULT 0,
    `high`            DECIMAL(14,4) DEFAULT 0,
    `low`             DECIMAL(14,4) DEFAULT 0,
    `open`            DECIMAL(14,4) DEFAULT 0,
    `close`           DECIMAL(14,4) DEFAULT 0,
    `raw_json`        JSON          DEFAULT NULL,
    `fetched_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_zqs_user_sym` (`user_id`, `tradingsymbol`, `exchange`),
    INDEX `idx_zqs_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 010_smallcase_portfolios.sql
-- ============================================================
-- Table: smallcase_portfolios
-- Domain: 021_broker_integrations  |  Sequence: 010
-- Source: migrations/t120_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smallcase_portfolios (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id          INT UNSIGNED NOT NULL,
    portfolio_id     INT UNSIGNED NOT NULL,
    name             VARCHAR(200) NOT NULL,
    description      TEXT         DEFAULT NULL,
    strategy_type    VARCHAR(100) DEFAULT NULL,
    manager          VARCHAR(100) DEFAULT NULL,
    external_id      VARCHAR(100) DEFAULT NULL COMMENT 'Smallcase basket ID if available',
    invested_amount  DECIMAL(14,2) NOT NULL DEFAULT 0,
    current_value    DECIMAL(14,2) DEFAULT NULL,
    gain_loss        DECIMAL(14,2) DEFAULT NULL,
    gain_loss_pct    DECIMAL(8,4)  DEFAULT NULL,
    xirr             DECIMAL(8,4)  DEFAULT NULL,
    subscription_fee DECIMAL(10,2) DEFAULT 0,
    fee_frequency    ENUM('monthly','quarterly','yearly','one_time') DEFAULT NULL,
    last_rebalanced  DATE          DEFAULT NULL,
    next_rebalance   DATE          DEFAULT NULL,
    is_active        TINYINT(1)    NOT NULL DEFAULT 1,
    notes            TEXT          DEFAULT NULL,
    created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user       (user_id),
    INDEX idx_portfolio  (portfolio_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 011_smallcase_holdings.sql
-- ============================================================
-- Table: smallcase_holdings
-- Domain: 021_broker_integrations  |  Sequence: 011
-- Source: migrations/t120_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smallcase_holdings (
    id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    smallcase_id       INT UNSIGNED NOT NULL,
    user_id            INT UNSIGNED NOT NULL,
    symbol             VARCHAR(30)  NOT NULL,
    company_name       VARCHAR(200) NOT NULL,
    exchange           ENUM('NSE','BSE') NOT NULL DEFAULT 'NSE',
    isin               VARCHAR(20)  DEFAULT NULL,
    quantity           DECIMAL(14,4) NOT NULL DEFAULT 0,
    avg_buy_price      DECIMAL(12,4) NOT NULL DEFAULT 0,
    invested_amount    DECIMAL(14,2) NOT NULL DEFAULT 0,
    current_price      DECIMAL(12,4) DEFAULT NULL,
    current_value      DECIMAL(14,2) DEFAULT NULL,
    weight_pct         DECIMAL(6,2)  DEFAULT NULL COMMENT 'Allocation % in this basket',
    target_weight_pct  DECIMAL(6,2)  DEFAULT NULL,
    sector             VARCHAR(100)  DEFAULT NULL,
    last_price_date    DATE          DEFAULT NULL,
    created_at         DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at         DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_smallcase (smallcase_id),
    INDEX idx_user      (user_id),
    INDEX idx_symbol    (symbol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 012_smallcase_transactions.sql
-- ============================================================
-- Table: smallcase_transactions
-- Domain: 021_broker_integrations  |  Sequence: 012
-- Source: migrations/t120_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smallcase_transactions (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    smallcase_id     INT UNSIGNED NOT NULL,
    user_id          INT UNSIGNED NOT NULL,
    txn_type         ENUM('invest','redeem','rebalance','dividend','switch') NOT NULL DEFAULT 'invest',
    txn_date         DATE         NOT NULL,
    amount           DECIMAL(14,2) NOT NULL DEFAULT 0,
    units_change     DECIMAL(14,4) DEFAULT NULL COMMENT 'For individual stock change in rebalance',
    notes            TEXT          DEFAULT NULL,
    import_source    VARCHAR(50)   DEFAULT 'manual',
    created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_smallcase (smallcase_id),
    INDEX idx_user      (user_id),
    INDEX idx_date      (txn_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 013_smallcase_rebalance_history.sql
-- ============================================================
-- Table: smallcase_rebalance_history
-- Domain: 021_broker_integrations  |  Sequence: 013
-- Source: migrations/t120_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smallcase_rebalance_history (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    smallcase_id     INT UNSIGNED NOT NULL,
    user_id          INT UNSIGNED NOT NULL,
    rebalance_date   DATE         NOT NULL,
    reason           VARCHAR(200) DEFAULT NULL COMMENT 'e.g. Quarterly rebalance, Stock addition',
    stocks_added     TEXT         DEFAULT NULL COMMENT 'JSON array of symbols added',
    stocks_removed   TEXT         DEFAULT NULL COMMENT 'JSON array of symbols removed',
    stocks_changed   TEXT         DEFAULT NULL COMMENT 'JSON array of weight changes',
    portfolio_value  DECIMAL(14,2) DEFAULT NULL,
    notes            TEXT         DEFAULT NULL,
    created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_smallcase (smallcase_id),
    INDEX idx_user      (user_id),
    INDEX idx_date      (rebalance_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 014_benchmark_opt_ins.sql
-- ============================================================
-- Table: benchmark_opt_ins
-- Domain: 021_broker_integrations  |  Sequence: 014
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS benchmark_opt_ins (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL UNIQUE,
  opted_in    TINYINT(1)   NOT NULL DEFAULT 0,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_boi_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 015_benchmark_snapshots.sql
-- ============================================================
-- Table: benchmark_snapshots
-- Domain: 021_broker_integrations  |  Sequence: 015
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS benchmark_snapshots (
  id                      INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id                 INT UNSIGNED NOT NULL UNIQUE,
  age_bracket             VARCHAR(10)  NOT NULL COMMENT '18-24, 25-34, 35-44, 45-54, 55+',
  risk_profile            VARCHAR(30)  NOT NULL,
  savings_rate            DECIMAL(6,2) NULL COMMENT 'percent',
  gain_pct                DECIMAL(7,2) NULL COMMENT 'percent',
  sip_count               SMALLINT     NULL,
  monthly_sip_pct_income  DECIMAL(6,2) NULL COMMENT 'percent',
  num_holdings            SMALLINT     NULL,
  created_at              DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at              DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_cohort (age_bracket, risk_profile),
  CONSTRAINT fk_bs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 016_benchmark_data.sql
-- ============================================================
-- Table: benchmark_data
-- Domain: 021_broker_integrations  |  Sequence: 016
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS benchmark_data (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    benchmark_name VARCHAR(50) NOT NULL COMMENT 'NIFTY50/SENSEX/NIFTY500',
    data_date DATE NOT NULL,
    close_value DECIMAL(15,4) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_bench_date (benchmark_name, data_date),
    INDEX idx_date (data_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 022_other_investments ─────────────────────────────────
-- 001_etf_master.sql
-- ============================================================
-- Table: etf_master
-- Domain: 022_other_investments  |  Sequence: 001
-- Source: migrations/t37_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `etf_master` (
    `id`                  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `symbol`              VARCHAR(20)  NOT NULL,
    `exchange`            VARCHAR(10)  NOT NULL DEFAULT 'NSE',
    `isin`                VARCHAR(20)  DEFAULT NULL,
    `scheme_name`         VARCHAR(200) NOT NULL,
    `amc`                 VARCHAR(100) DEFAULT NULL,
    `category`            VARCHAR(100) DEFAULT NULL  COMMENT 'Equity, Debt, Gold, International, etc.',
    `sub_category`        VARCHAR(100) DEFAULT NULL  COMMENT 'Nifty 50, Banking, IT, etc.',
    `underlying_index`    VARCHAR(100) DEFAULT NULL,
    `benchmark`           VARCHAR(100) DEFAULT NULL,
    `latest_price`        DECIMAL(14,4) DEFAULT 0,
    `nav`                 DECIMAL(14,4) DEFAULT NULL COMMENT 'Declared NAV if different from price',
    `price_change_1d`     DECIMAL(10,4) DEFAULT NULL,
    `price_change_1d_pct` DECIMAL(8,4)  DEFAULT NULL,
    `expense_ratio`       DECIMAL(6,4)  DEFAULT NULL COMMENT 'Annual TER %',
    `tracking_error`      DECIMAL(8,4)  DEFAULT NULL,
    `aum_cr`              DECIMAL(14,4) DEFAULT NULL COMMENT 'AUM in INR crores',
    `avg_volume`          BIGINT UNSIGNED DEFAULT NULL,
    `high_52`             DECIMAL(14,4) DEFAULT NULL,
    `low_52`              DECIMAL(14,4) DEFAULT NULL,
    `dividend_yield`      DECIMAL(8,4)  DEFAULT NULL,
    `returns_1y`          DECIMAL(8,4)  DEFAULT NULL,
    `returns_3y`          DECIMAL(8,4)  DEFAULT NULL,
    `returns_5y`          DECIMAL(8,4)  DEFAULT NULL,
    `is_gold_etf`         TINYINT(1)    DEFAULT 0,
    `is_international`    TINYINT(1)    DEFAULT 0,
    `price_updated_at`    DATETIME      DEFAULT NULL,
    `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_etf_symbol` (`symbol`, `exchange`),
    INDEX `idx_etf_isin`     (`isin`),
    INDEX `idx_etf_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 002_etf_holdings.sql
-- ============================================================
-- Table: etf_holdings
-- Domain: 022_other_investments  |  Sequence: 002
-- Source: migrations/t37_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `etf_holdings` (
    `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`     INT UNSIGNED NOT NULL,
    `etf_id`           INT UNSIGNED NOT NULL,
    `quantity`         DECIMAL(16,4) NOT NULL DEFAULT 0,
    `avg_buy_price`    DECIMAL(14,4) NOT NULL DEFAULT 0,
    `total_invested`   DECIMAL(18,4) DEFAULT 0,
    `current_value`    DECIMAL(18,4) DEFAULT 0,
    `first_buy_date`   DATE          DEFAULT NULL,
    `broker`           VARCHAR(50)   DEFAULT NULL,
    `notes`            TEXT          DEFAULT NULL,
    `created_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_eh_portfolio_etf` (`portfolio_id`, `etf_id`),
    INDEX `idx_eh_portfolio` (`portfolio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 003_etf_transactions.sql
-- ============================================================
-- Table: etf_transactions
-- Domain: 022_other_investments  |  Sequence: 003
-- Source: migrations/t37_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `etf_transactions` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`  INT UNSIGNED NOT NULL,
    `etf_id`        INT UNSIGNED NOT NULL,
    `type`          ENUM('buy','sell','dividend') NOT NULL DEFAULT 'buy',
    `quantity`      DECIMAL(16,4) NOT NULL,
    `price`         DECIMAL(14,4) NOT NULL DEFAULT 0,
    `total_value`   DECIMAL(18,4) DEFAULT 0,
    `brokerage`     DECIMAL(10,4) DEFAULT 0,
    `broker`        VARCHAR(50)   DEFAULT NULL,
    `txn_date`      DATE          NOT NULL,
    `notes`         TEXT          DEFAULT NULL,
    `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_et_portfolio` (`portfolio_id`),
    INDEX `idx_et_etf`       (`etf_id`),
    INDEX `idx_et_date`      (`txn_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 004_etf_sip.sql
-- ============================================================
-- Table: etf_sip
-- Domain: 022_other_investments  |  Sequence: 004
-- Source: migrations/t37_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `etf_sip` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `etf_id`          INT UNSIGNED NOT NULL,
    `monthly_amount`  DECIMAL(12,4) NOT NULL,
    `sip_date`        TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'Day of month 1-28',
    `start_date`      DATE          NOT NULL,
    `end_date`        DATE          DEFAULT NULL,
    `broker`          VARCHAR(50)   DEFAULT NULL,
    `is_active`       TINYINT(1)    NOT NULL DEFAULT 1,
    `last_executed`   DATE          DEFAULT NULL,
    `total_invested`  DECIMAL(18,4) DEFAULT 0,
    `installments`    INT UNSIGNED  DEFAULT 0,
    `notes`           TEXT          DEFAULT NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_esip_portfolio` (`portfolio_id`),
    INDEX `idx_esip_active`    (`is_active`, `sip_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 005_pms_holdings.sql
-- ============================================================
-- Table: pms_holdings
-- Domain: 022_other_investments  |  Sequence: 005
-- Source: migrations/t119_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS pms_holdings (
    id                  INT UNSIGNED    AUTO_INCREMENT PRIMARY KEY,
    user_id             INT UNSIGNED    NOT NULL,
    portfolio_id        INT UNSIGNED    NOT NULL,
    pms_name            VARCHAR(200)    NOT NULL               COMMENT 'e.g. Marcellus CCP, ASK IEP',
    manager_name        VARCHAR(150)    DEFAULT NULL           COMMENT 'PMS provider / AMC name',
    strategy_name       VARCHAR(200)    DEFAULT NULL           COMMENT 'Portfolio strategy name',
    asset_class         ENUM('PMS','AIF_CAT1','AIF_CAT2','AIF_CAT3') NOT NULL DEFAULT 'PMS',
    aif_category        TINYINT(1)      DEFAULT NULL           COMMENT '1, 2 or 3 for AIF',
    investment_date     DATE            NOT NULL,
    invested_amount     DECIMAL(16,2)   NOT NULL DEFAULT 0.00,
    current_value       DECIMAL(16,2)   DEFAULT NULL,
    gain_loss           DECIMAL(16,2)   GENERATED ALWAYS AS (current_value - invested_amount) STORED,
    gain_loss_pct       DECIMAL(8,4)    GENERATED ALWAYS AS (
                            CASE WHEN invested_amount > 0
                                 THEN ((current_value - invested_amount) / invested_amount) * 100
                                 ELSE NULL END
                        ) STORED,
    xirr                DECIMAL(8,4)    DEFAULT NULL           COMMENT 'Stored XIRR %',
    nav_current         DECIMAL(14,4)   DEFAULT NULL,
    nav_date            DATE            DEFAULT NULL,
    units               DECIMAL(14,4)   DEFAULT NULL,
    folio_number        VARCHAR(60)     DEFAULT NULL,
    lock_in_months      INT UNSIGNED    DEFAULT NULL,
    lock_in_end_date    DATE            DEFAULT NULL,
    management_fee_pct  DECIMAL(5,3)    DEFAULT NULL           COMMENT 'Annual mgmt fee %',
    performance_fee_pct DECIMAL(5,3)    DEFAULT NULL           COMMENT 'Performance fee % (hurdle)',
    hurdle_rate_pct     DECIMAL(5,3)    DEFAULT NULL,
    benchmark           VARCHAR(150)    DEFAULT NULL,
    platform            VARCHAR(100)    DEFAULT NULL           COMMENT 'Zerodha, IIFL, Motilal, etc.',
    notes               TEXT            DEFAULT NULL,
    is_active           TINYINT(1)      NOT NULL DEFAULT 1,
    created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_user          (user_id),
    INDEX idx_portfolio     (portfolio_id),
    INDEX idx_asset_class   (asset_class),
    INDEX idx_active        (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 006_pms_transactions.sql
-- ============================================================
-- Table: pms_transactions
-- Domain: 022_other_investments  |  Sequence: 006
-- Source: migrations/t119_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS pms_transactions (
    id              INT UNSIGNED    AUTO_INCREMENT PRIMARY KEY,
    holding_id      INT UNSIGNED    NOT NULL,
    user_id         INT UNSIGNED    NOT NULL,
    portfolio_id    INT UNSIGNED    NOT NULL,
    txn_type        ENUM('investment','withdrawal','dividend','management_fee','performance_fee','nav_update','switch') NOT NULL,
    txn_date        DATE            NOT NULL,
    amount          DECIMAL(16,2)   NOT NULL DEFAULT 0.00,
    nav             DECIMAL(14,4)   DEFAULT NULL,
    units           DECIMAL(14,4)   DEFAULT NULL,
    notes           TEXT            DEFAULT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_holding    (holding_id),
    INDEX idx_user       (user_id),
    INDEX idx_date       (txn_date),
    INDEX idx_type       (txn_type),
    CONSTRAINT fk_pmst_holding FOREIGN KEY (holding_id) REFERENCES pms_holdings (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 007_pms_nav_history.sql
-- ============================================================
-- Table: pms_nav_history
-- Domain: 022_other_investments  |  Sequence: 007
-- Source: migrations/t119_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS pms_nav_history (
    id          INT UNSIGNED    AUTO_INCREMENT PRIMARY KEY,
    holding_id  INT UNSIGNED    NOT NULL,
    nav_date    DATE            NOT NULL,
    nav         DECIMAL(14,4)   NOT NULL,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uq_nav (holding_id, nav_date),
    INDEX idx_holding (holding_id),
    INDEX idx_date    (nav_date),
    CONSTRAINT fk_pmsnav_holding FOREIGN KEY (holding_id) REFERENCES pms_holdings (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 008_intl_transactions.sql
-- ============================================================
-- Table: intl_transactions
-- Domain: 022_other_investments  |  Sequence: 008
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS intl_transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    stock_id BIGINT UNSIGNED NOT NULL,
    lrs_id BIGINT UNSIGNED DEFAULT NULL,
    transaction_type ENUM('BUY','SELL','DIVIDEND') NOT NULL,
    quantity DECIMAL(15,6) NOT NULL,
    price_foreign DECIMAL(15,4) NOT NULL,
    price_inr DECIMAL(15,4) NOT NULL,
    exchange_rate DECIMAL(10,4) NOT NULL,
    transaction_date DATE NOT NULL,
    charges_foreign DECIMAL(10,4) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (stock_id) REFERENCES international_stocks(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_stock_id (stock_id),
    INDEX idx_date (transaction_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── seeds ───────────────────────────────────────────────────────
-- 001_app_settings_nav_auto.sql
-- ============================================================
-- Seed: app_settings — NAV auto-update config rows
-- Domain: seeds  |  File: 001_app_settings_nav_auto.sql
-- Source: migrations/t05_migration.sql
-- Depends on: 001_core/007_app_settings.sql (table must exist before running this)
-- ============================================================
-- Run this AFTER all schema files have been applied.
-- Uses ON DUPLICATE KEY UPDATE where applicable — safe to re-run.
-- ============================================================

INSERT INTO app_settings (`setting_key`, `setting_val`)
VALUES
  ('nav_auto_enabled',            '1'),
  ('nav_auto_time',               '22:00'),
  ('nav_auto_update_last_run',    NULL),
  ('nav_auto_update_last_status', NULL)
ON DUPLICATE KEY UPDATE
  `updated_at` = CURRENT_TIMESTAMP;

-- 002_app_settings_peak_nav.sql
-- ============================================================
-- Seed: app_settings — peak NAV batch date seed
-- Domain: seeds  |  File: 002_app_settings_peak_nav.sql
-- Source: 21_peak_nav_setup.sql
-- Depends on: 001_core/007_app_settings.sql (table must exist before running this)
-- ============================================================
-- Run this AFTER all schema files have been applied.
-- Uses ON DUPLICATE KEY UPDATE where applicable — safe to re-run.
-- ============================================================

INSERT INTO app_settings (setting_key, setting_val)
VALUES ('peak_nav_batch_date', '2001-01-01')
ON DUPLICATE KEY UPDATE setting_val = setting_val;

-- 003_audit_retention_config.sql
-- ============================================================
-- Seed: audit_retention_config — default 365-day retention row
-- Domain: seeds  |  File: 003_audit_retention_config.sql
-- Source: migrations/t307_migration.sql
-- Depends on: 015_admin_infra/017_audit_retention_config.sql (table must exist before running this)
-- ============================================================
-- Run this AFTER all schema files have been applied.
-- Uses ON DUPLICATE KEY UPDATE where applicable — safe to re-run.
-- ============================================================

INSERT INTO `audit_retention_config` (`id`, `retention_days`, `auto_purge`)
VALUES (1, 365, 0)
ON DUPLICATE KEY UPDATE `id` = 1;

-- 004_perf_baselines.sql
-- ============================================================
-- Seed: perf_baselines — default action baseline timings
-- Domain: seeds  |  File: 004_perf_baselines.sql
-- Source: migrations/t412_migration.sql
-- Depends on: 015_admin_infra/014_perf_baselines.sql (table must exist before running this)
-- ============================================================
-- Run this AFTER all schema files have been applied.
-- Uses ON DUPLICATE KEY UPDATE where applicable — safe to re-run.
-- ============================================================

INSERT INTO `perf_baselines` (`action`, `baseline_ms`, `threshold_ms`) VALUES
    ('fd_list',          80,  500),
    ('savings_list',     80,  500),
    ('bank_list',        80,  500),
    ('bank_summary',     100, 600),
    ('mf_list',          120, 700),
    ('sip_list',         100, 600),
    ('get_dashboard_data',200, 1000),
    ('health_ping',       30, 200),
    ('al_list',           80, 500),
    ('gs_list',           60, 400),
    ('dbm_tables',        80, 500),
    ('perf_live',         100, 600)
ON DUPLICATE KEY UPDATE baseline_ms = VALUES(baseline_ms), threshold_ms = VALUES(threshold_ms);

-- 005_milestone_log.sql
-- ============================================================
-- Seed: milestone_log — GODMODE v1 milestone record
-- Domain: seeds  |  File: 005_milestone_log.sql
-- Source: migrations/t500_migration.sql
-- Note: This is a progress-tracking/informational record,
-- not required for app functionality. Run only if you use
-- the milestone tracking feature.
-- ============================================================

INSERT INTO `milestone_log` (milestone, description) VALUES
    ('GODMODE_v1', 'WealthDash GODMODE — All P1-P3 features complete. Sessions t23-t500 done by ID-M.')
ON DUPLICATE KEY UPDATE description = VALUES(description);

SET FOREIGN_KEY_CHECKS = 1;

SELECT 'WealthDash install complete — 306 tables + 5 seed files' AS status;