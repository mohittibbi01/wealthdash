-- ============================================================
-- Table: goal_buckets
-- Domain: 012_goals_budget  |  Sequence: 003
-- Source: 01_schema_complete.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: 33_goal_buckets (TODO), t139 (identical). Winner: base schema

CREATE TABLE IF NOT EXISTS `goal_buckets` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) NOT NULL,
  `emoji` varchar(10) NOT NULL DEFAULT '🎯',
  `color` varchar(7) NOT NULL DEFAULT '#6366f1',
  `target_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `target_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_achieved` tinyint(1) NOT NULL DEFAULT 0,
  `achieved_at` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gb_user` (`user_id`),
  CONSTRAINT `fk_gb_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
