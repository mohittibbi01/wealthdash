-- ============================================================
-- Table: milestone_log
-- Domain: 012_goals_budget  |  Sequence: 018
-- Source: migrations/t500_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `milestone_log` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `milestone`   VARCHAR(80)  NOT NULL,
    `description` TEXT         DEFAULT NULL,
    `achieved_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `achieved_by` INT UNSIGNED DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
