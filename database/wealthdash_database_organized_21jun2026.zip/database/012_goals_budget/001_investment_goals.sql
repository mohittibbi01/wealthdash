-- ============================================================
-- Table: investment_goals
-- Domain: 012_goals_budget  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `investment_goals` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `target_amount` decimal(16,2) NOT NULL,
  `target_date` date NOT NULL,
  `current_saved` decimal(16,2) NOT NULL DEFAULT 0.00,
  `monthly_sip_needed` decimal(14,2) DEFAULT NULL,
  `expected_return_pct` decimal(5,2) NOT NULL DEFAULT 12.00,
  `priority` enum('high','medium','low') NOT NULL DEFAULT 'medium',
  `color` varchar(7) NOT NULL DEFAULT '#2563EB',
  `icon` varchar(30) DEFAULT 'target',
  `linked_fund_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`linked_fund_ids`)),
  `linked_stock_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`linked_stock_ids`)),
  `linked_fd_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`linked_fd_ids`)),
  `is_achieved` tinyint(1) NOT NULL DEFAULT 0,
  `achieved_at` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ig_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_ig_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
