-- ============================================================
-- Table: goal_checkins
-- Domain: 012_goals_budget  |  Sequence: 006
-- Source: migrations/tg005_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS goal_checkins (
  id           INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  goal_id      INT UNSIGNED  NOT NULL,
  user_id      INT UNSIGNED  NOT NULL,
  amount       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  checkin_date DATE          NOT NULL,
  notes        VARCHAR(255)  NULL,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_goal_date   (goal_id, checkin_date),
  KEY idx_user_date   (user_id, checkin_date),
  CONSTRAINT fk_gc_goal FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE CASCADE,
  CONSTRAINT fk_gc_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
