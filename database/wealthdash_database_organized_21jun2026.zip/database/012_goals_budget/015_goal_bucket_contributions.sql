-- ============================================================
-- Table: goal_bucket_contributions
-- Domain: 012_goals_budget  |  Sequence: 015
-- Source: migrations/t139_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `goal_bucket_contributions` (
  `id`                int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `bucket_id`         int(10) UNSIGNED NOT NULL,
  `amount`            decimal(14,2) NOT NULL,
  `contribution_date` date NOT NULL,
  `note`              varchar(255) DEFAULT NULL,
  `created_at`        datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gbc_bucket`  (`bucket_id`),
  KEY `idx_gbc_date`    (`contribution_date`),
  CONSTRAINT `fk_gbc_bucket` FOREIGN KEY (`bucket_id`) REFERENCES `goal_buckets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
