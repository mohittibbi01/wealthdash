-- ============================================================
-- Table: investment_calendar_events
-- Domain: 012_goals_budget  |  Sequence: 017
-- Source: 26_investment_calendar.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `investment_calendar_events` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`      INT UNSIGNED DEFAULT NULL      COMMENT 'NULL = global/static event visible to all',
    `event_date`   DATE         NOT NULL,
    `event_type`   ENUM(
                     'tax_deadline',
                     'sebi_compliance',
                     'rbi_policy',
                     'budget',
                     'sgb_window',
                     'nfo_open',
                     'nfo_close',
                     'advance_tax',
                     'custom'
                   ) NOT NULL DEFAULT 'custom',
    `title`        VARCHAR(200) NOT NULL,
    `description`  TEXT         DEFAULT NULL,
    `icon`         VARCHAR(10)  DEFAULT '📅'     COMMENT 'Emoji icon for display',
    `color`        VARCHAR(20)  DEFAULT '#3b82f6' COMMENT 'Hex color for calendar cell',
    `is_important` TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_ice_date`    (`event_date`),
    KEY `idx_ice_user`    (`user_id`),
    KEY `idx_ice_type`    (`event_type`),
    CONSTRAINT `fk_ice_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Investment Calendar — FY 2025-26 events + user custom reminders';
