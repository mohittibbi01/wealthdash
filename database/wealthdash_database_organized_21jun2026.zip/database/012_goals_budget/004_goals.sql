-- ============================================================
-- Table: goals
-- Domain: 012_goals_budget  |  Sequence: 004
-- Source: migrations/025_goal_buckets.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 41_pending_tasks (simpler). Winner: 025_ (goal_timeline, risk_tolerance cols)

CREATE TABLE IF NOT EXISTS `goals` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `goal_name`       VARCHAR(120) NOT NULL,
    `goal_type`       ENUM('retirement','education','home','vehicle','emergency','vacation','wedding','business','other') DEFAULT 'other',
    `target_amount`   DECIMAL(16,2) NOT NULL,
    `target_date`     DATE NOT NULL,
    `current_amount`  DECIMAL(16,2) NOT NULL DEFAULT 0,
    `monthly_sip`     DECIMAL(12,2) DEFAULT NULL COMMENT 'Recommended monthly SIP to reach goal',
    `expected_return` DECIMAL(5,2)  DEFAULT 12.00 COMMENT 'Expected CAGR %',
    `inflation_rate`  DECIMAL(5,2)  DEFAULT 6.00,
    `priority`        TINYINT UNSIGNED NOT NULL DEFAULT 2 COMMENT '1=High 2=Medium 3=Low',
    `color`           VARCHAR(20)   DEFAULT '#3b82f6',
    `emoji`           VARCHAR(10)   DEFAULT '🎯',
    `status`          ENUM('active','achieved','paused','cancelled') NOT NULL DEFAULT 'active',
    `notes`           TEXT DEFAULT NULL,
    `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_goals_user` (`user_id`),
    CONSTRAINT `fk_goals_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
