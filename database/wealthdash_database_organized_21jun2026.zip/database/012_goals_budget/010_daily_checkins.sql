-- ============================================================
-- Table: daily_checkins
-- Domain: 012_goals_budget  |  Sequence: 010
-- Source: migrations/t242_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS daily_checkins (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL,
  checkin_date  DATE         NOT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_date (user_id, checkin_date),
  CONSTRAINT fk_dci_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
