-- ============================================================
-- Table: goal_holdings
-- Domain: 012_goals_budget  |  Sequence: 005
-- Source: 41_pending_tasks.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS goal_holdings (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    goal_id       INT UNSIGNED NOT NULL,
    user_id       INT UNSIGNED NOT NULL,
    asset_type    ENUM('mf','fd','nps','stock','crypto','other') NOT NULL,
    asset_id      INT UNSIGNED NOT NULL,
    allocated_pct DECIMAL(5,2) DEFAULT 100.00,
    notes         VARCHAR(200),
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_goal_asset (goal_id, asset_type, asset_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
