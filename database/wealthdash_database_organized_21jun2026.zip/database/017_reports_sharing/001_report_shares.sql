-- ============================================================
-- Table: report_shares
-- Domain: 017_reports_sharing  |  Sequence: 001
-- Source: migrations/t378_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS report_shares (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  channel     ENUM('whatsapp','email') NOT NULL,
  report_type VARCHAR(40)  NOT NULL DEFAULT 'summary',
  recipient   VARCHAR(150) NULL,
  success     TINYINT(1)   NOT NULL DEFAULT 1,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user (user_id),
  CONSTRAINT fk_rs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
