-- ============================================================
-- Table: report_share_tokens
-- Domain: 017_reports_sharing  |  Sequence: 002
-- Source: migrations/t378_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS report_share_tokens (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  token       VARCHAR(64)  NOT NULL UNIQUE,
  expires_at  DATETIME     NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_token (token),
  CONSTRAINT fk_rst_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
