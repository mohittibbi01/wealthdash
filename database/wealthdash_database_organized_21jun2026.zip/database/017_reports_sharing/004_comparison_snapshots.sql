-- ============================================================
-- Table: comparison_snapshots
-- Domain: 017_reports_sharing  |  Sequence: 004
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `comparison_snapshots` (
  `id`           int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      int(10) UNSIGNED NOT NULL,
  `snapshot_key` varchar(40)      NOT NULL COMMENT 'e.g. epf_nps_ppf_2024-25',
  `payload`      mediumtext       NOT NULL COMMENT 'JSON snapshot of comparison',
  `expires_at`   datetime         NOT NULL,
  `created_at`   datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_snap_user_key` (`user_id`, `snapshot_key`),
  KEY `idx_snap_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
