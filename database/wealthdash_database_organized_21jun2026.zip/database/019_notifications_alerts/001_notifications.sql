-- ============================================================
-- Table: notifications
-- Domain: 019_notifications_alerts  |  Sequence: 001
-- Source: 10_notifications.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t373 also. Winner: 10_ (original numbered schema)

CREATE TABLE IF NOT EXISTS `notifications` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED  NOT NULL,
  `type`         ENUM('nav_alert','fd_maturity','sip_reminder','drawdown','nfo_closing','system','goal','tax') NOT NULL,
  `title`        VARCHAR(300)  NOT NULL,
  `body`         TEXT          NOT NULL,
  `link_url`     VARCHAR(500)  DEFAULT NULL COMMENT 'Click pe kahan jaaye',
  `is_read`      TINYINT(1)    NOT NULL DEFAULT 0,
  `triggered_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `read_at`      DATETIME      DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notif_user_unread` (`user_id`, `is_read`, `triggered_at`),
  KEY `idx_notif_type`        (`type`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Notifications Center — sab alerts ek jagah';
