-- ============================================================
-- Table: notification_prefs
-- Domain: 019_notifications_alerts  |  Sequence: 002
-- Source: 10_notifications.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `notification_prefs` (
  `user_id`         INT UNSIGNED NOT NULL,
  `nav_alerts`      TINYINT(1)   NOT NULL DEFAULT 1,
  `fd_maturity`     TINYINT(1)   NOT NULL DEFAULT 1,
  `sip_reminder`    TINYINT(1)   NOT NULL DEFAULT 1,
  `drawdown_alerts` TINYINT(1)   NOT NULL DEFAULT 1,
  `nfo_alerts`      TINYINT(1)   NOT NULL DEFAULT 1,
  `tax_reminders`   TINYINT(1)   NOT NULL DEFAULT 1,
  `updated_at`      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_np_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
