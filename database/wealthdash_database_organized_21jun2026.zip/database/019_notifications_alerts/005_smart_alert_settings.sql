-- ============================================================
-- Table: smart_alert_settings
-- Domain: 019_notifications_alerts  |  Sequence: 005
-- Source: migrations/t404_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smart_alert_settings (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id         INT UNSIGNED NOT NULL UNIQUE,
  sip_due         TINYINT(1)   NOT NULL DEFAULT 1,
  insurance_due   TINYINT(1)   NOT NULL DEFAULT 1,
  loan_emi_due    TINYINT(1)   NOT NULL DEFAULT 1,
  drawdown_alert  TINYINT(1)   NOT NULL DEFAULT 1,
  gain_alert      TINYINT(1)   NOT NULL DEFAULT 1,
  goal_milestone  TINYINT(1)   NOT NULL DEFAULT 1,
  CONSTRAINT fk_sas_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
