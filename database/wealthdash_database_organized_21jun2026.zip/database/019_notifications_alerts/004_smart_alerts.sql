-- ============================================================
-- Table: smart_alerts
-- Domain: 019_notifications_alerts  |  Sequence: 004
-- Source: migrations/t404_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS smart_alerts (
  id            INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED  NOT NULL,
  alert_type    VARCHAR(40)   NOT NULL,
  dedup_key     VARCHAR(150)  NOT NULL,
  icon          VARCHAR(8)    NULL,
  message       VARCHAR(255)  NOT NULL,
  severity      ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
  relevant_date DATE          NULL,
  is_read       TINYINT(1)    NOT NULL DEFAULT 0,
  created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_user_dedup (user_id, dedup_key),
  KEY idx_user_read (user_id, is_read),
  CONSTRAINT fk_sa_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
