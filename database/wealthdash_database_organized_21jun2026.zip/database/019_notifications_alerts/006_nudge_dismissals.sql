-- ============================================================
-- Table: nudge_dismissals
-- Domain: 019_notifications_alerts  |  Sequence: 006
-- Source: 44_v48_sprint_tables.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nudge_dismissals` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED NOT NULL,
  `nudge_id`     VARCHAR(60)  NOT NULL,
  `dismissed_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_nudge` (`user_id`, `nudge_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
