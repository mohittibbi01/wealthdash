-- ============================================================
-- Seed: perf_baselines — default action baseline timings
-- Domain: seeds  |  File: 004_perf_baselines.sql
-- Source: migrations/t412_migration.sql
-- Depends on: 015_admin_infra/014_perf_baselines.sql (table must exist before running this)
-- ============================================================
-- Run this AFTER all schema files have been applied.
-- Uses ON DUPLICATE KEY UPDATE where applicable — safe to re-run.
-- ============================================================

INSERT INTO `perf_baselines` (`action`, `baseline_ms`, `threshold_ms`) VALUES
    ('fd_list',          80,  500),
    ('savings_list',     80,  500),
    ('bank_list',        80,  500),
    ('bank_summary',     100, 600),
    ('mf_list',          120, 700),
    ('sip_list',         100, 600),
    ('get_dashboard_data',200, 1000),
    ('health_ping',       30, 200),
    ('al_list',           80, 500),
    ('gs_list',           60, 400),
    ('dbm_tables',        80, 500),
    ('perf_live',         100, 600)
ON DUPLICATE KEY UPDATE baseline_ms = VALUES(baseline_ms), threshold_ms = VALUES(threshold_ms);
