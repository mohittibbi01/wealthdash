-- ============================================================
-- Seed: audit_retention_config — default 365-day retention row
-- Domain: seeds  |  File: 003_audit_retention_config.sql
-- Source: migrations/t307_migration.sql
-- Depends on: 015_admin_infra/017_audit_retention_config.sql (table must exist before running this)
-- ============================================================
-- Run this AFTER all schema files have been applied.
-- Uses ON DUPLICATE KEY UPDATE where applicable — safe to re-run.
-- ============================================================

INSERT INTO `audit_retention_config` (`id`, `retention_days`, `auto_purge`)
VALUES (1, 365, 0)
ON DUPLICATE KEY UPDATE `id` = 1;
