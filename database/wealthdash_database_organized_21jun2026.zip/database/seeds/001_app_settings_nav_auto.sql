-- ============================================================
-- Seed: app_settings — NAV auto-update config rows
-- Domain: seeds  |  File: 001_app_settings_nav_auto.sql
-- Source: migrations/t05_migration.sql
-- Depends on: 001_core/007_app_settings.sql (table must exist before running this)
-- ============================================================
-- Run this AFTER all schema files have been applied.
-- Uses ON DUPLICATE KEY UPDATE where applicable — safe to re-run.
-- ============================================================

INSERT INTO app_settings (`setting_key`, `setting_val`)
VALUES
  ('nav_auto_enabled',            '1'),
  ('nav_auto_time',               '22:00'),
  ('nav_auto_update_last_run',    NULL),
  ('nav_auto_update_last_status', NULL)
ON DUPLICATE KEY UPDATE
  `updated_at` = CURRENT_TIMESTAMP;
