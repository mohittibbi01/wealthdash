-- ============================================================
-- Seed: milestone_log — GODMODE v1 milestone record
-- Domain: seeds  |  File: 005_milestone_log.sql
-- Source: migrations/t500_migration.sql
-- Note: This is a progress-tracking/informational record,
-- not required for app functionality. Run only if you use
-- the milestone tracking feature.
-- ============================================================

INSERT INTO `milestone_log` (milestone, description) VALUES
    ('GODMODE_v1', 'WealthDash GODMODE — All P1-P3 features complete. Sessions t23-t500 done by ID-M.')
ON DUPLICATE KEY UPDATE description = VALUES(description);
