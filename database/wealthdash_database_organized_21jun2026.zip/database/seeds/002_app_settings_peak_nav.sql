-- ============================================================
-- Seed: app_settings — peak NAV batch date seed
-- Domain: seeds  |  File: 002_app_settings_peak_nav.sql
-- Source: 21_peak_nav_setup.sql
-- Depends on: 001_core/007_app_settings.sql (table must exist before running this)
-- ============================================================
-- Run this AFTER all schema files have been applied.
-- Uses ON DUPLICATE KEY UPDATE where applicable — safe to re-run.
-- ============================================================

INSERT INTO app_settings (setting_key, setting_val)
VALUES ('peak_nav_batch_date', '2001-01-01')
ON DUPLICATE KEY UPDATE setting_val = setting_val;
