-- ============================================================
-- Table: user_onboarding
-- Domain: 020_dashboard_ui  |  Sequence: 004
-- Source: migrations/t454_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t240 fewer cols. Winner: t454

CREATE TABLE IF NOT EXISTS user_onboarding (
  id                INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id           INT UNSIGNED NOT NULL UNIQUE,
  completed_steps   JSON         NOT NULL DEFAULT ('[]'),
  skipped           TINYINT(1)   NOT NULL DEFAULT 0,
  wizard_completed  TINYINT(1)   NOT NULL DEFAULT 0,
  wizard_data       JSON         NULL,
  started_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ob_user_wizard FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
