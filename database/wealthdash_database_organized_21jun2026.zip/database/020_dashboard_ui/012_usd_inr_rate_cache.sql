-- ============================================================
-- Table: usd_inr_rate_cache
-- Domain: 020_dashboard_ui  |  Sequence: 012
-- Source: migrations/t456_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `usd_inr_rate_cache` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `rate`        DECIMAL(10,4) NOT NULL,
    `source`      VARCHAR(30)   NOT NULL,
    `date_for`    DATE          NOT NULL,
    `fetched_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_urc_date` (`date_for`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
