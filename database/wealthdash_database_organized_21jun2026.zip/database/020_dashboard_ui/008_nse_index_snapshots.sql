-- ============================================================
-- Table: nse_index_snapshots
-- Domain: 020_dashboard_ui  |  Sequence: 008
-- Source: migrations/t222_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `nse_index_snapshots` (
  `id`            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `index_name`    VARCHAR(100)    NOT NULL  COMMENT 'e.g. NIFTY 50',
  `index_key`     VARCHAR(60)     NOT NULL  COMMENT 'NSE indexSymbol key',
  `snapshot_date` DATE            NOT NULL  COMMENT 'Trading date',
  `last_value`    DECIMAL(12,2)   NOT NULL  DEFAULT 0.00,
  `open`          DECIMAL(12,2)   NULL DEFAULT NULL,
  `high`          DECIMAL(12,2)   NULL DEFAULT NULL,
  `low`           DECIMAL(12,2)   NULL DEFAULT NULL,
  `prev_close`    DECIMAL(12,2)   NULL DEFAULT NULL,
  `change_val`    DECIMAL(10,2)   NULL DEFAULT NULL,
  `change_pct`    DECIMAL(8,4)    NULL DEFAULT NULL,
  `advances`      SMALLINT        NULL DEFAULT NULL,
  `declines`      SMALLINT        NULL DEFAULT NULL,
  `unchanged`     SMALLINT        NULL DEFAULT NULL,
  `year_high`     DECIMAL(12,2)   NULL DEFAULT NULL,
  `year_low`      DECIMAL(12,2)   NULL DEFAULT NULL,
  `created_at`    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_index_date` (`index_name`, `snapshot_date`),
  KEY `idx_nis_date`  (`snapshot_date`),
  KEY `idx_nis_name`  (`index_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Daily NSE index snapshots — Nifty 50, Bank Nifty, etc.';
