-- ============================================================
-- Table: networth_snapshots
-- Domain: 020_dashboard_ui  |  Sequence: 006
-- Source: 41_pending_tasks.sql
-- ============================================================
-- NOTE: Possible duplicate of net_worth_snapshots — both exist, keeping both with note

CREATE TABLE IF NOT EXISTS networth_snapshots (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id       INT UNSIGNED NOT NULL,
    snapshot_date DATE NOT NULL,
    mf_value      DECIMAL(15,2) DEFAULT 0,
    fd_value      DECIMAL(15,2) DEFAULT 0,
    nps_value     DECIMAL(15,2) DEFAULT 0,
    stock_value   DECIMAL(15,2) DEFAULT 0,
    crypto_value  DECIMAL(15,2) DEFAULT 0,
    other_value   DECIMAL(15,2) DEFAULT 0,
    total_value   DECIMAL(15,2) NOT NULL,
    UNIQUE KEY uk_user_date (user_id, snapshot_date),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
