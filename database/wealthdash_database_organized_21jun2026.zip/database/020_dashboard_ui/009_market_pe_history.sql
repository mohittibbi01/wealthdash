-- ============================================================
-- Table: market_pe_history
-- Domain: 020_dashboard_ui  |  Sequence: 009
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS market_pe_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    index_name VARCHAR(50) NOT NULL COMMENT 'NIFTY50/NIFTY500/SENSEX',
    data_date DATE NOT NULL,
    pe_ratio DECIMAL(10,4) NOT NULL,
    pb_ratio DECIMAL(10,4) DEFAULT NULL,
    div_yield DECIMAL(8,4) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_index_date (index_name, data_date),
    INDEX idx_date (data_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
