-- ============================================================
-- Table: sector_rotation_history
-- Domain: 020_dashboard_ui  |  Sequence: 011
-- Source: 25_sector_rotation.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `sector_rotation_history` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `sector_slug`  VARCHAR(60)  NOT NULL,
    `period_date`  DATE         NOT NULL          COMMENT 'Snapshot date',
    `ret_1m`       DECIMAL(8,4) DEFAULT NULL,
    `ret_3m`       DECIMAL(8,4) DEFAULT NULL,
    `ret_1y`       DECIMAL(8,4) DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_srh_sector_date` (`sector_slug`, `period_date`),
    KEY `idx_srh_date` (`period_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Sector rotation time-series — for trend line charts';
