-- ============================================================
-- Table: perf_baselines
-- Domain: 015_admin_infra  |  Sequence: 014
-- Source: migrations/t412_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `perf_baselines` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `action`      VARCHAR(100) NOT NULL,
    `baseline_ms` FLOAT        NOT NULL,
    `threshold_ms`FLOAT        NOT NULL,
    `measured_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_pb_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
