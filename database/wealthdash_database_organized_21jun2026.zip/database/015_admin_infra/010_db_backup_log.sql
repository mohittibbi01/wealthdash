-- ============================================================
-- Table: db_backup_log
-- Domain: 015_admin_infra  |  Sequence: 010
-- Source: migrations/t53_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `db_backup_log` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `filename`    VARCHAR(255) NOT NULL,
    `size_bytes`  BIGINT DEFAULT NULL,
    `tables`      INT DEFAULT NULL,
    `triggered_by` INT UNSIGNED DEFAULT NULL,
    `method`      ENUM('manual','cron','auto') NOT NULL DEFAULT 'manual',
    `status`      ENUM('completed','failed','in_progress') NOT NULL DEFAULT 'completed',
    `error_msg`   TEXT DEFAULT NULL,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_dbl_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
