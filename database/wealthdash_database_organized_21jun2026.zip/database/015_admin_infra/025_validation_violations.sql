-- ============================================================
-- Table: validation_violations
-- Domain: 015_admin_infra  |  Sequence: 025
-- Source: migrations/t480_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `validation_violations` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `asset_type` varchar(50) NOT NULL,
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `rule_key` varchar(100) NOT NULL,
  `field_name` varchar(100) NOT NULL,
  `bad_value` varchar(500) DEFAULT NULL,
  `error_msg` varchar(500) NOT NULL,
  `is_resolved` tinyint(1) NOT NULL DEFAULT 0,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_vv_portfolio` (`portfolio_id`),
  KEY `idx_vv_asset` (`asset_type`),
  KEY `idx_vv_resolved` (`is_resolved`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
