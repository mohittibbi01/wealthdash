-- ============================================================
-- Table: automation_rules
-- Domain: 015_admin_infra  |  Sequence: 026
-- ============================================================
-- !! STUB: NOT FOUND in any SQL file — never built, stub placeholder
-- !! Define the actual schema before running.
-- ============================================================

CREATE TABLE IF NOT EXISTS `automation_rules` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  -- TODO: define columns
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
