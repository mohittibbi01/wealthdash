-- ============================================================
-- Table: perf_hourly_stats
-- Domain: 015_admin_infra  |  Sequence: 013
-- Source: migrations/t308_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `perf_hourly_stats` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `hour`          DATETIME     NOT NULL COMMENT 'Truncated to hour',
    `action`        VARCHAR(100) NOT NULL DEFAULT '__all__',
    `request_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `avg_ms`        FLOAT        DEFAULT NULL,
    `p95_ms`        FLOAT        DEFAULT NULL,
    `max_ms`        FLOAT        DEFAULT NULL,
    `error_count`   INT UNSIGNED NOT NULL DEFAULT 0,
    `avg_memory_mb` FLOAT        DEFAULT NULL,
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_phs_hour_action` (`hour`, `action`),
    KEY `idx_phs_hour` (`hour`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
