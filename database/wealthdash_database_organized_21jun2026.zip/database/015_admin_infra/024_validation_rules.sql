-- ============================================================
-- Table: validation_rules
-- Domain: 015_admin_infra  |  Sequence: 024
-- Source: migrations/t480_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `validation_rules` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `rule_key` varchar(100) NOT NULL COMMENT 'e.g. mf_units_min, stock_price_max',
  `asset_type` enum('mf','stocks','nps','fd','savings','gold','realestate','crypto','all') NOT NULL DEFAULT 'all',
  `field_name` varchar(100) NOT NULL,
  `rule_type` enum('min','max','required','regex','enum','date_past','date_future','positive','nonzero') NOT NULL,
  `rule_value` varchar(500) DEFAULT NULL COMMENT 'numeric threshold or regex pattern or enum CSV',
  `error_msg` varchar(500) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rule_key` (`rule_key`),
  KEY `idx_vr_asset` (`asset_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
