-- ============================================================
-- Table: external_api_keys
-- Domain: 015_admin_infra  |  Sequence: 005
-- Source: migrations/t335_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `external_api_keys` (
    `id`            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `user_id`       INT UNSIGNED    NOT NULL,
    `name`          VARCHAR(80)     NOT NULL COMMENT 'e.g. My Excel Sheet, HomeAssistant',
    `key_prefix`    VARCHAR(12)     NOT NULL COMMENT 'Public prefix e.g. wdx_ab12cd',
    `key_hash`      VARCHAR(255)    NOT NULL COMMENT 'bcrypt hash of full key',
    `scopes`        JSON            NOT NULL COMMENT 'Array of allowed scopes',
    `rate_limit`    SMALLINT UNSIGNED NOT NULL DEFAULT 60 COMMENT 'Requests per minute',
    `last_used_at`  DATETIME        DEFAULT NULL,
    `last_ip`       VARCHAR(45)     DEFAULT NULL,
    `use_count`     BIGINT UNSIGNED NOT NULL DEFAULT 0,
    `expires_at`    DATE            DEFAULT NULL COMMENT 'NULL = never',
    `is_active`     TINYINT(1)      NOT NULL DEFAULT 1,
    `created_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_eak_prefix` (`key_prefix`),
    KEY `idx_eak_user`   (`user_id`),
    KEY `idx_eak_active` (`is_active`),
    CONSTRAINT `fk_eak_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
