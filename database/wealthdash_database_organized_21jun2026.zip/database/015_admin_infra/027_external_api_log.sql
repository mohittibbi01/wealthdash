-- ============================================================
-- Table: external_api_log
-- Domain: 015_admin_infra  |  Sequence: 027
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `external_api_log` (
    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `key_id`     INT UNSIGNED    NOT NULL,
    `endpoint`   VARCHAR(120)    NOT NULL,
    `method`     VARCHAR(8)      NOT NULL DEFAULT 'GET',
    `status`     SMALLINT        NOT NULL DEFAULT 200,
    `duration_ms`FLOAT           DEFAULT NULL,
    `ip_address` VARCHAR(45)     DEFAULT NULL,
    `created_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_eal_key`     (`key_id`),
    KEY `idx_eal_created` (`created_at`),
    CONSTRAINT `fk_eal_key` FOREIGN KEY (`key_id`) REFERENCES `external_api_keys`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
