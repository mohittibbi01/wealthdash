-- ============================================================
-- Table: external_api_rate
-- Domain: 015_admin_infra  |  Sequence: 006
-- Source: migrations/t335_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `external_api_rate` (
    `key_id`     INT UNSIGNED  NOT NULL,
    `window`     DATETIME      NOT NULL COMMENT 'Truncated to minute',
    `hits`       SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    PRIMARY KEY (`key_id`, `window`),
    CONSTRAINT `fk_ear_key` FOREIGN KEY (`key_id`) REFERENCES `external_api_keys`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
