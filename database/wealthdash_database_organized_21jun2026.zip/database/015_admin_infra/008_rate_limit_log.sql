-- ============================================================
-- Table: rate_limit_log
-- Domain: 015_admin_infra  |  Sequence: 008
-- Source: migrations/t243_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS rate_limit_log (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NULL,
  action     VARCHAR(80)  NOT NULL,
  ip         VARCHAR(45)  NULL,
  hit_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_action_time (action, hit_at),
  KEY idx_user_action (user_id, action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
