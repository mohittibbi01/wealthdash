-- ============================================================
-- Table: audit_retention_config
-- Domain: 015_admin_infra  |  Sequence: 017
-- Source: migrations/t307_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `audit_retention_config` (
    `id`               TINYINT UNSIGNED NOT NULL DEFAULT 1,
    `retention_days`   INT UNSIGNED NOT NULL DEFAULT 365,
    `auto_purge`       TINYINT(1) NOT NULL DEFAULT 0,
    `last_purge_at`    DATETIME DEFAULT NULL,
    `rows_purged`      BIGINT UNSIGNED NOT NULL DEFAULT 0,
    `updated_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
