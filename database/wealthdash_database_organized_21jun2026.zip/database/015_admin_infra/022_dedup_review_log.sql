-- ============================================================
-- Table: dedup_review_log
-- Domain: 015_admin_infra  |  Sequence: 022
-- Source: migrations/t479_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `dedup_review_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_type` enum('mf','stocks','nps') NOT NULL,
  `txn_id` int(10) UNSIGNED NOT NULL,
  `action` enum('merged','dismissed','kept') NOT NULL,
  `reviewed_by` int(10) UNSIGNED NOT NULL,
  `reviewed_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_dedup_txn` (`asset_type`, `txn_id`),
  KEY `idx_dedup_user` (`reviewed_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
