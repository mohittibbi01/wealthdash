-- ============================================================
-- Table: api_rate_limit
-- Domain: 015_admin_infra  |  Sequence: 003
-- Source: migrations/t504_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `api_rate_limit` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `api_key_id` int(10) UNSIGNED NOT NULL,
  `window_start` datetime NOT NULL,
  `request_count` int(10) UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rl_key_window` (`api_key_id`, `window_start`),
  KEY `idx_rl_window` (`window_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
