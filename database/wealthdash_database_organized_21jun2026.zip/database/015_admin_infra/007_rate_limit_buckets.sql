-- ============================================================
-- Table: rate_limit_buckets
-- Domain: 015_admin_infra  |  Sequence: 007
-- Source: migrations/t331_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: t332 identical. Winner: t331

CREATE TABLE IF NOT EXISTS rate_limit_buckets (
  bucket_key   VARCHAR(180) NOT NULL PRIMARY KEY,
  requests     SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  window_start INT UNSIGNED NOT NULL,
  KEY idx_window (window_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
