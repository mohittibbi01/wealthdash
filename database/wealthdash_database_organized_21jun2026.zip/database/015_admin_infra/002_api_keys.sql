-- ============================================================
-- Table: api_keys
-- Domain: 015_admin_infra  |  Sequence: 002
-- Source: migrations/t504_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `api_keys` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `key_name` varchar(100) NOT NULL COMMENT 'e.g. My App, Home Automation',
  `api_key` varchar(64) NOT NULL COMMENT 'SHA-256 hex — shown only once at creation',
  `key_prefix` varchar(8) NOT NULL COMMENT 'First 8 chars — shown in list for identification',
  `scopes` varchar(500) NOT NULL DEFAULT 'portfolio:read' COMMENT 'CSV of allowed scopes',
  `rate_limit` int(10) UNSIGNED NOT NULL DEFAULT 60 COMMENT 'Requests per minute',
  `last_used_at` datetime DEFAULT NULL,
  `last_ip` varchar(45) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `expires_at` datetime DEFAULT NULL COMMENT 'NULL = never expires',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_api_key` (`api_key`),
  KEY `idx_apikey_user` (`user_id`),
  KEY `idx_apikey_prefix` (`key_prefix`),
  CONSTRAINT `fk_apikey_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
