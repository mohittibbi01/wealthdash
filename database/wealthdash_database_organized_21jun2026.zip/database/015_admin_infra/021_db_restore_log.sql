-- ============================================================
-- Table: db_restore_log
-- Domain: 015_admin_infra  |  Sequence: 021
-- Source: migrations/t211_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `db_restore_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `backup_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'NULL if manual upload',
  `filename` varchar(255) NOT NULL,
  `status` enum('pending','running','done','failed') NOT NULL DEFAULT 'pending',
  `tables_restored` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `error_msg` text DEFAULT NULL,
  `restored_by` int(10) UNSIGNED NOT NULL,
  `started_at` datetime NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dbrestore_status` (`status`),
  KEY `idx_dbrestore_started` (`started_at`),
  CONSTRAINT `fk_dbrestore_user` FOREIGN KEY (`restored_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
