-- ============================================================
-- Table: db_query_log
-- Domain: 015_admin_infra  |  Sequence: 020
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `db_query_log` (
    `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`     INT UNSIGNED    NOT NULL,
    `query_text`  TEXT            NOT NULL,
    `rows_affected` INT DEFAULT NULL,
    `exec_ms`     FLOAT DEFAULT NULL,
    `is_success`  TINYINT(1) NOT NULL DEFAULT 1,
    `error_msg`   TEXT DEFAULT NULL,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_dql_user` (`user_id`),
    KEY `idx_dql_created` (`created_at`),
    CONSTRAINT `fk_dql_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
