-- ============================================================
-- Table: perf_request_log
-- Domain: 015_admin_infra  |  Sequence: 012
-- Source: migrations/t308_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `perf_request_log` (
    `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `action`       VARCHAR(100)    NOT NULL,
    `user_id`      INT UNSIGNED    DEFAULT NULL,
    `duration_ms`  FLOAT           NOT NULL,
    `memory_bytes` INT UNSIGNED    DEFAULT NULL,
    `db_queries`   SMALLINT        DEFAULT NULL,
    `status_code`  SMALLINT        DEFAULT 200,
    `ip_address`   VARCHAR(45)     DEFAULT NULL,
    `created_at`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_prl_action`  (`action`),
    KEY `idx_prl_created` (`created_at`),
    KEY `idx_prl_duration`(`duration_ms`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
