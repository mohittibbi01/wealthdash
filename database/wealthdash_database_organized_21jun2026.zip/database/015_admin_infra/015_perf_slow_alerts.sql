-- ============================================================
-- Table: perf_slow_alerts
-- Domain: 015_admin_infra  |  Sequence: 015
-- Source: migrations/t308_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `perf_slow_alerts` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `action`      VARCHAR(100) NOT NULL,
    `duration_ms` FLOAT        NOT NULL,
    `threshold_ms`FLOAT        NOT NULL,
    `user_id`     INT UNSIGNED DEFAULT NULL,
    `ip_address`  VARCHAR(45)  DEFAULT NULL,
    `context`     TEXT         DEFAULT NULL,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_psa_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
