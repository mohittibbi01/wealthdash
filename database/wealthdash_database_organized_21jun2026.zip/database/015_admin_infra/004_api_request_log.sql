-- ============================================================
-- Table: api_request_log
-- Domain: 015_admin_infra  |  Sequence: 004
-- Source: migrations/t504_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `api_request_log` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `api_key_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `method` varchar(10) NOT NULL,
  `endpoint` varchar(200) NOT NULL,
  `status_code` smallint(5) UNSIGNED NOT NULL DEFAULT 200,
  `response_ms` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `requested_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_apirl_key` (`api_key_id`),
  KEY `idx_apirl_user` (`user_id`),
  KEY `idx_apirl_req` (`requested_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
