# WealthDash Database — Organized Structure
**Reorganized: 21 June 2026** | 303 tables | 22 domains | 252 files

---

## Naye PC pe Setup (3 Steps)

```bash
# Step 1: MySQL mein wealthdash database banao
mysql -u root -p -e "CREATE DATABASE wealthdash CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# Step 2: Sab kuch ek command mein install karo
mysql -u root -p wealthdash < install.sql

# Step 3: Done! 306 tables + 5 seed rows ek hi file se.
```

Ya phpMyAdmin se: `wealthdash` database select karo → Import tab → `install.sql` upload karo → Go.

---

## Folder Structure

```
database/
  001_core/                     10 files   — users, sessions, auth, settings, portfolios
  002_mutual_funds/             42 files   — funds, NAV, SIP, benchmarks, watchlist
  003_stocks/                   25 files   — holdings, screener, ESOP, SIP, international
  004_fd_rd_savings/            16 files   — FD, RD, bank accounts, savings, sweep
  005_gold/                      6 files   — SGB, physical gold, price cache
  006_bonds_govt_securities/     7 files   — bonds, G-Secs, 54EC, NCDs, NSC, MIS/SCSS
  007_crypto/                   18 files   — holdings, DeFi, cold wallet, VDA tax
  008_epf_nps_retirement/       16 files   — EPF, NPS, gratuity, PPF, EPFO UAN
  009_insurance/                 7 files   — insurance, ULIP, health, premiums
  010_loans_credit/              7 files   — loans, credit cards, CIBIL, EMI
  011_property/                  4 files   — real estate, property, rental
  012_goals_budget/             13 files   — goals, budget, Monte Carlo, daily checkins
  013_tax/                       5 files   — AIS, 80C, LTA, leave encashment, indexation
  014_ai_features/              14 files   — AI chat, advisor, anomaly detection, narratives
  015_admin_infra/              17 files   — API keys, rate limit, perf monitor, DB backups
  016_import_export/            10 files   — Groww, bulk import, CSV v3, data export
  017_reports_sharing/           2 files   — report share tokens
  018_journal_gamification/      3 files   — journal entries, streaks, badges
  019_notifications_alerts/      6 files   — notifications, price alerts, smart alerts
  020_dashboard_ui/              4 files   — dashboard layouts, widgets, onboarding
  021_broker_integrations/      13 files   — Zerodha (9 tables), Smallcase (4 tables)
  022_other_investments/         7 files   — ETF, PMS (nav, holdings, transactions)

  seeds/                         5 files   — app_settings defaults, perf baselines, etc.
  install.sql                              — MASTER SCRIPT (saari files combined, run this)
  README.md                                — ye file
```

Har file ka naam: `NNN_tablename.sql` (NNN = dependency order ke hisaab se sequence number).

---

## Ek Domain ki Files Alag Se Run Karna

Agar sirf ek module add karna hai (jaise sirf crypto feature kisi existing database mein):

```bash
# Sirf 007_crypto ki saari tables:
cat database/007_crypto/*.sql | mysql -u root -p wealthdash

# Ya phpMyAdmin mein ek-ek file import kar sakte ho
```

**Dhyan rakhna:** `001_core` sabse pehle honi chahiye (users, portfolios) kyunki baaki sab uspe depend karte hain.

---

## Conflicts Jo Resolve Kiye Gaye

Reorganize karte waqt **39 tables** mili jinka schema do ya zyada jagah define hua tha. Ye sab resolve kar diye:

| Table | Kitne versions | Kya kiya |
|-------|---------------|----------|
| `user_sessions` | 3 | Live PHP code (`api/auth/session_security.php`) se authoritative schema liya — woh `country`/`is_current` column add karta hai jo kisi migration mein nahi tha |
| `app_settings` | 2 + live code | Live `global_settings.php` ne `setting_group`, `setting_type`, `label`, `description`, `is_public`, `is_locked` columns expect kiye jo kisi migration mein nahi the — yahan add kiye |
| `audit_log` | 2 | Base schema winner (entity_type/old_values/new_values ka JSON diff — live code issi ko use karta hai) |
| `sgb_holdings` | 4 | t113 winner (isin, nse_symbol — richest) |
| `nav_download_progress` | 3 + live code | Superset schema banaya jisme sab versions ke columns hain |
| `mf_dividends` | 3 | 14_ winner (nav_before/after, rate_per_unit) |
| `esop_grants/vesting` | 3 each | t117 winner (perquisite_value, PHANTOM type) |
| `bank_accounts` | 2 | t43 winner (branch, nickname, more account types) |
| `crypto_holdings` | 3 | 38_ winner (CoinGecko string ID, portfolio FK) |
| + 30 aur | | Har file mein CONFLICT RESOLVED comment likha hai |

---

## Known Issues / Future Work

1. **`cibil_history`** — koi bhi migration file mein implement nahi hui thi (40_cibil_history.sql sirf TODO placeholder tha). `010_loans_credit/007_cibil_history.sql` mein inferred schema diya hai — `api/credit/cibil.php` ke saath verify karna.

2. **`bond_holdings`** — same situation, 30_bond_holdings.sql = TODO. Bond data `bonds` table mein stored hai (004_bonds.sql), alag holdings table ki zaroorat nahi lagi.

3. **REST-style features (t38, t39, t114, t116, t118, t121, t145, t432, t435, t436)** — in 10 features ka backend PHP classes ke roop mein bana hai (`GoldTracker`, `BondsTracker`, etc.). Inke migration files hain aur tables yahan included hain, lekin `api/rest_dispatch.php` ka security note zaroor padho (router_merge_README.md mein detail hai).

4. **`recalc_holdings.php`** — router.php mein referenced hai lekin file exist nahi karti. Ye router merge se pehle se tha, humara nahi.

---

## Pehle Se Bane Database Pe Apply Karna (Existing DB)

Agar sirf naye features add karne hain existing database mein:

```bash
# Only run the specific domain(s) you need
# Example: sirf import/export feature ke tables add karna
cat database/016_import_export/*.sql | mysql -u root -p wealthdash
```

`IF NOT EXISTS` use hota hai har jagah — already-existing tables skip ho jayengi, koi error nahi ayega.

---

*WealthDash Database | Reorganized from 226 original SQL files | 21 June 2026*
