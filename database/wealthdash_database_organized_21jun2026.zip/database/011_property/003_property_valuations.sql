-- ============================================================
-- Table: property_valuations
-- Domain: 011_property  |  Sequence: 003
-- Source: migrations/t463_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS property_valuations (
  id              INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  property_id     INT UNSIGNED  NOT NULL,
  current_value   DECIMAL(16,2) NOT NULL DEFAULT 0,
  valuation_date  DATE          NOT NULL,
  source          VARCHAR(50)   NULL DEFAULT 'manual',
  notes           VARCHAR(255)  NULL,
  created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_property_date (property_id, valuation_date),
  CONSTRAINT fk_pv_property FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
