-- ============================================================
-- Table: reits_invits_distributions
-- Domain: 011_property  |  Sequence: 008
-- Source: migrations/t115_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS reits_invits_distributions (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    holding_id       INT UNSIGNED NOT NULL,
    user_id          INT UNSIGNED NOT NULL,
    symbol           VARCHAR(30)  NOT NULL,
    dist_type        ENUM('dividend','interest','SPD','return_of_capital') NOT NULL DEFAULT 'dividend',
    ex_date          DATE         NOT NULL,
    pay_date         DATE         DEFAULT NULL,
    per_unit_amount  DECIMAL(10,4) NOT NULL,
    units_held       DECIMAL(14,4) NOT NULL,
    total_amount     DECIMAL(12,2) NOT NULL,
    tds_deducted     DECIMAL(10,2) DEFAULT 0,
    net_amount       DECIMAL(12,2) NOT NULL,
    notes            TEXT          DEFAULT NULL,
    created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_holding (holding_id),
    INDEX idx_user    (user_id),
    INDEX idx_ex_date (ex_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
