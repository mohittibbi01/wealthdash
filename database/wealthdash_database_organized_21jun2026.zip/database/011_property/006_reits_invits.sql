-- ============================================================
-- Table: reits_invits
-- Domain: 011_property  |  Sequence: 006
-- Source: migrations/t115_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS reits_invits (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id          INT UNSIGNED NOT NULL,
    portfolio_id     INT UNSIGNED NOT NULL,
    symbol           VARCHAR(30)  NOT NULL,
    name             VARCHAR(200) NOT NULL,
    trust_type       ENUM('REIT','InvIT') NOT NULL DEFAULT 'REIT',
    exchange         ENUM('NSE','BSE') NOT NULL DEFAULT 'NSE',
    isin             VARCHAR(20)  DEFAULT NULL,
    units            DECIMAL(14,4) NOT NULL DEFAULT 0,
    avg_buy_price    DECIMAL(12,4) NOT NULL DEFAULT 0,
    total_invested   DECIMAL(14,2) NOT NULL DEFAULT 0,
    current_price    DECIMAL(12,4) DEFAULT NULL,
    current_value    DECIMAL(14,2) DEFAULT NULL,
    gain_loss        DECIMAL(14,2) DEFAULT NULL,
    gain_loss_pct    DECIMAL(8,4)  DEFAULT NULL,
    last_price_date  DATE          DEFAULT NULL,
    notes            TEXT          DEFAULT NULL,
    created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user   (user_id),
    INDEX idx_portfolio (portfolio_id),
    INDEX idx_symbol (symbol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
