-- ============================================================
-- Table: reits_invits_master
-- Domain: 011_property  |  Sequence: 005
-- Source: migrations/t115_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS reits_invits_master (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    symbol      VARCHAR(30)  NOT NULL UNIQUE,
    name        VARCHAR(200) NOT NULL,
    trust_type  ENUM('REIT','InvIT') NOT NULL,
    exchange    VARCHAR(10)  NOT NULL DEFAULT 'NSE',
    isin        VARCHAR(20)  DEFAULT NULL,
    sector      VARCHAR(100) DEFAULT NULL,
    sponsor     VARCHAR(200) DEFAULT NULL,
    is_active   TINYINT(1)   NOT NULL DEFAULT 1,
    INDEX idx_type (trust_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
