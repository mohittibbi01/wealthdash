-- ============================================================
-- Table: real_estate
-- Domain: 011_property  |  Sequence: 001
-- Source: migrations/t466_real_estate_physical_gold.sql
-- ============================================================
-- Note: 37_real_estate.sql was a TODO placeholder (discarded).
-- Actual implementation found in t466.
-- ============================================================

CREATE TABLE IF NOT EXISTS `real_estate` (
  `id`                  int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`        int(10) UNSIGNED NOT NULL,
  `property_name`       varchar(150) NOT NULL COMMENT 'e.g. 2BHK Malviya Nagar',
  `property_type`       enum('residential','commercial','plot','agricultural','other') NOT NULL DEFAULT 'residential',
  `address`             text DEFAULT NULL,
  `city`                varchar(80) DEFAULT NULL,
  `state`               varchar(80) DEFAULT NULL,
  `purchase_date`       date NOT NULL,
  `purchase_price`      decimal(18,2) NOT NULL COMMENT 'Total cost including stamp duty, registration',
  `current_value`       decimal(18,2) NOT NULL COMMENT 'Self-assessed current market value',
  `last_valued_date`    date DEFAULT NULL COMMENT 'When was current_value last updated',
  `is_self_occupied`    tinyint(1) NOT NULL DEFAULT 0,
  `monthly_rental`      decimal(12,2) DEFAULT NULL COMMENT 'Monthly rental income (if let out)',
  `annual_expenses`     decimal(12,2) DEFAULT NULL COMMENT 'Annual maintenance, property tax, etc.',
  `outstanding_loan`    decimal(18,2) DEFAULT NULL COMMENT 'Linked home loan outstanding (manual)',
  `loan_account_id`     int(10) UNSIGNED DEFAULT NULL COMMENT 'FK to loan_accounts if available',
  `ownership_pct`       decimal(5,2) NOT NULL DEFAULT 100.00 COMMENT 'Your ownership percentage',
  `notes`               text DEFAULT NULL,
  `is_active`           tinyint(1) NOT NULL DEFAULT 1,
  `created_at`          datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`          datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_re_portfolio`   (`portfolio_id`),
  KEY `idx_re_type`        (`property_type`),
  KEY `idx_re_active`      (`is_active`),
  CONSTRAINT `fk_re_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='t466: Real estate holdings';
