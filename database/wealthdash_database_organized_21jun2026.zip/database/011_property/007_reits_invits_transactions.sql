-- ============================================================
-- Table: reits_invits_transactions
-- Domain: 011_property  |  Sequence: 007
-- Source: migrations/t115_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS reits_invits_transactions (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    holding_id       INT UNSIGNED NOT NULL,
    user_id          INT UNSIGNED NOT NULL,
    portfolio_id     INT UNSIGNED NOT NULL,
    symbol           VARCHAR(30)  NOT NULL,
    transaction_type ENUM('BUY','SELL','DIVIDEND','DISTRIBUTION') NOT NULL,
    txn_date         DATE         NOT NULL,
    units            DECIMAL(14,4) NOT NULL,
    price            DECIMAL(12,4) NOT NULL,
    amount           DECIMAL(14,2) NOT NULL,
    brokerage        DECIMAL(10,2) DEFAULT 0,
    notes            TEXT          DEFAULT NULL,
    created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_holding (holding_id),
    INDEX idx_user    (user_id),
    INDEX idx_date    (txn_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
