-- ============================================================
-- Table: ulip_fund_values
-- Domain: 009_insurance  |  Sequence: 003
-- Source: migrations/t323_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS ulip_fund_values (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ulip_id     INT UNSIGNED  NOT NULL,
  fund_name   VARCHAR(150)  NOT NULL,
  units       DECIMAL(14,4) NOT NULL DEFAULT 0,
  nav         DECIMAL(12,4) NOT NULL DEFAULT 0,
  value_date  DATE          NOT NULL,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ulip (ulip_id, value_date),
  CONSTRAINT fk_ufv_ulip FOREIGN KEY (ulip_id) REFERENCES ulip_policies(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
