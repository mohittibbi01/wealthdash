-- ============================================================
-- Table: health_insurance_members
-- Domain: 009_insurance  |  Sequence: 006
-- Source: migrations/t460_health_insurance_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `health_insurance_members` (
  `id`            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `policy_id`     INT UNSIGNED    NOT NULL,
  `member_name`   VARCHAR(100)    NOT NULL,
  `relation`      ENUM('self','spouse','son','daughter','father','mother','father_in_law','mother_in_law','other') NOT NULL DEFAULT 'self',
  `dob`           DATE            NULL,
  `age`           TINYINT UNSIGNED NULL,
  `gender`        ENUM('male','female','other') NULL,
  `pre_existing`  TEXT            NULL COMMENT 'Pre-existing conditions (comma-sep)',
  `sum_insured`   DECIMAL(12,2)   NULL COMMENT 'Individual SI if not floater',
  `notes`         TEXT            NULL,
  `created_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_him_policy`  (`policy_id`),
  CONSTRAINT `fk_him_policy` FOREIGN KEY (`policy_id`) REFERENCES `insurance_policies`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Members covered under health insurance policies (t460)';
