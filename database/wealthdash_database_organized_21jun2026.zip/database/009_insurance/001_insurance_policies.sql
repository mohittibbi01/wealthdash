-- ============================================================
-- Table: insurance_policies
-- Domain: 009_insurance  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================
-- CONFLICT RESOLVED: 3-WAY CONFLICT: 32_insurance_policies.sql (TODO placeholder), t122_migration.sql (simpler). Winner: base schema (has policy_type enum, premium_mode, FK)

CREATE TABLE IF NOT EXISTS `insurance_policies` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `policy_number` varchar(50) DEFAULT NULL,
  `insurer_name` varchar(100) NOT NULL,
  `policy_type` enum('term','health','ulip','endowment','money_back','vehicle','home','travel','other') NOT NULL DEFAULT 'term',
  `insured_name` varchar(100) DEFAULT NULL,
  `sum_assured` decimal(16,2) NOT NULL DEFAULT 0.00,
  `premium_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `premium_frequency` enum('monthly','quarterly','half_yearly','yearly','single') NOT NULL DEFAULT 'yearly',
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `maturity_date` date DEFAULT NULL,
  `maturity_amount` decimal(16,2) DEFAULT NULL,
  `surrender_value` decimal(16,2) DEFAULT NULL,
  `status` enum('active','lapsed','surrendered','matured','claimed') NOT NULL DEFAULT 'active',
  `nominee` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ins_portfolio` (`portfolio_id`),
  KEY `idx_ins_type` (`policy_type`),
  CONSTRAINT `fk_ins_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
