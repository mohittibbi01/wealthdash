-- ============================================================
-- Table: health_insurance_claims
-- Domain: 009_insurance  |  Sequence: 007
-- Source: migrations/t460_health_insurance_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `health_insurance_claims` (
  `id`              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `policy_id`       INT UNSIGNED    NOT NULL,
  `member_id`       INT UNSIGNED    NULL COMMENT 'FK to health_insurance_members',
  `claim_number`    VARCHAR(60)     NULL,
  `claim_type`      ENUM('cashless','reimbursement') NOT NULL DEFAULT 'reimbursement',
  `claim_date`      DATE            NOT NULL,
  `hospital_name`   VARCHAR(150)    NULL,
  `diagnosis`       VARCHAR(200)    NULL,
  `admission_date`  DATE            NULL,
  `discharge_date`  DATE            NULL,
  `claimed_amount`  DECIMAL(14,2)   NOT NULL DEFAULT 0,
  `approved_amount` DECIMAL(14,2)   NULL,
  `settled_amount`  DECIMAL(14,2)   NULL,
  `deducted_amount` DECIMAL(14,2)   NULL COMMENT 'Copay + deductible applied',
  `status`          ENUM('submitted','under_review','approved','partially_approved','rejected','settled','withdrawn') NOT NULL DEFAULT 'submitted',
  `settlement_date` DATE            NULL,
  `rejection_reason`VARCHAR(300)    NULL,
  `documents_submitted` TEXT        NULL COMMENT 'Documents list',
  `notes`           TEXT            NULL,
  `created_at`      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_hic_policy`  (`policy_id`),
  KEY `idx_hic_member`  (`member_id`),
  KEY `idx_hic_status`  (`status`),
  KEY `idx_hic_date`    (`claim_date`),
  CONSTRAINT `fk_hic_policy` FOREIGN KEY (`policy_id`) REFERENCES `insurance_policies`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hic_member` FOREIGN KEY (`member_id`) REFERENCES `health_insurance_members`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT 'Health insurance claims tracker (t460)';
