-- ============================================================
-- Table: leave_encashment
-- Domain: 013_tax  |  Sequence: 004
-- Source: migrations/t49_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `leave_encashment` (
  `id`                   int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`              int(10) UNSIGNED NOT NULL,
  `encashment_date`      date             NOT NULL,
  `employer_type`        enum('govt','private') NOT NULL DEFAULT 'private',
  `amount_received`      decimal(14,2)    NOT NULL,
  `avg_10month_salary`   decimal(14,2)    NOT NULL DEFAULT 0.00,
  `leave_balance_days`   int              NOT NULL DEFAULT 0,
  `exempt_amount`        decimal(14,2)    NOT NULL DEFAULT 0.00,
  `taxable_amount`       decimal(14,2)    NOT NULL DEFAULT 0.00,
  `notes`                varchar(255)     DEFAULT NULL,
  `created_at`           datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_le_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
