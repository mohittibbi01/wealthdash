-- ============================================================
-- Table: tax_80c_manual_entries
-- Domain: 013_tax  |  Sequence: 002
-- Source: migrations/t48_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `tax_80c_manual_entries` (
  `id`          int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     int(10) UNSIGNED NOT NULL,
  `fy_year`     smallint(4)      NOT NULL COMMENT 'FY start year e.g. 2024 for FY2024-25',
  `category`    enum('lic_premium','elss','home_loan_principal','tuition_fee',
                     'nsc_purchase','sukanya_samridhi','stamp_duty',
                     'unit_linked_insurance','other') NOT NULL DEFAULT 'other',
  `section`     enum('80C','80CCD(1B)','80D','80E') NOT NULL DEFAULT '80C',
  `amount`      decimal(12,2)    NOT NULL,
  `description` varchar(255)     DEFAULT NULL,
  `is_active`   tinyint(1)       NOT NULL DEFAULT 1,
  `created_at`  datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`  datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_80c_user_fy` (`user_id`, `fy_year`),
  KEY `idx_80c_section` (`section`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
