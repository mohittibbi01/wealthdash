-- ============================================================
-- Table: lta_entries
-- Domain: 013_tax  |  Sequence: 005
-- Source: migrations/t49_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `lta_entries` (
  `id`              int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`         int(10) UNSIGNED NOT NULL,
  `travel_date`     date             NOT NULL,
  `destination`     varchar(150)     NOT NULL,
  `mode_of_travel`  enum('air','train','bus','other') NOT NULL DEFAULT 'train',
  `actual_fare`     decimal(12,2)    NOT NULL,
  `is_claimed`      tinyint(1)       NOT NULL DEFAULT 0,
  `claim_amount`    decimal(12,2)    NOT NULL DEFAULT 0.00,
  `exempt_amount`   decimal(12,2)    NOT NULL DEFAULT 0.00,
  `taxable_amount`  decimal(12,2)    NOT NULL DEFAULT 0.00,
  `notes`           varchar(255)     DEFAULT NULL,
  `created_at`      datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_lta_user_date` (`user_id`,`travel_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
