-- ============================================================
-- Table: us_lrs_tracker
-- Domain: 013_tax  |  Sequence: 006
-- Source: migrations/t456_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `us_lrs_tracker` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `financial_year`  VARCHAR(10)  NOT NULL  COMMENT 'e.g. FY2024-25',
    `remitted_usd`    DECIMAL(14,4) NOT NULL DEFAULT 0,
    `remitted_inr`    DECIMAL(18,4) NOT NULL DEFAULT 0,
    `limit_usd`       DECIMAL(14,4) NOT NULL DEFAULT 250000  COMMENT 'RBI LRS limit: $250,000/yr',
    `notes`           TEXT DEFAULT NULL,
    `updated_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_ulrs_user_fy` (`user_id`, `financial_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
