-- ============================================================
-- Table: lrs_remittances
-- Domain: 013_tax  |  Sequence: 007
-- Source: migrations_20jun2026_combined.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS lrs_remittances (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    remittance_date DATE NOT NULL,
    amount_inr DECIMAL(15,2) NOT NULL,
    amount_foreign DECIMAL(15,4) NOT NULL,
    currency VARCHAR(5) DEFAULT 'USD',
    exchange_rate DECIMAL(10,4) NOT NULL,
    purpose VARCHAR(200) COMMENT 'Investment/Education/Travel/etc',
    bank_name VARCHAR(100),
    forex_charges DECIMAL(10,2) DEFAULT 0.00,
    tcs_paid DECIMAL(10,2) DEFAULT 0.00 COMMENT 'TCS @ 20% above 7L threshold',
    financial_year VARCHAR(10),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_fy (financial_year),
    INDEX idx_date (remittance_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
