-- ============================================================
-- Table: international_stocks
-- Domain: 003_stocks  |  Sequence: 020
-- Source: migrations/t121_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS international_stocks (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    ticker VARCHAR(20) NOT NULL,
    stock_name VARCHAR(200) NOT NULL,
    exchange VARCHAR(20) NOT NULL COMMENT 'NYSE/NASDAQ/LSE/etc',
    country VARCHAR(5) DEFAULT 'US',
    currency VARCHAR(5) DEFAULT 'USD',
    quantity DECIMAL(15,6) NOT NULL COMMENT 'fractional shares allowed',
    avg_buy_price_foreign DECIMAL(15,4) NOT NULL COMMENT 'in foreign currency',
    avg_buy_price_inr DECIMAL(15,4) NOT NULL COMMENT 'INR at time of purchase',
    current_price_foreign DECIMAL(15,4) DEFAULT NULL,
    current_price_inr DECIMAL(15,4) DEFAULT NULL,
    broker_platform VARCHAR(100) COMMENT 'Vested/Indmoney/Stockal/etc',
    sector VARCHAR(100),
    notes TEXT,
    is_active TINYINT(1) DEFAULT 1,
    last_refreshed TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_ticker (ticker),
    INDEX idx_exchange (exchange),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
