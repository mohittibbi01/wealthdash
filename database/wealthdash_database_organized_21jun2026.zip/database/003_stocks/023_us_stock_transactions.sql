-- ============================================================
-- Table: us_stock_transactions
-- Domain: 003_stocks  |  Sequence: 023
-- Source: migrations/t456_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `us_stock_transactions` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `stock_id`        INT UNSIGNED NOT NULL,
    `type`            ENUM('buy','sell','dividend','transfer_in','transfer_out') NOT NULL DEFAULT 'buy',
    `quantity`        DECIMAL(16,6) NOT NULL,
    `price_usd`       DECIMAL(14,4) NOT NULL DEFAULT 0,
    `price_inr`       DECIMAL(14,4) DEFAULT NULL,
    `total_usd`       DECIMAL(18,4) DEFAULT 0,
    `total_inr`       DECIMAL(18,4) DEFAULT 0,
    `usd_inr_rate`    DECIMAL(10,4) DEFAULT NULL         COMMENT 'Exchange rate at transaction time',
    `fee_usd`         DECIMAL(10,4) DEFAULT 0,
    `broker`          VARCHAR(50)   DEFAULT NULL,
    `account_type`    ENUM('LRS','GIFT_CITY','DOMESTIC_BROKER','OTHER') DEFAULT 'LRS',
    `txn_date`        DATE          NOT NULL,
    `notes`           TEXT          DEFAULT NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_ust_portfolio` (`portfolio_id`),
    INDEX `idx_ust_stock`     (`stock_id`),
    INDEX `idx_ust_date`      (`txn_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
