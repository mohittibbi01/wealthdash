-- ============================================================
-- Table: stock_screener_filters
-- Domain: 003_stocks  |  Sequence: 010
-- Source: migrations/t431_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_screener_filters` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`     INT UNSIGNED NOT NULL,
    `name`        VARCHAR(100) NOT NULL,
    `filter_json` JSON         NOT NULL,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_ssf_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
