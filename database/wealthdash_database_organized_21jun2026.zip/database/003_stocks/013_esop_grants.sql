-- ============================================================
-- Table: esop_grants
-- Domain: 003_stocks  |  Sequence: 013
-- Source: migrations/t117_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 31_esop_grants.sql (TODO placeholder, discarded), migrations/019_esop.sql (fewer columns). Winner: t117 (richest — company_symbol, grant_ref, PHANTOM type, currency)

CREATE TABLE IF NOT EXISTS `esop_grants` (
    `id`                     INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`           INT UNSIGNED NOT NULL,
    `company_name`           VARCHAR(200) NOT NULL,
    `company_symbol`         VARCHAR(30)  DEFAULT NULL           COMMENT 'NSE/BSE symbol if listed',
    `grant_type`             ENUM('ESOP','RSU','SAR','PHANTOM')  NOT NULL DEFAULT 'ESOP',
    `grant_date`             DATE         NOT NULL,
    `grant_ref`              VARCHAR(100) DEFAULT NULL           COMMENT 'Internal grant ID / ref',
    `total_options`          INT UNSIGNED NOT NULL               COMMENT 'Total options/units granted',
    `exercise_price`         DECIMAL(12,4) NOT NULL DEFAULT 0   COMMENT '0 for RSU',
    `currency`               CHAR(3)      NOT NULL DEFAULT 'INR',
    `vesting_start`          DATE         NOT NULL,
    `vesting_cliff_months`   SMALLINT UNSIGNED NOT NULL DEFAULT 12,
    `vesting_period_months`  SMALLINT UNSIGNED NOT NULL DEFAULT 48,
    `vesting_schedule`       VARCHAR(100) DEFAULT '1/4 per year' COMMENT 'Human-readable schedule',
    `vesting_type`           ENUM('cliff','graded','custom')    NOT NULL DEFAULT 'graded',
    `current_fmv`            DECIMAL(12,4) DEFAULT NULL         COMMENT 'FMV per share today',
    `fmv_updated_at`         DATETIME     DEFAULT NULL,
    `options_vested`         INT UNSIGNED NOT NULL DEFAULT 0,
    `options_exercised`      INT UNSIGNED NOT NULL DEFAULT 0,
    `options_lapsed`         INT UNSIGNED NOT NULL DEFAULT 0,
    `status`                 ENUM('active','fully_vested','lapsed','exercised_partial','exercised_full','cancelled')
                             NOT NULL DEFAULT 'active',
    `expiry_date`            DATE         DEFAULT NULL           COMMENT 'ESOP exercise window expiry',
    `notes`                  TEXT         DEFAULT NULL,
    `created_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_esop_portfolio` (`portfolio_id`),
    INDEX `idx_esop_status`    (`status`),
    INDEX `idx_esop_grant_date`(`grant_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
