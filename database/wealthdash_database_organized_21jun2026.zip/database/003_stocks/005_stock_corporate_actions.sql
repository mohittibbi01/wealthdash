-- ============================================================
-- Table: stock_corporate_actions
-- Domain: 003_stocks  |  Sequence: 005
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_corporate_actions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `stock_id` int(10) UNSIGNED NOT NULL,
  `action_type` enum('split','bonus','rights','merger','demerger') NOT NULL,
  `action_date` date NOT NULL,
  `ratio_from` decimal(10,4) DEFAULT NULL,
  `ratio_to` decimal(10,4) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sca_stock` (`stock_id`),
  CONSTRAINT `fk_sca_stock` FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
