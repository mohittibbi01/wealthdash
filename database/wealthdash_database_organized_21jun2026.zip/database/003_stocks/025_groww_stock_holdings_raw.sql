-- ============================================================
-- Table: groww_stock_holdings_raw
-- Domain: 003_stocks  |  Sequence: 025
-- Source: migrations/t392_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `groww_stock_holdings_raw` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT UNSIGNED NOT NULL,
    `sync_log_id`     INT UNSIGNED NOT NULL,
    `symbol`          VARCHAR(30)  NOT NULL,
    `company_name`    VARCHAR(200) DEFAULT NULL,
    `exchange`        VARCHAR(10)  DEFAULT 'NSE',
    `isin`            VARCHAR(20)  DEFAULT NULL,
    `quantity`        DECIMAL(14,4) DEFAULT NULL,
    `avg_price`       DECIMAL(12,4) DEFAULT NULL,
    `ltp`             DECIMAL(12,4) DEFAULT NULL,
    `invested_value`  DECIMAL(14,2) DEFAULT NULL,
    `current_value`   DECIMAL(14,2) DEFAULT NULL,
    `pnl`             DECIMAL(14,2) DEFAULT NULL,
    `synced_at`       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user`  (`user_id`),
    INDEX `idx_sync`  (`sync_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
