-- ============================================================
-- Table: screener_filters
-- Domain: 003_stocks  |  Sequence: 017
-- Source: migrations/t38_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS screener_filters (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    filter_name VARCHAR(100) NOT NULL,
    filter_config JSON NOT NULL COMMENT 'JSON object with filter criteria',
    is_default TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
