-- ============================================================
-- Table: stock_holdings
-- Domain: 003_stocks  |  Sequence: 002
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_holdings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `stock_id` int(10) UNSIGNED NOT NULL,
  `quantity` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `avg_price` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `invested_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `current_value` decimal(16,2) NOT NULL DEFAULT 0.00,
  `gain_loss` decimal(16,2) NOT NULL DEFAULT 0.00,
  `gain_pct` decimal(8,4) NOT NULL DEFAULT 0.0000,
  `current_price` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `first_purchase_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sh` (`portfolio_id`, `stock_id`),
  KEY `idx_sh_stock` (`stock_id`),
  CONSTRAINT `fk_sh_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sh_stock` FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
