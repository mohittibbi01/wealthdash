-- ============================================================
-- Table: esop_vesting_events
-- Domain: 003_stocks  |  Sequence: 014
-- Source: migrations/t117_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 39_esop_vesting_events.sql (TODO placeholder, discarded), migrations/019_esop.sql (fewer columns). Winner: t117 (perquisite_value, perquisite_tax columns)

CREATE TABLE IF NOT EXISTS `esop_vesting_events` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `grant_id`        INT UNSIGNED NOT NULL,
    `vest_date`       DATE         NOT NULL,
    `units_vested`    INT UNSIGNED NOT NULL,
    `fmv_on_vest`     DECIMAL(12,4) DEFAULT NULL COMMENT 'FMV per share on vest date (perquisite value)',
    `perquisite_value`DECIMAL(14,4) DEFAULT NULL COMMENT '(fmv - exercise_price) * units',
    `perquisite_tax`  DECIMAL(14,4) DEFAULT NULL COMMENT 'Estimated tax on perquisite',
    `tax_slab_pct`    DECIMAL(5,2)  DEFAULT NULL,
    `is_exercised`    TINYINT(1)    NOT NULL DEFAULT 0,
    `exercise_date`   DATE          DEFAULT NULL,
    `exercise_price`  DECIMAL(12,4) DEFAULT NULL,
    `units_exercised` INT UNSIGNED  DEFAULT 0,
    `sale_date`       DATE          DEFAULT NULL,
    `sale_price`      DECIMAL(12,4) DEFAULT NULL,
    `units_sold`      INT UNSIGNED  DEFAULT 0,
    `capital_gain`    DECIMAL(14,4) DEFAULT NULL,
    `gain_type`       ENUM('STCG','LTCG') DEFAULT NULL,
    `notes`           VARCHAR(255)  DEFAULT NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_esop_vest_grant`  (`grant_id`),
    INDEX `idx_esop_vest_date`   (`vest_date`),
    INDEX `idx_esop_vest_exercised` (`is_exercised`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
