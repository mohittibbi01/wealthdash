-- ============================================================
-- Table: stock_fundamentals_history
-- Domain: 003_stocks  |  Sequence: 009
-- Source: migrations/t431_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_fundamentals_history` (
    `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `stock_id`         INT UNSIGNED NOT NULL  COMMENT 'FK stock_master.id',
    `period`           VARCHAR(10)  NOT NULL  COMMENT 'e.g. Q3FY25, FY2024',
    `period_type`      ENUM('quarterly','annual') NOT NULL DEFAULT 'quarterly',
    `pe_ratio`         DECIMAL(12,4) DEFAULT NULL,
    `pb_ratio`         DECIMAL(10,4) DEFAULT NULL,
    `market_cap`       DECIMAL(22,4) DEFAULT NULL,
    `eps`              DECIMAL(12,4) DEFAULT NULL,
    `revenue`          DECIMAL(22,4) DEFAULT NULL,
    `net_profit`       DECIMAL(22,4) DEFAULT NULL,
    `roe`              DECIMAL(8,4)  DEFAULT NULL,
    `roce`             DECIMAL(8,4)  DEFAULT NULL,
    `debt_to_equity`   DECIMAL(10,4) DEFAULT NULL,
    `promoter_holding` DECIMAL(6,3)  DEFAULT NULL,
    `fii_holding`      DECIMAL(6,3)  DEFAULT NULL,
    `source`           VARCHAR(30)   DEFAULT NULL,
    `fetched_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_sfh_stock_period` (`stock_id`, `period`, `period_type`),
    INDEX `idx_sfh_stock` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
