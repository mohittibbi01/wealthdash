-- ============================================================
-- Table: stock_fundamental_history
-- Domain: 003_stocks  |  Sequence: 007
-- Source: migrations/t281_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_fundamental_history` (
  `id`             INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `stock_id`       INT UNSIGNED    NOT NULL,
  `symbol`         VARCHAR(30)     NOT NULL,
  `snapshot_date`  DATE            NOT NULL  COMMENT 'Date of this snapshot',
  `pe_ratio`       DECIMAL(10,4)   NULL DEFAULT NULL,
  `pb_ratio`       DECIMAL(10,4)   NULL DEFAULT NULL,
  `eps`            DECIMAL(12,4)   NULL DEFAULT NULL,
  `market_cap`     DECIMAL(22,2)   NULL DEFAULT NULL COMMENT 'Market cap in INR',
  `dividend_yield` DECIMAL(8,4)    NULL DEFAULT NULL,
  `high_52`        DECIMAL(14,4)   NULL DEFAULT NULL,
  `low_52`         DECIMAL(14,4)   NULL DEFAULT NULL,
  `price_on_date`  DECIMAL(12,4)   NULL DEFAULT NULL COMMENT 'LTP at time of snapshot',
  `source`         VARCHAR(30)     NOT NULL DEFAULT 'yahoo'
                   COMMENT 'Data source: yahoo, screener, bse',
  `created_at`     TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sfh_stock_date`  (`stock_id`, `snapshot_date`),
  KEY `idx_sfh_symbol`            (`symbol`),
  KEY `idx_sfh_date`              (`snapshot_date`),
  KEY `idx_sfh_pe`                (`pe_ratio`),
  CONSTRAINT `fk_sfh_stock` FOREIGN KEY (`stock_id`)
      REFERENCES `stock_master` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Historical snapshots of stock fundamental data';
