-- ============================================================
-- Table: stock_fundamentals_cache
-- Domain: 003_stocks  |  Sequence: 008
-- Source: migrations/t432_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS stock_fundamentals_cache (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    stock_symbol VARCHAR(20) NOT NULL,
    isin VARCHAR(20),
    pe_ratio DECIMAL(10,4) DEFAULT NULL,
    pb_ratio DECIMAL(10,4) DEFAULT NULL,
    eps DECIMAL(15,4) DEFAULT NULL,
    market_cap DECIMAL(25,4) DEFAULT NULL,
    sector VARCHAR(100),
    industry VARCHAR(100),
    data_date DATE NOT NULL,
    source VARCHAR(50) DEFAULT 'NSE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_symbol_date (stock_symbol, data_date),
    INDEX idx_symbol (stock_symbol),
    INDEX idx_date (data_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
