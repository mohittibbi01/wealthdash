-- ============================================================
-- Table: stock_transactions
-- Domain: 003_stocks  |  Sequence: 003
-- Source: 01_schema_complete.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: migrations/t39_migration.sql has denormalised version (user_id+symbol text, no FK, REST-style). Winner: base schema (proper FK to stock_master/portfolios)

CREATE TABLE IF NOT EXISTS `stock_transactions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `stock_id` int(10) UNSIGNED NOT NULL,
  `txn_type` enum('buy','sell','bonus','split','rights') NOT NULL DEFAULT 'buy',
  `txn_date` date NOT NULL,
  `quantity` decimal(14,4) NOT NULL,
  `price` decimal(12,4) NOT NULL,
  `brokerage` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_st_portfolio` (`portfolio_id`),
  KEY `idx_st_stock` (`stock_id`),
  KEY `idx_st_date` (`txn_date`),
  CONSTRAINT `fk_st_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_st_stock` FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
