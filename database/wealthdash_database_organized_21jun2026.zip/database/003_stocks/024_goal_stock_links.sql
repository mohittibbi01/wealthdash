-- ============================================================
-- Table: goal_stock_links
-- Domain: 003_stocks  |  Sequence: 024
-- Source: migrations/025_goal_buckets.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `goal_stock_links` (
    `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `goal_id`      INT UNSIGNED NOT NULL,
    `portfolio_id` INT UNSIGNED NOT NULL,
    `stock_id`     INT UNSIGNED NOT NULL,
    `allocation_pct` DECIMAL(5,2) DEFAULT 100.00,
    `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_goal_stock` (`goal_id`, `stock_id`, `portfolio_id`),
    CONSTRAINT `fk_goal_stock_goal` FOREIGN KEY (`goal_id`) REFERENCES `goals`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
