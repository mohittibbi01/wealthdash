-- ============================================================
-- Table: stock_dividends
-- Domain: 003_stocks  |  Sequence: 004
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_dividends` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `stock_id` int(10) UNSIGNED NOT NULL,
  `ex_date` date NOT NULL,
  `dividend_per_share` decimal(10,4) NOT NULL,
  `shares_held` decimal(14,4) DEFAULT NULL,
  `total_dividend` decimal(14,2) DEFAULT NULL,
  `tds_deducted` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sd_portfolio` (`portfolio_id`),
  KEY `idx_sd_stock` (`stock_id`),
  CONSTRAINT `fk_sd_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sd_stock` FOREIGN KEY (`stock_id`) REFERENCES `stock_master` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
