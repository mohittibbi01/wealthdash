-- ============================================================
-- Table: us_stock_master
-- Domain: 003_stocks  |  Sequence: 021
-- Source: migrations/t456_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `us_stock_master` (
    `id`                  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `symbol`              VARCHAR(20)  NOT NULL,
    `exchange`            ENUM('NYSE','NASDAQ','AMEX','OTC') NOT NULL DEFAULT 'NASDAQ',
    `company_name`        VARCHAR(200) DEFAULT NULL,
    `isin`                VARCHAR(20)  DEFAULT NULL,
    `sector`              VARCHAR(100) DEFAULT NULL,
    `industry`            VARCHAR(100) DEFAULT NULL,
    `country`             VARCHAR(50)  DEFAULT 'US',
    `currency`            VARCHAR(5)   NOT NULL DEFAULT 'USD',
    `latest_price_usd`    DECIMAL(14,4) DEFAULT 0,
    `latest_price_inr`    DECIMAL(14,4) DEFAULT 0,
    `pe_ratio`            DECIMAL(12,4) DEFAULT NULL,
    `pb_ratio`            DECIMAL(10,4) DEFAULT NULL,
    `eps_ttm`             DECIMAL(12,4) DEFAULT NULL,
    `market_cap_usd`      DECIMAL(22,4) DEFAULT NULL,
    `high_52_usd`         DECIMAL(14,4) DEFAULT NULL,
    `low_52_usd`          DECIMAL(14,4) DEFAULT NULL,
    `dividend_yield`      DECIMAL(8,4)  DEFAULT NULL,
    `beta`                DECIMAL(8,4)  DEFAULT NULL,
    `price_change_24h_pct`DECIMAL(8,4)  DEFAULT NULL,
    `price_updated_at`    DATETIME      DEFAULT NULL,
    `fundamentals_updated_at` DATETIME  DEFAULT NULL,
    `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_usm_symbol` (`symbol`, `exchange`),
    INDEX `idx_usm_symbol` (`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
