-- ============================================================
-- Table: stock_master
-- Domain: 003_stocks  |  Sequence: 001
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `stock_master` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `exchange` enum('NSE','BSE') NOT NULL DEFAULT 'NSE',
  `symbol` varchar(30) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `isin` varchar(20) DEFAULT NULL,
  `sector` varchar(100) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `current_price` decimal(12,4) DEFAULT NULL,
  `prev_close` decimal(12,4) DEFAULT NULL,
  `day_change_pct` decimal(8,4) DEFAULT NULL,
  `market_cap` decimal(20,2) DEFAULT NULL,
  `pe_ratio` decimal(10,4) DEFAULT NULL,
  `price_updated_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stock` (`exchange`, `symbol`),
  KEY `idx_stock_isin` (`isin`),
  KEY `idx_stock_sector` (`sector`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
