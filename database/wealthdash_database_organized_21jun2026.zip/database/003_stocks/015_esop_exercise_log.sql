-- ============================================================
-- Table: esop_exercise_log
-- Domain: 003_stocks  |  Sequence: 015
-- Source: migrations/t117_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `esop_exercise_log` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `grant_id`        INT UNSIGNED NOT NULL,
    `vesting_event_id`INT UNSIGNED DEFAULT NULL,
    `exercise_date`   DATE         NOT NULL,
    `units`           INT UNSIGNED NOT NULL,
    `exercise_price`  DECIMAL(12,4) NOT NULL,
    `fmv_on_exercise` DECIMAL(12,4) DEFAULT NULL,
    `perquisite_value`DECIMAL(14,4) DEFAULT NULL COMMENT '(fmv - exercise_price) * units',
    `broker_charges`  DECIMAL(10,2) DEFAULT 0,
    `tds_deducted`    DECIMAL(12,4) DEFAULT NULL,
    `sale_date`       DATE          DEFAULT NULL,
    `sale_price`      DECIMAL(12,4) DEFAULT NULL,
    `capital_gain`    DECIMAL(14,4) DEFAULT NULL,
    `gain_type`       ENUM('STCG','LTCG') DEFAULT NULL,
    `notes`           VARCHAR(255)  DEFAULT NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_esop_ex_grant`  (`grant_id`),
    INDEX `idx_esop_ex_date`   (`exercise_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
