-- ============================================================
-- Table: stock_sip_installments
-- Domain: 003_stocks  |  Sequence: 012
-- Source: migrations/t436_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS stock_sip_installments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sip_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    installment_date DATE NOT NULL,
    quantity DECIMAL(15,6) NOT NULL,
    price DECIMAL(15,4) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    status ENUM('PENDING','EXECUTED','FAILED','SKIPPED') DEFAULT 'PENDING',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sip_id) REFERENCES stock_sip(id) ON DELETE CASCADE,
    INDEX idx_sip_id (sip_id),
    INDEX idx_user_id (user_id),
    INDEX idx_date (installment_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
