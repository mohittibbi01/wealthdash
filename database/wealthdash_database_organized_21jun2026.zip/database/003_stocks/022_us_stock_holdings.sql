-- ============================================================
-- Table: us_stock_holdings
-- Domain: 003_stocks  |  Sequence: 022
-- Source: migrations/t456_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `us_stock_holdings` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `portfolio_id`    INT UNSIGNED NOT NULL,
    `stock_id`        INT UNSIGNED NOT NULL  COMMENT 'FK us_stock_master.id',
    `quantity`        DECIMAL(16,6) NOT NULL DEFAULT 0  COMMENT 'Fractional shares supported',
    `avg_buy_price_usd`DECIMAL(14,4) NOT NULL DEFAULT 0,
    `avg_buy_price_inr`DECIMAL(14,4) DEFAULT NULL       COMMENT 'INR equivalent at time of buy',
    `total_invested_usd`DECIMAL(18,4) DEFAULT 0,
    `total_invested_inr`DECIMAL(18,4) DEFAULT 0,
    `current_value_usd` DECIMAL(18,4) DEFAULT 0,
    `current_value_inr` DECIMAL(18,4) DEFAULT 0,
    `broker`           VARCHAR(50)  DEFAULT NULL         COMMENT 'Groww, Vested, INDmoney, etc.',
    `account_type`     ENUM('LRS','GIFT_CITY','DOMESTIC_BROKER','OTHER') DEFAULT 'LRS',
    `first_buy_date`   DATE DEFAULT NULL,
    `notes`            TEXT DEFAULT NULL,
    `created_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_ush_portfolio_stock` (`portfolio_id`, `stock_id`),
    INDEX `idx_ush_portfolio` (`portfolio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
