-- ============================================================
-- Table: bank_balance_history
-- Domain: 004_fd_rd_savings  |  Sequence: 002
-- Source: migrations/t43_migration.sql
-- ============================================================
-- CONFLICT RESOLVED: CONFLICT: 01_schema_complete.sql also defines this. Winner: t43 (source same as bank_accounts, consistent)

CREATE TABLE IF NOT EXISTS `bank_balance_history` (
    `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `account_id`  INT UNSIGNED  NOT NULL,
    `snap_date`   DATE          NOT NULL,
    `balance`     DECIMAL(15,2) NOT NULL,
    `created_at`  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_bbh` (`account_id`, `snap_date`),
    KEY `idx_bbh_account` (`account_id`),
    CONSTRAINT `fk_bbh_account` FOREIGN KEY (`account_id`) REFERENCES `bank_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
