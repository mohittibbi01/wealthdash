-- ============================================================
-- Table: fd_interest_log
-- Domain: 004_fd_rd_savings  |  Sequence: 006
-- Source: 41_pending_tasks.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fd_interest_log (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    fd_id        INT UNSIGNED NOT NULL,
    credit_date  DATE NOT NULL,
    interest_earned DECIMAL(12,2) NOT NULL,
    tds_deducted DECIMAL(10,2) DEFAULT 0,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_date (credit_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
