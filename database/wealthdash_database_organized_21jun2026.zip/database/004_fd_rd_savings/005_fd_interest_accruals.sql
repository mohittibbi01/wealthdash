-- ============================================================
-- Table: fd_interest_accruals
-- Domain: 004_fd_rd_savings  |  Sequence: 005
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `fd_interest_accruals` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fd_id` int(10) UNSIGNED NOT NULL,
  `accrual_date` date NOT NULL,
  `interest_amount` decimal(14,2) NOT NULL,
  `cumulative_interest` decimal(14,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fdia_fd` (`fd_id`),
  CONSTRAINT `fk_fdia_fd` FOREIGN KEY (`fd_id`) REFERENCES `fd_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
