-- ============================================================
-- Table: fd_rate_history
-- Domain: 004_fd_rd_savings  |  Sequence: 009
-- Source: migrations/42_fd_rate_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fd_rate_history (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    bank_name       VARCHAR(120)  NOT NULL,
    tenure_months   SMALLINT UNSIGNED NOT NULL,
    rate_regular    DECIMAL(5,2) NOT NULL,
    rate_senior     DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    effective_date  DATE         NOT NULL,
    recorded_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_bank_tenure (bank_name, tenure_months),
    INDEX idx_date        (effective_date),
    INDEX idx_recorded    (recorded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='t421 — FD Rate Tracker history';
