-- ============================================================
-- Table: fd_market_rates
-- Domain: 004_fd_rd_savings  |  Sequence: 008
-- Source: 41_pending_tasks.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fd_market_rates (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    bank_name      VARCHAR(80)  NOT NULL,
    tenure_label   VARCHAR(30)  NOT NULL,
    rate_general   DECIMAL(5,2) NOT NULL,
    rate_senior    DECIMAL(5,2) NOT NULL,
    effective_date DATE DEFAULT (CURDATE()),
    source_url     VARCHAR(300) DEFAULT NULL,
    updated_at     DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
