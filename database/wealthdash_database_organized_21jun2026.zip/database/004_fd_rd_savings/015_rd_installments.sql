-- ============================================================
-- Table: rd_installments
-- Domain: 004_fd_rd_savings  |  Sequence: 015
-- Source: migrations/t45_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `rd_installments` (
  `id`             int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `rd_account_id`  int(10) UNSIGNED NOT NULL,
  `due_date`       date             NOT NULL,
  `paid_date`      date             DEFAULT NULL,
  `amount`         decimal(12,2)    NOT NULL,
  `status`         enum('paid','pending','missed') NOT NULL DEFAULT 'pending',
  `created_at`     datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rd_due` (`rd_account_id`,`due_date`),
  KEY `idx_rdi_account` (`rd_account_id`),
  CONSTRAINT `fk_rdi_account` FOREIGN KEY (`rd_account_id`) REFERENCES `rd_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
