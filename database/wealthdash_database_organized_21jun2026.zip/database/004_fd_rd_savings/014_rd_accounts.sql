-- ============================================================
-- Table: rd_accounts
-- Domain: 004_fd_rd_savings  |  Sequence: 014
-- Source: migrations/t45_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `rd_accounts` (
  `id`                  int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id`        int(10) UNSIGNED NOT NULL,
  `bank_name`           varchar(100)     NOT NULL,
  `account_number`      varchar(30)      DEFAULT NULL,
  `monthly_installment` decimal(12,2)    NOT NULL,
  `interest_rate`       decimal(5,2)     NOT NULL,
  `tenure_months`       smallint         NOT NULL,
  `start_date`          date             NOT NULL,
  `maturity_date`       date             NOT NULL,
  `maturity_amount`     decimal(16,2)    DEFAULT NULL,
  `status`              enum('active','matured','closed') NOT NULL DEFAULT 'active',
  `nominee`             varchar(100)     DEFAULT NULL,
  `notes`               varchar(255)     DEFAULT NULL,
  `created_at`          datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at`          datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_rd_portfolio` (`portfolio_id`),
  KEY `idx_rd_status`    (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
