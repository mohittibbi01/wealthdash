-- ============================================================
-- Table: fd_maturity_alerts
-- Domain: 004_fd_rd_savings  |  Sequence: 007
-- Source: 41_pending_tasks.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fd_maturity_alerts (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    fd_id        INT UNSIGNED NOT NULL,
    alert_days   TINYINT UNSIGNED NOT NULL,
    is_sent      TINYINT(1) NOT NULL DEFAULT 0,
    sent_at      DATETIME DEFAULT NULL,
    is_dismissed TINYINT(1) NOT NULL DEFAULT 0,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_fd_days (fd_id, alert_days),
    INDEX idx_user (user_id),
    INDEX idx_sent (is_sent)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
