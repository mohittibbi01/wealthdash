-- ============================================================
-- Table: savings_accounts
-- Domain: 004_fd_rd_savings  |  Sequence: 011
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `savings_accounts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_number` varchar(30) DEFAULT NULL,
  `account_type` varchar(20) NOT NULL DEFAULT 'savings',
  `current_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance_date` date DEFAULT NULL,
  `interest_rate` decimal(5,3) NOT NULL DEFAULT 4.000,
  `annual_interest_earned` decimal(12,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sa_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_sa_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
