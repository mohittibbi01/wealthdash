-- ============================================================
-- Table: savings_interest
-- Domain: 004_fd_rd_savings  |  Sequence: 012
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `savings_interest` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `account_id` int(10) UNSIGNED NOT NULL,
  `interest_date` date NOT NULL,
  `interest_amount` decimal(12,2) NOT NULL,
  `balance_after` decimal(14,2) DEFAULT NULL,
  `interest_fy` varchar(10) NOT NULL COMMENT 'e.g. 2024-25',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_si_acct_date` (`account_id`, `interest_date`),
  CONSTRAINT `fk_si_account` FOREIGN KEY (`account_id`) REFERENCES `savings_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
