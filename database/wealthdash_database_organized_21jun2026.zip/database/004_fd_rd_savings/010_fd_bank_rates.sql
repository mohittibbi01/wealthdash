-- ============================================================
-- Table: fd_bank_rates
-- Domain: 004_fd_rd_savings  |  Sequence: 010
-- Source: migrations/42_fd_rate_tracker.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS fd_bank_rates (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    bank_name       VARCHAR(120)  NOT NULL,
    bank_type       ENUM('public','private_large','private','small_finance','government','cooperative')
                    NOT NULL DEFAULT 'private',
    tenure_months   SMALLINT UNSIGNED NOT NULL,
    rate_regular    DECIMAL(5,2) NOT NULL,
    rate_senior     DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    min_amount      INT UNSIGNED NOT NULL DEFAULT 1000,
    is_special      TINYINT(1)   NOT NULL DEFAULT 0,
    is_active       TINYINT(1)   NOT NULL DEFAULT 1,
    effective_date  DATE         NOT NULL,
    source_url      VARCHAR(300) DEFAULT NULL,
    notes           VARCHAR(200) DEFAULT NULL,
    updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_bank_tenure (bank_name, tenure_months),
    INDEX idx_tenure      (tenure_months),
    INDEX idx_bank_type   (bank_type),
    INDEX idx_rate_reg    (rate_regular DESC),
    INDEX idx_effective   (effective_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='t421 — FD Rate Tracker: market rates per bank per tenure';
