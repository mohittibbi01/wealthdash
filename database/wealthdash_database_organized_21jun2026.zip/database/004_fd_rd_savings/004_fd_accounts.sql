-- ============================================================
-- Table: fd_accounts
-- Domain: 004_fd_rd_savings  |  Sequence: 004
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `fd_accounts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(10) UNSIGNED NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `fd_type` enum('cumulative','non_cumulative','tax_saver','flexi','senior_citizen') NOT NULL DEFAULT 'cumulative',
  `principal_amount` decimal(14,2) NOT NULL,
  `interest_rate` decimal(6,3) NOT NULL,
  `compounding` enum('monthly','quarterly','half_yearly','yearly','at_maturity') NOT NULL DEFAULT 'quarterly',
  `start_date` date NOT NULL,
  `maturity_date` date NOT NULL,
  `maturity_amount` decimal(14,2) DEFAULT NULL,
  `interest_earned` decimal(14,2) NOT NULL DEFAULT 0.00,
  `status` enum('active','matured','broken','renewed') NOT NULL DEFAULT 'active',
  `auto_renew` tinyint(1) NOT NULL DEFAULT 0,
  `folio_number` varchar(50) DEFAULT NULL,
  `nominee` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fd_portfolio` (`portfolio_id`),
  KEY `idx_fd_maturity` (`maturity_date`),
  CONSTRAINT `fk_fd_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
