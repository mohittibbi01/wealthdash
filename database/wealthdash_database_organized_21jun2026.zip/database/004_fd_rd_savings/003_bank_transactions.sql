-- ============================================================
-- Table: bank_transactions
-- Domain: 004_fd_rd_savings  |  Sequence: 003
-- Source: migrations/t43_migration.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `bank_transactions` (
    `id`             INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `account_id`     INT UNSIGNED     NOT NULL,
    `user_id`        INT UNSIGNED     NOT NULL,
    `txn_date`       DATE             NOT NULL,
    `value_date`     DATE             DEFAULT NULL,
    `type`           ENUM('credit','debit') NOT NULL,
    `category`       VARCHAR(50)      DEFAULT NULL
        COMMENT 'salary, rent, emi, utilities, transfer, fd_maturity, interest, other',
    `amount`         DECIMAL(15,2)    NOT NULL,
    `balance_after`  DECIMAL(15,2)    DEFAULT NULL,
    `description`    VARCHAR(255)     DEFAULT NULL,
    `ref_number`     VARCHAR(60)      DEFAULT NULL,
    `created_at`     TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bt_account`  (`account_id`),
    KEY `idx_bt_user`     (`user_id`),
    KEY `idx_bt_date`     (`txn_date`),
    CONSTRAINT `fk_bt_account` FOREIGN KEY (`account_id`) REFERENCES `bank_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
