-- ============================================================
-- Table: savings_interest_log
-- Domain: 004_fd_rd_savings  |  Sequence: 013
-- Source: 01_schema_complete.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `savings_interest_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `account_id` int(10) UNSIGNED NOT NULL,
  `log_date` date NOT NULL,
  `balance` decimal(14,2) NOT NULL,
  `interest_earned` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sil_account` (`account_id`),
  CONSTRAINT `fk_sil_sa` FOREIGN KEY (`account_id`) REFERENCES `savings_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
