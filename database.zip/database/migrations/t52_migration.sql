-- ============================================================
-- WealthDash — t52: Global Settings Control
-- Migration: database/migrations/t52_migration.sql
-- Worker: ID-M
-- ============================================================

-- Extend app_settings with group + type columns
ALTER TABLE `app_settings`
    ADD COLUMN IF NOT EXISTS `setting_group` VARCHAR(50) NOT NULL DEFAULT 'general' AFTER `setting_key`,
    ADD COLUMN IF NOT EXISTS `setting_type`  ENUM('string','boolean','integer','json','textarea') NOT NULL DEFAULT 'string' AFTER `setting_group`,
    ADD COLUMN IF NOT EXISTS `label`         VARCHAR(120) DEFAULT NULL AFTER `setting_type`,
    ADD COLUMN IF NOT EXISTS `description`   VARCHAR(255) DEFAULT NULL AFTER `label`,
    ADD COLUMN IF NOT EXISTS `is_public`     TINYINT(1) NOT NULL DEFAULT 0 AFTER `description`,
    ADD COLUMN IF NOT EXISTS `is_locked`     TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Cannot be edited via UI' AFTER `is_public`;

-- Insert default settings (ON DUPLICATE KEY = no-op if already exists)
INSERT INTO `app_settings` (`setting_key`, `setting_group`, `setting_type`, `label`, `description`, `setting_val`, `is_public`)
VALUES
    ('app_name',                'general',      'string',  'Application Name',          'Site title shown in browser and emails',  'WealthDash', 1),
    ('allow_registration',      'auth',         'boolean', 'Allow Public Registration', 'Users can register without invite',       'false', 0),
    ('require_email_verify',    'auth',         'boolean', 'Require Email Verification','New users must verify email',             'false', 0),
    ('session_lifetime_hours',  'auth',         'integer', 'Session Lifetime (hours)',  'Seconds before session expires',          '24',    0),
    ('login_max_attempts',      'auth',         'integer', 'Max Login Attempts',        'Lockout after N failed attempts',         '5',     0),
    ('login_lockout_minutes',   'auth',         'integer', 'Lockout Duration (min)',    'Minutes locked after max attempts',       '15',    0),
    ('nav_auto_fetch',          'market',       'boolean', 'Auto Fetch NAV',            'Automatically fetch NAV daily via cron',  'true',  0),
    ('nav_fetch_time',          'market',       'string',  'NAV Fetch Time',            'Cron time e.g. 21:30',                    '21:30', 0),
    ('stock_price_source',      'market',       'string',  'Stock Price Source',        'nse / yahoo / manual',                    'nse',   0),
    ('maintenance_mode',        'general',      'boolean', 'Maintenance Mode',          'Show maintenance page to non-admins',     'false', 0),
    ('maintenance_message',     'general',      'textarea','Maintenance Message',       'Message shown during maintenance',        'We are upgrading. Back shortly.', 1),
    ('date_format',             'display',      'string',  'Date Display Format',       'PHP date format e.g. j M Y',              'j M Y', 0),
    ('currency_symbol',         'display',      'string',  'Currency Symbol',           'e.g. ₹',                                  '₹',     1),
    ('default_theme',           'display',      'string',  'Default Theme',             'dark / light / blue / green',             'dark',  0),
    ('items_per_page',          'display',      'integer', 'Items Per Page',            'Default pagination size',                 '25',    0),
    ('cache_ttl_nav',           'performance',  'integer', 'NAV Cache TTL (sec)',       'Seconds to cache NAV data',               '300',   0),
    ('cache_ttl_portfolio',     'performance',  'integer', 'Portfolio Cache TTL (sec)','Seconds to cache portfolio data',         '300',   0),
    ('enable_audit_log',        'security',     'boolean', 'Enable Audit Log',         'Log all admin actions',                   'true',  0),
    ('max_upload_mb',           'security',     'integer', 'Max Upload (MB)',           'Max file upload size',                    '10',    0),
    ('smtp_host',               'email',        'string',  'SMTP Host',                'Mail server hostname',                    '',      0),
    ('smtp_port',               'email',        'integer', 'SMTP Port',                'Mail server port',                        '587',   0),
    ('smtp_from',               'email',        'string',  'From Email',               'Sender address for system emails',        '',      0),
    ('smtp_from_name',          'email',        'string',  'From Name',                'Sender name for system emails',           'WealthDash', 0)
ON DUPLICATE KEY UPDATE `label` = VALUES(`label`), `setting_group` = VALUES(`setting_group`),
                        `setting_type` = VALUES(`setting_type`), `description` = VALUES(`description`);
