-- ============================================================
-- WealthDash — t50: Multi-user Management (FIXED)
-- Migration: database/migrations/t50_migration.sql
-- Worker: ID-M
-- FIX: Removed avatar_url reference (column does not exist)
-- ============================================================

-- Add missing columns to users table (safe — IF NOT EXISTS)
ALTER TABLE `users`
    ADD COLUMN IF NOT EXISTS `status`        ENUM('active','suspended','pending') NOT NULL DEFAULT 'active' AFTER `role`,
    ADD COLUMN IF NOT EXISTS `notes`         TEXT DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS `invited_by`    INT UNSIGNED DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS `invited_at`    DATETIME DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS `login_count`   INT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS `storage_quota` BIGINT UNSIGNED DEFAULT NULL COMMENT 'bytes, NULL = unlimited';

-- User invitations table
CREATE TABLE IF NOT EXISTS `user_invitations` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `email`       VARCHAR(150) NOT NULL,
    `token`       VARCHAR(64)  NOT NULL,
    `role`        ENUM('user','admin') NOT NULL DEFAULT 'user',
    `invited_by`  INT UNSIGNED NOT NULL,
    `accepted_at` DATETIME DEFAULT NULL,
    `expires_at`  DATETIME NOT NULL,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_inv_token` (`token`),
    KEY `idx_inv_email` (`email`),
    KEY `idx_inv_invited_by` (`invited_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User activity log
CREATE TABLE IF NOT EXISTS `user_activity_log` (
    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`    INT UNSIGNED NOT NULL,
    `action`     VARCHAR(80) NOT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` VARCHAR(300) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_ual_user` (`user_id`),
    KEY `idx_ual_created` (`created_at`),
    CONSTRAINT `fk_ual_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;