<?php
define('WEALTHDASH', true);
require_once dirname(__DIR__) . '/config/config.php';
require_once APP_ROOT . '/includes/auth_check.php';
if (!is_logged_in() || !is_admin()) { header('Location: /wealthdash/login.php'); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>NAV History Downloader — WealthDash</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
:root{
  --bg:#f0f2f5;--surface:#fff;--surface2:#f7f8fa;--border:#e2e5ea;--border2:#d0d5dd;
  --text:#1a1d23;--muted:#6b7280;--muted2:#9ca3af;
  --accent:#2563eb;--accent-light:#eff6ff;--accent-dark:#1d4ed8;
  --green:#16a34a;--green-light:#f0fdf4;
  --orange:#d97706;--orange-light:#fffbeb;
  --red:#dc2626;--red-light:#fef2f2;
  --mono:'JetBrains Mono',monospace;--sans:'Inter',sans-serif;
  --radius:10px;--shadow:0 1px 3px rgba(0,0,0,.08),0 1px 2px rgba(0,0,0,.04);
  --shadow-md:0 4px 12px rgba(0,0,0,.08);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:var(--sans);font-size:13px;line-height:1.5;min-height:100vh}

/* Header */
.header{background:var(--surface);border-bottom:1px solid var(--border);padding:12px 24px;display:flex;align-items:center;gap:10px;box-shadow:var(--shadow)}
.header-logo{width:28px;height:28px;background:var(--accent);border-radius:7px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px}
.header h1{font-size:15px;font-weight:600;color:var(--text)}
.header-right{margin-left:auto;display:flex;align-items:center;gap:12px}
.status-badge{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--muted);background:var(--surface2);padding:4px 10px;border-radius:20px;border:1px solid var(--border)}
.sdot{width:7px;height:7px;border-radius:50%;background:var(--muted2);transition:all .3s}
.sdot.run{background:var(--green);box-shadow:0 0 0 3px rgba(22,163,74,.15);animation:pulse 1.5s infinite}
.sdot.err{background:var(--red)}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
.clock{font-family:var(--mono);font-size:12px;color:var(--muted);background:var(--surface2);padding:4px 10px;border-radius:20px;border:1px solid var(--border)}

/* Stat cards */
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:0;background:var(--surface);border-bottom:1px solid var(--border)}
.card{padding:14px 20px;border-right:1px solid var(--border)}
.card:last-child{border-right:none}
.card-label{font-size:10px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:6px}
.card-val{font-family:var(--mono);font-size:22px;font-weight:500;line-height:1}
.card-sub{font-size:11px;color:var(--muted2);margin-top:4px}
.c-blue .card-val{color:var(--accent)}.c-orange .card-val{color:var(--orange)}.c-red .card-val{color:var(--red)}.c-green .card-val{color:var(--green)}

/* Layout */
.layout{display:grid;grid-template-columns:1fr 300px;height:calc(100vh - 105px)}
.main{padding:16px;overflow-y:auto;display:flex;flex-direction:column;gap:14px}
.sidebar{border-left:1px solid var(--border);background:var(--surface);display:flex;flex-direction:column;overflow:hidden}

/* Panels */
.panel{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;box-shadow:var(--shadow)}
.panel-head{padding:10px 16px;border-bottom:1px solid var(--border);font-size:12px;font-weight:600;display:flex;align-items:center;gap:6px;background:var(--surface2)}
.panel-body{padding:14px 16px}

/* Progress */
.prog-bar-bg{background:var(--bg);border-radius:4px;height:7px;overflow:hidden;border:1px solid var(--border);margin:8px 0 14px}
.prog-bar-fill{height:100%;background:linear-gradient(90deg,var(--accent-dark),var(--accent));border-radius:4px;transition:width .5s ease;min-width:3px}
.prog-meta{display:flex;justify-content:space-between;font-size:11px;color:var(--muted)}

/* Breakdown — compact horizontal */
.breakdown{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:10px}
.bk-item{background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:10px 12px;text-align:center}
.bk-dot{width:8px;height:8px;border-radius:50%;margin:0 auto 6px}
.bk-val{font-family:var(--mono);font-size:18px;font-weight:500}
.bk-label{font-size:10px;color:var(--muted);margin-top:2px;text-transform:uppercase;letter-spacing:.06em}
.bk-downloaded .bk-val{color:var(--green)}.bk-progress .bk-val{color:var(--accent)}.bk-pending .bk-val{color:var(--muted)}.bk-errors .bk-val{color:var(--red)}

/* Fund table */
.tab-bar{display:flex;padding:0 16px;border-bottom:1px solid var(--border);background:var(--surface2)}
.tab{padding:8px 12px;font-size:11px;font-weight:600;color:var(--muted);cursor:pointer;border-bottom:2px solid transparent;transition:all .15s;display:flex;align-items:center;gap:4px}
.tab.active{color:var(--accent);border-color:var(--accent)}.tab:hover:not(.active){color:var(--text)}
.tbadge{background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:1px 6px;font-size:10px}
.tab.active .tbadge{background:var(--accent-light);border-color:var(--accent);color:var(--accent)}
.search-row{padding:8px 12px;border-bottom:1px solid var(--border);background:var(--surface)}
.search-in{width:100%;background:var(--surface2);border:1px solid var(--border2);border-radius:6px;padding:7px 10px 7px 30px;font-size:12px;outline:none;color:var(--text);transition:border-color .2s;font-family:var(--sans)}
.search-in:focus{border-color:var(--accent);background:var(--surface)}
.search-in::placeholder{color:var(--muted2)}
.search-wrap{position:relative}
.s-ico{position:absolute;left:9px;top:50%;transform:translateY(-50%);color:var(--muted2);font-size:13px}
.tbl-scroll{overflow-y:auto;flex:1;max-height:260px}
.ftbl{width:100%;border-collapse:collapse}
.ftbl th{background:var(--surface2);padding:7px 12px;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);text-align:left;border-bottom:1px solid var(--border);position:sticky;top:0}
.ftbl td{padding:7px 12px;font-size:11px;border-bottom:1px solid var(--border);vertical-align:middle}
.ftbl tr:hover td{background:var(--accent-light)}
.fcode{font-family:var(--mono);font-size:10px;color:var(--muted2)}
.spill{display:inline-flex;align-items:center;gap:3px;padding:2px 7px;border-radius:10px;font-size:10px;font-weight:600}
.sp-pend{background:#f3f4f6;color:var(--muted)}.sp-work{background:var(--accent-light);color:var(--accent)}.sp-done{background:var(--green-light);color:var(--green)}.sp-err{background:var(--red-light);color:var(--red)}

/* Sidebar sections */
.sb-timers{padding:14px 16px;border-bottom:1px solid var(--border)}
.timers-row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.tbox{background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:10px;text-align:center}
.tval{font-family:var(--mono);font-size:17px;font-weight:500;color:var(--text)}
.tlbl{font-size:9px;color:var(--muted2);text-transform:uppercase;letter-spacing:.1em;margin-top:3px}
.today{margin-top:8px;font-size:11px;color:var(--muted2);text-align:center;font-family:var(--mono)}

.sb-info{padding:10px 16px;border-bottom:1px solid var(--border);background:var(--surface2)}
.irow{display:flex;justify-content:space-between;align-items:center;padding:3px 0;font-size:11px}
.ilbl{color:var(--muted)}.ival{font-family:var(--mono);color:var(--text)}.ival.hi{color:var(--accent)}

.sb-ctrl{padding:14px 16px;border-bottom:1px solid var(--border)}
.ctrl-title{font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted2);margin-bottom:10px}
.prl-row{display:flex;align-items:center;gap:8px;background:var(--surface2);border:1px solid var(--border);border-radius:7px;padding:7px 12px;margin-bottom:10px}
.prl-lbl{font-size:11px;color:var(--muted);flex:1}
.prl-val{font-family:var(--mono);font-size:14px;font-weight:600;color:var(--accent);width:26px;text-align:center}
.prl-btn{background:var(--surface);border:1px solid var(--border2);border-radius:4px;width:24px;height:24px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;color:var(--text);transition:all .15s}
.prl-btn:hover{background:var(--border);border-color:var(--accent)}

/* Buttons */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:9px 14px;border-radius:7px;border:none;font-family:var(--sans);font-size:12px;font-weight:600;cursor:pointer;transition:all .15s;width:100%}
.btn:active{transform:scale(.97)}
.btn-primary{background:var(--accent);color:#fff}.btn-primary:hover{background:var(--accent-dark)}
.btn-primary:disabled{background:#bfdbfe;color:#93c5fd;cursor:not-allowed;transform:none}
.btn-ghost{background:transparent;color:var(--text);border:1px solid var(--border2)}.btn-ghost:hover{border-color:var(--accent);color:var(--accent);background:var(--accent-light)}
.btn-warn{background:transparent;color:var(--orange);border:1px solid #fcd34d}.btn-warn:hover{background:var(--orange-light)}
.btn-danger{background:transparent;color:var(--red);border:1px solid #fca5a5}.btn-danger:hover{background:var(--red-light)}
.btn-sm{padding:7px 12px;font-size:11px}
.brow{display:flex;flex-direction:column;gap:7px}
.brow2{display:flex;gap:7px}

/* Log */
.sb-log{flex:1;display:flex;flex-direction:column;min-height:0}
.log-head{padding:8px 16px;border-bottom:1px solid var(--border);font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted2);display:flex;align-items:center;justify-content:space-between;background:var(--surface2)}
.log-clr{cursor:pointer;font-size:10px;color:var(--muted2)}.log-clr:hover{color:var(--red)}
.log-feed{flex:1;overflow-y:auto;padding:6px 0;background:var(--surface)}
.log-item{padding:3px 16px;font-family:var(--mono);font-size:10px;color:var(--muted);line-height:1.6;border-left:2px solid transparent}
.log-item.ok{color:var(--green);border-color:var(--green)}.log-item.er{color:var(--red);border-color:var(--red)}.log-item.inf{color:var(--accent);border-color:var(--accent)}.log-item.wn{color:var(--orange)}

/* Modal */
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;z-index:1000;opacity:0;pointer-events:none;transition:opacity .2s}
.overlay.open{opacity:1;pointer-events:all}
.modal{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px;max-width:360px;width:90%;box-shadow:var(--shadow-md);transform:translateY(8px);transition:transform .2s}
.overlay.open .modal{transform:none}
.modal h3{font-size:15px;font-weight:600;margin-bottom:8px}
.modal p{font-size:12px;color:var(--muted);line-height:1.6;margin-bottom:18px}
.mbtns{display:flex;gap:8px;justify-content:flex-end}

/* Toast */
.toast-c{position:fixed;bottom:20px;right:20px;z-index:2000;display:flex;flex-direction:column;gap:7px}
.toast{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:10px 14px;font-size:12px;max-width:300px;display:flex;align-items:center;gap:8px;animation:slideUp .2s ease;box-shadow:var(--shadow-md)}
@keyframes slideUp{from{transform:translateY(16px);opacity:0}to{transform:none;opacity:1}}
.toast.tok{border-color:#bbf7d0}.toast.ter{border-color:#fecaca}
</style>
</head>
<body>

<!-- Header -->
<div class="header">
  <div class="header-logo">📡</div>
  <h1>NAV History Downloader</h1>
  <div class="header-right">
    <div class="status-badge"><span class="sdot" id="sdot"></span><span id="stxt" style="font-size:11px">Idle</span></div>
    <div class="clock" id="clk">--:--:--</div>
  </div>
</div>

<!-- Cards -->
<div class="cards">
  <div class="card c-blue">
    <div class="card-label">📊 Total Funds</div>
    <div class="card-val" id="cTotal">—</div>
    <div class="card-sub" id="cNav">— NAV records</div>
  </div>
  <div class="card c-orange">
    <div class="card-label">⏳ Needs Update</div>
    <div class="card-val" id="cNeeds">—</div>
    <div class="card-sub">Funds with missing NAV</div>
  </div>
  <div class="card c-red">
    <div class="card-label">⚠ Errors</div>
    <div class="card-val" id="cErr">—</div>
    <div class="card-sub">Click retry to fix</div>
  </div>
  <div class="card c-green">
    <div class="card-label">✅ Downloaded</div>
    <div class="card-val" id="cDone">—</div>
    <div class="card-sub" id="cLatest">Latest: —</div>
  </div>
</div>

<!-- Layout -->
<div class="layout">
  <!-- Main -->
  <div class="main">

    <!-- Progress panel -->
    <div class="panel">
      <div class="panel-head">
        📈 Overall Progress
        <span style="margin-left:auto;font-family:var(--mono);font-size:13px;color:var(--accent);font-weight:600" id="pct">0%</span>
      </div>
      <div class="panel-body" style="padding-bottom:12px">
        <div class="prog-meta"><span id="pLabel">No active download</span><span id="pDates" style="font-family:var(--mono);font-size:10px">Oldest: — &nbsp; Latest: —</span></div>
        <div class="prog-bar-bg"><div class="prog-bar-fill" id="pBar" style="width:0%"></div></div>
        <!-- Compact breakdown cards -->
        <div class="breakdown">
          <div class="bk-item bk-downloaded">
            <div class="bk-dot" style="background:var(--green)"></div>
            <div class="bk-val" id="bDone">0</div>
            <div class="bk-label">Downloaded</div>
          </div>
          <div class="bk-item bk-progress">
            <div class="bk-dot" style="background:var(--accent)"></div>
            <div class="bk-val" id="bProg">0</div>
            <div class="bk-label">In Progress</div>
          </div>
          <div class="bk-item bk-pending">
            <div class="bk-dot" style="background:var(--muted2)"></div>
            <div class="bk-val" id="bPend">0</div>
            <div class="bk-label">Pending</div>
          </div>
          <div class="bk-item bk-errors">
            <div class="bk-dot" style="background:var(--red)"></div>
            <div class="bk-val" id="bErr">0</div>
            <div class="bk-label">Errors</div>
          </div>
        </div>
        <div style="margin-top:10px;font-size:11px;color:var(--muted);display:flex;justify-content:space-between">
          <span>Effective Total: <span id="effTotal" style="font-family:var(--mono);color:var(--text);font-weight:500">—</span></span>
          <span id="estTime" style="font-family:var(--mono)"></span>
        </div>
      </div>
    </div>

    <!-- Fund Queue -->
    <div class="panel" style="flex:1;display:flex;flex-direction:column;min-height:280px">
      <div class="panel-head">📋 Fund Queue</div>
      <div class="tab-bar">
        <div class="tab active" id="tPend" onclick="stab('pending')">⏳ Pending <span class="tbadge" id="tbPend">0</span></div>
        <div class="tab" id="tWork" onclick="stab('working')">⚡ Working <span class="tbadge" id="tbWork">0</span></div>
        <div class="tab" id="tErrs" onclick="stab('errors')">⚠ Errors <span class="tbadge" id="tbErrs">0</span></div>
        <div class="tab" id="tDone" onclick="stab('done')">✅ Done <span class="tbadge" id="tbDone2">0</span></div>
      </div>
      <div class="search-row">
        <div class="search-wrap">
          <span class="s-ico">🔍</span>
          <input class="search-in" id="fsearch" placeholder="Search scheme name or code..." oninput="filterF()">
        </div>
      </div>
      <div class="tbl-scroll">
        <table class="ftbl">
          <thead><tr><th>Scheme Name</th><th>Code</th><th>From Date</th><th>Status</th><th>Records</th></tr></thead>
          <tbody id="ftbody"><tr><td colspan="5" style="text-align:center;color:var(--muted2);padding:32px;font-size:12px">No funds in queue. Click Start Download.</td></tr></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Timers -->
    <div class="sb-timers">
      <div class="timers-row">
        <div class="tbox"><div class="tval" id="tTotal">00:00:00</div><div class="tlbl">Total Elapsed</div></div>
        <div class="tbox"><div class="tval" id="tSess">00:00:00</div><div class="tlbl">This Session</div></div>
      </div>
      <div class="today" id="tDate"></div>
    </div>

    <!-- Info -->
    <div class="sb-info">
      <div class="irow"><span class="ilbl">NAV Date Range</span><span class="ival hi" id="iRange">—</span></div>
      <div class="irow"><span class="ilbl">Needs Update</span><span class="ival" id="iNeeds">—</span></div>
      <div class="irow"><span class="ilbl">Last Processed</span><span class="ival" id="iLast" style="font-size:10px">—</span></div>
    </div>

    <!-- Controls -->
    <div class="sb-ctrl">
      <div class="ctrl-title">Controls</div>
      <div class="prl-row">
        <span class="prl-lbl">⚡ Parallel Workers</span>
        <button class="prl-btn" onclick="chgP(-1)">−</button>
        <span class="prl-val" id="prlV">4</span>
        <button class="prl-btn" onclick="chgP(1)">+</button>
      </div>
      <div class="brow">
        <button class="btn btn-primary" id="btnStart" onclick="doStart()">▶ Start Download</button>
        <div class="brow2">
          <button class="btn btn-warn btn-sm" id="btnPause" onclick="doPause()" style="flex:1" disabled>⏸ Pause</button>
          <button class="btn btn-ghost btn-sm" onclick="doRetry()" style="flex:1">🔄 Retry Errors</button>
        </div>
        <div class="brow2">
          <button class="btn btn-ghost btn-sm" onclick="doExport()" style="flex:1">📥 Export CSV</button>
          <button class="btn btn-danger btn-sm" onclick="showMod()" style="flex:1">🗑 Clear Queue</button>
        </div>
      </div>
    </div>

    <!-- Log -->
    <div class="sb-log">
      <div class="log-head">Activity Log <span class="log-clr" onclick="clrLog()">Clear</span></div>
      <div class="log-feed" id="logFeed">
        <div class="log-item inf">System ready. Click Start Download to begin incremental update.</div>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="overlay" id="mod">
  <div class="modal">
    <h3>🗑 Clear Queue</h3>
    <p>Queue clear ho jayegi. Aapka existing NAV history data safe rahega. Kabhi bhi restart kar sakte hain.</p>
    <div class="mbtns">
      <button class="btn btn-ghost btn-sm" style="width:auto" onclick="closeMod()">Cancel</button>
      <button class="btn btn-danger btn-sm" style="width:auto" onclick="doReset()">Clear Queue</button>
    </div>
  </div>
</div>
<div class="toast-c" id="toastC"></div>

<script>
const API='nav_worker.php';
let S={running:false,paused:false,parallel:4,workers:0,sessStart:null,totalSec:0,tab:'pending',stats:{}};

// Clock
const fmtT=s=>[Math.floor(s/3600),Math.floor((s%3600)/60),s%60].map(n=>String(n).padStart(2,'0')).join(':');
setInterval(()=>{
  const n=new Date();
  g('clk').textContent=n.toLocaleTimeString('en-IN',{hour12:false});
  g('tDate').textContent=n.toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'short',year:'numeric'});
  const sessS=S.sessStart&&S.running&&!S.paused?(Date.now()-S.sessStart)/1000:0;
  g('tTotal').textContent=fmtT(S.totalSec+sessS);
  if(S.sessStart) g('tSess').textContent=fmtT((Date.now()-S.sessStart)/1000);
},1000);
(()=>{const n=new Date();g('clk').textContent=n.toLocaleTimeString('en-IN',{hour12:false});g('tDate').textContent=n.toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'short',year:'numeric'});})();

// API
async function api(action,extra={}){
  const r=await fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...extra})});
  return r.json();
}

// Poll
async function poll(){
  try{const d=await api('status');if(!d.ok)return;S.stats=d;renderUI(d);}catch(e){}
}

function renderUI(d){
  const q=d.queue??{};
  const tot=(q.pending||0)+(q.in_progress||0)+(q.downloaded||0)+(q.errors||0);
  const done=q.downloaded||0;
  const pct=tot>0?Math.round((done/tot)*100):0;

  g('cTotal').textContent=d.total_funds??'—';
  g('cNav').textContent=(d.nav_records||0).toLocaleString()+' NAV records';
  g('cNeeds').textContent=d.funds_needing_update??'—';
  g('cErr').textContent=q.errors??'—';
  g('cDone').textContent=q.downloaded??'—';
  g('cLatest').textContent='Latest: '+(d.date_range?.latest??'—');

  g('pct').textContent=pct+'%';
  g('pBar').style.width=pct+'%';
  g('pLabel').textContent=tot>0?`${done} of ${tot} funds processed`:'No active download session';
  g('pDates').textContent=`Oldest: ${d.date_range?.oldest??'—'}   Latest: ${d.date_range?.latest??'—'}`;

  g('bDone').textContent=q.downloaded||0;
  g('bProg').textContent=q.in_progress||0;
  g('bPend').textContent=q.pending||0;
  g('bErr').textContent=q.errors||0;
  g('effTotal').textContent=tot||'—';

  g('tbPend').textContent=q.pending||0;
  g('tbWork').textContent=q.in_progress||0;
  g('tbErrs').textContent=q.errors||0;
  g('tbDone2').textContent=q.downloaded||0;

  g('iRange').textContent=(d.date_range?.oldest??'—')+' → '+(d.date_range?.latest??'—');
  g('iNeeds').textContent=(d.funds_needing_update??0)+' funds';
  if(d.last_done) g('iLast').textContent=(d.last_done.scheme_code||'')+' @ '+(d.last_done.updated_at||'').substring(0,16);

  S.totalSec=d.total_elapsed_sec||0;
  S.paused=d.paused;
  const pb=g('btnPause');
  pb.textContent=S.paused?'▶ Resume':'⏸ Pause';
  pb.className=S.paused?'btn btn-primary btn-sm':'btn btn-warn btn-sm';
}

// Workers
async function procOne(){
  try{
    const d=await api('process_next');
    if(!d.ok)return 'err';
    if(d.status==='idle')return 'idle';
    if(d.status==='paused')return 'paused';
    if(d.status==='processed') log(`✓ ${d.name||d.scheme} — ${d.inserted} records`,'ok');
    else if(d.status==='error') log(`✗ ${d.scheme}: ${d.error}`,'er');
    return d.status;
  }catch(e){return 'err';}
}

async function wLoop(){
  while(S.running&&!S.paused){
    const r=await procOne();
    if(r==='idle'||r==='paused')break;
    await new Promise(r2=>setTimeout(r2,100));
  }
  S.workers--;
  if(S.workers===0&&S.running&&!S.paused){
    const q=S.stats?.queue??{};
    if((q.pending||0)===0){
      S.running=false;setRun(false);
      log('✓ Download complete!','ok');toast('Download complete!',true);
    }
  }
}

function setRun(r){
  const dot=g('sdot'),txt=g('stxt'),sb=g('btnStart'),pb=g('btnPause');
  if(r){dot.className='sdot run';txt.textContent='Running';sb.disabled=true;pb.disabled=false;}
  else{dot.className='sdot';txt.textContent=S.paused?'Paused':'Idle';sb.disabled=false;pb.disabled=!S.paused;}
}

// Handlers
async function doStart(){
  log('Starting — missing NAV funds queue ho rahe hain...','inf');
  const d=await api('start');
  if(!d.ok){toast(d.message,false);log('✗ '+d.message,'er');return;}
  if(!d.queued){toast(d.message,true);log('✓ '+d.message,'ok');return;}
  log(`Queued ${d.queued} funds. ${S.parallel} workers launch ho rahe hain...`,'inf');
  toast(`${d.queued} funds queued`,true);
  S.sessStart=Date.now();S.running=true;S.paused=false;
  g('tSess').textContent='00:00:00';setRun(true);
  S.workers=S.parallel;
  for(let i=0;i<S.parallel;i++) wLoop();
  await poll();
}

async function doPause(){
  const d=await api('pause');if(!d.ok)return;
  S.paused=d.paused;
  if(S.paused){S.running=false;setRun(false);log('⏸ Paused','wn');toast('Paused',true);}
  else{S.running=true;setRun(true);log('▶ Resumed','inf');toast('Resumed',true);S.workers=S.parallel;for(let i=0;i<S.parallel;i++)wLoop();}
}

async function doRetry(){
  const d=await api('retry_errors');toast(d.message,d.ok);log((d.ok?'🔄':'✗')+' '+d.message,d.ok?'inf':'er');
  if(d.ok&&d.retried>0&&!S.running){S.running=true;S.paused=false;setRun(true);S.workers=S.parallel;for(let i=0;i<S.parallel;i++)wLoop();}
  await poll();
}

function doExport(){window.open(API+'?action=export_csv','_blank');log('📥 CSV export started','inf');}

async function doReset(){
  closeMod();
  const d=await api('reset',{confirm:true});
  toast(d.message,d.ok);log((d.ok?'✓':'✗')+' '+d.message,d.ok?'ok':'er');
  S.running=false;setRun(false);await poll();
}

function chgP(delta){S.parallel=Math.max(1,Math.min(16,S.parallel+delta));g('prlV').textContent=S.parallel;}

// Tabs
function stab(tab){
  S.tab=tab;
  ['Pend','Work','Errs','Done'].forEach(t=>g('t'+t)?.classList.remove('active'));
  const m={pending:'Pend',working:'Work',errors:'Errs',done:'Done'};
  g('t'+m[tab])?.classList.add('active');
}

function filterF(){
  const q=g('fsearch').value.toLowerCase();
  document.querySelectorAll('#ftbody tr').forEach(tr=>{tr.style.display=tr.textContent.toLowerCase().includes(q)?'':'none';});
}

// Log
function log(msg,type=''){
  const f=g('logFeed');
  const t=new Date().toLocaleTimeString('en-IN',{hour12:false});
  const i=document.createElement('div');i.className='log-item '+type;i.textContent=`[${t}] ${msg}`;
  f.appendChild(i);f.scrollTop=f.scrollHeight;
  while(f.children.length>200)f.removeChild(f.firstChild);
}
function clrLog(){g('logFeed').innerHTML='';}

// Modal
function showMod(){g('mod').classList.add('open');}
function closeMod(){g('mod').classList.remove('open');}
g('mod').addEventListener('click',e=>{if(e.target===g('mod'))closeMod();});

// Toast
function toast(msg,ok=true){
  const t=document.createElement('div');t.className='toast '+(ok?'tok':'ter');
  t.innerHTML=(ok?'✅':'❌')+' <span>'+msg+'</span>';
  g('toastC').appendChild(t);setTimeout(()=>t.remove(),4000);
}

function g(id){return document.getElementById(id);}

// Init
poll();setInterval(poll,4000);
</script>
</body>
</html>
